#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Phase 2b: Join new node to existing RabbitMQ cluster

.DESCRIPTION
    Run this script on EACH new server after running 02-Prepare-NewNode.ps1

.PARAMETER ClusterNode
    Hostname of an existing cluster node to join (e.g., "OLD-SERVER-1")

.EXAMPLE
    .\03-Join-Cluster.ps1 -ClusterNode "OLD-SERVER-1"

.NOTES
    Part of RabbitMQ 2-node to 4-node migration
#>

param(
    [Parameter(Mandatory=$true, HelpMessage="Hostname of existing cluster node to join")]
    [string]$ClusterNode
)

# =============================================================================
# CONFIGURATION - Update this path if RabbitMQ is installed elsewhere
# =============================================================================
$RabbitMQCtl = "C:\Program Files\RabbitMQ Server\rabbitmq_server-3.12.1\sbin\rabbitmqctl.bat"

# Verify rabbitmqctl exists
if (-not (Test-Path $RabbitMQCtl)) {
    Write-Host "[ERROR] rabbitmqctl.bat not found at: $RabbitMQCtl" -ForegroundColor Red
    Write-Host "        Update the `$RabbitMQCtl variable with the correct path." -ForegroundColor Yellow
    exit 1
}
# =============================================================================

Write-Host "=== Joining RabbitMQ Cluster ===" -ForegroundColor Cyan
Write-Host "This node: $env:COMPUTERNAME"
Write-Host "Target cluster node: rabbit@$ClusterNode"

# Verify we can resolve the target node
Write-Host "`n[1/5] Verifying network connectivity to $ClusterNode..." -ForegroundColor Yellow
$Ping = Test-Connection -ComputerName $ClusterNode -Count 1 -Quiet
if ($Ping) {
    Write-Host "      [OK] Can reach $ClusterNode" -ForegroundColor Green
} else {
    Write-Host "      [WARNING] Cannot ping $ClusterNode - may still work if ICMP blocked" -ForegroundColor Yellow
}

# Test RabbitMQ ports
$Ports = @(4369, 25672)
foreach ($Port in $Ports) {
    $Test = Test-NetConnection -ComputerName $ClusterNode -Port $Port -WarningAction SilentlyContinue
    if ($Test.TcpTestSucceeded) {
        Write-Host "      [OK] Port $Port open" -ForegroundColor Green
    } else {
        Write-Host "      [ERROR] Port $Port closed - clustering will fail!" -ForegroundColor Red
        exit 1
    }
}

# Stop app (not service)
Write-Host "`n[2/5] Stopping RabbitMQ app..." -ForegroundColor Yellow
& $RabbitMQCtl stop_app
if ($LASTEXITCODE -ne 0) {
    Write-Host "      [ERROR] Failed to stop app" -ForegroundColor Red
    exit 1
}
Write-Host "      [OK] App stopped" -ForegroundColor Green

# Reset to clear any previous cluster membership
Write-Host "`n[3/5] Resetting node..." -ForegroundColor Yellow
& $RabbitMQCtl reset
if ($LASTEXITCODE -ne 0) {
    Write-Host "      [WARNING] Reset returned error (may be OK if already reset)" -ForegroundColor Yellow
}
Write-Host "      [OK] Node reset" -ForegroundColor Green

# Join cluster
Write-Host "`n[4/5] Joining cluster rabbit@$ClusterNode..." -ForegroundColor Yellow
& $RabbitMQCtl join_cluster "rabbit@$ClusterNode"
if ($LASTEXITCODE -ne 0) {
    Write-Host "      [ERROR] Failed to join cluster" -ForegroundColor Red
    Write-Host "`n      Troubleshooting:" -ForegroundColor Yellow
    Write-Host "      - Verify Erlang cookie matches: C:\ProgramData\RabbitMQ\.erlang.cookie"
    Write-Host "      - Check firewall: ports 4369, 25672 must be open"
    Write-Host "      - Verify target node is running: & $RabbitMQCtl cluster_status on $ClusterNode"
    Write-Host "      - Check hostnames resolve both ways (DNS or hosts file)"
    exit 1
}
Write-Host "      [OK] Joined cluster" -ForegroundColor Green

# Start app
Write-Host "`n[5/5] Starting RabbitMQ app..." -ForegroundColor Yellow
& $RabbitMQCtl start_app
if ($LASTEXITCODE -ne 0) {
    Write-Host "      [ERROR] Failed to start app" -ForegroundColor Red
    exit 1
}
Write-Host "      [OK] App started" -ForegroundColor Green

# Verify cluster membership
Write-Host "`n=== Cluster Status ===" -ForegroundColor Green
& $RabbitMQCtl cluster_status

Write-Host "`n--- NEXT STEPS ---" -ForegroundColor Cyan
Write-Host "1. Run this script on remaining new nodes"
Write-Host "2. Once all nodes joined, run 04-Update-HAPolicy.ps1 on any node"
