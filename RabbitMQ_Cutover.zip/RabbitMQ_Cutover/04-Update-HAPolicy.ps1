#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Phase 3: Update HA policy and monitor queue synchronization

.DESCRIPTION
    Run this script on ANY cluster node after all new nodes have joined.
    Updates HA policy to replicate to all nodes and monitors sync progress.

.NOTES
    Part of RabbitMQ 2-node to 4-node migration
#>

# =============================================================================
# CONFIGURATION - Update this path if RabbitMQ is installed elsewhere
# =============================================================================
$RabbitMQCtl = "C:\Program Files\RabbitMQ Server\rabbitmq_server-3.12.1\sbin\rabbitmqctl.bat"

# Verify rabbitmqctl exists
if (-not (Test-Path $RabbitMQCtl)) {
    Write-Host "[ERROR] rabbitmqctl.bat not found at: $RabbitMQCtl" -ForegroundColor Red
    Write-Host "        Update the `$RabbitMQCtl variable with the correct path." -ForegroundColor Yellow
    exit 1
}
# =============================================================================

Write-Host "=== Updating HA Policy ===" -ForegroundColor Cyan

# Show current cluster
Write-Host "`n[Cluster Members]" -ForegroundColor Yellow
$ClusterInfo = & $RabbitMQCtl cluster_status 2>&1 | Select-String -Pattern "Running Nodes|running_nodes" -Context 0,5
Write-Host $ClusterInfo

# Show current policies
Write-Host "`n[Current Policies]" -ForegroundColor Yellow
& $RabbitMQCtl list_policies

# Prompt before updating
Write-Host "`n" -NoNewline
$Confirm = Read-Host "Update HA policy to replicate to ALL nodes? (yes/no)"
if ($Confirm -ne "yes") {
    Write-Host "Aborted." -ForegroundColor Yellow
    exit 0
}

# Update HA policy to replicate to all nodes
Write-Host "`n[Updating HA policy to 'all' mode with automatic sync]" -ForegroundColor Yellow
& $RabbitMQCtl set_policy ha-all "^ha\." "{`"ha-mode`":`"all`",`"ha-sync-mode`":`"automatic`"}" --apply-to queues

if ($LASTEXITCODE -eq 0) {
    Write-Host "[OK] HA policy updated" -ForegroundColor Green
} else {
    Write-Host "[ERROR] Failed to update policy" -ForegroundColor Red
    exit 1
}

# Show updated policies
Write-Host "`n[Updated Policies]" -ForegroundColor Yellow
& $RabbitMQCtl list_policies

# Monitor sync status
Write-Host "`n=== Monitoring Queue Synchronization ===" -ForegroundColor Cyan
Write-Host "Checking every 10 seconds... (Ctrl+C to stop when all synced)`n"

$AllSynced = $false
$Iterations = 0
$MaxIterations = 60  # 10 minutes max

do {
    $Iterations++
    Clear-Host
    Write-Host "=== Queue Sync Monitor (Check $Iterations) ===" -ForegroundColor Cyan
    Write-Host "Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`n"

    # Get queue info
    $QueueOutput = & $RabbitMQCtl list_queues name slave_pids synchronised_slave_pids 2>$null

    $Synced = 0
    $Total = 0
    $QueueLines = $QueueOutput -split "`n" | Where-Object { $_ -match "^ha\." }

    foreach ($Line in $QueueLines) {
        $Total++
        # Parse the line - format is: name [slaves] [synced_slaves]
        if ($Line -match "^\S+\s+\[(.*?)\]\s+\[(.*?)\]") {
            $Slaves = $Matches[1]
            $SyncedSlaves = $Matches[2]

            $SlaveCount = if ($Slaves -eq "") { 0 } else { ($Slaves -split ",").Count }
            $SyncedCount = if ($SyncedSlaves -eq "") { 0 } else { ($SyncedSlaves -split ",").Count }

            $QueueName = ($Line -split "\s+")[0]

            if ($SlaveCount -eq $SyncedCount -and $SlaveCount -gt 0) {
                $Synced++
                Write-Host "  [SYNCED]  $QueueName ($SyncedCount/$SlaveCount mirrors)" -ForegroundColor Green
            } elseif ($SlaveCount -eq 0) {
                $Synced++
                Write-Host "  [OK]      $QueueName (no mirrors needed)" -ForegroundColor Green
            } else {
                Write-Host "  [SYNCING] $QueueName ($SyncedCount/$SlaveCount mirrors)" -ForegroundColor Yellow
            }
        }
    }

    if ($Total -eq 0) {
        Write-Host "  No HA queues found matching '^ha\.'" -ForegroundColor Yellow
        $AllSynced = $true
    } else {
        Write-Host "`n[$Synced/$Total queues fully synced]" -ForegroundColor Cyan

        if ($Synced -eq $Total) {
            $AllSynced = $true
            Write-Host "`n=== All Queues Synchronized ===" -ForegroundColor Green
        }
    }

    if (-not $AllSynced) {
        if ($Iterations -ge $MaxIterations) {
            Write-Host "`n[TIMEOUT] Max wait time reached. Check queues manually." -ForegroundColor Red
            break
        }
        Write-Host "`nNext check in 10 seconds... (Ctrl+C to exit)" -ForegroundColor Gray
        Start-Sleep -Seconds 10
    }

} while (-not $AllSynced)

Write-Host "`n--- NEXT STEPS ---" -ForegroundColor Cyan
Write-Host "1. Update client application connection strings to new server hostnames"
Write-Host "2. Restart/reconnect client applications"
Write-Host "3. Verify connections moved to new nodes: rabbitmqctl.bat list_connections node"
Write-Host "4. Once clients migrated, run 05-Decommission-OldNodes.ps1"
