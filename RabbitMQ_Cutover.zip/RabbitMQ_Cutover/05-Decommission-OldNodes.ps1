#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Phase 5: Decommission old RabbitMQ nodes from cluster

.DESCRIPTION
    Run this script on NEW-NODE-1 after clients have been migrated.
    Removes old nodes from the cluster and updates HA policy.

.PARAMETER OldNode1
    Hostname of first old node to remove (e.g., "OLD-SERVER-1")

.PARAMETER OldNode2
    Hostname of second old node to remove (e.g., "OLD-SERVER-2")

.EXAMPLE
    .\05-Decommission-OldNodes.ps1 -OldNode1 "OLD-SERVER-1" -OldNode2 "OLD-SERVER-2"

.NOTES
    Part of RabbitMQ 2-node to 4-node migration
#>

param(
    [Parameter(Mandatory=$true, HelpMessage="Hostname of first old node")]
    [string]$OldNode1,

    [Parameter(Mandatory=$true, HelpMessage="Hostname of second old node")]
    [string]$OldNode2
)

# =============================================================================
# CONFIGURATION - Update this path if RabbitMQ is installed elsewhere
# =============================================================================
$RabbitMQCtl = "C:\Program Files\RabbitMQ Server\rabbitmq_server-3.12.1\sbin\rabbitmqctl.bat"

# Verify rabbitmqctl exists
if (-not (Test-Path $RabbitMQCtl)) {
    Write-Host "[ERROR] rabbitmqctl.bat not found at: $RabbitMQCtl" -ForegroundColor Red
    Write-Host "        Update the `$RabbitMQCtl variable with the correct path." -ForegroundColor Yellow
    exit 1
}
# =============================================================================

Write-Host "=== Decommissioning Old Nodes ===" -ForegroundColor Cyan
Write-Host "Running on: $env:COMPUTERNAME"
Write-Host "Nodes to remove:"
Write-Host "  - rabbit@$OldNode1"
Write-Host "  - rabbit@$OldNode2"

# Safety check - don't remove self
if ($env:COMPUTERNAME -eq $OldNode1 -or $env:COMPUTERNAME -eq $OldNode2) {
    Write-Host "`n[ERROR] Cannot run this script on a node being decommissioned!" -ForegroundColor Red
    Write-Host "        Run this script on one of the NEW nodes." -ForegroundColor Red
    exit 1
}

# Check current cluster status
Write-Host "`n[Current Cluster Status]" -ForegroundColor Yellow
& $RabbitMQCtl cluster_status

# Check connections on old nodes
Write-Host "`n[Checking connections on old nodes]" -ForegroundColor Yellow
$Connections = & $RabbitMQCtl list_connections node 2>$null

$OldNode1Connections = ($Connections | Select-String "rabbit@$OldNode1" | Measure-Object).Count
$OldNode2Connections = ($Connections | Select-String "rabbit@$OldNode2" | Measure-Object).Count
$TotalOldConnections = $OldNode1Connections + $OldNode2Connections

Write-Host "  rabbit@$OldNode1: $OldNode1Connections connections"
Write-Host "  rabbit@$OldNode2: $OldNode2Connections connections"

if ($TotalOldConnections -gt 0) {
    Write-Host "`n[WARNING] $TotalOldConnections connections still on old nodes!" -ForegroundColor Red
    Write-Host "          These connections will be dropped when nodes are removed." -ForegroundColor Yellow
    $Continue = Read-Host "`nContinue with decommission? (yes/no)"
    if ($Continue -ne "yes") {
        Write-Host "Aborted. Migrate clients first." -ForegroundColor Yellow
        exit 0
    }
} else {
    Write-Host "`n[OK] No connections on old nodes" -ForegroundColor Green
}

# Final confirmation
Write-Host "`n" -NoNewline
$Confirm = Read-Host "FINAL CONFIRMATION: Remove old nodes from cluster? (yes/no)"
if ($Confirm -ne "yes") {
    Write-Host "Aborted." -ForegroundColor Yellow
    exit 0
}

# Remove old node 1
Write-Host "`n[1/4] Removing rabbit@$OldNode1..." -ForegroundColor Yellow

# Try to gracefully stop the app on old node first
Write-Host "      Attempting graceful stop on $OldNode1..." -ForegroundColor Gray
$RemoteStop = Invoke-Command -ComputerName $OldNode1 -ScriptBlock {
    param($ctl)
    & $ctl stop_app 2>&1
} -ArgumentList $RabbitMQCtl -ErrorAction SilentlyContinue 2>$null

if ($?) {
    Write-Host "      [OK] App stopped on $OldNode1" -ForegroundColor Green
} else {
    Write-Host "      [INFO] Could not reach $OldNode1 remotely - will force forget" -ForegroundColor Yellow
}

# Forget the node from cluster
Write-Host "      Forgetting node from cluster..." -ForegroundColor Gray
& $RabbitMQCtl forget_cluster_node "rabbit@$OldNode1"
if ($LASTEXITCODE -eq 0) {
    Write-Host "      [OK] rabbit@$OldNode1 removed from cluster" -ForegroundColor Green
} else {
    Write-Host "      [ERROR] Failed to remove rabbit@$OldNode1" -ForegroundColor Red
}

# Remove old node 2
Write-Host "`n[2/4] Removing rabbit@$OldNode2..." -ForegroundColor Yellow

# Try to gracefully stop the app on old node first
Write-Host "      Attempting graceful stop on $OldNode2..." -ForegroundColor Gray
$RemoteStop = Invoke-Command -ComputerName $OldNode2 -ScriptBlock {
    param($ctl)
    & $ctl stop_app 2>&1
} -ArgumentList $RabbitMQCtl -ErrorAction SilentlyContinue 2>$null

if ($?) {
    Write-Host "      [OK] App stopped on $OldNode2" -ForegroundColor Green
} else {
    Write-Host "      [INFO] Could not reach $OldNode2 remotely - will force forget" -ForegroundColor Yellow
}

# Forget the node from cluster
Write-Host "      Forgetting node from cluster..." -ForegroundColor Gray
& $RabbitMQCtl forget_cluster_node "rabbit@$OldNode2"
if ($LASTEXITCODE -eq 0) {
    Write-Host "      [OK] rabbit@$OldNode2 removed from cluster" -ForegroundColor Green
} else {
    Write-Host "      [ERROR] Failed to remove rabbit@$OldNode2" -ForegroundColor Red
}

# Update HA policy for 2-node cluster
Write-Host "`n[3/4] Updating HA policy for 2-node cluster..." -ForegroundColor Yellow
& $RabbitMQCtl set_policy ha-all "^ha\." "{`"ha-mode`":`"exactly`",`"ha-params`":2,`"ha-sync-mode`":`"automatic`"}" --apply-to queues
if ($LASTEXITCODE -eq 0) {
    Write-Host "      [OK] HA policy updated to 'exactly 2'" -ForegroundColor Green
} else {
    Write-Host "      [WARNING] Failed to update HA policy - check manually" -ForegroundColor Yellow
}

# Show final cluster status
Write-Host "`n[4/4] Final Cluster Status" -ForegroundColor Yellow
& $RabbitMQCtl cluster_status

Write-Host "`n=== Decommission Complete ===" -ForegroundColor Green
Write-Host "`nReminder: Stop RabbitMQ service on old servers:"
Write-Host "  On $OldNode1: Stop-Service RabbitMQ"
Write-Host "  On $OldNode2: Stop-Service RabbitMQ"

Write-Host "`n--- NEXT STEP ---" -ForegroundColor Cyan
Write-Host "Run 06-Validate-Cluster.ps1 to verify migration success"
