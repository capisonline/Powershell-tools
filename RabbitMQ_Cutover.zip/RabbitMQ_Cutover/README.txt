RabbitMQ Cluster Migration Scripts
===================================
Migration: 2-node (Win2012) -> 4-node -> 2-node (Win2019)
RabbitMQ Version: 3.12.1
Erlang Version: 25.3.2

EXECUTION ORDER
===============
Step  Script                          Run On              Description
----  ------                          ------              -----------
1     01-Backup-RabbitMQ.ps1          Old-Node-1          Backup definitions, policies, queues
2     (manual)                        -                   Copy .erlang.cookie to new servers
3     02-Prepare-NewNode.ps1          New-Node-1          Prepare node for cluster join
4     02-Prepare-NewNode.ps1          New-Node-2          Prepare node for cluster join
5     03-Join-Cluster.ps1             New-Node-1          Join to existing cluster
6     03-Join-Cluster.ps1             New-Node-2          Join to existing cluster
7     04-Update-HAPolicy.ps1          Any node            Update HA policy, monitor sync
8     (manual)                        -                   Update client connection strings
9     (manual)                        -                   Restart client applications
10    05-Decommission-OldNodes.ps1    New-Node-1          Remove old nodes from cluster
11    06-Validate-Cluster.ps1         New-Node-1          Verify migration success

PREREQUISITES
=============
- New Win2019 servers provisioned
- RabbitMQ 3.12.1 installed on new servers
- Erlang 25.3.2 installed on new servers
- Firewall rules: ports 4369, 25672, 5672, 15672 open between all nodes
- Admin PowerShell access to all servers
- WinRM enabled for remote commands (optional, for graceful decommission)

COOKIE LOCATION
===============
For LocalSystem service account:
  C:\ProgramData\RabbitMQ\.erlang.cookie

Copy from old to new servers:
  copy \\OLD-SERVER\C$\ProgramData\RabbitMQ\.erlang.cookie C:\ProgramData\RabbitMQ\

ROLLBACK PLAN
=============
If issues occur before Phase 5 (decommission):
1. Point clients back to old node hostnames
2. On new nodes: rabbitmqctl.bat stop_app
3. On old node: rabbitmqctl.bat forget_cluster_node rabbit@NEW-NODE-1
4. On old node: rabbitmqctl.bat forget_cluster_node rabbit@NEW-NODE-2
5. Restore original HA policy if changed

IMPORTANT NOTES
===============
- Classic mirrored queues (ha-*) are deprecated in 3.12 and removed in 3.13
- Consider migrating to quorum queues after this infrastructure migration
- All scripts require Administrator privileges (#Requires -RunAsAdministrator)
- Test in non-production environment first if possible
