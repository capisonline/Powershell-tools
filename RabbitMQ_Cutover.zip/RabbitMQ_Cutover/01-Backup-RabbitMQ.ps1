#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Phase 1: Backup and document current RabbitMQ cluster state

.DESCRIPTION
    Run this script on OLD-NODE-1 before starting migration.
    Creates backups of definitions, policies, queue status, and Erlang cookie.

.NOTES
    Part of RabbitMQ 2-node to 4-node migration
#>

$BackupDir = "C:\RabbitMQ_Migration_Backup"
$Date = Get-Date -Format "yyyyMMdd_HHmmss"

# Create backup directory
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null

Write-Host "=== RabbitMQ Pre-Migration Backup ===" -ForegroundColor Cyan
Write-Host "Backup directory: $BackupDir"
Write-Host "Timestamp: $Date"

# Export definitions
Write-Host "`n[1/5] Exporting cluster definitions..." -ForegroundColor Yellow
rabbitmqctl.bat export_definitions "$BackupDir\definitions_$Date.json"
if ($LASTEXITCODE -eq 0) {
    Write-Host "      Saved: definitions_$Date.json" -ForegroundColor Green
} else {
    Write-Host "      [ERROR] Failed to export definitions" -ForegroundColor Red
}

# List policies
Write-Host "`n[2/5] Documenting policies..." -ForegroundColor Yellow
rabbitmqctl.bat list_policies | Out-File "$BackupDir\policies_$Date.txt"
Write-Host "      Saved: policies_$Date.txt" -ForegroundColor Green

# List queues with sync status
Write-Host "`n[3/5] Documenting queue sync status..." -ForegroundColor Yellow
rabbitmqctl.bat list_queues name slave_pids synchronised_slave_pids | Out-File "$BackupDir\queues_$Date.txt"
Write-Host "      Saved: queues_$Date.txt" -ForegroundColor Green

# Cluster status
Write-Host "`n[4/5] Documenting cluster status..." -ForegroundColor Yellow
rabbitmqctl.bat cluster_status | Out-File "$BackupDir\cluster_status_$Date.txt"
Write-Host "      Saved: cluster_status_$Date.txt" -ForegroundColor Green

# Backup cookie
Write-Host "`n[5/5] Backing up Erlang cookie..." -ForegroundColor Yellow
$CookiePath = "C:\ProgramData\RabbitMQ\.erlang.cookie"
if (Test-Path $CookiePath) {
    Copy-Item $CookiePath "$BackupDir\erlang.cookie.backup"
    Write-Host "      Saved: erlang.cookie.backup" -ForegroundColor Green
} else {
    Write-Host "      [WARNING] Cookie not found at $CookiePath" -ForegroundColor Red
    Write-Host "      Check alternate location: C:\Windows\.erlang.cookie" -ForegroundColor Yellow
}

Write-Host "`n=== Backup Complete ===" -ForegroundColor Green
Write-Host "`nBackup location: $BackupDir"
Write-Host "`n--- NEXT STEPS ---" -ForegroundColor Cyan
Write-Host "1. Copy the Erlang cookie to new servers:"
Write-Host "   Source: $CookiePath"
Write-Host "   Dest:   \\NEW-SERVER\C`$\ProgramData\RabbitMQ\.erlang.cookie"
Write-Host "`n2. Run 02-Prepare-NewNode.ps1 on each new server"
