#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Phase 6: Post-migration validation

.DESCRIPTION
    Run this script on any new node after decommissioning old nodes.
    Performs health checks on the new 2-node cluster.

.NOTES
    Part of RabbitMQ 2-node to 4-node migration
#>

# =============================================================================
# CONFIGURATION - Update this path if RabbitMQ is installed elsewhere
# =============================================================================
$RabbitMQCtl = "C:\Program Files\RabbitMQ Server\rabbitmq_server-3.12.1\sbin\rabbitmqctl.bat"

# Verify rabbitmqctl exists
if (-not (Test-Path $RabbitMQCtl)) {
    Write-Host "[ERROR] rabbitmqctl.bat not found at: $RabbitMQCtl" -ForegroundColor Red
    Write-Host "        Update the `$RabbitMQCtl variable with the correct path." -ForegroundColor Yellow
    exit 1
}
# =============================================================================

Write-Host "=== Post-Migration Validation ===" -ForegroundColor Cyan
Write-Host "Running on: $env:COMPUTERNAME"
Write-Host "Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"

$Errors = 0
$Warnings = 0

# Check 1: Cluster status
Write-Host "`n[1/6] Cluster Status" -ForegroundColor Yellow
$ClusterStatus = & $RabbitMQCtl cluster_status 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "      [OK] Cluster responding" -ForegroundColor Green
} else {
    Write-Host "      [ERROR] Cluster not responding" -ForegroundColor Red
    Write-Host $ClusterStatus
    $Errors++
}

# Check 2: Node count
Write-Host "`n[2/6] Running Nodes" -ForegroundColor Yellow
$RunningNodes = & $RabbitMQCtl cluster_status 2>&1 | Select-String -Pattern "rabbit@"
$NodeCount = ($RunningNodes | Measure-Object).Count

if ($NodeCount -eq 2) {
    Write-Host "      [OK] 2 nodes running" -ForegroundColor Green
    $RunningNodes | ForEach-Object { Write-Host "          $_" }
} elseif ($NodeCount -gt 2) {
    Write-Host "      [WARNING] $NodeCount nodes running (expected 2)" -ForegroundColor Yellow
    $RunningNodes | ForEach-Object { Write-Host "          $_" }
    $Warnings++
} else {
    Write-Host "      [ERROR] Only $NodeCount node(s) running (expected 2)" -ForegroundColor Red
    $RunningNodes | ForEach-Object { Write-Host "          $_" }
    $Errors++
}

# Check 3: Queue health
Write-Host "`n[3/6] Queue Health" -ForegroundColor Yellow
$Queues = & $RabbitMQCtl list_queues name state messages consumers 2>&1

$QueueLines = $Queues -split "`n" | Where-Object { $_ -match "^\S+\s+(running|idle|down)" }
$TotalQueues = ($QueueLines | Measure-Object).Count
$DownQueues = ($QueueLines | Where-Object { $_ -match "\s+down\s+" } | Measure-Object).Count

if ($DownQueues -eq 0) {
    Write-Host "      [OK] All $TotalQueues queues healthy" -ForegroundColor Green
} else {
    Write-Host "      [ERROR] $DownQueues/$TotalQueues queues down:" -ForegroundColor Red
    $QueueLines | Where-Object { $_ -match "\s+down\s+" } | ForEach-Object { Write-Host "          $_" }
    $Errors++
}

# Check 4: HA Policy
Write-Host "`n[4/6] HA Policy" -ForegroundColor Yellow
$Policies = & $RabbitMQCtl list_policies 2>&1
$HAPolicy = $Policies | Select-String "ha-all"

if ($HAPolicy) {
    Write-Host "      [OK] HA policy configured" -ForegroundColor Green
    Write-Host "          $HAPolicy"
} else {
    Write-Host "      [WARNING] No 'ha-all' policy found" -ForegroundColor Yellow
    $Warnings++
}

# Check 5: Connections
Write-Host "`n[5/6] Client Connections" -ForegroundColor Yellow
$Connections = & $RabbitMQCtl list_connections node user 2>&1
$ConnectionLines = $Connections -split "`n" | Where-Object { $_ -match "^rabbit@" }
$ConnectionCount = ($ConnectionLines | Measure-Object).Count

Write-Host "      [INFO] $ConnectionCount active connections" -ForegroundColor Cyan

# Group by node
$ConnectionLines | ForEach-Object {
    if ($_ -match "^(rabbit@\S+)") {
        $Matches[1]
    }
} | Group-Object | ForEach-Object {
    Write-Host "          $($_.Name): $($_.Count) connections"
}

if ($ConnectionCount -eq 0) {
    Write-Host "      [WARNING] No client connections - verify clients are configured" -ForegroundColor Yellow
    $Warnings++
}

# Check 6: Alarms
Write-Host "`n[6/6] Cluster Alarms" -ForegroundColor Yellow
$Alarms = & $RabbitMQCtl list_alarms 2>&1

if ($Alarms -match "^\s*$" -or $Alarms -match "Listing alarms" -and $Alarms.Count -le 1) {
    Write-Host "      [OK] No alarms" -ForegroundColor Green
} else {
    $AlarmLines = $Alarms -split "`n" | Where-Object { $_ -notmatch "Listing alarms" -and $_ -match "\S" }
    if ($AlarmLines.Count -eq 0) {
        Write-Host "      [OK] No alarms" -ForegroundColor Green
    } else {
        Write-Host "      [WARNING] Active alarms:" -ForegroundColor Red
        $AlarmLines | ForEach-Object { Write-Host "          $_" }
        $Warnings++
    }
}

# Summary
Write-Host "`n" + ("=" * 50) -ForegroundColor Cyan
Write-Host "=== Validation Summary ===" -ForegroundColor Cyan
Write-Host ("=" * 50) -ForegroundColor Cyan

if ($Errors -eq 0 -and $Warnings -eq 0) {
    Write-Host "`nAll checks passed! Migration successful." -ForegroundColor Green
} elseif ($Errors -eq 0) {
    Write-Host "`n$Warnings warning(s) - review above" -ForegroundColor Yellow
    Write-Host "Migration likely successful but verify warnings." -ForegroundColor Yellow
} else {
    Write-Host "`n$Errors error(s), $Warnings warning(s) - review above" -ForegroundColor Red
    Write-Host "Migration may have issues - investigate errors." -ForegroundColor Red
}

Write-Host "`n--- POST-MIGRATION TASKS ---" -ForegroundColor Cyan
Write-Host "1. Monitor cluster for 24-48 hours"
Write-Host "2. Verify application functionality end-to-end"
Write-Host "3. Update monitoring/alerting with new server names"
Write-Host "4. Update documentation with new cluster details"
Write-Host "5. Decommission old server VMs when confident"
Write-Host "6. Consider migrating from classic mirrored queues to quorum queues"
Write-Host "   (Classic mirrored queues removed in RabbitMQ 3.13+)"
