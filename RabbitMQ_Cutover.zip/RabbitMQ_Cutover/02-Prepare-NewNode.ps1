#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Phase 2a: Prepare new RabbitMQ node for cluster join

.DESCRIPTION
    Run this script on EACH new server AFTER copying the Erlang cookie
    but BEFORE joining the cluster.

.NOTES
    Part of RabbitMQ 2-node to 4-node migration
#>

Write-Host "=== Preparing New RabbitMQ Node ===" -ForegroundColor Cyan
Write-Host "Hostname: $env:COMPUTERNAME"

# Verify cookie exists
$CookiePath = "C:\ProgramData\RabbitMQ\.erlang.cookie"
Write-Host "`n[1/4] Checking Erlang cookie..." -ForegroundColor Yellow

if (Test-Path $CookiePath) {
    Write-Host "      [OK] Erlang cookie found at $CookiePath" -ForegroundColor Green
    $CookieHash = (Get-FileHash $CookiePath -Algorithm SHA256).Hash.Substring(0,16)
    Write-Host "      Cookie hash (first 16 chars): $CookieHash"
    Write-Host "      Verify this matches the hash from old nodes!" -ForegroundColor Yellow
} else {
    Write-Host "      [ERROR] Erlang cookie not found at $CookiePath" -ForegroundColor Red
    Write-Host "      Copy cookie from old node first!" -ForegroundColor Red
    Write-Host "`n      Example:" -ForegroundColor Yellow
    Write-Host "      copy \\OLD-SERVER\C`$\ProgramData\RabbitMQ\.erlang.cookie C:\ProgramData\RabbitMQ\"
    exit 1
}

# Stop service if running
Write-Host "`n[2/4] Stopping RabbitMQ service (if running)..." -ForegroundColor Yellow
$Service = Get-Service RabbitMQ -ErrorAction SilentlyContinue
if ($Service) {
    if ($Service.Status -eq 'Running') {
        Stop-Service RabbitMQ -Force
        Write-Host "      Service stopped" -ForegroundColor Green
    } else {
        Write-Host "      Service already stopped" -ForegroundColor Green
    }
} else {
    Write-Host "      [ERROR] RabbitMQ service not found - is RabbitMQ installed?" -ForegroundColor Red
    exit 1
}

# Reset node (clean state)
Write-Host "`n[3/4] Resetting node to clean state..." -ForegroundColor Yellow
Start-Service RabbitMQ
Start-Sleep -Seconds 5

rabbitmqctl.bat stop_app 2>$null | Out-Null
rabbitmqctl.bat reset 2>$null | Out-Null
rabbitmqctl.bat stop_app 2>$null | Out-Null

Write-Host "      Node reset complete" -ForegroundColor Green

# Start service fresh
Write-Host "`n[4/4] Starting RabbitMQ service..." -ForegroundColor Yellow
Stop-Service RabbitMQ -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Start-Service RabbitMQ

Write-Host "      Waiting for RabbitMQ to initialize..." -ForegroundColor Yellow
Start-Sleep -Seconds 15

# Verify running
$Status = rabbitmqctl.bat status 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "      [OK] RabbitMQ is running" -ForegroundColor Green

    # Get node name
    $NodeName = rabbitmqctl.bat eval "node()." 2>$null
    Write-Host "`n=== Node Ready to Join Cluster ===" -ForegroundColor Green
    Write-Host "Node name: $NodeName"
    Write-Host "`n--- NEXT STEP ---" -ForegroundColor Cyan
    Write-Host "Run: .\03-Join-Cluster.ps1 -ClusterNode 'OLD-SERVER-HOSTNAME'"
} else {
    Write-Host "      [ERROR] RabbitMQ failed to start properly" -ForegroundColor Red
    Write-Host $Status
    exit 1
}
