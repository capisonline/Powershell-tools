﻿# PowerShell script to create a scheduled task to run the SQL backup script 

# Task Scheduler details
$taskName = "Netstat_Port_Checker"
$taskDescription = "Runs command: Netstat -bano every 3mins and saves to text file."
$taskScriptPath = "C:\temp\sql_backup_script.ps1"
$taskRunTime = "02:00" # Time of day when the task should run

# Check if the task already exists
$existingTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($null -ne $existingTask) {
    Write-Output "Task '$taskName' already exists. Removing the existing one to create a new one."
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}

# Create the action to run the PowerShell script
$action = New-ScheduledTaskAction -Execute "Powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$taskScriptPath`""

# Create the trigger for the task (daily at a specified time)
$trigger = New-ScheduledTaskTrigger -Daily -At $taskRunTime

# Specify the user under which the task should run (System account)
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount

# Register the task with the action and trigger
Register-ScheduledTask -TaskName $taskName -Description $taskDescription -Action $action -Trigger $trigger -Principal $principal

Write-Output "Scheduled Task '$taskName' created successfully to run daily at $taskRunTime."
