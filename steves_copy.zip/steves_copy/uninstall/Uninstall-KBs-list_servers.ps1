﻿# Define the file paths 
$serverListFile = "C:\path\to\servers.txt"  # Path to the text file containing server names
$outputCsv = "C:\path\to\UninstallResults.csv"  # Path to save the CSV output
$logFile = "C:\path\to\UninstallLog.txt"  # Path to save the log file

# Define the KB number to uninstall
$kbNumber = "4486153"  # KB number to uninstall

# Initialize an array to store results
$results = @()

# Function to uninstall the update on a remote server and reboot
function Uninstall-KBUpdate {
    param (
        [string]$server,
        [string]$kbNumber
    )

    try {
        # Test if the server is reachable
        if (Test-Connection -ComputerName $server -Count 1 -Quiet) {
            # Start the uninstall process and capture the output
            $uninstallResult = Invoke-Command -ComputerName $server -ScriptBlock {
                param ($kbNumber)
                # Get the update by the KB number and uninstall it
                $update = Get-WmiObject -Query "SELECT * FROM Win32_QuickFixEngineering WHERE HotFixID = '$kbNumber'"
                if ($update) {
                    # Log the uninstall initiation
                    $message = "Uninstalling KB$kbNumber on $env:COMPUTERNAME"
                    Add-Content -Path $using:logFile -Value $message

                    # Initiate the uninstall
                    wusa.exe /uninstall /kb:$kbNumber /quiet /norestart
                    Start-Sleep -Seconds 30  # Give it some time to process

                    # Log that the uninstall was initiated
                    $message = "Uninstall initiated on $env:COMPUTERNAME for KB$kbNumber"
                    Add-Content -Path $using:logFile -Value $message
                    
                    # Reboot the server
                    Restart-Computer -Force
                    return "Uninstall initiated and rebooting"
                }
                else {
                    # Log update not found
                    $message = "KB$kbNumber not found on $env:COMPUTERNAME"
                    Add-Content -Path $using:logFile -Value $message
                    return "Update not found"
                }
            } -ArgumentList $kbNumber -ErrorAction Stop
        }
        else {
            # Log unreachable server
            $message = "Server $server unreachable"
            Add-Content -Path $logFile -Value $message
            $uninstallResult = "Server Unreachable"
        }

        return $uninstallResult
    }
    catch {
        # Log error and return error message
        $message = "Error occurred on ${server}: $_"
        Add-Content -Path $logFile -Value $message
        return "Error occurred: $_"
    }
}

# Read server names from file
$servers = Get-Content -Path $serverListFile

# Loop through each server and uninstall the update
foreach ($server in $servers) {
    $result = Uninstall-KBUpdate -server $server -kbNumber $kbNumber
    # Store the result
    $results += [PSCustomObject]@{
        ServerName = $server
        KBNumber   = $kbNumber
        Result     = $result
    }
}

# Export the results to CSV
$results | Export-Csv -Path $outputCsv -NoTypeInformation

# Notify user of completion
Write-Host "Completed uninstall attempts and saved results to $outputCsv"
Write-Host "Log saved to $logFile"

