﻿<# 
.SYNOPSIS
    This script connects to a list of remote servers, backs up specified registry keys, 
    deletes them if they exist, and then recreates them. All logs are centralized to a 
    single log file on the local machine.

.DESCRIPTION
    - Reads a list of servers from C:\Temp\serverlist.txt.
    - Processes multiple registry keys specified in the $RegistryPaths array.
    - Backs up each registry key on the remote server in C:\Temp with a timestamp.
    - Removes the registry keys if they exist.
    - Recreates the registry keys after deletion.
    - Centralizes all logs to C:\Temp\Centralized_RegBackup_Log.txt on the local machine.
    - Includes error handling for unreachable servers.

.NOTES
    - Ensure the script is run with administrative privileges.
    - The list of servers must be stored in C:\Temp\serverlist.txt (one per line).
    - The script logs all actions, including errors, to a centralized log file.



.AUTHOR
    Rogers.Steven(CC) <Rogers.Steven2@police.qld.gov.au>
#>

# Define the list of servers
$Servers = Get-Content "C:\Temp\serverlist.txt"

# Define the registry paths to process (Add more as needed)
$RegistryPaths = @(
    "HKLM:\SOFTWARE\YourSoftwareKey1",
    "HKLM:\SOFTWARE\YourSoftwareKey2"
)

# Define local log file path for centralized logging
$LocalLogFile = "C:\Temp\Centralized_RegBackup_Log.txt"

# Add a header to the log file
Add-Content -Path $LocalLogFile -Value "`n=== Registry Backup & Cleanup Log - $(Get-Date -Format "yyyy-MM-dd HH:mm:ss") ==="

# Loop through each server
foreach ($Server in $Servers) {
    Write-Host "`nProcessing $Server..."

    # Test connectivity
    if (Test-Connection -ComputerName $Server -Count 1 -Quiet) {
        try {
            $Result = Invoke-Command -ComputerName $Server -ScriptBlock {
                param($RegistryPaths)

                $BackupFolder = "C:\Temp"
                if (!(Test-Path -Path $BackupFolder)) {
                    New-Item -Path $BackupFolder -ItemType Directory -Force
                }

                # Generate timestamp
                $Timestamp = Get-Date -Format "yyyyMMdd_HHmm"
                $ServerLog = "`n=== Processing $env:COMPUTERNAME at $Timestamp ==="

                foreach ($RegPath in $RegistryPaths) {
                    $RegKeyName = ($RegPath -replace "HKLM:\\", "").Replace("\", "_")
                    $BackupPath = "$BackupFolder\RegBackup_${RegKeyName}_$Timestamp.reg"

                    $ServerLog += "`nBacking up: $RegPath -> $BackupPath"
                    reg export $RegPath $BackupPath /y 2>&1 | Out-String | ForEach-Object { $ServerLog += "`n$_" }

                    # If registry path exists, remove it
                    if (Test-Path -Path $RegPath) {
                        $ServerLog += "`nRemoving Registry Key: $RegPath"
                        Remove-Item -Path $RegPath -Recurse -Force -ErrorAction SilentlyContinue
                    }

                    # Recreate the Registry Key
                    $ServerLog += "`nRecreating Registry Key: $RegPath"
                    New-Item -Path $RegPath -Force | Out-Null
                }

                $ServerLog += "`nCompleted on $env:COMPUTERNAME"
                return $ServerLog
            } -ArgumentList $RegistryPaths

            # Append server-specific logs to the centralized log file
            Add-Content -Path $LocalLogFile -Value $Result
            Write-Host "Log for $Server added to centralized log file."
        }
        catch {
            Write-Host "Error processing $Server: $_"
            Add-Content -Path $LocalLogFile -Value "`nERROR: Could not process $Server - $_"
        }
    }
    else {
        Write-Host "Server $Server is unreachable!"
        Add-Content -Path $LocalLogFile -Value "`nERROR: Server $Server is unreachable!"
    }
}

Write-Host "`nAll logs centralized to $LocalLogFile"
