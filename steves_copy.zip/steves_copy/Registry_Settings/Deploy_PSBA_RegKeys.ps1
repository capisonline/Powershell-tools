﻿# Set Environment 
$Environment = Read-Host -Prompt "Enter Environment e.g. VT"
$LogFile = "C:\temp\QCAD\PR\Reg_Settings\DeploymentLog.txt"

# Initialize Log Function
function Write-Log {
    param (
        [string]$Message,
        [string]$LogType = "INFO"
    )
    $TimeStamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$TimeStamp [$LogType] $Message" | Out-File -FilePath $LogFile -Append
}

Write-Log "Script started for environment: $Environment"

# Get list of servers from ServerList
$Servers = Import-Csv -Path 'C:\temp\QCAD\PR\Reg_Settings\ServerList.csv'

foreach ($Server in $Servers) {
    if ($Server.Environment -eq $Environment) {
        Write-Log "Processing server: $($Server.server)"

        try {
            Invoke-Command -ComputerName $Server.server -ArgumentList $Environment -ScriptBlock {
                param ($Environment)
                # Set the location to the registry
                Set-Location -Path 'HKLM:\SOFTWARE'
                # Create required registry keys and values
                $PSBAPath = 'HKLM:\SOFTWARE\PSBA'
                $BuildVariablesPath = "$PSBAPath\BuildVariables"
                $SysInfoPath = "$PSBAPath\SysInfo"

                # Ensure PSBA key exists
                if (-not (Test-Path -Path $PSBAPath)) {
                    New-Item -Path $PSBAPath -Force | Out-Null
                }

                # Ensure BuildVariables key exists
                if (-not (Test-Path -Path $BuildVariablesPath)) {
                    New-Item -Path $BuildVariablesPath -Force | Out-Null
                }

                # Ensure SysInfo key exists
                if (-not (Test-Path -Path $SysInfoPath)) {
                    New-Item -Path $SysInfoPath -Force | Out-Null
                }

                # Add or update properties in BuildVariables
                $BuildVariables = @{
                    'isSQLServer'    = "false"
                    'Customer'       = "Public Safety Business Agency"
                    'Service'        = "QCAD"
                    'Lifecycle'      = "QCAD $Environment"
                    'SupportHrs'     = "24/7"
                    'HQR'            = "Undefined"
                    'Owner'          = "FDDPlatinumServicesCBD@police.qld.gov.au"
                    'BossReference'  = "000000"
                    'Design'         = "Undefined"
                    'Warranty'       = "Provisioned by Orchestrator"
                    'Component'      = "Application"
                    'Environment'    = "QCAD $Environment"
                }

                foreach ($Key in $BuildVariables.Keys) {
                    New-ItemProperty -Path $BuildVariablesPath -Name $Key -Value $BuildVariables[$Key] -PropertyType String -Force | Out-Null
                }

                # Add or update properties in SysInfo
                $SysInfo = @{
                    'Build_Serial'      = "2016-12-31-21-02"
                    'Deploy_Serial'     = "2018-10-15-11-00"
                    'Customer_Stream'   = "Public Safety Business Agency"
                    'Service'           = "QCAD $Environment"
                    'Service_Component' = "Application"
                    'Support'           = "24/7"
                    'Warranty'          = "Provisioned by Orchestrator"
                    'HQR'               = "Undefined"
                    'TIG'               = "Undefined"
                    'Template_Serial'   = "2018-09-29-21-01"
                    'Custom_Message'    = ""
                    'DeploymentStatus'  = "Completed"
                    'Lifecycle'         = "QCAD $Environment"
                    'BuildOperator'     = "FDDIV-D-F_DDHeadsofHouse@qldpolice.onmicrosoft.com"
                }

                foreach ($Key in $SysInfo.Keys) {
                    New-ItemProperty -Path $SysInfoPath -Name $Key -Value $SysInfo[$Key] -PropertyType String -Force | Out-Null
                }
            }

            Write-Log "Successfully processed server: $($Server.server)"
        } catch {
            Write-Log "Error processing server $($Server.server): $_" -LogType "ERROR"
        }
    } else {
        Write-Log "Skipping server $($Server.server) as it does not match environment: $Environment"
    }
}

Write-Log "Script completed."
Write-Host "Script execution complete. Check the log file at $LogFile for details."
