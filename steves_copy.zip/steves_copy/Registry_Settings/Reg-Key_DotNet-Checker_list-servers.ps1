﻿# Define the file paths 
$serverListFile = "C:\temp\QCAD\PR\PR_New_Servers.txt"  # Path to the text file containing server names
$outputCsv = "C:\temp\QCAD\PR\dotNet\PR-dotNetVersions-final.csv"  # Path to save the CSV output

# Initialize an array to store results
$results = @()

# Function to get the installed .NET versions from the NDP folder
function Get-DotNetVersion {
    param (
        [string]$server
    )

    $dotNetVersions = @()

    # Define the root registry path for .NET versions
    $rootRegistryPath = "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP"

    try {
        # Test if the server is reachable
        if (Test-Connection -ComputerName $server -Count 1 -Quiet) {
            $versions = Invoke-Command -ComputerName $server -ScriptBlock {
                # Get all subkeys under NDP and search for the 'Version' key
                Get-ChildItem -Path $using:rootRegistryPath -Recurse |
                ForEach-Object {
                    $subKeyPath = $_.PSPath
                    $versionKey = Get-ItemProperty -Path $subKeyPath -ErrorAction Ignore | Select-Object -ExpandProperty Version -ErrorAction Ignore
                    if ($versionKey) {
                        # Capture the version along with the folder name
                        [PSCustomObject]@{
                            Framework = $_.PSChildName
                            Version   = $versionKey
                        }
                    }
                }
            }

            # Collect the version information
            $dotNetVersions = $versions
        }
        else {
            $dotNetVersions = @([PSCustomObject]@{ Framework = $null; Version = "Server Unreachable" })
        }

        return $dotNetVersions
    }
    catch {
        return @([PSCustomObject]@{ Framework = $null; Version = "Error retrieving version" })
    }
}

# Read server names from file
$servers = Get-Content -Path $serverListFile

# Loop through each server and get the .NET versions
foreach ($server in $servers) {
    $versions = Get-DotNetVersion -server $server
    foreach ($version in $versions) {
        # Add server name to each result
        $results += [PSCustomObject]@{
            ServerName = $server
            Framework  = $version.Framework
            Version    = $version.Version
        }
    }
}

# Export the results to CSV
$results | Export-Csv -Path $outputCsv -NoTypeInformation

# Notify user of completion
Write-Host "Completed scanning servers and saved results to $outputCsv"

