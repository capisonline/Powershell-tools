﻿# Define the path to the input CSV file and the output CSV file 
$inputCsvPath = "C:\temp\QCAD\TP\Oracle\TP_Oracle-Reg-DLL_Path.csv"
$outputCsvPath = "C:\temp\QCAD\TP\Oracle\TP_Oracle-Reg-DLL_Path-checked2.csv"

# Read the input CSV file
$serverList = Import-Csv -Path $inputCsvPath

# Prepare an array to hold the results
$results = @()

foreach ($server in $serverList) {
    try {
        # Establish a remote session to the server
        $session = New-PSSession -ComputerName $server.Hostname -ErrorAction Stop

        # Attempt to retrieve the registry value
        $regValue = Invoke-Command -Session $session -ScriptBlock {
            param($path, $name)
            Get-ItemPropertyValue -Path $path -Name $name -ErrorAction Stop
        } -ArgumentList $server.Key_Path, $server.Key_Name -ErrorAction SilentlyContinue

        # Check if the retrieved data matches the expected data
        $isCorrect = if ($regValue -eq $server.Data) { "Yes" } else { "No" }

        # Record the result
        $results += [PSCustomObject]@{
            Hostname       = $server.Hostname
            Key_Path       = $server.Key_Path
            Key_Name       = $server.Key_Name
            Data           = $server.Data
            Correct        = $isCorrect
        }

        # Close the session
        Remove-PSSession -Session $session
    } catch {
        # Handle errors such as missing registry entries or access issues
        $results += [PSCustomObject]@{
            Hostname       = $server.Hostname
            Key_Path       = $server.Key_Path
            Key_Name       = $server.Key_Name
            Data           = $server.Data
            Correct        = "Error: " + $_.Exception.Message
        }
    }
}

# Output the results to a new CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation
