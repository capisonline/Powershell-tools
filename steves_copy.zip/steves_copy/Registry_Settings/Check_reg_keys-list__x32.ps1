﻿<#
Input CSV structured as shown:
Key_Path	                                                    Key_Name	   Data
HKLM:\SOFTWARE\WOW6432Node\ORACLE\KEY_OraClient19Home1_32bit	ORACLE_HOME	   D:\oracle\product\19.0.0\client_1

Script takes input file, checks Reg keys exist and checks data, outputs input file info and confirms match with Yes/No
#>


# Define the file paths 
$serversFile = "C:\temp\QCAD\PR\Oracle\32bit\32bit_input.txt"
$registryFile = "C:\temp\QCAD\PR\Oracle\32bit\Oracle-x32_Reg-DLL_Path.csv"
$outputFile = "C:\temp\QCAD\PR\Oracle\32bit\PR_x32_RegistryCheckResults.csv"

# Read the server names from the text file
$servers = Get-Content $serversFile

# Read the registry data from the CSV file
$registryEntries = Import-Csv $registryFile

# Prepare the results array
$results = @()

foreach ($server in $servers) {
    foreach ($entry in $registryEntries) {
        # Remote registry query command
        $scriptBlock = {
            param($keyPath, $keyName)
            # Check if the registry key and value exist
            if (Test-Path $keyPath) {
                $value = Get-ItemProperty -Path $keyPath -Name $keyName -ErrorAction SilentlyContinue
                if ($value -and $value.$keyName) {
                    return $value.$keyName
                }
            }
            return $null
        }

        # Invoke the command on the remote server
        $dataValue = Invoke-Command -ComputerName $server -ScriptBlock $scriptBlock -ArgumentList $entry.Key_Path, $entry.Key_Name -ErrorAction SilentlyContinue

        # Determine if the Data matches
        $matchResult = if ($dataValue -eq $entry.Data) { "Yes" } else { "No" }

        # Create a result object
        $result = [PSCustomObject]@{
            Server = $server
            Key_Path = $entry.Key_Path
            Key_Name = $entry.Key_Name
            Expected_Data = $entry.Data
            Found_Data = $dataValue
            Is_Match = $matchResult
        }

        # Add the result to the results array
        $results += $result
    }
}

# Export the results to a new CSV file
$results | Export-Csv -Path $outputFile -NoTypeInformation
