﻿<# 
.SYNOPSIS
    This script migrates DNS aliases from old servers to new servers using input from a CSV file.
    It logs the migration process, including any successes or errors, with timestamps to a log file.
    
.DESCRIPTION
    The script reads from a CSV file with two columns: OLD (old server name) and NEW (new server name).
    For each old server name, it checks if a DNS alias exists on the specified DNS server, then updates the alias to point to the new server name.
    The process is logged in detail with timestamps to a specified log file. 
    The script is designed to be run with a Scheduled task to migrate at a specific time but can be from within PowerShell ISE.
    
.PARAMETER csvPath
    The file path to the CSV file containing OLD and NEW server names.

.PARAMETER logFilePath
    The file path to the log file where all actions and outcomes are recorded with timestamps.

.PARAMETER domain
    The DNS domain where the aliases are being migrated.

.PARAMETER dnsServer
    The DNS server to use for managing the DNS records.

.EXAMPLE
    To run the script, modify the csvPath, logFilePath, domain, and dnsServer variables to point to the appropriate locations.
    

    $csvPath = "C:\temp\input.csv"
    $logFilePath = "C:\temp\migration_log.txt"
    $domain = "yourdomain.com"
    $dnsServer = "yourdnsserver.com"


    rogers.steven2@police.qld.gov.au
 
#>

# Variables
$csvPath = "C:\path\to\your\input.csv" # Path to your input CSV
$logFilePath = "C:\path\to\your\migration_log.txt" # Path to your log file
$domain = "prds.qldpol" # Domain for DNS records
$dnsServer = "164.112.162.141" # DNS Server to query

# Start logging
Start-Transcript -Path $logFilePath

# Function to log with timestamps
function Write-Log {
    param (
        [string]$message
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $logFilePath -Value "$timestamp - $message"
}

# Import the CSV
try {
    $aliasData = Import-Csv -Path $csvPath
    Write-Log "Successfully imported CSV file from $csvPath."
} catch {
    Write-Log "Failed to import CSV file. $_"
    Stop-Transcript
    throw $_
}

# Loop through each entry in the CSV
foreach ($entry in $aliasData) {
    $oldServer = $entry.OLD
    $newServer = $entry.NEW

    try {
        # Check if the old DNS alias exists on the specified DNS server
        $oldDnsRecord = Get-DnsServerResourceRecord -ZoneName $domain -Name $oldServer -ComputerName $dnsServer

        if ($oldDnsRecord) {
            Write-Log "Old DNS alias $oldServer found in domain $domain on DNS server $dnsServer. Migrating to $newServer."

            # Update the DNS alias to point to the new server on the specified DNS server
            Set-DnsServerResourceRecord -OldInputObject $oldDnsRecord -NewName $newServer -ComputerName $dnsServer

            Write-Log "Successfully migrated DNS alias from $oldServer to $newServer in domain $domain on DNS server $dnsServer."
        } else {
            Write-Log "Old DNS alias $oldServer not found in domain $domain on DNS server $dnsServer. Skipping."
        }
    } catch {
        Write-Log "Error migrating $oldServer to $newServer in domain $domain on DNS server $dnsServer. $_"
    }
}

# Stop logging
Stop-Transcript

# if being run within ISE 
Write-Host "DNS alias migration completed. Check the log file for details."
