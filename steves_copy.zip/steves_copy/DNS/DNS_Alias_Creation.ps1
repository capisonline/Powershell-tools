﻿<#
This script uses Add-DnsServerResourceRecordCName and is required to be installed on the machine running this script
The CSV columns require this structure:
ColumnA         ColumnB
AliasName       ServerName
PAcad-aas01   	EGLVCADCCMTP01.prds.qldpol

1x Alias per row
It will skip the creation if it already exists

Be sure to set:
        $zoneName = "prds.qldpol" # Change this to the DNS zone name
        $dnsServer = "164.112.162.141" # Change DNS server's IP address

#>

# Define the path to your CSV file 
$csvFilePath = "C:\temp\QCAD\VT\DNS_Alias\VT-DNS_Alias.csv"

# Import the CSV file. It's expected to have 'AliasName' and 'ServerName' columns.
$dnsEntries = Import-Csv -Path $csvFilePath

# Loop through each entry in the CSV file
foreach ($entry in $dnsEntries) {
    $aliasName = $entry.AliasName
    $serverName = $entry.ServerName

    # Check if the DNS alias already exists
    $existingRecord = Resolve-DnsName -Name $aliasName -ErrorAction SilentlyContinue

    if ($existingRecord) {
        Write-Output "DNS alias '$aliasName' already exists. Skipping creation."
    }
    else {
        # Specify the DNS zone name and the DNS server name
        $zoneName = "prds.qldpol" # Change this to the DNS zone name
        $dnsServer = "164.112.162.141" # Change to DNS server's IP address

        # Adding the CNAME record
        try {
            Add-DnsServerResourceRecordCName -Name $aliasName -HostNameAlias $serverName -ZoneName $zoneName -ComputerName $dnsServer
            Write-Output "DNS alias '$aliasName' for server '$serverName' created successfully."
        }
        catch {
            Write-Output "Failed to create DNS alias '$aliasName' for server '$serverName'. Error: $_"
        }
    }
}

Write-Output "DNS alias check and creation process completed."
