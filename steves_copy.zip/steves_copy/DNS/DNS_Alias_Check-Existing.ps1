﻿# Variables 
$Zone = "prds.qldpol" # Set DNS zone name
$Server = "164.112.162.141"   # Replace with DNS server name / IP 
$InputFilePath = "C:\temp\QCAD\VT\Networking\nslookup_all_VT.txt"  # Input text file
$OutputDir = "C:\temp\QCAD\VT\Networking\"  # output directory


# Ensure the output directory exists, creating it if necessary
if (-not (Test-Path -Path $OutputDir)) {
    New-Item -Path $OutputDir -Type Directory -Force | Out-Null
}

# Set a timestamp for unique output files
$timestamp = Get-Date -Format yyyy-MM-dd-HH-mm

# Set the directory where DNS records will be saved
$outputPath = Join-Path -Path $OutputDir -ChildPath 'DNS Records'
if (-not (Test-Path -Path $outputPath)) {
    New-Item -Path $outputPath -Type Directory -Force | Out-Null
}

# Read the list of hostnames from the input file
if (-not (Test-Path -Path $InputFilePath)) {
    Write-Error "The input file was not found at '$InputFilePath'."
    return
}
$inputHostnames = Get-Content -Path $InputFilePath

# Retrieve all DNS records for the specified zone
try {
    $allRecords = Get-DnsServerResourceRecord -ZoneName $Zone -ComputerName $Server -ErrorAction Stop
} catch {
    Write-Error "Failed to retrieve DNS records: $_"
    return
}

# Filter records
$filteredRecords = foreach ($hostname in $inputHostnames) {
    $allRecords | Where-Object {
        ($_ -is [Microsoft.Management.Infrastructure.CimInstance] -and $_.RecordType -in 'A','AAAA','CNAME') -and
        ($_.HostName -eq $hostname -or ($_.RecordType -eq 'CNAME' -and ($_.RecordData.HostNameAlias -split '\.')[0] -eq $hostname))
    } | ForEach-Object {
        $IP = if ($_.RecordType -eq 'A' -and $_.RecordData.IPv4Address) {
                    $_.RecordData.IPv4Address.ToString()
                } elseif ($_.RecordType -eq 'AAAA' -and $_.RecordData.IPv6Address) {
                    $_.RecordData.IPv6Address.ToString()
                } else {
                    "N/A"
                }
        [PSCustomObject]@{
            RecordType = $_.RecordType
            Hostname   = if ($_.RecordType -eq 'CNAME') { ($_.RecordData.HostNameAlias -split '\.')[0] } else { $_.HostName }
            DNSAlias   = if ($_.RecordType -eq 'CNAME') { $_.HostName } else { "N/A" }
            IP         = $IP
            TTL        = $_.TimeToLive
        }
    }
}

# Export to CSV 
$outputCsv = Join-Path -Path $outputPath -ChildPath "$($Zone) Filtered DNS Records $($timestamp).csv"
$filteredRecords | Export-Csv -Path $outputCsv -NoTypeInformation -Delimiter ","

Write-Output "Filtered DNS records have been exported to '$outputCsv'."
