﻿<#
.SYNOPSIS
    Simple daily cleanup: delete all files in a specific folder.

.DESCRIPTION
    - Hard-coded target folder and log file.
    - Deletes all files (non-recursive) in the folder.
    - Logs how many files were deleted and how many remain.
#>

# ---------------------------
# HARD-CODED SETTINGS
# ---------------------------
$TargetFolder = 'E:\Path\To\Cleanup'             # <<< SET THIS >>>
$LogFile      = 'C:\Logs\DailyFolderCleanup.log' # <<< SET IF NEEDED >>>

# ---------------------------
# BASIC CHECKS
# ---------------------------

if (-not (Test-Path -Path $TargetFolder -PathType Container)) {
    # Folder doesn't exist - nothing to do
    exit 0
}

# Prevent obvious disasters: don't run on drive root like "E:\"
$normalizedTarget = (Get-Item $TargetFolder).FullName.TrimEnd('\')
if ($normalizedTarget -match '^[A-Za-z]:$') {
    # If someone points it at just C:\ or E:\, bail out.
    exit 1
}

# Ensure log directory exists
$logDir = Split-Path -Path $LogFile -Parent
if (-not (Test-Path $logDir)) {
    New-Item -Path $logDir -ItemType Directory -Force | Out-Null
}

$timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

# ---------------------------
# DELETE FILES
# ---------------------------

$files = Get-ChildItem -Path $TargetFolder -File

if (-not $files -or $files.Count -eq 0) {
    Add-Content -Path $LogFile -Value "$timestamp - [$TargetFolder] No files found. Nothing deleted."
    exit 0
}

$deletedCount = 0

foreach ($file in $files) {
    try {
        Remove-Item -Path $file.FullName -Force -ErrorAction Stop
        $deletedCount++
    }
    catch {
        # Ignore individual failures, we'll see remaining count below
        continue
    }
}

# Count what’s left
$remainingCount = (Get-ChildItem -Path $TargetFolder -File | Measure-Object).Count

Add-Content -Path $LogFile -Value "$timestamp - [$TargetFolder] Deleted: $deletedCount file(s). Remaining: $remainingCount file(s)."
