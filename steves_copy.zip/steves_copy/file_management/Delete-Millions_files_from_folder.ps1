﻿<#
.SYNOPSIS
    Fast deletion of very large numbers of files from a Windows folder.

.DESCRIPTION
    This script is designed for scenarios where a Windows directory contains millions of files (e.g. > 7 million) and normal deletion
    methods (Explorer, native PowerShell Get-ChildItem + Remove-Item, etc.)
    are too slow or cause the OS to become unresponsive.

    Instead of enumerating and deleting each file individually, the script uses
    ROBOCOPY with the /MIR (mirror) switch to mirror an intentionally empty
    folder onto the target. This is a well-known, efficient pattern for bulk
    deletion on Windows:

        robocopy <empty-folder> <target-folder> /MIR

    Mirroring an empty folder onto the target causes ROBOCOPY to remove all
    files in the target folder without loading millions of file objects into
    memory. This is much faster and more reliable on heavily loaded servers.

    SAFETY:
    - The target folder is hard-coded to the path:
          D:\Name_your_path\
    - The script verifies that:
        * The target exists and is a directory.
        * The target is NOT a drive root (e.g. "D:\").
    - The source "empty" folder is hard-coded to:
          C:\temp\Empty_Folder_Does_not_exist
      and the script will:
        * Create it if it does not exist.
        * Refuse to proceed if it is not empty.

    NOTE:
    - This script deletes ALL contents of the target folder.
    - It does not stop applications or verify the server is idle; that must be
      handled by the change plan/runbook.
    - Use only under change control and Server Owner agreement.

    Documentation:
    https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy

#>

# ---------------------------
# HARD-CODED PATHS
# ---------------------------

# Target folder to be emptied (Oracle adump)
$TargetFolder = 'D:\oracle\admin\vtcad\adump'

# Intentionally empty folder used as the source for robocopy /MIR
$EmptyFolder  = 'D:\temp\Empty_Folder_Does_not_exist'

Write-Host "=== Oracle adump bulk delete using robocopy /MIR ===" -ForegroundColor Cyan
Write-Host "Target folder : $TargetFolder"
Write-Host "Empty folder  : $EmptyFolder"
Write-Host ""

# ---------------------------
# SAFETY CHECKS
# ---------------------------

# 1. Validate target folder exists and is a directory
if (-not (Test-Path -Path $TargetFolder -PathType Container)) {
    Write-Error "Target folder '$TargetFolder' does not exist or is not a directory. Aborting."
    exit 1
}

# 2. Ensure target is NOT a drive root (e.g. C:\)
$normalizedTarget = (Get-Item $TargetFolder).FullName.TrimEnd('\')
if ($normalizedTarget -match '^[A-Za-z]:$') {
    Write-Error "Target '$normalizedTarget' appears to be a drive root. Refusing to run robocopy /MIR. Aborting."
    exit 1
}

# 3. Ensure the empty folder exists, create if necessary
if (-not (Test-Path -Path $EmptyFolder -PathType Container)) {
    Write-Host "Empty folder does not exist. Creating: $EmptyFolder"
    New-Item -Path $EmptyFolder -ItemType Directory -Force | Out-Null
}

# 4. Ensure the empty folder is actually empty
$emptyContents = Get-ChildItem -Path $EmptyFolder -Force
if ($emptyContents.Count -gt 0) {
    Write-Error "Empty folder '$EmptyFolder' is NOT empty. Please clear it manually, then re-run. Aborting."
    exit 1
}

Write-Host "Safety checks passed. Proceeding to mirror empty folder onto target..." -ForegroundColor Yellow
Write-Host ""

# ---------------------------
# ROBOCOPY /MIR OPERATION
# ---------------------------

# Robocopy exit codes:
# 0  = No changes
# 1-7 = Success with different levels of copying/deletion
# >=8 = Failure
$arguments = @(
    $EmptyFolder,
    $TargetFolder,
    '/MIR',
    '/R:1',   # Retry once on failure
    '/W:1',   # Wait 1 second between retries
    '/NFL',   # No file list
    '/NDL',   # No directory list
    '/NJH',   # No job header
    '/NJS',   # No job summary
    '/NP'     # No progress
)

Write-Host "Running: robocopy $($arguments -join ' ')" -ForegroundColor Gray
& robocopy @arguments
$exitCode = $LASTEXITCODE

Write-Host ""
Write-Host "Robocopy exit code: $exitCode"

if ($exitCode -ge 8) {
    Write-Error "Robocopy reported a failure (exit code $exitCode). Review the output above."
    exit $exitCode
}

# ---------------------------
# POST-CHECK
# ---------------------------

# Check how many items remain in the target folder
$remaining = Get-ChildItem -Path $TargetFolder -Force | Measure-Object
Write-Host "Items remaining in target folder '$TargetFolder': $($remaining.Count)" -ForegroundColor Green

Write-Host "Bulk delete via robocopy /MIR completed. Review output and remaining item count before proceeding." -ForegroundColor Cyan
