﻿# Define the CSV file path containing the list of file paths 
$csvFilePath = "C:\temp\QCAD\TP\Log4Net\testing\log4net_eventlog-update-input.csv"

# Define the base search path for the files
$searchPath = "C:\temp\QCAD\TP\Log4Net\testing\"

# Import the list of file paths from the CSV
$fileList = Import-Csv -Path $csvFilePath

# Define the eventlog appender template
$eventlogAppenderTemplate = @"
<appender name='EventLogAppender' type='log4net.Appender.EventLogAppender'>
  <param name='LogName' value='Vision' />
  <param name='ApplicationName' value='{0}' />
  <filter type='log4net.Filter.LevelRangeFilter'>
    <param name='LevelMin' value='ERROR' />
    <param name='LevelMax' value='FATAL' />
  </filter>
  <layout type='log4net.Layout.PatternLayout'>
    <conversionPattern value='%date [%thread] %-5level %logger - %message%newline' />
  </layout>
</appender>
"@

# Process each file in the list
foreach ($file in $fileList) {
    $serverName = $file.Servername
    $fileName = $file.Filename
    
    # Search for the file recursively on the server's specified directory
    $filePath = Invoke-Command -ComputerName $serverName -ScriptBlock {
        param ($fileName, $searchPath)
        $files = Get-ChildItem -Path $searchPath -Filter $fileName -Recurse -ErrorAction SilentlyContinue
        if ($files) {
            return $files.FullName
        } else {
            return $null
        }
    } -ArgumentList $fileName, $searchPath

    if ($filePath) {
        # Create a backup of the original file
        $backupFilePath = "$filePath.old"
        Copy-Item -Path $filePath -Destination $backupFilePath -Force

        # Load the XML content of the config file
        [xml]$xmlConfig = Get-Content -Path $filePath

        # Get the application name to use as the source name
        $applicationName = [System.IO.Path]::GetFileNameWithoutExtension($fileName)

        # Create the eventlog appender XML node
        $eventlogAppenderXml = [xml]$([string]::Format($eventlogAppenderTemplate, $applicationName))

        # Append the eventlog appender to the appenders section
        $log4netNode = $xmlConfig.configuration.log4net
        $appendersNode = $log4netNode.appenders
        if (-not $appendersNode) {
            $appendersNode = $log4netNode.AppendChild($xmlConfig.CreateElement("appenders"))
        }
        $appendersNode.AppendChild($xmlConfig.ImportNode($eventlogAppenderXml.appender, $true))

        # Add the appender reference to the root section if it doesn't already exist
        $rootNode = $log4netNode.root
        $rootAppenderRefExists = $rootNode["appender-ref"] | Where-Object { $_.ref -eq "EventLogAppender" }
        if (-not $rootAppenderRefExists) {
            $rootAppenderRef = $xmlConfig.CreateElement("appender-ref")
            $rootAppenderRef.SetAttribute("ref", "EventLogAppender")
            $rootNode.AppendChild($rootAppenderRef)
        }

        # Add the appender reference to each logger if it doesn't already exist
        foreach ($logger in $log4netNode.logger) {
            $loggerAppenderRefExists = $logger["appender-ref"] | Where-Object { $_.ref -eq "EventLogAppender" }
            if (-not $loggerAppenderRefExists) {
                $appenderRef = $xmlConfig.CreateElement("appender-ref")
                $appenderRef.SetAttribute("ref", "EventLogAppender")
                $logger.AppendChild($appenderRef)
            }
        }

        # Save the modified XML back to the config file
        $xmlConfig.Save($filePath)

        Write-Host "Eventlog appender added to $filePath on server $serverName."
    } else {
        Write-Host "File $fileName not found on server $serverName."
    }
}
