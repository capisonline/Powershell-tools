﻿# Define the input and output locations 
$inputFolder = "C:\temp\QCAD\BA\LogMan\configs"
$outputCsv = "C:\temp\QCAD\BA\LogMan\configs\log4net_settings.csv"

# Create an array to hold the extracted data
$log4netData = @()

# Get all config files in the input folder
$configFiles = Get-ChildItem -Path $inputFolder #-Filter *.config

# Function to extract log4net settings from the config file
function Extract-Log4NetSettings {
    param (
        [string]$filePath
    )

    # Load the XML content
    [xml]$xmlContent = Get-Content -Path $filePath

    # Extract common log4net root settings
    $priority = $xmlContent.log4net.root.priority.value
    $appenderRefs = ($xmlContent.log4net.root.'appender-ref' | ForEach-Object { $_.ref }) -join ", "

    # Extract log4net appender settings
    $appenders = $xmlContent.log4net.appender | Where-Object { $_.type -eq 'log4net.Appender.RollingFileAppender' }

    foreach ($appender in $appenders) {
        $name = $appender.name
        $file = ($appender.param | Where-Object { $_.name -eq 'File' }).value
        $appendToFile = ($appender.param | Where-Object { $_.name -eq 'AppendToFile' }).value
        $maxSizeRollBackups = ($appender.param | Where-Object { $_.name -eq 'MaxSizeRollBackups' }).value
        $maximumFileSize = ($appender.param | Where-Object { $_.name -eq 'MaximumFileSize' }).value
        $rollingStyle = ($appender.param | Where-Object { $_.name -eq 'RollingStyle' }).value
        $lockingModel = ($appender.param | Where-Object { $_.name -eq 'LockingModel' }).value
        $staticLogFileName = ($appender.param | Where-Object { $_.name -eq 'StaticLogFileName' }).value
        $conversionPattern = $appender.layout.conversionPattern.value

        # Create a custom object to hold the extracted settings
        $log4netSettings = [PSCustomObject]@{
            FileName           = $filePath
            AppenderName       = $name
            Priority           = $priority
            AppenderRefs       = $appenderRefs
            File               = $file
            AppendToFile       = $appendToFile
            MaxSizeRollBackups = $maxSizeRollBackups
            MaximumFileSize    = $maximumFileSize
            RollingStyle       = $rollingStyle
            LockingModel       = $lockingModel
            StaticLogFileName  = $staticLogFileName
            ConversionPattern  = $conversionPattern
        }

        # Add the custom object to the array
        $log4netData += $log4netSettings
    }
}

# Iterate over each config file and extract settings
foreach ($configFile in $configFiles) {
    Extract-Log4NetSettings -filePath $configFile.FullName
}

# Export the extracted data to a CSV file
$log4netData | Export-Csv -Path $outputCsv -NoTypeInformation

# Display the results in a table
$log4netData | Format-Table -AutoSize
