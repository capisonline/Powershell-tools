﻿# Define the input and output locations 
$inputFolder = "C:\temp\QCAD\BA\LogMan\configs"
$outputCsv = "C:\temp\QCAD\BA\LogMan\configs\log4net_settings333.csv"

# Function to extract log4net rolling file appender information from XML file
function Get-Log4NetAppenders {
    param (
        [string]$filePath
    )
    
    [xml]$xmlContent = Get-Content -Path $filePath
    
    $appenders = @()
    
    foreach ($appender in $xmlContent.configuration.appender) {
        if ($appender.type -like "*RollingFileAppender*") {
            $appenderInfo = [PSCustomObject]@{
                FilePath        = $filePath
                AppenderName    = $appender.name
                AppenderType    = $appender.type
                File            = $null
                AppendToFile    = $null
                MaxSizeRollBackups = $null
                MaximumFileSize = $null
                RollingStyle    = $null
                LockingModel    = $null
                StaticLogFileName = $null
                ConversionPattern = $null
            }
            
            foreach ($param in $appender.param) {
                switch ($param.name) {
                    "File" { $appenderInfo.File = $param.value }
                    "AppendToFile" { $appenderInfo.AppendToFile = $param.value }
                    "MaxSizeRollBackups" { $appenderInfo.MaxSizeRollBackups = $param.value }
                    "MaximumFileSize" { $appenderInfo.MaximumFileSize = $param.value }
                    "RollingStyle" { $appenderInfo.RollingStyle = $param.value }
                    "LockingModel" { $appenderInfo.LockingModel = $param.value }
                    "StaticLogFileName" { $appenderInfo.StaticLogFileName = $param.value }
                }
            }

            if ($appender.layout -and $appender.layout.conversionPattern) {
                $appenderInfo.ConversionPattern = $appender.layout.conversionPattern.value
            }

            $appenders += $appenderInfo
        }
    }
    
    return $appenders
}

# Collect all log4net appender information from config files in the input folder
$allAppenders = @()
$files = Get-ChildItem -Path $inputFolder #-Filter *.config -Recurse
foreach ($file in $files) {
    $allAppenders += Get-Log4NetAppenders -filePath $file.FullName
}

# Export the collected information to a CSV file
$allAppenders | Export-Csv -Path $outputCsv -NoTypeInformation
