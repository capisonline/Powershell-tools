﻿# Define the directory to scan 
$rootDir = "C:\temp\QCAD\BA\LogMan\configs\"

# Define the output CSV file
$outputCsv = "C:\temp\QCAD\BA\LogMan\configs\log4net_settings77777.csv"

# Initialize an ArrayList to store the details
$configFiles = [System.Collections.ArrayList]@()

# Function to recursively scan for config files and extract log4net rolling file appender details
function Get-ConfigFiles {
    param (
        [string]$directory
    )

    # Get all config files in the current directory
    $files = Get-ChildItem -Path $directory -Filter "*.config" -File

    foreach ($file in $files) {
        try {
            # Parse the XML file to extract log4net rolling file appender details
            [xml]$xml = Get-Content -Path $file.FullName -Raw

            foreach ($appender in $xml.SelectNodes("//appender[@type='log4net.Appender.RollingFileAppender']")) {
                $appenderInfo = [PSCustomObject]@{
                    FileName          = $file.Name
                    FullPath          = $file.FullName
                    LastModified      = $file.LastWriteTime
                    AppenderName      = $appender.name
                    AppenderType      = $appender.type
                    File              = $appender.param | Where-Object { $_.name -eq "File" } | Select-Object -ExpandProperty value
                    AppendToFile      = $appender.param | Where-Object { $_.name -eq "AppendToFile" } | Select-Object -ExpandProperty value
                    MaxSizeRollBackups = $appender.param | Where-Object { $_.name -eq "MaxSizeRollBackups" } | Select-Object -ExpandProperty value
                    MaximumFileSize   = $appender.param | Where-Object { $_.name -eq "MaximumFileSize" } | Select-Object -ExpandProperty value
                    RollingStyle      = $appender.param | Where-Object { $_.name -eq "RollingStyle" } | Select-Object -ExpandProperty value
                    LockingModel      = $appender.param | Where-Object { $_.name -eq "LockingModel" } | Select-Object -ExpandProperty value
                    StaticLogFileName = $appender.param | Where-Object { $_.name -eq "StaticLogFileName" } | Select-Object -ExpandProperty value
                    ConversionPattern = $null
                }
                
                if ($appender.layout -and $appender.layout.conversionPattern) {
                    $appenderInfo.ConversionPattern = $appender.layout.conversionPattern.value
                }

                # Add the custom object to the ArrayList
                [void]$configFiles.Add($appenderInfo)
            }
        } catch {
            Write-Warning "Failed to parse XML file: $($file.FullName)"
        }
    }

    # Recursively scan subdirectories
    $subDirs = Get-ChildItem -Path $directory -Directory
    foreach ($subDir in $subDirs) {
        Get-ConfigFiles -directory $subDir.FullName
    }
}

# Start scanning from the root directory
Get-ConfigFiles -directory $rootDir

# Check if $configFiles is not null before exporting
if ($configFiles -ne $null -and $configFiles.Count -gt 0) {
    # Export the details to a CSV file
    $configFiles | Export-Csv -Path $outputCsv -NoTypeInformation
    Write-Host "Log4net appender details have been exported to $outputCsv"
} else {
    Write-Host "No log4net appenders found."
}

