﻿# Load necessary assemblies for XML parsing 
Add-Type -AssemblyName System.Xml

# Path to the Management Pack XML file
$mpXmlPath = "C:\temp\QCAD\PR\SCOM\Application.QCAD.xml"

# Load the XML file
$mpXml = [xml](Get-Content -Path $mpXmlPath)

# Extract Management Pack details
$mpName = $mpXml.ManagementPack.Name
$mpVersion = $mpXml.ManagementPack.Version

Write-Host "Management Pack Name: $mpName"
Write-Host "Management Pack Version: $mpVersion"
Write-Host "---------------------------------------"

# Extract and display Monitors
Write-Host "Monitors:"
$mpXml.ManagementPack.MonitorTypes.MonitorType | ForEach-Object {
    [PSCustomObject]@{
        ID = $_.ID
        DisplayName = $_.DisplayName
        Target = $_.Target
    }
} | Format-Table -AutoSize

# Extract and display Rules
Write-Host "`nRules:"
$mpXml.ManagementPack.Rules.Rule | ForEach-Object {
    [PSCustomObject]@{
        ID = $_.ID
        DisplayName = $_.DisplayName
        Target = $_.Target
    }
} | Format-Table -AutoSize

# Extract and display Discoveries
Write-Host "`nDiscoveries:"
$mpXml.ManagementPack.Discoveries.Discovery | ForEach-Object {
    [PSCustomObject]@{
        ID = $_.ID
        DisplayName = $_.DisplayName
        Target = $_.Target
    }
} | Format-Table -AutoSize

# Extract and display Tasks
Write-Host "`nTasks:"
$mpXml.ManagementPack.Tasks.Task | ForEach-Object {
    [PSCustomObject]@{
        ID = $_.ID
        DisplayName = $_.DisplayName
        Target = $_.Target
    }
} | Format-Table -AutoSize

# Extract and display Relationships
Write-Host "`nRelationships:"
$mpXml.ManagementPack.Relationships.Relationship | ForEach-Object {
    [PSCustomObject]@{
        ID = $_.ID
        Source = $_.Source
        Target = $_.Target
    }
} | Format-Table -AutoSize

# Extract and display Workflows
Write-Host "`nWorkflows:"
$mpXml.ManagementPack.Workflows.Workflow | ForEach-Object {
    [PSCustomObject]@{
        ID = $_.ID
        DisplayName = $_.DisplayName
        Target = $_.Target
    }
} | Format-Table -AutoSize

Write-Host "Summary extraction complete."
