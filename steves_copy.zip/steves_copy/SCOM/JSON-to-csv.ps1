﻿# Function to generate a report from the exported JSON settings 
function Generate-SCOMReport {
    param (
        [string]$JsonFilePath,
        [string]$ReportOutputPath
    )

    # Load the JSON file
    $jsonContent = Get-Content -Path $JsonFilePath | ConvertFrom-Json

    # Open a new report file for writing
    $reportFile = New-Item -Path $ReportOutputPath -ItemType File -Force
    $reportWriter = [System.IO.StreamWriter]::new($reportFile.FullName)

    # Write the header
    $reportWriter.WriteLine("SCOM Management Pack Report")
    $reportWriter.WriteLine("Generated on: $(Get-Date)")
    $reportWriter.WriteLine("========================================")
    $reportWriter.WriteLine("")

    # Write the found phrases
    $reportWriter.WriteLine("Found Phrases:")
    $reportWriter.WriteLine("-------------------------------")
    foreach ($phrase in $jsonContent.FoundPhrases.Keys) {
        $reportWriter.WriteLine("Phrase: $phrase")
        foreach ($match in $jsonContent.FoundPhrases[$phrase]) {
            $reportWriter.WriteLine("  Match: $match")
        }
        $reportWriter.WriteLine("")
    }

    # Write the additional patterns
    $reportWriter.WriteLine("Additional Patterns:")
    $reportWriter.WriteLine("-------------------------------")
    foreach ($pattern in $jsonContent.AdditionalPatterns) {
        $reportWriter.WriteLine("Pattern: $pattern")
    }

    # Close the report writer
    $reportWriter.Close()

    Write-Output "Report generated at $ReportOutputPath"
}

# Example usage
$jsonFilePath = "C:\temp\QCAD\PR\SCOM\latest_attempt\ExportedSettings.json"
$reportOutputPath = "C:\temp\QCAD\PR\SCOM\latest_attempt\SCOM_Report.txt"

Generate-SCOMReport -JsonFilePath $jsonFilePath -ReportOutputPath $reportOutputPath
