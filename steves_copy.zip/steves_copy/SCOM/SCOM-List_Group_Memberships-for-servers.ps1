﻿# this script checks all groups in scom for the memberships of the servers listed in the inputfile
# It saves the results in a csv with the hostname and group name 1 per row
# Input file requires fqdn: TWB-CCM-PR-04.prds.qldpol
# unfortunately due to the way it has to search, it's slow..... Sorry
# rogers.steven2@police.qld.gov.au
Import-Module OperationsManager 

# Path to the text file with server names
$serverListPath = "E:\Steve\Servers.txt"

# Path to the CSV output file
$outputCsvPath = "E:\Steve\ServerGroupMembership.csv"

# Read server names from the text file
$serverNames = Get-Content -Path $serverListPath

# Initialize an array to hold the results
$results = @()

# Get all SCOM groups
$SCOMGroups = Get-SCOMGroup

foreach ($serverName in $serverNames) {
    Write-Host "Checking groups for server: $serverName"
    foreach ($SCOMGroup in $SCOMGroups) {
        # Get the members of the current group
        $groupMembers = Get-SCOMGroup -DisplayName $SCOMGroup.DisplayName | Get-SCOMClassInstance

        # Check if the server is a member of this group
        $isMember = $groupMembers | Where-Object { $_.DisplayName -eq $serverName }

        if ($isMember) {
            # Add the result to the results array
            $results += [PSCustomObject]@{
                ServerName = $serverName
                GroupName  = $SCOMGroup.DisplayName
            }
            # Display the found group
            Write-Host " - Found in group: $($SCOMGroup.DisplayName)"
        }
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

Write-Host "Group membership information has been saved to $outputCsvPath"
