﻿# Function to parse and export the entire management pack
function Parse-EntireSCOMManagementPack {
    param (
        [string]$ManagementPackPath,
        [string]$OutputPath
    )

    # Load the management pack XML
    [xml]$mpXml = Get-Content -Path $ManagementPackPath

    # Create a hashtable to store the settings
    $mpInfo = @{}

    # Collect basic information
    $mpInfo["ID"] = $mpXml.ManagementPack.Manifest.Identity.ID
    $mpInfo["Version"] = $mpXml.ManagementPack.Manifest.Identity.Version
    $mpInfo["Name"] = $mpXml.ManagementPack.Manifest.Identity.Alias

    # Collect display strings
    $mpInfo["DisplayStrings"] = $mpXml.ManagementPack.LanguagePacks.LanguagePack.DisplayStrings.DisplayString | ForEach-Object {
        @{
            ElementID = $_.ElementID
            Name = $_.Name
            Description = $_.Description
        }
    }

    # Collect references
    $mpInfo["References"] = $mpXml.ManagementPack.Manifest.References.Reference | ForEach-Object {
        @{
            Alias = $_.Alias
            ID = $_.ID
            Version = $_.Version
            PublicKeyToken = $_.PublicKeyToken
        }
    }

    # Collect monitoring objects
    $mpInfo["Monitors"] = $mpXml.ManagementPack.Monitoring.Monitors.Monitor | ForEach-Object {
        @{
            ID = $_.ID
            DisplayName = $_.DisplayName
            Target = $_.Target
            Category = $_.Category
            Enabled = $_.Enabled
            Expression = $_.Expression.InnerXml
        }
    }

    # Collect rules
    $mpInfo["Rules"] = $mpXml.ManagementPack.Monitoring.Rules.Rule | ForEach-Object {
        @{
            ID = $_.ID
            DisplayName = $_.DisplayName
            Target = $_.Target
            DataSource = $_.DataSources.DataSourceModule.TypeID
            ConditionDetection = $_.ConditionDetectionModules.ConditionDetectionModule.TypeID
            WriteActions = $_.WriteActions.WriteActionModule.TypeID
        }
    }

    # Collect discoveries
    $mpInfo["Discoveries"] = $mpXml.ManagementPack.Monitoring.Discoveries.Discovery | ForEach-Object {
        @{
            ID = $_.ID
            DisplayName = $_.DisplayName
            Target = $_.Target
            Enabled = $_.Enabled
            DataSource = $_.DataSourceModule.TypeID
        }
    }

    # Collect module types
    $mpInfo["ModuleTypes"] = $mpXml.ManagementPack.ModuleTypes | ForEach-Object {
        @{
            ID = $_.ID
            Configuration = $_.Configuration.InnerXml
        }
    }

    # Collect knowledge articles
    $mpInfo["KnowledgeArticles"] = $mpXml.ManagementPack.KnowledgeArticles.KnowledgeArticle | ForEach-Object {
        @{
            ArticleID = $_.ID
            LanguageCode = $_.LanguageCode
            Text = $_.Text
        }
    }

    # Export the information to a JSON file for documentation
    $mpInfo | ConvertTo-Json | Out-File -FilePath $OutputPath

    Write-Output "Management pack information exported to $OutputPath"
}

# Example usage
$managementPackPath = "C:\temp\QCAD\PR\SCOM\latest_attempt\Application.QCAD.xml"
$outputPath = "C:\temp\QCAD\PR\SCOM\latest_attempt\ExportedManagementPack777.json"

Parse-EntireSCOMManagementPack -ManagementPackPath $managementPackPath -OutputPath $outputPath
