﻿# Load necessary SCOM modules 
Import-Module OperationsManager

# Function to export settings from a management pack
function Export-SCOMManagementPackSettings {
    param (
        [string]$ManagementPackPath,
        [string]$OutputPath,
        [string]$InputPhrasesPath
    )

    # Load the management pack XML
    [xml]$mpXml = Get-Content -Path $ManagementPackPath

    # Create a hashtable to store the settings
    $settings = @{}

    # Read phrases from the input text file
    $phrases = Get-Content -Path $InputPhrasesPath

    # Extract hardcoded server names and regex patterns
    $foundPhrases = @{}
    foreach ($phrase in $phrases) {
        $foundPhrases[$phrase] = @()

        # Find the phrase in the management pack XML
        $matches = Select-Xml -Xml $mpXml -XPath "//*[contains(text(),'$phrase')]"
        foreach ($match in $matches) {
            $foundPhrases[$phrase] += $match.Node.OuterXml
        }
    }

    $settings["FoundPhrases"] = $foundPhrases

    # Attempt to find additional regex patterns that may have been missed
    $additionalPatterns = Select-Xml -Xml $mpXml -XPath "//*[contains(text(),'regex') or contains(text(),'pattern')]"
    $settings["AdditionalPatterns"] = $additionalPatterns | ForEach-Object { $_.Node.InnerText }

    # Export the settings to a JSON file for documentation
    $settings | ConvertTo-Json | Out-File -FilePath $OutputPath

    Write-Output "Settings exported to $OutputPath"
}

# Example usage
$managementPackPath = "C:\temp\QCAD\PR\SCOM\latest_attempt\Application.QCAD.xml"
$outputPath = "C:\temp\QCAD\PR\SCOM\latest_attempt\ExportedSettings.json"
$inputPhrasesPath = "C:\temp\QCAD\PR\SCOM\latest_attempt\phrases.txt"

Export-SCOMManagementPackSettings -ManagementPackPath $managementPackPath -OutputPath $outputPath -InputPhrasesPath $inputPhrasesPath
