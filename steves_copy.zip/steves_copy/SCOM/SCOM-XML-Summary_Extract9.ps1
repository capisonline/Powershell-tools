﻿# This script parses all the monitors for a scom managemnet pack.
# It's the closest to building an accurate doco I could get in a short timeframe
# Define the path to the XML file 
$xmlFilePath = "C:\temp\QCAD\PR\SCOM\application.ARL.xml"
# Define the path to the CSV file to export the rules
$csvFilePath = "C:\temp\QCAD\PR\SCOM\application.ARL.xml---Parsed.csv"

# Load the XML content
[xml]$xmlContent = Get-Content -Path $xmlFilePath

# Initialize an array to hold the parsed rules
$rules = @()

# Iterate through the DisplayString elements to extract rules
$xmlContent.SelectNodes("//DisplayString") | ForEach-Object {
    $elementId = $_.ElementID
    $name = $_.Name
    $description = $_.Description

    # Determine the type based on the ElementID
    $type = "Unknown"
    if ($elementId -like "*.AlertMessage") {
        $type = "Alert Message"
    } elseif ($elementId -like "*.Rule") {
        $type = "Rule"
    } elseif ($elementId -like "*.Monitor") {
        $type = "Monitor"
    } elseif ($elementId -like "MomUIGeneratedRule*") {
        $type = "MOM UI Generated Rule"
    } elseif ($elementId -like "UIGeneratedRule*") {
        $type = "UI Generated Rule"
    }

    # Create a custom object for the rule
    $rule = [PSCustomObject]@{
        ElementID    = $elementId
        Type         = $type
        Name         = $name
        Description  = $description
    }

    # Add the rule to the array
    $rules += $rule
}

# Write the rules to a CSV file
$rules | Export-Csv -Path $csvFilePath -NoTypeInformation

Write-Host "Export completed. The custom rules have been saved to $csvFilePath"
