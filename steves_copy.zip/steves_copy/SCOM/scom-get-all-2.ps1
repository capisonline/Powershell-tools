﻿# Load the Operations Manager module 
Import-Module OperationsManager

# Set up the connection to your SCOM management server
$managementServer = "QPS-MGT-PR-21"
New-SCOMManagementGroupConnection -ComputerName $managementServer

# Get all SCOM groups
$groups = Get-SCOMGroup

# Initialize an array to store the output
$output = @()

# Loop through each group
foreach ($group in $groups) {
    $groupName = $group.DisplayName
    Write-Host "Processing group: $groupName"

    # Get the members of the group
    $members = Get-SCOMClassInstance -Instance $group

    # Loop through each member and add it to the output array
    foreach ($member in $members) {
        $output += [PSCustomObject]@{
            GroupName = $groupName
            ServerName = $member.DisplayName
        }
    }
}

# Export the output to a CSV file
$output | Export-Csv -Path "E:\Steve\SCOMGroupMemberships222.csv" -NoTypeInformation

Write-Output "CSV file 'SCOMGroupMemberships.csv' has been created successfully."
Write-Host "Script completed."
