﻿# Load the Operations Manager module 
Import-Module OperationsManager

# Set up the connection to your SCOM management server
$managementServer = "YourManagementServerName"
New-SCOMManagementGroupConnection -ComputerName $managementServer

# Function to get SCOM group members recursively
function Get-SCOMGroupMembers {
    param (
        [Microsoft.EnterpriseManagement.Monitoring.MonitoringObject]$group
    )

    $members = @()
    
    # Get all instances that are members of the group
    $relationshipClass = Get-SCOMRelationshipClass -Name "Microsoft.SystemCenter.InstanceGroupContainsEntities"
    $memberInstances = Get-SCOMRelationshipInstance -Relationship $relationshipClass | Where-Object { $_.SourceObject.Id -eq $group.Id }

    foreach ($memberInstance in $memberInstances) {
        $members += $memberInstance.TargetObject

        # Check if the target object is a group itself and get its members recursively
        if ($memberInstance.TargetObject.OriginalMonitoringClassName -eq "Microsoft.SystemCenter.InstanceGroup") {
            $subGroup = Get-SCOMGroup | Where-Object { $_.Id -eq $memberInstance.TargetObject.Id }
            if ($subGroup) {
                $members += Get-SCOMGroupMembers -group $subGroup
            }
        }
    }

    return $members
}

# Get all SCOM groups
$groups = Get-SCOMGroup

# Initialize an array to store the output
$output = @()

# Loop through each group
foreach ($group in $groups) {
    $groupName = $group.DisplayName
    Write-Host "Processing group: $groupName"

    # Get the members of the group
    $members = Get-SCOMGroupMembers -group $group

    # Loop through each member and add it to the output array
    foreach ($member in $members) {
        $output += [PSCustomObject]@{
            GroupName = $groupName
            ServerName = $member.DisplayName
        }
    }
}

# Export the output to a CSV file
$output | Export-Csv -Path "SCOMGroupMemberships.csv" -NoTypeInformation

Write-Output "CSV file 'SCOMGroupMemberships.csv' has been created successfully."
Write-Host "Script completed."
