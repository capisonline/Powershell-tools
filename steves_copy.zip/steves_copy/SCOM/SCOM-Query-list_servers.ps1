﻿# Load SCOM SDK Assemblies 
Add-Type -Path "C:\temp\scripts\SCOM\Microsoft.EnterpriseManagement.Core.dll"
Add-Type -Path "C:\temp\scripts\SCOM\Microsoft.EnterpriseManagement.OperationsManager.dll"

# Connect to the SCOM management server
$scomServer = "QPS-MGT-PR-20.prds.qldpol"
$managementGroup = New-Object Microsoft.EnterpriseManagement.ManagementGroup($scomServer)

# Path to the text file with the list of server names
$serverListPath = "C:\temp\QCAD\PR\SCOM\Servers.txt"

# Read the list of server names
$servers = Get-Content -Path $serverListPath

# Create directories to store the exported data
$exportPath = "C:\temp\QCAD\PR\SCOM"
$monitorsPath = Join-Path -Path $exportPath -ChildPath "Monitors"
$rulesPath = Join-Path -Path $exportPath -ChildPath "Rules"
New-Item -ItemType Directory -Path $monitorsPath -Force
New-Item -ItemType Directory -Path $rulesPath -Force

foreach ($server in $servers) {
    Write-Host "Processing server: $server"

    # Get the class instance for the server
    $criteria = New-Object Microsoft.EnterpriseManagement.Common.ObjectCriteria("DisplayName = '$server'", 
                [Microsoft.EnterpriseManagement.Configuration.MonitoringClass]::GetMonitoringClass)
    $serverInstances = $managementGroup.EntityObjects.GetObjectReader($criteria, 
                [Microsoft.EnterpriseManagement.Common.ObjectQueryOptions]::None)

    if ($serverInstances.Count -gt 0) {
        $serverInstance = $serverInstances[0]

        # Get all monitors applied to the server
        $monitors = $serverInstance.GetMonitors()
        $monitorData = $monitors | ForEach-Object {
            [PSCustomObject]@{
                ID          = $_.Id
                DisplayName = $_.DisplayName
                Target      = $_.Target.DisplayName
                Category    = $_.Category
                Enabled     = $_.IsEnabled
            }
        }
        $monitorData | Export-Csv -Path (Join-Path -Path $monitorsPath -ChildPath "$server-Monitors.csv") -NoTypeInformation

        # Get all rules applied to the server
        $rules = $serverInstance.GetRules()
        $ruleData = $rules | ForEach-Object {
            [PSCustomObject]@{
                ID          = $_.Id
                DisplayName = $_.DisplayName
                Target      = $_.Target.DisplayName
                Category    = $_.Category
                Enabled     = $_.IsEnabled
            }
        }
        $ruleData | Export-Csv -Path (Join-Path -Path $rulesPath -ChildPath "$server-Rules.csv") -NoTypeInformation
    } else {
        Write-Host "Server $server not found in SCOM"
    }
}

Write-Host "Export complete. Check the $exportPath directory for details."
