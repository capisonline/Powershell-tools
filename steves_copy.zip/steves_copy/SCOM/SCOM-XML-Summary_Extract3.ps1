﻿# Load necessary assemblies for XML parsing 
Add-Type -AssemblyName System.Xml

# Path to the Management Pack XML file
$mpXmlPath = "C:\temp\QCAD\PR\SCOM\Application.QCAD.xml"

# Load the XML file
$mpXml = [xml](Get-Content -Path $mpXmlPath)

# Extract Management Pack details
$mpName = $mpXml.ManagementPack.Manifest.Identity.ID
$mpVersion = $mpXml.ManagementPack.Manifest.Identity.Version

Write-Host "Management Pack Name: $mpName"
Write-Host "Management Pack Version: $mpVersion"
Write-Host "---------------------------------------"

# Function to extract details from XML nodes
function Extract-Details {
    param (
        [xml[]]$xmlNodes,
        [string[]]$properties
    )

    $details = @()
    foreach ($node in $xmlNodes) {
        $item = [ordered]@{}
        foreach ($property in $properties) {
            if ($node.SelectSingleNode($property) -ne $null) {
                $item[$property] = $node.SelectSingleNode($property).InnerText
            }
        }
        $details += [PSCustomObject]$item
    }

    return $details
}

# Function to extract custom details
function Extract-CustomDetails {
    param (
        [xml]$xmlElement
    )

    $actions = @()
    $logNames = @()
    $serverNames = @()
    $comments = @()

    foreach ($node in $xmlElement.SelectNodes("//Action")) {
        $actions += [PSCustomObject]@{
            LogName    = $node.SelectSingleNode("LogName").InnerText
            ServerName = $node.SelectSingleNode("ServerName").InnerText
            ActionType = $node.SelectSingleNode("ActionType").InnerText
            Comment    = $node.SelectSingleNode("Comment").InnerText
        }
    }

    foreach ($node in $xmlElement.SelectNodes("//*[LogName]")) {
        $logNames += $node.SelectSingleNode("LogName").InnerText
    }
    
    foreach ($node in $xmlElement.SelectNodes("//*[ServerName]")) {
        $serverNames += $node.SelectSingleNode("ServerName").InnerText
    }
    
    foreach ($node in $xmlElement.SelectNodes("//*[Comment]")) {
        $comments += $node.SelectSingleNode("Comment").InnerText
    }

    return @{
        Actions     = $actions
        LogNames    = $logNames | Sort-Object -Unique
        ServerNames = $serverNames | Sort-Object -Unique
        Comments    = $comments | Sort-Object -Unique
    }
}

# Path to save the CSV files
$exportPath = "C:\temp\QCAD\PR\SCOM\extract_summary"
if (-not (Test-Path -Path $exportPath)) {
    New-Item -ItemType Directory -Path $exportPath
}

# Extract and save Monitors
if ($mpXml.ManagementPack.Monitors.Monitor) {
    Write-Host "Monitors:"
    $monitors = Extract-Details -xmlNodes $mpXml.ManagementPack.Monitors.Monitor -properties @('ID', 'DisplayName', 'Target')
    $monitors | Export-Csv -Path "$exportPath\Monitors.csv" -NoTypeInformation -Force
    Write-Host "Monitors saved to $exportPath\Monitors.csv"
} else {
    Write-Host "No monitors found."
}

# Extract and save Rules
if ($mpXml.ManagementPack.Rules.Rule) {
    Write-Host "`nRules:"
    $rules = Extract-Details -xmlNodes $mpXml.ManagementPack.Rules.Rule -properties @('ID', 'DisplayName', 'Target')
    $rules | Export-Csv -Path "$exportPath\Rules.csv" -NoTypeInformation -Force
    Write-Host "Rules saved to $exportPath\Rules.csv"
} else {
    Write-Host "No rules found."
}

# Extract and save Discoveries
if ($mpXml.ManagementPack.Discoveries.Discovery) {
    Write-Host "`nDiscoveries:"
    $discoveries = Extract-Details -xmlNodes $mpXml.ManagementPack.Discoveries.Discovery -properties @('ID', 'DisplayName', 'Target')
    $discoveries | Export-Csv -Path "$exportPath\Discoveries.csv" -NoTypeInformation -Force
    Write-Host "Discoveries saved to $exportPath\Discoveries.csv"
} else {
    Write-Host "No discoveries found."
}

# Extract and save Tasks
if ($mpXml.ManagementPack.Tasks.Task) {
    Write-Host "`nTasks:"
    $tasks = Extract-Details -xmlNodes $mpXml.ManagementPack.Tasks.Task -properties @('ID', 'DisplayName', 'Target')
    $tasks | Export-Csv -Path "$exportPath\Tasks.csv" -NoTypeInformation -Force
    Write-Host "Tasks saved to $exportPath\Tasks.csv"
} else {
    Write-Host "No tasks found."
}

# Extract and save Custom Details (e.g., actions, comments)
Write-Host "`nCustom Details (Actions, Comments, etc.):"
$customDetails = Extract-CustomDetails -xmlElement $mpXml.ManagementPack
if ($customDetails.Actions.Count -gt 0) {
    $customDetails.Actions | Export-Csv -Path "$exportPath\Actions.csv" -NoTypeInformation -Force
    Write-Host "Actions saved to $exportPath\Actions.csv"
} else {
    Write-Host "No actions found."
}

if ($customDetails.LogNames.Count -gt 0) {
    $customDetails.LogNames | Export-Csv -Path "$exportPath\LogNames.csv" -NoTypeInformation -Force
    Write-Host "Log Names saved to $exportPath\LogNames.csv"
} else {
    Write-Host "No log names found."
}

if ($customDetails.ServerNames.Count -gt 0) {
    $customDetails.ServerNames | Export-Csv -Path "$exportPath\ServerNames.csv" -NoTypeInformation -Force
    Write-Host "Server Names saved to $exportPath\ServerNames.csv"
} else {
    Write-Host "No server names found."
}

if ($customDetails.Comments.Count -gt 0) {
    $customDetails.Comments | Export-Csv -Path "$exportPath\Comments.csv" -NoTypeInformation -Force
    Write-Host "Comments saved to $exportPath\Comments.csv"
} else {
    Write-Host "No comments found."
}

Write-Host "Summary extraction complete."
