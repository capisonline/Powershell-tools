﻿$WShell = New-Object -com "Wscript.Shell"
while ($true)
{ 
$WShell.sendkeys("{NUMLOCK}")
Start-Sleep -Milliseconds 10
$WShell.sendkeys("{NUMLOCK}")
Start-Sleep -Seconds 120
}


<#WMDGN-G9PQG-XVVXX-R3X43-63DFG

# decr:6
# system.data.oracleclient
# oracle.dataaccess.client


# cni tester 
# sql tables


#System.Data.OracleClient Namespace
#https://learn.microsoft.com/en-us/dotnet/api/system.data.oracleclient?view=dotnet-plat-ext-8.0

#Oracle and ADO.NET
#https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/oracle-and-adonet

TWBPCADCCMPR04
TWBPCADCCMPR03
BNLPCADCCMPR04
TNVPCADCCMPR04
TNVPCADCCMPR03
CNSPCADCCMPR04
CNSPCADCCMPR03
BNEPCADCCMPR05
BNEPCADCCMPR04

#>

<#
machine.config - no mention of v4 in 
Go to installation location

C:\Windows\Microsoft.NET\Framework\vXXXX\Config folder and locate the machine.config.default file

Step: 2

Open the file with editor and find the following lines

<DbProviderFactories/> //Remove this line

Step: 3

Add the following lines

XML
 <DbProviderFactories>

<add name="SqlClient Data Provider" invariant="System.Data.SqlClient" description=".Net Framework Data Provider for SqlServer" type="System.Data.SqlClient.SqlClientFactory, System.Data, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089""/>

</DbProviderFactories>




possibly registered incorrect DLL
d:
cd d:\oracle\product\19.0.0\client_1\ODP.NET\bin\2.x
OraProvCfg.exe /action:gac /providerpath:"D:\oracle\product\19.0.0\client_1\ODP.NET\bin\2.x\Oracle.DataAccess.dll"

#>



