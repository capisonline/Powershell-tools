﻿# Path to the text file with the server names (one per line)
$serverListPath = "C:\temp\QCAD\PA\PA_NEW_Server_list.txt"

# Log file to track results
$logPath = "C:\temp\QCAD\PA\PA_ShutdownLog.txt"

# Read the list of servers
$servers = Get-Content -Path $serverListPath

foreach ($server in $servers) {
    try {
        Write-Host "Attempting to shut down $server..." -ForegroundColor Cyan

        Invoke-Command -ComputerName $server -ScriptBlock {
            Stop-Computer -Force
        }  -ErrorAction Stop

        "$server - Shutdown initiated successfully." | Out-File -FilePath $logPath -Append
    }
    catch {
        "$server - ERROR: $_" | Out-File -FilePath $logPath -Append
    }
}
