﻿# Input and output files 
$ServerList = "C:\temp\QCAD\TP\TP_NEW_Server_list.txt"  # List of servers (one per line)
$OutputFile = "C:\temp\QCAD\TP\GAC_Assemblies\GAC_Report-TP.csv"  # Output CSV file


# Initialize output
$Results = @()

# Read server list
$Servers = Get-Content -Path $ServerList

# Iterate through each server
foreach ($Server in $Servers) {
    try {
        Write-Host "Connecting to $Server..." -ForegroundColor Green

        # Invoke command to get GAC assemblies
        $GACAssemblies = Invoke-Command -ComputerName $Server -ScriptBlock {
            # Define the GAC paths
            $GACPaths = @(
                "C:\Windows\Microsoft.NET\assembly\GAC_MSIL",
                "C:\Windows\Microsoft.NET\assembly\GAC_32",
                "C:\Windows\Microsoft.NET\assembly\GAC_64"
            )

            # Collect assembly details
            $Assemblies = foreach ($Path in $GACPaths) {
                if (Test-Path $Path) {
                    Get-ChildItem -Path $Path -Recurse -Directory | ForEach-Object {
                        [PSCustomObject]@{
                            AssemblyName = $_.Name
                            Path         = $_.FullName
                        }
                    }
                }
            }

            $Assemblies
        } -ErrorAction Stop

        # Add results to the collection
        $Results += $GACAssemblies | Select-Object -Property AssemblyName, Path, @{Name="Server";Expression={$Server}}
    }
    catch {
        Write-Warning "Failed to connect to $Server or query GAC. Error: $_"
    }
}

# Export results to CSV
if ($Results.Count -gt 0) {
    $Results | Export-Csv -Path $OutputFile -NoTypeInformation -Force
    Write-Host "GAC list saved to $OutputFile" -ForegroundColor Yellow
} else {
    Write-Host "No data collected. Check for errors in connectivity or permissions." -ForegroundColor Red
}
