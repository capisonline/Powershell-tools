﻿$filePath = "C:\temp\QCAD\VT\Fail_Testing\Fail_over_DC\Reboot_list.txt"
$computerNames = Get-Content $filePath | ForEach-Object { $_.Trim() } | Where-Object { $_ }

foreach ($computer in $computerNames) {
  Write-Host "Attempting to restart $computer..."
  & shutdown.exe /r /m "\\$computer" /f /t 0 2>&1 | ForEach-Object { Write-Host "  $_" }

  if ($LASTEXITCODE -eq 0) {
    Write-Host "${computer}: accepted."
  } else {
    Write-Host "${computer}: FAILED (exit code $LASTEXITCODE)."
  }
}
