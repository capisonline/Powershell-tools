﻿<#.\QCAD_MergePatch.ps1 `
  -OldEnvXmlPath 'C:\temp\QCAD\VT\Configs\Merging\OLD\OLD_VT.xml' `
  -NewEnvXmlPath 'C:\temp\QCAD\VT\Configs\Merging\NEW\NEW_VT.xml' `
  -ConfigRoot 'C:\temp\QCAD\VT\Configs\Merging\NEW' `
  -OutputRoot 'C:\temp\QCAD\VT\Configs\Merged_Output\testing' `
  -ScopeCsvPath C:\temp\QCAD\VT\Configs\Merging\Merge_required_results_VT.csv

#>
param(
    [Parameter(Mandatory=$true)] [string]$OldEnvXmlPath,
    [Parameter(Mandatory=$true)] [string]$NewEnvXmlPath,
    [Parameter(Mandatory=$true)] [string]$ConfigRoot,
    [Parameter(Mandatory=$true)] [string]$OutputRoot,
    [string]$ScopeCsvPath = "",
    [switch]$ApplyChanges
)

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath    = Join-Path $OutputRoot "QCAD_MergePatch_$ts.log"
$reportPath = Join-Path $OutputRoot "QCAD_MergePatch_Report_$ts.csv"

New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null
"File,Setting,OldValue,NewValue,Rule,Status,Notes" | Out-File $reportPath -Encoding UTF8

function Log([string]$msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    $line | Tee-Object -FilePath $logPath -Append | Out-Null
}

function Add-ReportRow {
    param(
        [string]$File,
        [string]$Setting,
        [string]$OldValue,
        [string]$NewValue,
        [string]$Rule,
        [string]$Status,
        [string]$Notes = ""
    )
    """$File"",""$Setting"",""$OldValue"",""$NewValue"",""$Rule"",""$Status"",""$Notes""" |
        Out-File $reportPath -Append -Encoding UTF8
}

function Load-XmlDoc([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { throw "File not found: $path" }
    $doc = New-Object System.Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    $doc.Load($path)
    return $doc
}

function Get-LeafTextValues([System.Xml.XmlNode]$node) {
    $vals = New-Object System.Collections.Generic.List[string]
    foreach ($child in $node.ChildNodes) {
        if ($child.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }
        $hasElementChildren = $false
        foreach ($gc in $child.ChildNodes) {
            if ($gc.NodeType -eq [System.Xml.XmlNodeType]::Element) { $hasElementChildren = $true; break }
        }
        if ($hasElementChildren) {
            $nested = Get-LeafTextValues $child
            foreach ($n in $nested) { [void]$vals.Add($n) }
        } else {
            $txt = $child.InnerText.Trim()
            if (-not [string]::IsNullOrWhiteSpace($txt)) { [void]$vals.Add($txt) }
        }
    }
    return $vals
}

function Join-UniqueOrdered {
    param(
        [string[]]$OldItems,
        [string[]]$NewItems
    )
    $out = New-Object System.Collections.Generic.List[string]
    $seen = @{}
    foreach ($item in @($OldItems + $NewItems)) {
        if ([string]::IsNullOrWhiteSpace($item)) { continue }
        if (-not $seen.ContainsKey($item)) {
            $seen[$item] = $true
            [void]$out.Add($item)
        }
    }
    return $out
}

function Get-ServerMaps([xml]$envXml) {
    $map = @{
        VAS = @()
        APL = @()
        CCM = @()
        VCS = @()
        VWS = @()
        VIM = @()
        VMG = @()
    }

    foreach ($node in $envXml.QCAD.Variable.Inputs.Servers.ChildNodes) {
        if ($node.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }
        $name = $node.Name
        if ($map.ContainsKey($name)) {
            $obj = [ordered]@{}
            foreach ($child in $node.ChildNodes) {
                if ($child.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }
                if ($child.Name -eq 'VasOrder') {
                    $order = @()
                    foreach ($l in $child.List) { $order += [int]$l.InnerText.Trim() }
                    $obj['VasOrder'] = $order
                } elseif ($child.Name -eq 'RequiredAddress') {
                    $addrs = @()
                    foreach ($a in $child.Address) { $addrs += $a.InnerText.Trim() }
                    $obj['RequiredAddress'] = $addrs
                } else {
                    $obj[$child.Name] = $child.InnerText.Trim()
                }
            }
            $map[$name] += [pscustomobject]$obj
        }
    }
    return $map
}

function Get-MergedVasList($oldMap, $newMap) {
    $list = @()
    foreach ($v in $oldMap.VAS) {
        $list += [pscustomobject]@{
            Cohort   = "OLD"
            HostName = $v.HostName
            IpAddress = $v.IpAddress
            Required = $v.Required
            RequiredAddress = $v.RequiredAddress
        }
    }
    foreach ($v in $newMap.VAS) {
        $list += [pscustomobject]@{
            Cohort   = "NEW"
            HostName = $v.HostName
            IpAddress = $v.IpAddress
            Required = $v.Required
            RequiredAddress = $v.RequiredAddress
        }
    }
    return $list
}

function Apply-OrderPattern {
    param(
        [object[]]$OldItems,
        [object[]]$NewItems,
        [int[]]$Pattern
    )
    $ordered = New-Object System.Collections.Generic.List[object]
    if (-not $Pattern -or $Pattern.Count -eq 0) {
        foreach ($i in $OldItems) { [void]$ordered.Add($i) }
        foreach ($i in $NewItems) { [void]$ordered.Add($i) }
        return $ordered
    }
    foreach ($idx in $Pattern) {
        if ($idx -ge 1 -and $idx -le $OldItems.Count) { [void]$ordered.Add($OldItems[$idx-1]) }
    }
    foreach ($idx in $Pattern) {
        if ($idx -ge 1 -and $idx -le $NewItems.Count) { [void]$ordered.Add($NewItems[$idx-1]) }
    }
    return $ordered
}

function Build-MergeContext($oldMap, $newMap) {
    $ctx = [ordered]@{}
    $ctx['MergedVAS'] = Get-MergedVasList $oldMap $newMap
    $ctx['OldAPL'] = $oldMap.APL
    $ctx['NewAPL'] = $newMap.APL
    $ctx['MergedAPL'] = @($oldMap.APL + $newMap.APL)
    return $ctx
}

function Get-ThisServerFromPath([string]$filePath, [string]$configRoot) {
    $rel = $filePath.Substring($configRoot.Length).TrimStart('\','/')
    $parts = $rel -split '[\\/]'
    if ($parts.Count -ge 1) { return $parts[0] }
    return ""
}

function Find-ServerObject($maps, [string]$hostName) {
    foreach ($group in @('CCM','VCS','VAS','APL','VWS','VIM','VMG')) {
        foreach ($s in $maps[$group]) {
            if ($s.HostName -eq $hostName) { return $s }
        }
    }
    return $null
}

function Get-OrderedMergedVasForServer($oldMap, $newMap, [string]$serverHostName) {
    $oldS = Find-ServerObject $oldMap $serverHostName
    $newS = Find-ServerObject $newMap $serverHostName

    $pattern = $null
    if ($oldS -and $oldS.PSObject.Properties.Name -contains 'VasOrder') {
        $pattern = $oldS.VasOrder
    } elseif ($newS -and $newS.PSObject.Properties.Name -contains 'VasOrder') {
        $pattern = $newS.VasOrder
    }

    return Apply-OrderPattern -OldItems $oldMap.VAS -NewItems $newMap.VAS -Pattern $pattern
}

function Get-MergedPipeValue {
    param(
        [string[]]$OldItems,
        [string[]]$NewItems
    )
    $merged = Join-UniqueOrdered -OldItems $OldItems -NewItems $NewItems
    return ($merged -join '|')
}

function Split-PipeValue([string]$value) {
    if ([string]::IsNullOrWhiteSpace($value)) { return @() }
    return @($value -split '\|')
}

function Get-MergedMlsGateways($oldMap, $newMap) {
    $old = @()
    foreach ($a in $oldMap.APL) {
        $old += "http://$($a.HostName).PRDS.QLDPOL/VisVT_MlsGateway/MlsGateway.asmx"
    }
    $new = @()
    foreach ($a in $newMap.APL) {
        $new += "http://$($a.HostName).PRDS.QLDPOL/VisVT_MlsGateway/MlsGateway.asmx"
    }
    return Get-MergedPipeValue -OldItems $old -NewItems $new
}

function Get-MergedCadHosts($oldMap, $newMap) {
    $old = @($oldMap.VAS | ForEach-Object { $_.IpAddress })
    $new = @($newMap.VAS | ForEach-Object { $_.IpAddress })
    return Get-MergedPipeValue -OldItems $old -NewItems $new
}

function Get-MergedHostsForServer($oldMap, $newMap, [string]$serverHostName, [string]$suffix = '') {
    $ordered = Get-OrderedMergedVasForServer -oldMap $oldMap -newMap $newMap -serverHostName $serverHostName
    $vals = New-Object System.Collections.Generic.List[string]
    foreach ($v in $ordered) {
        $entry = $v.IpAddress
        if ($suffix) { $entry = "${entry}:$suffix" }
        [void]$vals.Add($entry)
    }
    return $vals
}

function Get-MergedSyncHostsForServer($oldMap, $newMap, [string]$serverHostName, [string]$siteCode = '') {
    $oldServerObj = Find-ServerObject $oldMap $serverHostName
    $newServerObj = Find-ServerObject $newMap $serverHostName
    if ($oldServerObj -and $oldServerObj.PSObject.Properties.Name -contains 'SiteCode') { $siteCode = $oldServerObj.SiteCode }
    if (-not $siteCode -and $newServerObj -and $newServerObj.PSObject.Properties.Name -contains 'SiteCode') { $siteCode = $newServerObj.SiteCode }

    $ordered = Get-OrderedMergedVasForServer -oldMap $oldMap -newMap $newMap -serverHostName $serverHostName
    $vals = New-Object System.Collections.Generic.List[string]
    foreach ($v in $ordered) {
        [void]$vals.Add($v.IpAddress)
        [void]$vals.Add("VisVT_VisionPacketManager")
        [void]$vals.Add($v.HostName)
    }

    if ($siteCode) {
        $localOld = Find-ServerObject $oldMap $serverHostName
        $localNew = Find-ServerObject $newMap $serverHostName
        if ($localOld -and $localOld.IpAddress) {
            [void]$vals.Add($localOld.IpAddress)
            [void]$vals.Add("VisVT_${siteCode}_VisionPacketManager")
            [void]$vals.Add($localOld.HostName)
        }
        if ($localNew -and $localNew.IpAddress) {
            [void]$vals.Add($localNew.IpAddress)
            [void]$vals.Add("VisVT_${siteCode}_VisionPacketManager")
            [void]$vals.Add($localNew.HostName)
        }
    }

    return ($vals -join '|')
}

function Get-AppSettingAddNode([xml]$doc, [string]$key) {
    return $doc.SelectSingleNode("//appSettings/add[@key='$key']")
}

function Set-AppSettingValue([xml]$doc, [string]$key, [string]$value, [bool]$createIfMissing = $false) {
    $node = Get-AppSettingAddNode -doc $doc -key $key
    if ($node) {
        $old = $node.GetAttribute("value")
        $node.SetAttribute("value", $value)
        return [pscustomobject]@{ Found = $true; OldValue = $old; NewValue = $value }
    }

    if ($createIfMissing) {
        $appSettings = $doc.SelectSingleNode("//appSettings")
        if ($appSettings) {
            $newNode = $doc.CreateElement("add")
            [void]$newNode.SetAttribute("key", $key)
            [void]$newNode.SetAttribute("value", $value)
            [void]$appSettings.AppendChild($newNode)
            return [pscustomobject]@{ Found = $false; OldValue = ""; NewValue = $value }
        }
    }

    return $null
}

function Set-NumberedHostKeys {
    param(
        [xml]$Doc,
        [string]$GroupName,
        [string[]]$Values
    )

    $updated = New-Object System.Collections.Generic.List[object]
    $appSettings = $Doc.SelectSingleNode("//appSettings")
    if (-not $appSettings) { return $updated }

    $countNode = Get-AppSettingAddNode -doc $Doc -key "$GroupName.Count"
    $oldCount = ""
    if ($countNode) {
        $oldCount = $countNode.GetAttribute("value")
        $countNode.SetAttribute("value", [string]$Values.Count)
    } else {
        $countNode = $Doc.CreateElement("add")
        [void]$countNode.SetAttribute("key", "$GroupName.Count")
        [void]$countNode.SetAttribute("value", [string]$Values.Count)
        [void]$appSettings.AppendChild($countNode)
    }
    [void]$updated.Add([pscustomobject]@{ Setting="$GroupName.Count"; OldValue=$oldCount; NewValue=[string]$Values.Count })

    $existing = @($Doc.SelectNodes("//appSettings/add[starts-with(@key,'$GroupName.Host')]"))
    foreach ($node in $existing) {
        [void]$node.ParentNode.RemoveChild($node)
    }

    $insertAfter = $countNode
    for ($i = 0; $i -lt $Values.Count; $i++) {
        $n = $Doc.CreateElement("add")
        [void]$n.SetAttribute("key", "$GroupName.Host$($i+1)")
        [void]$n.SetAttribute("value", $Values[$i])
        if ($insertAfter -and $insertAfter.ParentNode -eq $appSettings) {
            $insertAfter = $appSettings.InsertAfter($n, $insertAfter)
        } else {
            [void]$appSettings.AppendChild($n)
            $insertAfter = $n
        }
        [void]$updated.Add([pscustomobject]@{ Setting="$GroupName.Host$($i+1)"; OldValue=""; NewValue=$Values[$i] })
    }

    return $updated
}

function Set-ApplicationSettingsStringOrXmlList {
    param(
        [xml]$Doc,
        [string]$SettingName,
        [string[]]$Values,
        [switch]$AsXmlList
    )

    $node = $Doc.SelectSingleNode("//applicationSettings/*/setting[@name='$SettingName']")
    if (-not $node) { return $null }

    $valueNode = $node.SelectSingleNode("value")
    if (-not $valueNode) {
        $valueNode = $Doc.CreateElement("value")
        [void]$node.AppendChild($valueNode)
    }

    $oldDisplay = $valueNode.InnerText.Trim()

    if ($AsXmlList) {
        while ($valueNode.HasChildNodes) { [void]$valueNode.RemoveChild($valueNode.FirstChild) }
        $arr = $Doc.CreateElement("ArrayOfString")
        [void]$arr.SetAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
        [void]$arr.SetAttribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema")
        foreach ($v in $Values) {
            $s = $Doc.CreateElement("string")
            $s.InnerText = $v
            [void]$arr.AppendChild($s)
        }
        [void]$valueNode.AppendChild($arr)
        return [pscustomobject]@{ Setting=$SettingName; OldValue=$oldDisplay; NewValue=($Values -join '|') }
    } else {
        $newValue = $Values -join '|'
        $valueNode.InnerText = $newValue
        return [pscustomobject]@{ Setting=$SettingName; OldValue=$oldDisplay; NewValue=$newValue }
    }
}

function Should-ProcessRow($scopeRows, [string]$relativePath, [string]$settingKey) {
    if (-not $scopeRows) { return $true }
    foreach ($r in $scopeRows) {
        if ($r.RelativePath -eq $relativePath -and $r.SettingKey -eq $settingKey) { return $true }
    }
    return $false
}

$oldDoc = Load-XmlDoc $OldEnvXmlPath
$newDoc = Load-XmlDoc $NewEnvXmlPath

$oldMaps = Get-ServerMaps $oldDoc
$newMaps = Get-ServerMaps $newDoc

$scopeRows = $null
if ($ScopeCsvPath) {
    $scopeRows = Import-Csv -LiteralPath $ScopeCsvPath
}

Log "Starting merge patcher. ApplyChanges=$ApplyChanges ConfigRoot=$ConfigRoot"

$files = Get-ChildItem -LiteralPath $ConfigRoot -Recurse -File -Include *.config,*.settings,*.ini
foreach ($file in $files) {
    $rel = $file.FullName.Substring($ConfigRoot.Length).TrimStart('\')
    $serverName = Get-ThisServerFromPath -filePath $file.FullName -configRoot $ConfigRoot

    try {
        $doc = Load-XmlDoc $file.FullName
    } catch {
        Log "WARN: XML load failed: $($file.FullName)"
        continue
    }

    $changed = $false

    # appSettings numbered Hosts.*
    if (Should-ProcessRow $scopeRows $rel "Hosts") {
        $hasHostsCount = $doc.SelectSingleNode("//appSettings/add[@key='Hosts.Count']")
        if ($hasHostsCount) {
            $vals = Get-MergedHostsForServer -oldMap $oldMaps -newMap $newMaps -serverHostName $serverName -suffix 'VisVT'
            $updates = Set-NumberedHostKeys -Doc $doc -GroupName "Hosts" -Values $vals
            if ($updates.Count -gt 0) {
                foreach ($u in $updates) {
                    Add-ReportRow -File $rel -Setting $u.Setting -OldValue $u.OldValue -NewValue $u.NewValue -Rule "OLD-first ordered host list" -Status "Preview"
                }
                $changed = $true
            }
        }
    }

    # appSettings numbered VSCM.*
    if (Should-ProcessRow $scopeRows $rel "VSCM") {
        $hasVscmCount = $doc.SelectSingleNode("//appSettings/add[@key='VSCM.Count']")
        if ($hasVscmCount) {
            $vals = Get-MergedHostsForServer -oldMap $oldMaps -newMap $newMaps -serverHostName $serverName -suffix 'VisVT'
            $updates = Set-NumberedHostKeys -Doc $doc -GroupName "VSCM" -Values $vals
            if ($updates.Count -gt 0) {
                foreach ($u in $updates) {
                    Add-ReportRow -File $rel -Setting $u.Setting -OldValue $u.OldValue -NewValue $u.NewValue -Rule "OLD-first ordered VSCM list" -Status "Preview"
                }
                $changed = $true
            }
        }
    }

    # applicationSettings pipe/xml list types
    if (Should-ProcessRow $scopeRows $rel "CADHosts") {
        $merged = Get-MergedCadHosts -oldMap $oldMaps -newMap $newMaps
        $res = Set-ApplicationSettingsStringOrXmlList -Doc $doc -SettingName "CADHosts" -Values (Split-PipeValue $merged) -AsXmlList
        if ($res) {
            Add-ReportRow -File $rel -Setting "CADHosts" -OldValue $res.OldValue -NewValue $res.NewValue -Rule "OLD-first pipe list union" -Status "Preview"
            $changed = $true
        }
    }

    if (Should-ProcessRow $scopeRows $rel "MlsGateways") {
        $merged = Get-MergedMlsGateways -oldMap $oldMaps -newMap $newMaps
        $res = Set-ApplicationSettingsStringOrXmlList -Doc $doc -SettingName "MlsGateways" -Values (Split-PipeValue $merged) -AsXmlList
        if ($res) {
            Add-ReportRow -File $rel -Setting "MlsGateways" -OldValue $res.OldValue -NewValue $res.NewValue -Rule "OLD-first APL gateway union" -Status "Preview"
            $changed = $true
        }
    }

    if (Should-ProcessRow $scopeRows $rel "Hosts") {
        $node = $doc.SelectSingleNode("//applicationSettings/*/setting[@name='Hosts']")
        if ($node) {
            $vals = Get-MergedHostsForServer -oldMap $oldMaps -newMap $newMaps -serverHostName $serverName
            $res = Set-ApplicationSettingsStringOrXmlList -Doc $doc -SettingName "Hosts" -Values $vals -AsXmlList
            if ($res) {
                Add-ReportRow -File $rel -Setting "Hosts" -OldValue $res.OldValue -NewValue $res.NewValue -Rule "OLD-first ordered host list" -Status "Preview"
                $changed = $true
            }
        }
    }

    if (Should-ProcessRow $scopeRows $rel "VISIONHosts") {
        $node = $doc.SelectSingleNode("//applicationSettings/*/setting[@name='VISIONHosts']")
        if ($node) {
            $vals = Get-MergedHostsForServer -oldMap $oldMaps -newMap $newMaps -serverHostName $serverName
            $res = Set-ApplicationSettingsStringOrXmlList -Doc $doc -SettingName "VISIONHosts" -Values $vals -AsXmlList
            if ($res) {
                Add-ReportRow -File $rel -Setting "VISIONHosts" -OldValue $res.OldValue -NewValue $res.NewValue -Rule "OLD-first ordered host list" -Status "Preview"
                $changed = $true
            }
        }
    }

    if (Should-ProcessRow $scopeRows $rel "VSCM") {
        $node = $doc.SelectSingleNode("//applicationSettings/*/setting[@name='VSCM']")
        if ($node) {
            $vals = Get-MergedHostsForServer -oldMap $oldMaps -newMap $newMaps -serverHostName $serverName
            $res = Set-ApplicationSettingsStringOrXmlList -Doc $doc -SettingName "VSCM" -Values $vals -AsXmlList
            if ($res) {
                Add-ReportRow -File $rel -Setting "VSCM" -OldValue $res.OldValue -NewValue $res.NewValue -Rule "OLD-first ordered VSCM list" -Status "Preview"
                $changed = $true
            }
        }
    }

    if (Should-ProcessRow $scopeRows $rel "SyncHosts") {
        $node = $doc.SelectSingleNode("//applicationSettings/*/setting[@name='SyncHosts']")
        if ($node) {
            $siteCode = ""
            if ($rel -match 'VisVT_([A-Z]{3})') { $siteCode = $Matches[1] }
            $merged = Get-MergedSyncHostsForServer -oldMap $oldMaps -newMap $newMaps -serverHostName $serverName -siteCode $siteCode
            $res = Set-ApplicationSettingsStringOrXmlList -Doc $doc -SettingName "SyncHosts" -Values (Split-PipeValue $merged) -AsXmlList
            if ($res) {
                Add-ReportRow -File $rel -Setting "SyncHosts" -OldValue $res.OldValue -NewValue $res.NewValue -Rule "OLD-first sync host triplets" -Status "Preview"
                $changed = $true
            }
        }
    }

    # Manual-review-only settings
    if (Should-ProcessRow $scopeRows $rel "UdpIp") {
        $node = $doc.SelectSingleNode("//applicationSettings/*/setting[@name='UdpIp']")
        if ($node) {
            $oldTxt = $node.InnerText.Trim()
            Add-ReportRow -File $rel -Setting "UdpIp" -OldValue $oldTxt -NewValue $oldTxt -Rule "Manual review required" -Status "Skipped" -Notes "Local bind/interface value not auto-merged"
        }
    }

    if ($changed) {
        $target = Join-Path $OutputRoot $rel
        $targetDir = Split-Path -Parent $target
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
        if ($ApplyChanges) {
            $doc.Save($target)
            Log "WROTE: $target"
        } else {
            $doc.Save($target)
            Log "PREVIEW-WROTE: $target"
        }
    }
}

Log "Done. Report=$reportPath"
Write-Host "Done."
Write-Host "Report: $reportPath"
Write-Host "Log:    $logPath"