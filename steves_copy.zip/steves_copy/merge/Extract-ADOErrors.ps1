﻿<#
.SYNOPSIS
    Extracts useful Azure DevOps pipeline errors from downloaded/extracted log files.

.DESCRIPTION
    Recursively scans .txt/.log files for common ADO, PowerShell, WinRM,
    RabbitMQ, SQL, and Windows service failure patterns.

    Produces:
      - ErrorSummary.csv
      - ErrorSummary.txt
      - FailedLogsOnly folder containing only logs with detected errors

.EXAMPLE
    .\Extract-ADOErrors.ps1 -LogRoot "D:\Temp\logs_63476" -OutputRoot "D:\Temp\ADO_Error_Report"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$LogRoot,

    [Parameter(Mandatory = $true)]
    [string]$OutputRoot
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path -LiteralPath $LogRoot)) {
    throw "LogRoot not found: $LogRoot"
}

New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null

$failedCopyRoot = Join-Path $OutputRoot "FailedLogsOnly"
New-Item -ItemType Directory -Path $failedCopyRoot -Force | Out-Null

$csvPath = Join-Path $OutputRoot "ErrorSummary.csv"
$txtPath = Join-Path $OutputRoot "ErrorSummary.txt"

$patterns = @(
    "##\[error\]",
    "PowerShell exited with code '[1-9]",
    "NativeCommandError",
    "CategoryInfo\s+:\s+.*",
    "FullyQualifiedErrorId\s+:\s+.*",
    "Cannot start service",
    "FAILED to start",
    "WinRM cannot complete the operation",
    "Access is denied",
    "UnauthorizedAccessException",
    "unable to perform an operation on node",
    "rabbit@",
    "join_cluster",
    "Error:",
    "Exception",
    "FAILED",
    "##\[section\]Starting:",
    "##\[section\]Finishing:"
)

$files = Get-ChildItem -Path $LogRoot -Recurse -File |
    Where-Object { $_.Extension -in ".txt", ".log" }

$results = New-Object System.Collections.Generic.List[object]

foreach ($file in $files) {
    $lines = Get-Content -LiteralPath $file.FullName -ErrorAction SilentlyContinue

    $currentTask = ""
    $hasError = $false

    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = $lines[$i]

        if ($line -match "##\[section\]Starting:\s*(.+)$") {
            $currentTask = $Matches[1].Trim()
        }

        $matched = $false
        foreach ($pattern in $patterns) {
            if ($line -match $pattern) {
                $matched = $true
                break
            }
        }

        if ($matched) {
            $severity = "INFO"

            if ($line -match "##\[error\]|PowerShell exited with code '[1-9]|Cannot start service|FAILED to start|WinRM cannot complete|unable to perform|NativeCommandError|Exception|Access is denied|Error:") {
                $severity = "ERROR"
                $hasError = $true
            }
            elseif ($line -match "FAILED") {
                $severity = "WARN"
                $hasError = $true
            }

            $contextStart = [Math]::Max(0, $i - 3)
            $contextEnd   = [Math]::Min($lines.Count - 1, $i + 5)
            $context = ($lines[$contextStart..$contextEnd] -join "`n")

            $results.Add([pscustomobject]@{
                FileName     = $file.Name
                FullPath     = $file.FullName
                Task         = $currentTask
                LineNumber   = $i + 1
                Severity     = $severity
                MatchedLine  = $line
                Context      = $context
            })
        }
    }

    if ($hasError) {
        Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $failedCopyRoot $file.Name) -Force
    }
}

$results |
    Sort-Object Severity, FileName, LineNumber |
    Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

$summary = @()

$summary += "ADO Error Extraction Summary"
$summary += "============================"
$summary += ""
$summary += "Log root: $LogRoot"
$summary += "Output root: $OutputRoot"
$summary += "Files scanned: $($files.Count)"
$summary += "Error/warning matches: $($results.Count)"
$summary += ""

$summary += "Top error groups:"
$summary += "-----------------"

$results |
    Where-Object { $_.Severity -eq "ERROR" } |
    Group-Object {
        if ($_.MatchedLine -match "unable to perform an operation on node") { "RabbitMQ node operation failure" }
        elseif ($_.MatchedLine -match "Cannot start service|FAILED to start") { "Windows service startup failure" }
        elseif ($_.MatchedLine -match "WinRM cannot complete") { "WinRM / remoting failure" }
        elseif ($_.MatchedLine -match "PowerShell exited with code") { "PowerShell non-zero exit" }
        elseif ($_.MatchedLine -match "Access is denied|UnauthorizedAccessException") { "Access denied" }
        elseif ($_.MatchedLine -match "NativeCommandError") { "Native command failure" }
        else { "Other error" }
    } |
    Sort-Object Count -Descending |
    ForEach-Object {
        $summary += ("{0}: {1}" -f $_.Name, $_.Count)
    }

$summary += ""
$summary += "Files with detected errors:"
$summary += "---------------------------"

$results |
    Where-Object { $_.Severity -eq "ERROR" } |
    Select-Object -ExpandProperty FileName -Unique |
    Sort-Object |
    ForEach-Object {
        $summary += $_
    }

$summary | Set-Content -Path $txtPath -Encoding UTF8

Write-Host ""
Write-Host "Done." -ForegroundColor Green
Write-Host "CSV report:  $csvPath"
Write-Host "Text report: $txtPath"
Write-Host "Failed logs: $failedCopyRoot"