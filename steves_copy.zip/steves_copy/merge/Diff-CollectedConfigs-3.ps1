﻿param(
    [Parameter(Mandatory=$true)] [string]$CsvPath,
    [Parameter(Mandatory=$true)] [string]$CollectedRoot,
    [string]$OutputRoot = "",
    [string]$EnvironmentToken = "",
    [switch]$IgnoreCountKeys
)

# -------------------- Setup --------------------
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
if ([string]::IsNullOrWhiteSpace($OutputRoot)) { $OutputRoot = $CollectedRoot }

$outCsv     = Join-Path $OutputRoot "QCAD_SettingsCompare_$ts.csv"
$missingCsv = Join-Path $OutputRoot "QCAD_MissingFiles_$ts.csv"
$logPath    = Join-Path $OutputRoot "QCAD_DiffLog_$ts.log"

"OldServer,NewServer,OldFullPath,NewFullPath,SettingType,SettingKey,OldValue,NewValue,Status,RelativePath" | Out-File $outCsv -Encoding UTF8
"OldServer,NewServer,MissingSide,MissingFullPath,RelativePath" | Out-File $missingCsv -Encoding UTF8

function Log([string]$msg) {
    $line = "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") $msg"
    $line | Tee-Object -FilePath $logPath -Append | Out-Null
}

function Get-RelativeUnderServer([string]$serverRoot, [string]$fullPath) {
    return $fullPath.Substring($serverRoot.Length).TrimStart('\')
}

function Try-LoadXml([string]$path) {
    try {
        $raw = Get-Content -LiteralPath $path -Raw -ErrorAction Stop
        $xml = New-Object System.Xml.XmlDocument
        $xml.PreserveWhitespace = $false
        $xml.LoadXml($raw)
        return $xml
    } catch {
        return $null
    }
}

function Normalize-Value([string]$value) {
    if ($null -eq $value) { return $null }
    $v = $value.Trim()

    if ($v -match '^(?i:true|false)$') {
        return $v.ToUpper()
    }

    return $v
}

function Add-Setting {
    param(
        [hashtable]$Map,
        [string]$SettingType,
        [string]$SettingKey,
        [string]$Value
    )

    if ([string]::IsNullOrWhiteSpace($SettingType) -or [string]::IsNullOrWhiteSpace($SettingKey)) { return }

    if ($IgnoreCountKeys -and $SettingKey -match '\.Count$') { return }

    $id = "$SettingType::$SettingKey"
    if (-not $Map.ContainsKey($id)) {
        $Map[$id] = $Value
    } else {
        $i = 2
        while ($Map.ContainsKey("$id#$i")) { $i++ }
        $Map["$id#$i"] = $Value
    }
}

function Get-LeafElementTexts([System.Xml.XmlNode]$node) {
    $values = New-Object System.Collections.Generic.List[string]

    foreach ($child in $node.ChildNodes) {
        if ($child.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }

        $hasElementChildren = $false
        foreach ($gc in $child.ChildNodes) {
            if ($gc.NodeType -eq [System.Xml.XmlNodeType]::Element) {
                $hasElementChildren = $true
                break
            }
        }

        if ($hasElementChildren) {
            $nested = Get-LeafElementTexts $child
            foreach ($n in $nested) { [void]$values.Add($n) }
        } else {
            $text = Normalize-Value($child.InnerText)
            if (-not [string]::IsNullOrWhiteSpace($text)) {
                [void]$values.Add($text)
            }
        }
    }

    return $values
}

function Get-ApplicationSettingValue([System.Xml.XmlNode]$settingNode) {
    $valueNode = $settingNode.SelectSingleNode("value")
    if (-not $valueNode) { return $null }

    $hasElementChildren = $false
    foreach ($child in $valueNode.ChildNodes) {
        if ($child.NodeType -eq [System.Xml.XmlNodeType]::Element) {
            $hasElementChildren = $true
            break
        }
    }

    if (-not $hasElementChildren) {
        return Normalize-Value($valueNode.InnerText)
    }

    $leafValues = Get-LeafElementTexts $valueNode
    if ($leafValues.Count -gt 0) {
        return ($leafValues -join "|")
    }

    return Normalize-Value($valueNode.InnerText)
}

function Get-ConfigSettings {
    param([Parameter(Mandatory=$true)][string]$FilePath)

    $results = @{}
    $xml = Try-LoadXml $FilePath
    if ($null -eq $xml) {
        $results["__error__"] = "XML parse failed"
        return $results
    }

    try {
        # --- appSettings ---
        if ($xml.configuration.appSettings) {
            foreach ($add in $xml.configuration.appSettings.add) {
                if ($add.key -ne $null) {
                    Add-Setting $results "appSettings" ($add.key.ToString()) (Normalize-Value($add.value.ToString()))
                }
            }
        }

        # --- applicationSettings ---
        if ($xml.configuration.applicationSettings) {
            foreach ($section in $xml.configuration.applicationSettings.ChildNodes) {
                if ($section.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }

                foreach ($setting in $section.ChildNodes) {
                    if ($setting.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }
                    if ($setting.name) {
                        $value = Get-ApplicationSettingValue -settingNode $setting
                        Add-Setting $results "applicationSettings" ($setting.name.ToString()) $value
                    }
                }
            }
        }

        # --- connectionStrings ---
        if ($xml.configuration.connectionStrings) {
            foreach ($conn in $xml.configuration.connectionStrings.add) {
                if ($conn.name -ne $null) {
                    Add-Setting $results "connectionStrings" ($conn.name.ToString()) (Normalize-Value($conn.connectionString.ToString()))
                }
            }
        }

        # --- system.web::compilation and authentication ---
        $compilation = $xml.configuration.'system.web'.compilation
        if ($compilation) {
            if ($compilation.debug -ne $null) {
                Add-Setting $results "system.web" "compilation.debug" (Normalize-Value($compilation.debug.ToString()))
            }
            if ($compilation.targetFramework -ne $null) {
                Add-Setting $results "system.web" "compilation.targetFramework" (Normalize-Value($compilation.targetFramework.ToString()))
            }
        }

        $authentication = $xml.configuration.'system.web'.authentication
        if ($authentication -and $authentication.mode -ne $null) {
            Add-Setting $results "system.web" "authentication.mode" (Normalize-Value($authentication.mode.ToString()))
        }

        # --- bindingRedirect mappings ---
        $depAssemblies = $null
        try {
            $depAssemblies = $xml.configuration.runtime.assemblyBinding.dependentAssembly
        } catch {
            $depAssemblies = $null
        }

        if ($depAssemblies) {
            foreach ($dep in $depAssemblies) {
                $name = $dep.assemblyIdentity.name
                $oldVersion = $dep.bindingRedirect.oldVersion
                $newVersion = $dep.bindingRedirect.newVersion
                if ($name -and $oldVersion -and $newVersion) {
                    Add-Setting $results "bindingRedirect" ($name.ToString()) ("$oldVersion => $newVersion")
                }
            }
        }

        # --- VISION/Application (INI-style XML) ---
        if ($xml.VISION -and $xml.VISION.Application) {
            foreach ($app in $xml.VISION.Application) {
                $appName = $app.Name
                foreach ($add in $app.add) {
                    if ($appName -and $add.key -ne $null) {
                        $keyName = "$($appName)::" + $add.key
                        Add-Setting $results "iniSettings" $keyName (Normalize-Value($add.value.ToString()))
                    }
                }
            }
        }

    } catch {
        $results["__error__"] = $_.Exception.Message
    }

    return $results
}

# -------------------- Main --------------------
$mapCsv = Import-Csv -LiteralPath $CsvPath
if (-not ($mapCsv[0].PSObject.Properties.Name -contains "OLD_Server" -and $mapCsv[0].PSObject.Properties.Name -contains "NEW_Server")) {
    throw "CSV must have headers: OLD_Server, NEW_Server"
}

$oldRoot = Join-Path $CollectedRoot "OLD"
$newRoot = Join-Path $CollectedRoot "NEW"
if (-not (Test-Path -LiteralPath $oldRoot)) { throw "Missing folder: $oldRoot" }
if (-not (Test-Path -LiteralPath $newRoot)) { throw "Missing folder: $newRoot" }

Log "Starting settings compare. CollectedRoot=$CollectedRoot Output=$outCsv IgnoreCountKeys=$IgnoreCountKeys EnvFilter='$EnvironmentToken'"

foreach ($row in $mapCsv) {
    $oldServer = ($row.OLD_Server | ForEach-Object { $_.ToString().Trim() })
    $newServer = ($row.NEW_Server | ForEach-Object { $_.ToString().Trim() })

    if ([string]::IsNullOrWhiteSpace($oldServer) -or [string]::IsNullOrWhiteSpace($newServer)) { continue }

    if ($EnvironmentToken) {
        if (($oldServer -notmatch [regex]::Escape($EnvironmentToken)) -or ($newServer -notmatch [regex]::Escape($EnvironmentToken))) {
            continue
        }
    }

    $oldServerRoot = Join-Path $oldRoot $oldServer
    $newServerRoot = Join-Path $newRoot $newServer

    if (-not (Test-Path -LiteralPath $oldServerRoot)) {
        Log "WARN: Missing OLD folder: $oldServerRoot"
        continue
    }
    if (-not (Test-Path -LiteralPath $newServerRoot)) {
        Log "WARN: Missing NEW folder: $newServerRoot"
        continue
    }

    Log "Pair: $oldServer -> $newServer"

    $oldFiles = Get-ChildItem -LiteralPath $oldServerRoot -Recurse -File | ForEach-Object {
        [pscustomobject]@{
            Full = $_.FullName
            Rel  = Get-RelativeUnderServer $oldServerRoot $_.FullName
        }
    }

    $newFiles = Get-ChildItem -LiteralPath $newServerRoot -Recurse -File | ForEach-Object {
        [pscustomobject]@{
            Full = $_.FullName
            Rel  = Get-RelativeUnderServer $newServerRoot $_.FullName
        }
    }

    $oldIndex = @{}
    foreach ($f in $oldFiles) {
        if (-not $oldIndex.ContainsKey($f.Rel)) { $oldIndex[$f.Rel] = $f.Full }
    }

    $newIndex = @{}
    foreach ($f in $newFiles) {
        if (-not $newIndex.ContainsKey($f.Rel)) { $newIndex[$f.Rel] = $f.Full }
    }

    $allRel = New-Object System.Collections.Generic.HashSet[string]
    foreach ($k in $oldIndex.Keys) { [void]$allRel.Add($k) }
    foreach ($k in $newIndex.Keys) { [void]$allRel.Add($k) }

    foreach ($rel in ($allRel | Sort-Object)) {
        $oldPath = $oldIndex[$rel]
        $newPath = $newIndex[$rel]

        if (-not $oldPath) {
            "$oldServer,$newServer,OLD,""$newPath"",""$rel""" | Out-File $missingCsv -Append -Encoding UTF8
            continue
        }

        if (-not $newPath) {
            "$oldServer,$newServer,NEW,""$oldPath"",""$rel""" | Out-File $missingCsv -Append -Encoding UTF8
            continue
        }

        $oldSet = Get-ConfigSettings $oldPath
        $newSet = Get-ConfigSettings $newPath

        if ($oldSet.ContainsKey("__error__") -or $newSet.ContainsKey("__error__")) {
            Log "WARN: XML parse failed for $rel"
            continue
        }

        $allKeys = New-Object System.Collections.Generic.HashSet[string]
        foreach ($k in $oldSet.Keys) { [void]$allKeys.Add($k) }
        foreach ($k in $newSet.Keys) { [void]$allKeys.Add($k) }

        foreach ($id in ($allKeys | Sort-Object)) {
            $oldVal = $oldSet[$id]
            $newVal = $newSet[$id]

            $status = ""
            if ($oldVal -eq $newVal) {
                $status = "Same"
            } elseif ($null -ne $oldVal -and $null -ne $newVal) {
                $status = "Changed"
            } elseif ($null -ne $oldVal -and $null -eq $newVal) {
                $status = "Missing in New"
            } elseif ($null -ne $newVal -and $null -eq $oldVal) {
                $status = "Missing in Old"
            } else {
                $status = "Unknown"
            }

            if ($null -eq $oldVal) { $oldVal = "" }
            if ($null -eq $newVal) { $newVal = "" }

            if ($id -match '^([^:]+)::(.+)$') {
                $settingType = $matches[1]
                $settingKey  = $matches[2]
            } else {
                $settingType = "Unknown"
                $settingKey  = $id
            }

            "$oldServer,$newServer,""$oldPath"",""$newPath"",""$settingType"",""$settingKey"",""$oldVal"",""$newVal"",""$status"",""$rel""" |
                Out-File $outCsv -Append -Encoding UTF8
        }
    }
}

Log "Done. Output=$outCsv"
Log "Done. Missing=$missingCsv"
Write-Host "DONE. Settings compare CSV:"
Write-Host $outCsv
Write-Host "Missing files CSV:"
Write-Host $missingCsv
Write-Host "Log:"
Write-Host $logPath