# --- CONFIGURATION (edit these paths for your environment) ---
$OldRoot     = "C:\temp\QCAD\VT\Merge\Merge_Discovery\old_servers"
$NewRoot     = "C:\temp\QCAD\VT\Merge\Merge_Discovery\New_Servers"
$MappingCsv  = "C:\temp\QCAD\VT\Merge\Merge_Discovery\Merge_Match_input.csv"
$OutputCsv   = "C:\temp\QCAD\VT\Merge\Merge_Discovery\VT_QCAD_Config_Differences33.csv"
$MissingLog  = "C:\temp\QCAD\VT\Merge\Merge_Discovery\Missing_Files33.csv"

# --- FUNCTION: Extracts structured settings from XML-based configuration files ---
function Get-ConfigSettings {
    param ($FilePath)
    $results = @{}

    try {
        [xml]$xml = Get-Content -LiteralPath $FilePath -Raw

        # --- appSettings section ---
        # Found in: *.config, web.config
        if ($xml.configuration.appSettings) {
            foreach ($add in $xml.configuration.appSettings.add) {
                $results["appSettings::$($add.key)"] = $add.value
            }
        }

        # --- applicationSettings section ---
        # Found in: *.config, *.settings
        if ($xml.configuration.applicationSettings) {
            foreach ($section in $xml.configuration.applicationSettings.ChildNodes) {
                foreach ($setting in $section.ChildNodes) {
                    $name = $setting.name
                    $valueNode = $setting.SelectSingleNode("value")
                    if ($name -and $valueNode) {
                        $results["applicationSettings::$name"] = $valueNode.InnerText.Trim()
                    }
                }
            }
        }

        # --- connectionStrings section ---
        # Found in: *.config, web.config
        if ($xml.configuration.connectionStrings) {
            foreach ($conn in $xml.configuration.connectionStrings.add) {
                $results["connectionStrings::$($conn.name)"] = $conn.connectionString
            }
        }

        # --- system.web::compilation and authentication ---
        # Found in: web.config only
        $compilation = $xml.configuration.'system.web'.compilation
        if ($compilation) {
            if ($compilation.debug) {
                $results["system.web::compilation.debug"] = $compilation.debug
            }
            if ($compilation.targetFramework) {
                $results["system.web::compilation.targetFramework"] = $compilation.targetFramework
            }
        }

        $authentication = $xml.configuration.'system.web'.authentication
        if ($authentication -and $authentication.mode) {
            $results["system.web::authentication.mode"] = $authentication.mode
        }

        # --- bindingRedirect version mappings ---
        # Found in: web.config only
        $bindings = $xml.configuration.runtime.assemblyBinding.dependentAssembly
        foreach ($dep in $bindings) {
            $name = $dep.assemblyIdentity.name
            $oldVersion = $dep.bindingRedirect.oldVersion
            $newVersion = $dep.bindingRedirect.newVersion
            if ($name -and $oldVersion -and $newVersion) {
                $results["bindingRedirect::$name"] = "$oldVersion => $newVersion"
            }
        }

        # --- INI-style format used in *.ini and *.settings files ---
        if ($xml.VISION.Application) {
            foreach ($app in $xml.VISION.Application) {
                $appName = $app.Name
                foreach ($add in $app.add) {
                    $key = "$($appName)::" + $add.key
                    $results["iniSettings::$key"] = $add.value
                }
            }
        }

    } catch {
        $results["__error__"] = $_.Exception.Message
    }

    return $results
}

# --- MAIN COMPARISON LOGIC ---
$rows = @()
$missing = @()
$log = Import-Csv $MappingCsv

foreach ($entry in $log) {
    $oldServer = $entry.OldServer
    $newServer = $entry.NewServer

    $oldServerRoot = Join-Path $OldRoot $oldServer
    $newServerRoot = Join-Path $NewRoot $newServer

    # Gather config-like files to compare recursively
    $newFiles = Get-ChildItem -Path $newServerRoot -Recurse -File | Where-Object {
        $_.Extension -in ".config", ".ini", ".settings"
    }

    foreach ($newFile in $newFiles) {
        $relativePath = $newFile.FullName.Substring($newServerRoot.Length).TrimStart("\\")
        $oldFile = Join-Path $oldServerRoot $relativePath

        Write-Host "Comparing: $relativePath"

        if (-not (Test-Path $oldFile)) {
            Write-Warning "Missing old file: $relativePath"
            $missing += [PSCustomObject]@{
                OldServer     = $oldServer
                NewServer     = $newServer
                MissingPath   = $oldFile
                RelativePath  = $relativePath
            }
            continue
        }

        #  Use full paths here
        $oldSettings = Get-ConfigSettings -FilePath $oldFile
        $newSettings = Get-ConfigSettings -FilePath $newFile.FullName

        $allKeys = ($oldSettings.Keys + $newSettings.Keys) | Sort-Object -Unique

        foreach ($key in $allKeys) {
            $oldVal = $oldSettings[$key]
            $newVal = $newSettings[$key]

            $status = if ($oldVal -eq $newVal) {
                "Same"
            } elseif ($oldVal -and $newVal) {
                "Changed"
            } elseif ($oldVal -and -not $newVal) {
                "Missing in New"
            } elseif ($newVal -and -not $oldVal) {
                "Missing in Old"
            } else {
                "Unknown"
            }

            # Split setting name into type and key using regex fallback
            if ($key -match '^([^:]+)::(.+)$') {
                $settingType = $matches[1]
                $settingKey  = $matches[2]
            } else {
                $settingType = "Unknown"
                $settingKey  = $key
            }

            $rows += [PSCustomObject]@{
                OldServer     = $oldServer
                NewServer     = $newServer
                OldFullPath   = $oldFile
                NewFullPath   = $newFile.FullName
                RelativePath  = $relativePath
                SettingType   = $settingType
                SettingKey    = $settingKey
                OldValue      = $oldVal
                NewValue      = $newVal
                Status        = $status
            }
        }
    }
}

# Export results to output CSV and missing log
$rows | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding Default
$missing | Export-Csv -Path $MissingLog -NoTypeInformation -Encoding Default
Write-Host "Comparison complete. Results saved to:`n $OutputCsv`n $MissingLog"
