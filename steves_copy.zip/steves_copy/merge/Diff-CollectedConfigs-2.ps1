﻿param(
    [Parameter(Mandatory=$true)] [string]$CsvPath,
    [Parameter(Mandatory=$true)] [string]$CollectedRoot,
    [string]$OutputRoot = "",
    [string]$EnvironmentToken = "",
    [switch]$IgnoreCountKeys,
    [switch]$RedactSensitive,
    [string]$RedactKeyRegex = '(?i)(password|pwd|secret|token|apikey|privatekey|username|oracleconnectionpassword|oracleconnectionuser|smtp_password|smtp_username)'
)

# -------------------- Setup --------------------
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
if ([string]::IsNullOrWhiteSpace($OutputRoot)) { $OutputRoot = $CollectedRoot }

$fileSummaryPath = Join-Path $OutputRoot "FileSummary_$ts.csv"
$keyDiffsPath    = Join-Path $OutputRoot "KeyDiffs_$ts.csv"
$logPath         = Join-Path $OutputRoot "Diff_$ts.log"

"OldServer,NewServer,RelativePath,OldPath,NewPath,Status,OldHash,NewHash,Notes" | Out-File $fileSummaryPath -Encoding UTF8
"OldServer,NewServer,RelativePath,Context,Key,OldValue,NewValue,DiffType,Notes" | Out-File $keyDiffsPath -Encoding UTF8

function Log([string]$msg) {
    $line = "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") $msg"
    $line | Tee-Object -FilePath $logPath -Append | Out-Null
}

function Get-FileHashSafe([string]$path) {
    try { return (Get-FileHash -Algorithm SHA256 -LiteralPath $path -ErrorAction Stop).Hash }
    catch { return $null }
}

function Is-SensitiveKey([string]$key) {
    if ([string]::IsNullOrWhiteSpace($key)) { return $false }
    return ($key -match $RedactKeyRegex)
}

function OutValue([string]$key, [string]$value) {
    if ($RedactSensitive -and (Is-SensitiveKey $key)) { return "**REDACTED**" }
    return $value
}

function Get-RelativeUnderServer([string]$serverRoot, [string]$fullPath) {
    return $fullPath.Substring($serverRoot.Length).TrimStart('\')
}

function Try-LoadXml([string]$path) {
    try {
        $raw = Get-Content -LiteralPath $path -Raw -ErrorAction Stop
        $xml = New-Object System.Xml.XmlDocument
        $xml.PreserveWhitespace = $false
        $xml.LoadXml($raw)
        return $xml
    } catch { return $null }
}

function Get-AncestorApplicationName([System.Xml.XmlNode]$node) {
    $cur = $node
    while ($cur -ne $null) {
        if ($cur.Name -eq "Application" -and $cur.Attributes) {
            $a = $cur.Attributes["Name"]
            if ($a -and $a.Value) { return $a.Value }
        }
        $cur = $cur.ParentNode
    }
    return ""
}

function Get-NodeBreadcrumb([System.Xml.XmlNode]$node) {
    $names = New-Object System.Collections.Generic.List[string]
    $cur = $node
    $limit = 0
    while ($cur -ne $null -and $limit -lt 8) {
        if ($cur.NodeType -eq "Element" -and $cur.Name -ne "#document") {
            $names.Add($cur.Name)
            $limit++
        }
        $cur = $cur.ParentNode
    }
    if ($names.Count -eq 0) { return "" }
    $names.Reverse()
    return ($names -join "/")
}

function Normalize-Value([string]$value) {
    if ($null -eq $value) { return $null }
    $v = $value.Trim()

    if ($v -match '^(?i:true|false)$') {
        return $v.ToUpper()
    }

    return $v
}

function Get-LeafElementTexts([System.Xml.XmlNode]$node) {
    $values = New-Object System.Collections.Generic.List[string]

    foreach ($child in $node.ChildNodes) {
        if ($child.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }

        $hasElementChildren = $false
        foreach ($gc in $child.ChildNodes) {
            if ($gc.NodeType -eq [System.Xml.XmlNodeType]::Element) {
                $hasElementChildren = $true
                break
            }
        }

        if ($hasElementChildren) {
            $nested = Get-LeafElementTexts $child
            foreach ($n in $nested) { [void]$values.Add($n) }
        } else {
            $text = Normalize-Value($child.InnerText)
            if (-not [string]::IsNullOrWhiteSpace($text)) {
                [void]$values.Add($text)
            }
        }
    }

    return $values
}

function Get-ApplicationSettingValue([System.Xml.XmlNode]$settingNode) {
    $valueNode = $settingNode.SelectSingleNode("value")
    if (-not $valueNode) { return $null }

    $hasElementChildren = $false
    foreach ($child in $valueNode.ChildNodes) {
        if ($child.NodeType -eq [System.Xml.XmlNodeType]::Element) {
            $hasElementChildren = $true
            break
        }
    }

    if (-not $hasElementChildren) {
        return Normalize-Value($valueNode.InnerText)
    }

    $leafValues = Get-LeafElementTexts $valueNode
    if ($leafValues.Count -gt 0) {
        return ($leafValues -join "|")
    }

    return Normalize-Value($valueNode.InnerText)
}

function Add-ToMap {
    param(
        [hashtable]$Map,
        [string]$CompositeKey,
        [string]$Value
    )

    if (-not $Map.ContainsKey($CompositeKey)) {
        $Map[$CompositeKey] = $Value
    } else {
        $i = 2
        while ($Map.ContainsKey("$CompositeKey#$i")) { $i++ }
        $Map["$CompositeKey#$i"] = $Value
    }
}

function Extract-KVPairs([string]$xmlPath) {
    $xml = Try-LoadXml $xmlPath
    if ($null -eq $xml) { return $null }

    $map = @{}

    # 1) Generic <add key="X" value="Y" />
    $nodes = $xml.SelectNodes("//*[@key and @value]")
    foreach ($n in $nodes) {
        $k = $n.Attributes["key"].Value
        $v = Normalize-Value($n.Attributes["value"].Value)

        if ($IgnoreCountKeys -and $k -match '\.Count$') { continue }

        $app = Get-AncestorApplicationName $n
        $crumb = Get-NodeBreadcrumb $n
        $ctx = if ($app) { "Application=$app; Path=$crumb" } else { "Path=$crumb" }

        $composite = "$ctx|$k"
        Add-ToMap -Map $map -CompositeKey $composite -Value $v
    }

    # 2) connectionStrings
    $csNodes = $xml.SelectNodes("//connectionStrings/add[@name and @connectionString]")
    foreach ($n in $csNodes) {
        $k = "connectionStrings:" + $n.Attributes["name"].Value
        $v = Normalize-Value($n.Attributes["connectionString"].Value)

        $app = Get-AncestorApplicationName $n
        $crumb = Get-NodeBreadcrumb $n
        $ctx = if ($app) { "Application=$app; Path=$crumb" } else { "Path=$crumb" }

        $composite = "$ctx|$k"
        Add-ToMap -Map $map -CompositeKey $composite -Value $v
    }

    # 3) applicationSettings / ClientSettingsSection
    $settingNodes = $xml.SelectNodes("//applicationSettings/*/setting[@name]")
    foreach ($n in $settingNodes) {
        $k = $n.Attributes["name"].Value
        if ($IgnoreCountKeys -and $k -match '\.Count$') { continue }

        $v = Get-ApplicationSettingValue $n

        $sectionName = if ($n.ParentNode -and $n.ParentNode.Name) { $n.ParentNode.Name } else { "" }
        $ctx = if ($sectionName) {
            "Section=$sectionName; Path=" + (Get-NodeBreadcrumb $n)
        } else {
            "Path=" + (Get-NodeBreadcrumb $n)
        }

        $composite = "$ctx|$k"
        Add-ToMap -Map $map -CompositeKey $composite -Value $v
    }

    return $map
}

# -------------------- Main --------------------
$map = Import-Csv -LiteralPath $CsvPath
if (-not ($map[0].PSObject.Properties.Name -contains "OLD_Server" -and $map[0].PSObject.Properties.Name -contains "NEW_Server")) {
    throw "CSV must have headers: OLD_Server, NEW_Server"
}

$oldRoot = Join-Path $CollectedRoot "OLD"
$newRoot = Join-Path $CollectedRoot "NEW"
if (-not (Test-Path -LiteralPath $oldRoot)) { throw "Missing folder: $oldRoot" }
if (-not (Test-Path -LiteralPath $newRoot)) { throw "Missing folder: $newRoot" }

Log "Starting diff. CollectedRoot=$CollectedRoot OutputRoot=$OutputRoot IgnoreCountKeys=$IgnoreCountKeys EnvFilter='$EnvironmentToken' RedactSensitive=$RedactSensitive"

foreach ($row in $map) {
    $oldServer = ($row.OLD_Server  | ForEach-Object { $_.ToString().Trim() })
    $newServer = ($row.NEW_Server  | ForEach-Object { $_.ToString().Trim() })
    if ([string]::IsNullOrWhiteSpace($oldServer) -or [string]::IsNullOrWhiteSpace($newServer)) { continue }

    if ($EnvironmentToken) {
        if (($oldServer -notmatch [regex]::Escape($EnvironmentToken)) -or ($newServer -notmatch [regex]::Escape($EnvironmentToken))) { continue }
    }

    $oldServerRoot = Join-Path $oldRoot $oldServer
    $newServerRoot = Join-Path $newRoot $newServer

    if (-not (Test-Path -LiteralPath $oldServerRoot)) {
        Log "WARN: Missing OLD server folder: $oldServerRoot"
        "$oldServer,$newServer,,,,MissingOldServerFolder,,," | Out-File $fileSummaryPath -Append -Encoding UTF8
        continue
    }
    if (-not (Test-Path -LiteralPath $newServerRoot)) {
        Log "WARN: Missing NEW server folder: $newServerRoot"
        "$oldServer,$newServer,,,,MissingNewServerFolder,,," | Out-File $fileSummaryPath -Append -Encoding UTF8
        continue
    }

    Log "Pair: $oldServer -> $newServer"

    $oldFiles = Get-ChildItem -LiteralPath $oldServerRoot -Recurse -File | ForEach-Object {
        [pscustomobject]@{ Full=$_.FullName; Rel=(Get-RelativeUnderServer $oldServerRoot $_.FullName) }
    }
    $newFiles = Get-ChildItem -LiteralPath $newServerRoot -Recurse -File | ForEach-Object {
        [pscustomobject]@{ Full=$_.FullName; Rel=(Get-RelativeUnderServer $newServerRoot $_.FullName) }
    }

    $oldIndex = @{}; foreach ($f in $oldFiles) { if (-not $oldIndex.ContainsKey($f.Rel)) { $oldIndex[$f.Rel] = $f.Full } }
    $newIndex = @{}; foreach ($f in $newFiles) { if (-not $newIndex.ContainsKey($f.Rel)) { $newIndex[$f.Rel] = $f.Full } }

    $allRel = New-Object System.Collections.Generic.HashSet[string]
    foreach ($k in $oldIndex.Keys) { [void]$allRel.Add($k) }
    foreach ($k in $newIndex.Keys) { [void]$allRel.Add($k) }

    foreach ($rel in ($allRel | Sort-Object)) {
        $oPath = $oldIndex[$rel]
        $nPath = $newIndex[$rel]

        if (-not $oPath) {
            "$oldServer,$newServer,""$rel"","""",""$nPath"",MissingOnOld,,$(Get-FileHashSafe $nPath),""" | Out-File $fileSummaryPath -Append -Encoding UTF8
            continue
        }
        if (-not $nPath) {
            "$oldServer,$newServer,""$rel"",""$oPath"","""",MissingOnNew,$(Get-FileHashSafe $oPath),,""" | Out-File $fileSummaryPath -Append -Encoding UTF8
            continue
        }

        $oHash = Get-FileHashSafe $oPath
        $nHash = Get-FileHashSafe $nPath

        if ($oHash -and $nHash -and $oHash -eq $nHash) {
            "$oldServer,$newServer,""$rel"",""$oPath"",""$nPath"",Same,$oHash,$nHash,""" | Out-File $fileSummaryPath -Append -Encoding UTF8
            continue
        }

        $oldKV = Extract-KVPairs $oPath
        $newKV = Extract-KVPairs $nPath

        if ($null -eq $oldKV -or $null -eq $newKV) {
            $notes = "XMLParseFailed:" + ($(if ($null -eq $oldKV) { " OLD" } else { "" }) + $(if ($null -eq $newKV) { " NEW" } else { "" }))
            "$oldServer,$newServer,""$rel"",""$oPath"",""$nPath"",Different,$oHash,$nHash,""$notes""" | Out-File $fileSummaryPath -Append -Encoding UTF8
            continue
        }

        "$oldServer,$newServer,""$rel"",""$oPath"",""$nPath"",Different,$oHash,$nHash,""" | Out-File $fileSummaryPath -Append -Encoding UTF8

        $keysAll = New-Object System.Collections.Generic.HashSet[string]
        foreach ($k in $oldKV.Keys) { [void]$keysAll.Add($k) }
        foreach ($k in $newKV.Keys) { [void]$keysAll.Add($k) }

        foreach ($ck in ($keysAll | Sort-Object)) {
            $ov = $oldKV[$ck]
            $nv = $newKV[$ck]

            $split = $ck.Split("|",2)
            $ctxOut = if ($split.Count -ge 1) { $split[0] } else { "" }
            $keyOut = if ($split.Count -ge 2) { $split[1] } else { $ck }

            if ($null -eq $ov) {
                "$oldServer,$newServer,""$rel"",""$ctxOut"",""$keyOut"","""",""$(OutValue $keyOut $nv)"",OnlyInNew,""" | Out-File $keyDiffsPath -Append -Encoding UTF8
                continue
            }
            if ($null -eq $nv) {
                "$oldServer,$newServer,""$rel"",""$ctxOut"",""$keyOut"",""$(OutValue $keyOut $ov)"","""",OnlyInOld,""" | Out-File $keyDiffsPath -Append -Encoding UTF8
                continue
            }
            if ($ov -ne $nv) {
                "$oldServer,$newServer,""$rel"",""$ctxOut"",""$keyOut"",""$(OutValue $keyOut $ov)"",""$(OutValue $keyOut $nv)"",ValueChanged,""" | Out-File $keyDiffsPath -Append -Encoding UTF8
            }
        }
    }
}

Log "Done. Outputs:"
Log "  $fileSummaryPath"
Log "  $keyDiffsPath"
Write-Host "DONE."
Write-Host "File summary: $fileSummaryPath"
Write-Host "Key diffs:     $keyDiffsPath"
Write-Host "Log:          $logPath"