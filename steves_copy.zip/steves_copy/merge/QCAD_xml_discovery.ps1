﻿<#
.SYNOPSIS
Discovers and inventories the full XML structure of QCAD configuration files.

.DESCRIPTION
This script recursively scans a directory containing application configuration files
(e.g., *.config, *.settings, *.xml) and parses the complete XML structure of each file.
It walks the entire XML tree and records all elements, attributes, and optionally text
nodes, producing a detailed structural inventory of the configuration.

The purpose of this discovery process is to identify both standard .NET configuration
sections (such as appSettings, connectionStrings, and system.serviceModel) and custom
application-specific sections used by the QCAD Vision/Fortek applications.

Unlike traditional configuration comparison scripts that only evaluate known key/value
pairs, this script performs structural discovery of the XML documents. This allows
engineers to identify custom configuration sections, repeated node structures, and
network-related settings that may influence system behaviour.

The output is written to a CSV file containing details such as:

    - File path
    - XML section name
    - Full XML path
    - Parent path
    - Node name
    - Node type (Element, Attribute, or Text)
    - Attribute names and values
    - Repeated sibling indicators
    - Sibling counts

This discovery process was created to support the QCAD VT environment merge project,
where legacy and replacement server pools are combined within configuration files.
Because many Fortek configuration sections use custom structured XML rather than
standard key/value settings, automated diff tools alone cannot reliably determine
which settings must be modified.

By producing a full structural inventory of the XML configuration, engineers can:

    - Identify custom configuration sections
    - Locate server pools and host definitions
    - Discover message queue or endpoint references
    - Understand how configuration settings are structured
    - Determine where manual merge logic must be applied

The output CSV can then be reviewed to identify which configuration sections require
changes when merging OLD and NEW environments.

.PARAMETER RootPath
Root folder containing configuration files to scan recursively.

.PARAMETER OutputCsv
Path where the XML discovery results will be written as a CSV file.

.PARAMETER IncludeTextNodes
Optional switch to include inner XML text values in the discovery output.

.PARAMETER InterestingOnly
Optional switch that filters the output to settings that are likely to contain
network, host, or service configuration such as server names, addresses, ports,
queues, or endpoints. This is useful when reviewing large configuration sets.

.NOTES
Designed for the QCAD configuration merge analysis process.

The script is intentionally discovery-focused and does not modify any files.

This tool should be run against a copied configuration repository rather than
directly against production servers.

.EXAMPLES

Run full XML discovery across all config files
.\QCAD_xml_discovery.ps1 `
  -RootPath "C:\temp\QCAD\ConfigRepo" `
  -OutputCsv "C:\temp\QCAD\XmlDiscovery\Full_Discovery.csv"

Run filtered discovery (network / host related settings only)

.\QCAD_xml_discovery.ps1 `
  -RootPath "C:\temp\QCAD\ConfigRepo" `
  -OutputCsv "C:\temp\QCAD\XmlDiscovery\Filtered_Discovery.csv" `
  -InterestingOnly

Include inner text values in discovery output

.\QCAD_xml_discovery.ps1 `
  -RootPath "C:\temp\QCAD\ConfigRepo" `
  -OutputCsv "C:\temp\QCAD\XmlDiscovery\WithText.csv" `
  -IncludeTextNodes

  
#>

param(
    [Parameter(Mandatory=$true)] [string]$RootPath,
    [Parameter(Mandatory=$true)] [string]$OutputCsv,
    [string]$OutputSummaryCsv = "",
    [string]$OutputLog = "",
    [string[]]$IncludeExtensions = @(".config", ".settings", ".ini", ".xml"),
    [switch]$InterestingOnly,
    [string]$InterestingNameRegex = '(?i)(host|server|address|ip|port|queue|msmq|sync|gateway|user|password|cad|vision|endpoint|uri|connection)',
    [switch]$IncludeTextNodes
)

if ([string]::IsNullOrWhiteSpace($OutputSummaryCsv)) {
    $OutputSummaryCsv = [System.IO.Path]::Combine(
        [System.IO.Path]::GetDirectoryName($OutputCsv),
        ([System.IO.Path]::GetFileNameWithoutExtension($OutputCsv) + "_Sections.csv")
    )
}

if ([string]::IsNullOrWhiteSpace($OutputLog)) {
    $OutputLog = [System.IO.Path]::Combine(
        [System.IO.Path]::GetDirectoryName($OutputCsv),
        ([System.IO.Path]::GetFileNameWithoutExtension($OutputCsv) + ".log")
    )
}

New-Item -ItemType Directory -Path ([System.IO.Path]::GetDirectoryName($OutputCsv)) -Force | Out-Null

$detailRows  = New-Object System.Collections.Generic.List[object]
$summaryRows = New-Object System.Collections.Generic.List[object]

function Log([string]$msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    $line | Out-File -FilePath $OutputLog -Append -Encoding UTF8
    Write-Host $line
}

function Get-RelativePathSafe([string]$basePath, [string]$fullPath) {
    try {
        return $fullPath.Substring($basePath.Length).TrimStart('\')
    } catch {
        return $fullPath
    }
}

function Get-XPathLike([System.Xml.XmlNode]$node) {
    $parts = New-Object System.Collections.Generic.List[string]
    $current = $node

    while ($null -ne $current -and $current.NodeType -ne [System.Xml.XmlNodeType]::Document) {
        if ($current.NodeType -eq [System.Xml.XmlNodeType]::Element) {
            $name = $current.Name
            $index = 1

            if ($current.ParentNode -and $current.ParentNode.NodeType -eq [System.Xml.XmlNodeType]::Element) {
                $siblings = @($current.ParentNode.ChildNodes | Where-Object {
                    $_.NodeType -eq [System.Xml.XmlNodeType]::Element -and $_.Name -eq $current.Name
                })

                if ($siblings.Count -gt 1) {
                    for ($i = 0; $i -lt $siblings.Count; $i++) {
                        if ([object]::ReferenceEquals($siblings[$i], $current)) {
                            $index = $i + 1
                            break
                        }
                    }
                    $name = "$name[$index]"
                }
            }

            $parts.Insert(0, $name)
        }
        $current = $current.ParentNode
    }

    return "/" + ($parts -join "/")
}

function Get-TopSectionName([System.Xml.XmlNode]$node) {
    $current = $node
    $top = $null

    while ($null -ne $current -and $current.ParentNode -ne $null) {
        if ($current.ParentNode.Name -eq "configuration") {
            $top = $current.Name
            break
        }
        $current = $current.ParentNode
    }

    if ($top) { return $top }
    return $node.Name
}

function Is-Interesting {
    param(
        [string]$Section,
        [string]$NodeName,
        [string]$AttributeName,
        [string]$Value,
        [bool]$IsRepeatedSibling,
        [int]$SiblingCount
    )

    if (-not $InterestingOnly) { return $true }

    if ($IsRepeatedSibling -or $SiblingCount -gt 1) { return $true }

    foreach ($candidate in @($Section, $NodeName, $AttributeName, $Value)) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and $candidate -match $InterestingNameRegex) {
            return $true
        }
    }

    return $false
}

function Add-DetailRow {
    param(
        [string]$File,
        [string]$RelativePath,
        [string]$Section,
        [string]$ParentPath,
        [string]$XmlPath,
        [string]$NodeName,
        [string]$NodeType,
        [string]$AttributeName,
        [string]$Value,
        [bool]$IsRepeatedSibling,
        [int]$SiblingCount
    )

    if (-not (Is-Interesting -Section $Section -NodeName $NodeName -AttributeName $AttributeName -Value $Value -IsRepeatedSibling $IsRepeatedSibling -SiblingCount $SiblingCount)) {
        return
    }

    $detailRows.Add([pscustomobject]@{
        File              = $File
        RelativePath      = $RelativePath
        Section           = $Section
        ParentPath        = $ParentPath
        XmlPath           = $XmlPath
        NodeName          = $NodeName
        NodeType          = $NodeType
        AttributeName     = $AttributeName
        Value             = $Value
        IsRepeatedSibling = $IsRepeatedSibling
        SiblingCount      = $SiblingCount
    }) | Out-Null
}

function Walk-XmlNode {
    param(
        [System.Xml.XmlNode]$Node,
        [string]$File,
        [string]$RelativePath
    )

    if ($Node.NodeType -ne [System.Xml.XmlNodeType]::Element) { return }

    $section = Get-TopSectionName $Node
    $xmlPath = Get-XPathLike $Node
    $parentPath = if ($Node.ParentNode -and $Node.ParentNode.NodeType -eq [System.Xml.XmlNodeType]::Element) {
        Get-XPathLike $Node.ParentNode
    } else {
        ""
    }

    $siblings = @()
    if ($Node.ParentNode -and $Node.ParentNode.NodeType -eq [System.Xml.XmlNodeType]::Element) {
        $siblings = @($Node.ParentNode.ChildNodes | Where-Object {
            $_.NodeType -eq [System.Xml.XmlNodeType]::Element -and $_.Name -eq $Node.Name
        })
    }

    $isRepeated = $siblings.Count -gt 1
    $siblingCount = $siblings.Count

    Add-DetailRow -File $File -RelativePath $RelativePath -Section $section -ParentPath $parentPath -XmlPath $xmlPath `
        -NodeName $Node.Name -NodeType "Element" -AttributeName "" -Value "" -IsRepeatedSibling $isRepeated -SiblingCount $siblingCount

    if ($Node.Attributes) {
        foreach ($attr in $Node.Attributes) {
            Add-DetailRow -File $File -RelativePath $RelativePath -Section $section -ParentPath $xmlPath -XmlPath ($xmlPath + "/@" + $attr.Name) `
                -NodeName $Node.Name -NodeType "Attribute" -AttributeName $attr.Name -Value $attr.Value `
                -IsRepeatedSibling $isRepeated -SiblingCount $siblingCount
        }
    }

    if ($IncludeTextNodes) {
        $hasElementChildren = $false
        foreach ($child in $Node.ChildNodes) {
            if ($child.NodeType -eq [System.Xml.XmlNodeType]::Element) {
                $hasElementChildren = $true
                break
            }
        }

        if (-not $hasElementChildren) {
            $text = $Node.InnerText.Trim()
            if (-not [string]::IsNullOrWhiteSpace($text)) {
                Add-DetailRow -File $File -RelativePath $RelativePath -Section $section -ParentPath $parentPath -XmlPath ($xmlPath + "/text()") `
                    -NodeName $Node.Name -NodeType "Text" -AttributeName "" -Value $text `
                    -IsRepeatedSibling $isRepeated -SiblingCount $siblingCount
            }
        }
    }

    foreach ($child in $Node.ChildNodes) {
        if ($child.NodeType -eq [System.Xml.XmlNodeType]::Element) {
            Walk-XmlNode -Node $child -File $File -RelativePath $RelativePath
        }
    }
}

Log "Starting XML discovery. RootPath=$RootPath InterestingOnly=$InterestingOnly IncludeTextNodes=$IncludeTextNodes"

$files = Get-ChildItem -LiteralPath $RootPath -Recurse -File | Where-Object {
    $IncludeExtensions -contains $_.Extension.ToLower()
}

foreach ($file in $files) {
    $relativePath = Get-RelativePathSafe -basePath $RootPath -fullPath $file.FullName
    Log "Processing: $relativePath"

    try {
        $xml = New-Object System.Xml.XmlDocument
        $xml.PreserveWhitespace = $true
        $xml.Load($file.FullName)
    } catch {
        $detailRows.Add([pscustomobject]@{
            File              = $file.FullName
            RelativePath      = $relativePath
            Section           = ""
            ParentPath        = ""
            XmlPath           = ""
            NodeName          = ""
            NodeType          = "ParseError"
            AttributeName     = ""
            Value             = $_.Exception.Message
            IsRepeatedSibling = $false
            SiblingCount      = 0
        }) | Out-Null
        continue
    }

    if ($xml.DocumentElement) {
        Walk-XmlNode -Node $xml.DocumentElement -File $file.FullName -RelativePath $relativePath

        $topSections = @($xml.DocumentElement.ChildNodes | Where-Object { $_.NodeType -eq [System.Xml.XmlNodeType]::Element } | Select-Object -ExpandProperty Name -Unique)

        foreach ($sectionName in $topSections) {
            $sectionNodes = @($xml.SelectNodes("/configuration/$sectionName"))
            $allDescendants = @()
            foreach ($sn in $sectionNodes) {
                $allDescendants += @($sn.SelectNodes(".//*"))
            }

            $repeatedNodes = $allDescendants | Group-Object Name | Where-Object { $_.Count -gt 1 } | Select-Object -ExpandProperty Name
            $attrNames = New-Object System.Collections.Generic.HashSet[string]

            foreach ($desc in $allDescendants) {
                if ($desc.Attributes) {
                    foreach ($a in $desc.Attributes) {
                        [void]$attrNames.Add($a.Name)
                    }
                }
            }

            $summaryRows.Add([pscustomobject]@{
                File                 = $file.FullName
                RelativePath         = $relativePath
                Section              = $sectionName
                SectionPath          = "/configuration/$sectionName"
                NodeCount            = $allDescendants.Count
                RepeatedNodeNames    = ($repeatedNodes -join "|")
                AttributeNames       = (($attrNames | Sort-Object) -join "|")
                LooksCustomStructured = [bool](($repeatedNodes.Count -gt 0) -or ($attrNames.Count -gt 0))
            }) | Out-Null
        }
    }
}

$detailRows  | Export-Csv -LiteralPath $OutputCsv -NoTypeInformation -Encoding UTF8
$summaryRows | Export-Csv -LiteralPath $OutputSummaryCsv -NoTypeInformation -Encoding UTF8

Log "Done."
Log "Detail CSV:  $OutputCsv"
Log "Summary CSV: $OutputSummaryCsv"
Log "Log:         $OutputLog"