﻿<#
.SYNOPSIS
    Compares QCAD XML/config files between TeamCity-generated configs and repo configs.

.DESCRIPTION
    Handles paths like:
      POLVCADVCSVT10\Vision\VisVT\Services\VCS
      POLVCADVCSVT10\d$\vision\VisVT\Services\VCS
      QPS-VWS-VT-16\d$\inetpub\wwwroot\...

    Outputs:
      - CSV summary with inline differences
      - Per-file full diff files
      - Log file

.EXAMPLE
    .\Compare-QCADXmlConfigs.ps1 `
      -GeneratedPath "C:\temp\QCAD\VT\Configs\TeamCity_Generated\OLD" `
      -RepoPath "C:\temp\QCAD\VT\Merge\pipelines\Deployment.QCAD.Merge\Configs\VT\Merging\OLD" `
      -OutputPath "C:\temp\QCAD\VT\ConfigDiffs" `
      -MaxDiffLinesInCsv 50
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$GeneratedPath,

    [Parameter(Mandatory = $true)]
    [string]$RepoPath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [string[]]$Include = @("*.config", "*.xml"),

    # Matches:
    #   POLVCADVCSVT10
    #   EGLVCADVCSVT01
    #   QPS-VWS-VT-16
    #   QPS-VAS-VT-05
    #   QPS-CCM-VT-03
    [string]$ServerNameRegex = '([A-Z0-9]+VCADV[A-Z]+VT\d{2}|QPS-[A-Z]+-VT-\d{2})',

    [switch]$IgnoreWhitespaceOnlyChanges,

    [int]$MaxDiffLinesInCsv = 25
)

$ErrorActionPreference = "Stop"

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$runRoot = Join-Path $OutputPath "ConfigCompare_$timestamp"
$diffRoot = Join-Path $runRoot "Diffs"
$csvPath = Join-Path $runRoot "Config_Diff_Summary.csv"
$logPath = Join-Path $runRoot "Config_Diff_Log.txt"

New-Item -ItemType Directory -Path $runRoot -Force | Out-Null
New-Item -ItemType Directory -Path $diffRoot -Force | Out-Null

function Write-Log {
    param([string]$Message)

    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Message"
    Write-Host $line
    Add-Content -Path $logPath -Value $line
}

function Get-ComparablePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$FullPath,

        [Parameter(Mandatory = $true)]
        [string]$ServerRegex
    )

    $normalised = $FullPath -replace '/', '\'

    $match = [regex]::Match(
        $normalised,
        $ServerRegex,
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )

    if (-not $match.Success) {
        # Fallback for files like OLD_VT.xml / NEW_VT.xml that do not sit under a server folder.
        # They are compared by filename only.
        return ("_rootfiles\" + (Split-Path -Path $FullPath -Leaf)).ToLower()
    }

    $pathFromServer = $normalised.Substring($match.Index)

    # SERVER\d$\vision\... becomes SERVER\vision\...
    # SERVER\c$\inetpub\... becomes SERVER\inetpub\...
    $pathFromServer = $pathFromServer -replace '(?i)\\[a-z]\$\\', '\'

    # Normalise duplicate slashes and casing
    $pathFromServer = $pathFromServer -replace '\\+', '\'

    return $pathFromServer.ToLower()
}

function Get-SafeFileName {
    param([string]$Value)

    return ($Value -replace '[\\/:*?"<>|]', '_')
}

function Get-FileLinesNormalised {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [switch]$IgnoreWhitespaceOnlyChanges
    )

    try {
        [xml]$xml = Get-Content -LiteralPath $Path -Raw

        $settings = New-Object System.Xml.XmlWriterSettings
        $settings.Indent = $true
        $settings.IndentChars = "  "
        $settings.NewLineChars = "`r`n"
        $settings.NewLineHandling = "Replace"
        $settings.OmitXmlDeclaration = $false

        $stringBuilder = New-Object System.Text.StringBuilder
        $writer = [System.Xml.XmlWriter]::Create($stringBuilder, $settings)
        $xml.Save($writer)
        $writer.Close()

        $lines = $stringBuilder.ToString() -split "`r?`n"
    }
    catch {
        $lines = Get-Content -LiteralPath $Path
    }

    if ($IgnoreWhitespaceOnlyChanges) {
        $lines = $lines |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ -ne "" }
    }

    return $lines
}

function Get-DiffSummary {
    param(
        $Diff,
        [int]$MaxLines = 25
    )

    if ($null -eq $Diff -or $Diff.Count -eq 0) {
        return ""
    }

    $lines = $Diff |
        Select-Object -First $MaxLines |
        ForEach-Object {
            "$($_.SideIndicator) $($_.InputObject)"
        }

    $summary = $lines -join " | "

    if ($Diff.Count -gt $MaxLines) {
        $summary += " ... ($($Diff.Count) total differences)"
    }

    return $summary
}

function Build-FileLookup {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RootPath,

        [Parameter(Mandatory = $true)]
        [string[]]$Include,

        [Parameter(Mandatory = $true)]
        [string]$ServerRegex,

        [Parameter(Mandatory = $true)]
        [string]$SourceName
    )

    $lookup = @{}
    $files = @()

    foreach ($pattern in $Include) {
        $files += Get-ChildItem -Path $RootPath -Recurse -File -Filter $pattern
    }

    Write-Log "$SourceName files discovered: $($files.Count)"

    foreach ($file in $files) {
        try {
            $key = Get-ComparablePath `
                -FullPath $file.FullName `
                -ServerRegex $ServerRegex

            if (-not $lookup.ContainsKey($key)) {
                $lookup[$key] = @()
            }

            $lookup[$key] += $file
        }
        catch {
            Write-Log "WARNING: Skipping file: $($file.FullName)"
            Write-Log "WARNING: $($_.Exception.Message)"
        }
    }

    return $lookup
}

Write-Log "Starting QCAD XML config comparison"
Write-Log "Generated path: $GeneratedPath"
Write-Log "Repo path: $RepoPath"
Write-Log "Output path: $runRoot"
Write-Log "Server regex: $ServerNameRegex"
Write-Log "Max CSV diff lines: $MaxDiffLinesInCsv"

$generatedLookup = Build-FileLookup `
    -RootPath $GeneratedPath `
    -Include $Include `
    -ServerRegex $ServerNameRegex `
    -SourceName "Generated"

$repoLookup = Build-FileLookup `
    -RootPath $RepoPath `
    -Include $Include `
    -ServerRegex $ServerNameRegex `
    -SourceName "Repo"

$allKeys = @()
$allKeys += $generatedLookup.Keys
$allKeys += $repoLookup.Keys
$allKeys = $allKeys | Sort-Object -Unique

Write-Log "Comparable file keys found: $($allKeys.Count)"

$results = @()

foreach ($key in $allKeys) {
    $generatedFiles = @()
    $repoFiles = @()

    if ($generatedLookup.ContainsKey($key)) {
        $generatedFiles = $generatedLookup[$key]
    }

    if ($repoLookup.ContainsKey($key)) {
        $repoFiles = $repoLookup[$key]
    }

    if ($generatedFiles.Count -eq 0) {
        foreach ($repoFile in $repoFiles) {
            $results += [pscustomobject]@{
                ComparablePath = $key
                Status         = "MissingInGenerated"
                GeneratedFile  = ""
                RepoFile       = $repoFile.FullName
                DiffFile       = ""
                DiffCount      = ""
                DiffSummary    = "File exists in repo but not in generated configs"
                GeneratedHash  = ""
                RepoHash       = (Get-FileHash -LiteralPath $repoFile.FullName -Algorithm SHA256).Hash
                Notes          = "Missing from generated output"
            }
        }
        continue
    }

    if ($repoFiles.Count -eq 0) {
        foreach ($generatedFile in $generatedFiles) {
            $results += [pscustomobject]@{
                ComparablePath = $key
                Status         = "MissingInRepo"
                GeneratedFile  = $generatedFile.FullName
                RepoFile       = ""
                DiffFile       = ""
                DiffCount      = ""
                DiffSummary    = "File exists in generated configs but not in repo"
                GeneratedHash  = (Get-FileHash -LiteralPath $generatedFile.FullName -Algorithm SHA256).Hash
                RepoHash       = ""
                Notes          = "Missing from repo"
            }
        }
        continue
    }

    if ($generatedFiles.Count -gt 1 -or $repoFiles.Count -gt 1) {
        Write-Log "WARNING: Duplicate comparable key found: $key"
    }

    foreach ($generatedFile in $generatedFiles) {
        foreach ($repoFile in $repoFiles) {
            Write-Log "Comparing: $key"

            $generatedHash = (Get-FileHash -LiteralPath $generatedFile.FullName -Algorithm SHA256).Hash
            $repoHash = (Get-FileHash -LiteralPath $repoFile.FullName -Algorithm SHA256).Hash

            $generatedLines = Get-FileLinesNormalised `
                -Path $generatedFile.FullName `
                -IgnoreWhitespaceOnlyChanges:$IgnoreWhitespaceOnlyChanges

            $repoLines = Get-FileLinesNormalised `
                -Path $repoFile.FullName `
                -IgnoreWhitespaceOnlyChanges:$IgnoreWhitespaceOnlyChanges

            $diff = Compare-Object `
                -ReferenceObject $repoLines `
                -DifferenceObject $generatedLines `
                -IncludeEqual:$false

            if ($null -eq $diff) {
                $diffCount = 0
            }
            else {
                $diffCount = $diff.Count
            }

            $diffSummary = Get-DiffSummary `
                -Diff $diff `
                -MaxLines $MaxDiffLinesInCsv

            if ($diffCount -eq 0) {
                $status = "SameAfterNormalisation"
                $diffFile = ""
                $notes = "No content differences after XML/text normalisation"
            }
            else {
                $status = "Different"
                $safeName = Get-SafeFileName -Value $key
                $diffFile = Join-Path $diffRoot "$safeName.diff.txt"

                @(
                    "Comparable path:"
                    $key
                    ""
                    "Repo file:"
                    $repoFile.FullName
                    ""
                    "Generated file:"
                    $generatedFile.FullName
                    ""
                    "Legend:"
                    "<= Exists in repo"
                    "=> Exists in generated config"
                    ""
                    "Differences:"
                    ""
                    $diff | ForEach-Object {
                        "$($_.SideIndicator) $($_.InputObject)"
                    }
                ) | Set-Content -Path $diffFile

                $notes = "Content differs. Inline summary is in CSV. Full diff is in DiffFile."
            }

            $results += [pscustomobject]@{
                ComparablePath = $key
                Status         = $status
                GeneratedFile  = $generatedFile.FullName
                RepoFile       = $repoFile.FullName
                DiffFile       = $diffFile
                DiffCount      = $diffCount
                DiffSummary    = $diffSummary
                GeneratedHash  = $generatedHash
                RepoHash       = $repoHash
                Notes          = $notes
            }
        }
    }
}

$results |
    Sort-Object Status, ComparablePath |
    Export-Csv -Path $csvPath -NoTypeInformation

$summary = $results | Group-Object Status | Sort-Object Name

Write-Log ""
Write-Log "Summary:"
foreach ($item in $summary) {
    Write-Log "$($item.Name): $($item.Count)"
}

Write-Log ""
Write-Log "Complete"
Write-Log "CSV summary: $csvPath"
Write-Log "Diff files: $diffRoot"
Write-Log "Log file: $logPath"

Write-Host ""
Write-Host "Done. Summary CSV:" -ForegroundColor Green
Write-Host $csvPath