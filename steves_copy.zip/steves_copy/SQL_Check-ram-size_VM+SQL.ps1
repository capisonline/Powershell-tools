# Specify the path to the text file containing server names 
$serversFile = "C:\temp\serverlist.txt"

# Specify the path for the output CSV file
$outputFile = "C:\temp\SQL_CHeck-output.csv"

# Check if the file exists
if (Test-Path $serversFile) {
    # Read the list of server names from the file
    $servers = Get-Content $serversFile

    # Create an array to store results
    $results = @()

    foreach ($server in $servers) {
        try {
            # Load the SQL Server SMO assembly
            [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Smo') | Out-Null

            # Connect to the SQL Server instance (adjust the instance name accordingly)
            $sqlServerInstance = New-Object Microsoft.SqlServer.Management.Smo.Server($server)

            # Retrieve the SQL Server edition and version
            $sqlEdition = $sqlServerInstance.Information.Edition
            $sqlVersion = $sqlServerInstance.Information.ProductLevel

            # Retrieve the configured max server memory (in MB)
            $maxServerMemory = $sqlServerInstance.Configuration.MaxServerMemory.ConfigValue

            # Retrieve the host VM's RAM size
            $vmRamSize = Get-WmiObject Win32_ComputerSystem | Select-Object -ExpandProperty TotalPhysicalMemory
            $vmRamSizeInGB = [math]::Round($vmRamSize / 1GB, 2)

            # Create a custom object with the results
            $resultObject = [PSCustomObject]@{
                Server = $server
                SqlEdition = $sqlEdition
                SqlVersion = $sqlVersion
                MaxServerMemory_MB = $maxServerMemory
                HostVMRamSize_GB = $vmRamSizeInGB
            }

            # Add the result object to the array
            $results += $resultObject
        }
        catch {
            Write-Host "Error connecting to SQL Server on $_"
        }
    }

    # Export the results to CSV
    $results | Export-Csv -Path $outputFile -NoTypeInformation
    Write-Host "Results saved to $outputFile"
} else {
    Write-Host "Server list file not found: $serversFile"
}
