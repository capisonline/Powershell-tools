# Input and Output File Paths 
$InputFile = "C:\temp\QCAD\VT\Adapter-Details\VT_Ping_list.txt"
$OutputFile = "C:\temp\QCAD\VT\Adapter-Details\VT_PingResults.csv"

# Import the list of hostnames
$Hostnames = Get-Content -Path $InputFile

# Initialize an empty array for results
$Results = @()

# Use parallel processing for faster pings
$Results = $Hostnames | ForEach-Object -Parallel {
    try {
        # Ping the hostname
        $PingResult = Test-Connection -ComputerName $_ -Count 1 -ErrorAction Stop
        $IPAddress = $PingResult.IPV4Address.IPAddressToString

        # Get FQDN
        $FQDN = ([System.Net.Dns]::GetHostEntry($_)).HostName

        # Return the result as a PSCustomObject
        [PSCustomObject]@{
            Hostname  = $_
            FQDN      = $FQDN
            IPAddress = $IPAddress
        }
    }
    catch {
        # Return an entry for failed pings
        [PSCustomObject]@{
            Hostname  = $_
            FQDN      = "N/A"
            IPAddress = "Ping Failed"
        }
    }
} -ThrottleLimit 50 # Adjust the throttle limit as needed for your environment

# Export the results to a CSV file
$Results | Export-Csv -Path $OutputFile -NoTypeInformation -Encoding UTF8

Write-Host "Ping results have been saved to $OutputFile"
