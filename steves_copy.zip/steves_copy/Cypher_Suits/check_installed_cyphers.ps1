﻿# Check if the Get-TlsCipherSuite cmdlet is available (Server 2016+)
Write-Host "=== Active Cipher Suites (via Get-TlsCipherSuite) ==="
if (Get-Command -Name Get-TlsCipherSuite -ErrorAction SilentlyContinue) {
    Get-TlsCipherSuite | Sort-Object Priority | Select-Object -Property Priority, Name
} else {
    Write-Warning "Get-TlsCipherSuite cmdlet not available. Skipping."
}

Write-Host "`n=== Cipher Suites Registry (Schannel overrides) ==="

# Registry paths for cipher suite overrides
$regPaths = @(
    "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002",  # Group Policy
    "HKLM:\SYSTEM\CurrentControlSet\Control\Cryptography\Configuration\Local\SSL\00010002"  # Local
)

foreach ($path in $regPaths) {
    if (Test-Path $path) {
        $ciphers = Get-ItemProperty -Path $path -Name "Functions" -ErrorAction SilentlyContinue
        if ($ciphers.Functions) {
            Write-Host "`nCiphers defined at: $path"
            $ciphers.Functions -split ',' | ForEach-Object { $_.Trim() } | Sort-Object
        } else {
            Write-Host "`n$path exists, but no 'Functions' value is defined."
        }
    } else {
        Write-Host "`n$path not found."
    }
}
