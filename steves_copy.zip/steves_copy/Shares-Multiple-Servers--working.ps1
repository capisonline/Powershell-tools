﻿# Path to the text file containing the server names 
$serverListPath = "C:\temp\QCAD\VT\VT_Old_Servers.txt"

# Read the server names from the file
$servers = Get-Content -Path $serverListPath

# The CSV file path where the results will be saved
$csvFilePath = "C:\temp\QCAD\VT\Shared_Folders-NTFS_Perms\VT_server_shares.csv"

# Create an empty array to hold the results
$results = @()

foreach ($server in $servers) {
    # Check if the server is reachable
    $isReachable = Test-Connection -ComputerName $server -Count 1 -Quiet

    if ($isReachable) {
        $smbShares = Get-SMBShare -CimSession $server

        foreach ($share in $smbShares) {
            $accessList = Get-SmbShareAccess -Name $share.Name -CimSession $server

            # For each access rule, add a custom object to the results array
            foreach ($access in $accessList) {
                $result = [PSCustomObject]@{
                    Server = $server
                    ShareName = $share.Name
                    LocalPath = $share.Path
                    AccountName = $access.AccountName
                    AccessRight = $access.AccessRight
                    Status = "Accessible"
                }
                $results += $result
            }
        }
    } else {
        # Add a record for the skipped server
        $result = [PSCustomObject]@{
            Server = $server
            ShareName = "N/A"
            LocalPath = "N/A"
            AccountName = "N/A"
            AccessRight = "N/A"
            Status = "Skipped - Not Reachable"
        }
        $results += $result
        Write-Host "Server $server is not reachable. Skipping..."
    }
}

# Export the results array to a CSV file
$results | Export-Csv -Path $csvFilePath -NoTypeInformation

