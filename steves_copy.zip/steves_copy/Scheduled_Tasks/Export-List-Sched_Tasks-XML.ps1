﻿# List of target servers 
$servers = Get-Content "C:\temp\QCAD\BA\Scheduled_Tasks\Server_List.txt" # Replace with your server names

# Local folder to store the exported XML files
$localOutputFolder = "C:\temp\QCAD\BA\Scheduled_Tasks\ExportedTasks" # Update to your desired path

# Ensure the local folder exists
if (!(Test-Path -Path $localOutputFolder)) {
    New-Item -Path $localOutputFolder -ItemType Directory
}

# Loop through each server
foreach ($server in $servers) {
    try {
        # Check if the server is accessible
        Test-Connection -ComputerName $server -Count 1 -Quiet
        if ($?) {
            # Retrieve the list of scheduled tasks on the remote server
            $tasks = Invoke-Command -ComputerName $server -ScriptBlock {
                Get-ScheduledTask | Select-Object -ExpandProperty TaskName
            }

            foreach ($task in $tasks) {
                # Export each task to a temporary XML file on the remote server
                Invoke-Command -ComputerName $server -ScriptBlock {
                    param ($task)
                    $remoteTempXml = "C:\Temp\$($task).xml"
                    if (!(Test-Path -Path 'C:\Temp')) {
                        New-Item -Path 'C:\Temp' -ItemType Directory
                    }
                    Export-ScheduledTask -TaskName $task -Path $remoteTempXml
                    return $remoteTempXml
                } -ArgumentList $task | ForEach-Object {
                    $remoteTempXml = $_

                    # Download the XML file to the local machine
                    $localFilePath = Join-Path -Path $localOutputFolder -ChildPath "$server-$task.xml"
                    Copy-Item -Path "\\$server\C$\Temp\$($task).xml" -Destination $localFilePath -Force

                    # Optionally, remove the temp XML file from the remote server
                    Invoke-Command -ComputerName $server -ScriptBlock {
                        param ($filePath)
                        Remove-Item -Path $filePath -Force
                    } -ArgumentList $remoteTempXml
                }
                Write-Output "Task '$task' exported from server: $server to $localFilePath."
            }
        } else {
            Write-Output "Unable to reach server: $server."
        }
    } catch {
        Write-Output "An error occurred while processing server: $server. Error: $_"
    }
}
