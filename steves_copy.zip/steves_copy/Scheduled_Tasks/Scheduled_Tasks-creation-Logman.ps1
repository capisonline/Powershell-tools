﻿# PowerShell script to create a scheduled task on each server listed in a text file 

$taskName = "logman (QCAD logfile management)"
$taskDescription = "Truncates & Cleans Vision Log Files"
$serversList = "C:\temp\QCAD\BA\Scheduled_Tasks\Server_List.txt"

# Read the list of servers
$servers = Get-Content -Path $serversList

# Loop through each server and set up the task
foreach ($server in $servers) {
    # Create the action to run the batch file
    $action = New-ScheduledTaskAction -Execute "E:\tasks\run-task-2012-logman.bat"

    # Create the trigger to run the task daily with repetition every 4 hours
    $trigger = New-ScheduledTaskTrigger -Daily -At "00:00:30" `
        -RepetitionInterval (New-TimeSpan -Hours 4) `
        -RepetitionDuration (New-TimeSpan -Days 9999)

    # Create the principal with a specified user ID and highest privilege
    $principal = New-ScheduledTaskPrincipal -UserId "PRDS\QCAD-BatchJob-BA" -LogonType S4U -RunLevel Highest

    # Create task settings as specified
    $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew `
        -DisallowStartIfOnBatteries -StopIfGoingOnBatteries `
        -AllowHardTerminate -Priority 7 `
        -ExecutionTimeLimit (New-TimeSpan -Hours 1)

    # Script block to be executed on the remote server
    $scriptBlock = {
        Param ($taskName, $taskDescription, $action, $trigger, $principal, $settings)

        # Unregister any existing task with the same name and create a new one
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
        $task = New-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -Settings $settings
        Register-ScheduledTask -TaskName $taskName -InputObject $task

        Start-ScheduledTask -TaskName $taskName
        Write-Output "Scheduled Task '$taskName' created and started successfully on $(hostname)."
    }

    # Execute the task creation process on the remote server
    try {
        Invoke-Command -ComputerName $server -ScriptBlock $scriptBlock `
            -ArgumentList $taskName, $taskDescription, $action, $trigger, $principal, $settings `
            -ErrorAction Stop
    } catch {
        Write-Error "Failed to create or start task on ${server}: $_"
    }
}
