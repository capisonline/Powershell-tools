﻿# PowerShell script to copy a local script to each server listed in a text file and create a scheduled task to execute it every 3 minutes 

# Task Scheduler details
$taskName = "Netstat"
$taskDescription = "Runs C:\temp\netstat-bano_loop.ps1 script every 3 minutes."
$localScriptPath = "C:\temp\scripts\Networking\netstat-bano_loop.ps1"
$remoteScriptPath = "C$\temp"
$serversList = "C:\temp\QCAD\TP\Networking\TP_Old-Server-Netstat.txt"

# Read the list of servers
$servers = Get-Content -Path $serversList

# Loop through each server and set up the task
foreach ($server in $servers) {
    # Construct the UNC path for copying the script using ${} to delineate variable
    $uncPath = "\\${server}\${remoteScriptPath}" # Correct format for UNC path with explicit variable delineation

    # Try to copy the script to the remote server, handle potential errors
    try {
        Copy-Item -Path $localScriptPath -Destination $uncPath -Force -ErrorAction Stop
    } catch {
        Write-Error "Failed to copy to ${server} $_"
        continue # Skip further commands and proceed with the next server
    }

    # Define the action to run the PowerShell script on the remote server
    $action = New-ScheduledTaskAction -Execute "Powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"${remoteScriptPath}`""

    # Define the trigger to run every 3 minutes
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(3) -RepetitionInterval (New-TimeSpan -Minutes 3) -RepetitionDuration ([timespan]::MaxValue)

    # Define the principal under which the task should run (System account)
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount

    # Use Invoke-Command to register the task on the remote server
    $scriptBlock = {
        param($taskName, $taskDescription, $action, $trigger, $principal)
        Register-ScheduledTask -TaskName $taskName -Description $taskDescription -Action $action -Trigger $trigger -Principal $principal
    }

    try {
        Invoke-Command -ComputerName $server -ScriptBlock $scriptBlock -ArgumentList $taskName, $taskDescription, $action, $trigger, $principal -ErrorAction Stop
        Write-Output "Scheduled Task '$taskName' created successfully on $server to run every 3 minutes."
    } catch {
        Write-Error "Failed to create task on ${server} $_"
    }
}
