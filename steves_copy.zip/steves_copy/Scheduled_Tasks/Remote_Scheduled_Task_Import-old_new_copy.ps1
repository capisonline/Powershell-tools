﻿# Define the path to the input CSV file 
$csvPath = "C:\temp\QCAD\BA\LogMan\xml_update-input.csv"

# Define the path to the folder to be copied
$folderPath = "C$\temp\QCAD\BA\LogMan\working\"

# Define the path where the folder should be copied on the new server
$destinationPath = "E$\"

# Define the name of the scheduled task file
$scheduledTaskFile = "C$\temp\QCAD\BA\LogMan\working\tasks\logman (QCAD logfile management).xml"

# Define the hardcoded credentials
$taskUsername = "PRDS\QCAD-BatchJob-BA"
$taskPassword = "w0*2i*gotk"

# Import the CSV file
$servers = Import-Csv -Path $csvPath

foreach ($server in $servers) {
    $oldServer = $server.OldServer
    $newServer = $server.NewServer

    # Copy the folder from the old server to the new server
    $sourceFolder = "\\$oldServer\$folderPath"
    $destinationFolder = "\\$newServer\$destinationPath"

    Write-Host "Copying folder from $sourceFolder to $destinationFolder"
    Copy-Item -Path $sourceFolder -Destination $destinationFolder -Recurse -Force

    # Import the scheduled task on the new server
    $taskXmlPath = Join-Path -Path $destinationFolder -ChildPath $scheduledTaskFile
    $taskName = "logman (QCAD logfile management)"

    Write-Host "Registering scheduled task on $newServer"
    $command = {
        param ($taskXmlPath, $taskName, $taskUsername, $taskPassword)
        schtasks.exe /Create /XML $taskXmlPath /TN $taskName /RU $taskUsername /RP $taskPassword
    }
    Invoke-Command -ComputerName $newServer -ScriptBlock $command -ArgumentList $taskXmlPath, $taskName, $taskUsername, $taskPassword
}

Write-Host "Script execution completed."
