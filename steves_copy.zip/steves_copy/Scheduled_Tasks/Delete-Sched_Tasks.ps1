﻿
# Define the path to the text file containing the list of server names 
$serverListPath = "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"

# Read the server names from the text file
$servers = Get-Content -Path $serverListPath

# Ask for the name of the scheduled task to delete
$taskName = Read-Host "Enter the name of the scheduled task you want to delete"

# Loop through each server and attempt to delete the specified task
foreach ($server in $servers) {
    # Use Invoke-Command to run commands on the remote server
    Invoke-Command -ComputerName $server -ScriptBlock {
        Param($taskName)
        # Check if the scheduled task exists
        $taskExists = Get-ScheduledTask | Where-Object {$_.TaskName -eq $taskName}

        if ($taskExists) {
            # Task found, proceed with deletion
            Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
            Write-Output "Scheduled task '$taskName' has been deleted successfully on $env:COMPUTERNAME."
        } else {
            # Task not found
            Write-Output "No scheduled task named '$taskName' was found on $env:COMPUTERNAME."
        }
    } -ArgumentList $taskName
}
