﻿# Deploy-ExportFirewallTask.ps1
# Copies ExportFirewall.ps1 and registers a 2-hourly scheduled task on all servers listed in servers.txt

$TaskName = "ExportFirewallLog"
$ScriptSource = "C:\temp\scripts\Scheduled_Tasks\ExportFirewallLog.ps1"
$ScriptDestination = "D:\scripts\ExportFirewallLog.ps1"
$Servers = Get-Content "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"

foreach ($Server in $Servers) {
    Write-Host "Deploying to $Server..."

    try {
        # Create D:\scripts if it doesn't exist
        Invoke-Command -ComputerName $Server -ScriptBlock {
            if (-not (Test-Path "D:\scripts")) {
                New-Item -Path "D:\scripts" -ItemType Directory -Force | Out-Null
            }
        }

        # Copy the ExportFirewall script to the server
        Copy-Item -Path $ScriptSource -Destination "\\$Server\D$\scripts\" -Force

        # Register scheduled task on remote server
        Invoke-Command -ComputerName $Server -ScriptBlock {
            param ($TaskName, $ScriptPath)

            $Action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-ExecutionPolicy Bypass -File `"$ScriptPath`""

            # Start 1 minute from now, repeat every 2 hours indefinitely
            $StartTime = (Get-Date).AddMinutes(1)
            $Trigger = New-ScheduledTaskTrigger -Once -At $StartTime `
                -RepetitionInterval (New-TimeSpan -Hours 2) `
                -RepetitionDuration (New-TimeSpan -Days 365)

            $Principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
            $Task = New-ScheduledTask -Action $Action -Trigger $Trigger -Principal $Principal

            Register-ScheduledTask -TaskName $TaskName -InputObject $Task -Force

            Write-Host "Scheduled Task '$TaskName' created on $env:COMPUTERNAME"
        } -ArgumentList $TaskName, $ScriptDestination

        Write-Host "$Server - Deployed and scheduled task registered." -ForegroundColor Green
    } catch {
        Write-Warning "$Server - Deployment failed: $_"
    }
}
