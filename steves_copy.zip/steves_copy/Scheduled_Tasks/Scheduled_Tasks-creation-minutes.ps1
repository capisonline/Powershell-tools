﻿# PowerShell script to create a scheduled task to run the SQL backup script every 3 minutes 

# Task Scheduler details
$taskName = "SQLDatabaseBackup"
$taskDescription = "Runs an SQL database backup script every 3 minutes."
$taskScriptPath = "C:\temp\sql_backup_script.ps1"

# Check if the task already exists
$existingTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($null -ne $existingTask) {
    Write-Output "Task '$taskName' already exists. Removing the existing one to create a new one."
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}

# Create the action to run the PowerShell script
$action = New-ScheduledTaskAction -Execute "Powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$taskScriptPath`""

# Create the trigger for the task to run every 3 minutes
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(3) -RepetitionInterval (New-TimeSpan -Minutes 3) -RepetitionDuration ([timespan]::MaxValue)

# Specify the user under which the task should run (System account)
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount

# Register the task with the action and trigger
Register-ScheduledTask -TaskName $taskName -Description $taskDescription -Action $action -Trigger $trigger -Principal $principal

Write-Output "Scheduled Task '$taskName' created successfully to run every 3 minutes."
