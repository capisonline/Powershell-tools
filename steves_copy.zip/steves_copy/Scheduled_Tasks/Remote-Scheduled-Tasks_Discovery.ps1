﻿# Path to the text file containing server names (one per line) 
$serversFile = "C:\temp\QCAD\VT\VT_Old_Servers.txt"

# Path to save the scheduled tasks information as a CSV file
$outputPath = "C:\temp\QCAD\VT\Scheduled_Tasks\VT_Old_Servers_ScheduledTasksReport_final.csv"

# Folder containing custom tasks (e.g., root '\' or other specific folder)
$folderPath = '\'

# Read server names
$servers = Get-Content -Path $serversFile

# Initialize a list to collect task details
$taskList = New-Object System.Collections.Generic.List[object]

# Function to convert state code to descriptive text
function Convert-State {
    param (
        [int]$stateCode
    )

    switch ($stateCode) {
        0 { "Unknown" }
        1 { "Disabled" }
        2 { "Queued" }
        3 { "Ready" }
        4 { "Running" }
        default { "Unspecified" }
    }
}

# Function to fetch tasks
function Get-CustomTasks {
    param (
        [string]$server,
        [string]$folder
    )

    $tasks = Invoke-Command -ComputerName $server -ScriptBlock {
        param($folder)
        Get-ScheduledTask -TaskPath $folder | Where-Object {$_.TaskName -notlike '\Microsoft\*'}
    } -ArgumentList $folder

    # Process each task and store relevant details
    foreach ($task in $tasks) {
        $taskDetails = [PSCustomObject]@{
            Server       = $server
            TaskName     = $task.TaskName
            TaskPath     = $task.TaskPath
            Description  = $task.Description
            State        = Convert-State -stateCode $task.State
            LastRunTime  = $task.LastRunTime
            NextRunTime  = $task.NextRunTime
            RunAsAccount = $task.Principal.UserId
        }
        $taskList.Add($taskDetails)
    }
}

# Retrieve and store task data from each server
foreach ($server in $servers) {
    Get-CustomTasks -server $server -folder $folderPath
}

# Export to CSV
$taskList | Export-Csv -Path $outputPath -NoTypeInformation

Write-Output "Scheduled tasks have been collected and saved to $outputPath"
