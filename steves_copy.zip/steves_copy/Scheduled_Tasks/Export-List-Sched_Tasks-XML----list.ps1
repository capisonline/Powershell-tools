﻿# Load CSV file 
$csvPath = "C:\temp\QCAD\BA\Scheduled_Tasks\BA_Schedtasks_Input.csv"  # Adjust this to the correct path
$outputFolder = "C:\temp\QCAD\BA\Scheduled_Tasks\ExportedTasks7\"  # Specify the local output folder

$remoteTempFolder = "C$\temp"  # Specify the remote temp directory for storing XMLs

# Check if output folder exists; if not, create it
if (!(Test-Path -Path $outputFolder)) {
    New-Item -Path $outputFolder -ItemType Directory
}

# Read CSV data
$scheduledTasks = Import-Csv -Path $csvPath

# Loop through each row in the CSV file
foreach ($taskEntry in $scheduledTasks) {
    $server = $taskEntry.Server.Trim()  # Remove any leading/trailing whitespace
    $taskName = $taskEntry.Task.Trim()  # Similarly, trim task name

    # Ensure both server and task names are not empty
    if ([string]::IsNullOrWhiteSpace($server) -or [string]::IsNullOrWhiteSpace($taskName)) {
        Write-Warning "Skipped entry due to missing server or task name"
        continue
    }

    # Safely format the file name by replacing illegal characters and spaces
    $safeTaskName = $taskName -replace '[\\/:*?"<>|]+', '_' -replace '\s', '_'
    $taskFileName = "${server}_${safeTaskName}.xml"
    $remoteTaskPath = Join-Path -Path $remoteTempFolder -ChildPath $taskFileName
    $taskOutputPath = Join-Path -Path $outputFolder -ChildPath $taskFileName

    # Debug output to verify correct task name and output path
    Write-Output "Server: '$server', Task: '$taskName'"
    Write-Output "Generating output file name: '$taskFileName'"

    # Try to connect and export the scheduled task to the remote server's temp directory
    try {
        Invoke-Command -ComputerName $server -ScriptBlock {
            param ($taskName, $remoteTempFolder, $remoteTaskPath)
            # Create the temp folder if it does not exist
            if (!(Test-Path -Path $remoteTempFolder)) {
                New-Item -Path $remoteTempFolder -ItemType Directory
            }

            # Export the task
            $task = Get-ScheduledTask -TaskName $taskName
            Export-ScheduledTask -InputObject $task | Out-File -FilePath $remoteTaskPath
        } -ArgumentList $taskName, $remoteTempFolder, $remoteTaskPath

        # Copy the exported file from the remote server back to the local machine
        Copy-Item -Path "\\$server\$remoteTempFolder\$taskFileName" -Destination $taskOutputPath

        Write-Output "Successfully exported task '$taskName' from server '$server' to $taskOutputPath"
    }
    catch {
        Write-Warning "Could not export task '$taskName' from server '$server': $_"
    }
}
