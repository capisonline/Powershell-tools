﻿# Specify the path to the text file containing server names 
$serversFile = "C:\path\to\serverlist.txt"

# Specify the path for the output file
$outputFile = "C:\path\to\output.txt"

# Check if the file exists
if (Test-Path $serversFile) {
    # Read the list of server names from the file
    $servers = Get-Content $serversFile

    # Loop through each server
    foreach ($serverName in $servers) {
        # Get server information from Active Directory
        $server = Get-ADComputer -Filter {Name -eq $serverName} -Properties MemberOf

        # Check if the server object is found
        if ($server) {
            # Save the results to the output file
            "$serverName Groups: $($server.MemberOf -join ', ')" | Out-File -Append -FilePath $outputFile
        } else {
            "Server $serverName not found in Active Directory." | Out-File -Append -FilePath $outputFile
        }
    }

    Write-Host "Results saved to $outputFile"
} else {
    Write-Host "Server list file not found: $serversFile"
}
