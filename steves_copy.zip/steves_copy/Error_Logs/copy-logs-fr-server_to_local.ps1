﻿
# Define paths 
$serverList = "C:\temp\QCAD\tp\TP_NEW_Server_list.txt"  # List of servers
$remoteNewFolder = "D$\vision\visTP"  # Folder where new .config files are stored
$remoteOldFolder = "E$\backup\2024-12A_1\vision\visTP"  # Folder where old .config files are stored
$localBaseFolder = "C:\temp\QCAD\TP\reto-fix\configs"  # Local folder where files will be saved
$logFile = "$localBaseFolder\copy_log.txt"

# Ensure local destination exists
if (-not (Test-Path $localBaseFolder)) {
    New-Item -ItemType Directory -Path $localBaseFolder -Force
}

# Read the list of servers
$servers = Get-Content -Path $serverList

foreach ($server in $servers) {
    $newRemotePath = "\\$server\$remoteNewFolder"
    $oldRemotePath = "\\$server\$remoteOldFolder"
    
    # Create server-specific local folder
    $serverLocalFolder = Join-Path -Path $localBaseFolder -ChildPath $server
    $newLocalFolder = Join-Path -Path $serverLocalFolder -ChildPath "New"
    $oldLocalFolder = Join-Path -Path $serverLocalFolder -ChildPath "Old"

    # Ensure local subfolders exist
    foreach ($folder in @($serverLocalFolder, $newLocalFolder, $oldLocalFolder)) {
        if (-not (Test-Path $folder)) {
            New-Item -ItemType Directory -Path $folder -Force
        }
    }

    # Copy New Config Files
    if (Test-Path $newRemotePath) {
        Write-Output "Copying new .config files from $server..." | Tee-Object -FilePath $logFile -Append
        try {
            Get-ChildItem -Path $newRemotePath -Filter "*.config" -File -Recurse | ForEach-Object {
                $destFile = Join-Path -Path $newLocalFolder -ChildPath $_.Name
                Copy-Item -Path $_.FullName -Destination $destFile -Force
            }
            Write-Output "New config files copied successfully from $server." | Tee-Object -FilePath $logFile -Append
        }
        catch {
            Write-Output "Error copying new config files from $server - $_" | Tee-Object -FilePath $logFile -Append
        }
    }
    else {
        Write-Output "New config folder not found on $server." | Tee-Object -FilePath $logFile -Append
    }

    # Copy Old Config Files
    if (Test-Path $oldRemotePath) {
        Write-Output "Copying old .config files from $server..." | Tee-Object -FilePath $logFile -Append
        try {
            Get-ChildItem -Path $oldRemotePath -Filter "*.config" -File -Recurse | ForEach-Object {
                $destFile = Join-Path -Path $oldLocalFolder -ChildPath $_.Name
                Copy-Item -Path $_.FullName -Destination $destFile -Force
            }
            Write-Output "Old config files copied successfully from $server." | Tee-Object -FilePath $logFile -Append
        }
        catch {
            Write-Output "Error copying old config files from $server - $_" | Tee-Object -FilePath $logFile -Append
        }
    }
    else {
        Write-Output "Old config folder not found on $server." | Tee-Object -FilePath $logFile -Append
    }
}

Write-Output "Copy operation completed!" | Tee-Object -FilePath $logFile -Append

