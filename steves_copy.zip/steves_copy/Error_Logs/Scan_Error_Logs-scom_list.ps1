﻿# Define the path to the folder containing the log files on the local machine 
$logFolderPath = "C:\temp\QCAD\PR\logs\2024-06-10"

# Define the base path for the output CSV files
$localCsvBasePath = "C:\temp\QCAD\PR\logs\2024-06-10\Vision_scom_output.csv"

# Get the hostname of the local server
$hostname = $env:COMPUTERNAME

# Define the search terms
$searchTerms = @("ERROR - DbConn",
"ORA-",
"ERROR ? DbConn",
"ERROR - An exception occured whilst processing - ICEMS",
"System.OutOfMemoryException",
"ORA-16456",
"Bulk Copy completed",
"Access to the registry key",
"Error: The connection is broken and recovery is not possible",
"Only one usage of each socket address",
"New incident number request ERROR",
"I am not eligible to be master; 10.46.205.236",
"A request to send or receive data was disallowed",
"I am not eligible to be master - I am not connected to the network",
"Failed to send command - No connection could be made",
"An exception has occured in NumberCruncher",
" ORA-",
"ERROR ? Connection refused",
"An exception occured while processing data received from a VSCM",
"ERROR - Oracle Critical Error",
"New incident number request",
"ERROR - VisionID is empty",
"AddNewIInID",
" Failed to add Incident Narrative ",
" While processing the Policelink_Event request of event_id ",
"Database is not replicating",
"Forbidden",
"following incidents failed",
"DbConn1 Test query successful. Database is available",
"WARN" #<Addtional to SCOM query
)

# Function to scan a file for the specified terms
function Scan-File {
    param (
        [string]$filePath,
        [array]$terms
    )

    $results = @()

    try {
        # Open the file with shared read access
        $fileStream = [System.IO.File]::Open($filePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $streamReader = New-Object System.IO.StreamReader($fileStream)
        while ($line = $streamReader.ReadLine()) {
            foreach ($term in $terms) {
                if ($line -match "$term - ") {
                    # Extract the date, time, and message
                    if ($line -match '^(?<DateTime>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) \[\d+\] ' + $term + ' - (?<Message>.*)$') {
                        $dateTime = $matches['DateTime']
                        $message = $matches['Message']
                        $results += [pscustomobject]@{
                            FileName = $filePath
                            DateTime = $dateTime
                            Message  = $message
                        }
                    }
                }
            }
        }
        $streamReader.Close()
        $fileStream.Close()
    } catch {
        $results += [pscustomobject]@{
            FileName = $filePath
            DateTime = ""
            Message  = "File Locked or Not Accessible"
        }
    }

    return $results
}

# Function to scan all log files in a folder
function Scan-Folder {
    param (
        [string]$folderPath,
        [array]$terms
    )

    $logFiles = Get-ChildItem -Path $folderPath -Filter *.log

    foreach ($logFile in $logFiles) {
        $fileResults = Scan-File -filePath $logFile.FullName -terms $terms

        # Construct the CSV file name based on hostname and log file name
        $localCsvFilePath = "$($localCsvBasePath)_$($hostname)_$($logFile.Name).csv"

        # Update the local CSV file with the scan results
        $fileResults | Export-Csv -Path $localCsvFilePath -NoTypeInformation -Force
    }
}

# Call the function to scan the folder
Scan-Folder -folderPath $logFolderPath -terms $searchTerms
