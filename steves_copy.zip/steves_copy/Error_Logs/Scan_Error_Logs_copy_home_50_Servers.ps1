﻿<#
.SYNOPSIS
    Run QCAD log scan on multiple servers in parallel and collect results.

.DESCRIPTION
    - Connects to each server via PowerShell remoting (WinRM).
    - Scans E:\vision\*.log* for ERROR/WARNING between Start/End timestamps.
    - Captures 5 lines before and 50 lines after each match.
    - Writes per-host CSV to a central output share.
#>

[CmdletBinding()]
param(
    [string]$ServerListPath      = "C:\temp\QCAD\VT\Oracle\SWitchover_Logs\VT_Old_Servers.txt",   # one hostname per line
    [string]$LogInputRoot        = "E:\vision\",                    # path on each server
    [string]$CentralOutputRoot   = "\\PC556292\c$\temp\QCAD\VT\Oracle\SWitchover_Logs\2", # central share
    [string]$StartTimeString     = "2025-12-22 09:00:00",
    [string]$EndTimeString       = "2025-12-24 15:00:59",
    [int]$LinesBefore            = 5,
    [int]$LinesAfter             = 50,
    [int]$ThrottleLimit          = 10                              # max concurrent servers
)

# --- Parse times ---
$startTime = [datetime]::ParseExact($StartTimeString, "yyyy-MM-dd HH:mm:ss", $null)
$endTime   = [datetime]::ParseExact($EndTimeString,   "yyyy-MM-dd HH:mm:ss", $null)

# --- Ensure output root exists ---
if (-not (Test-Path $CentralOutputRoot)) {
    New-Item -Path $CentralOutputRoot -ItemType Directory -Force | Out-Null
}

# --- Load server list ---
$servers = Get-Content -Path $ServerListPath |
    Where-Object { $_ -and $_.Trim() -notlike '#*' } |
    ForEach-Object { $_.Trim() }

if (-not $servers) {
    Write-Warning "No servers found in $ServerListPath"
    return
}

$searchPhrases = @("ERROR", "WARNING")

# --- Script that actually runs on each remote server ---
$remoteScript = {
    param(
        [datetime]$StartTime,
        [datetime]$EndTime,
        [int]$LinesBefore,
        [int]$LinesAfter,
        [string[]]$SearchPhrases,
        [string]$LogInputRoot,
        [string]$CentralOutputRoot
    )

    # Each server writes its own CSV into the central share
    $hostname   = $env:COMPUTERNAME
    $outputPath = Join-Path $CentralOutputRoot "logscan_$hostname.csv"

    $results = @()

    if (-not (Test-Path $LogInputRoot)) {
        Write-Host "[$hostname] Log root not found: $LogInputRoot"
        return
    }

    # Recursively scan *.log* under E:\vision\
    Get-ChildItem -Path $LogInputRoot -Filter "*.log" -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
        $file  = $_.FullName
        Write-Host "[$hostname] Scanning $file"

        # NOTE: this reads whole file into memory – OK for many logs, but be cautious on huge ones
        $lines = Get-Content -Path $file

        for ($i = 0; $i -lt $lines.Count; $i++) {
            $line = "$($lines[$i])".Trim()

            # Skip if line too short to contain a timestamp
            if ($line.Length -lt 23) { continue }

            $timestampString = $line.Substring(0, 23)

            try {
                $timestamp = [datetime]::ParseExact($timestampString, "yyyy-MM-dd HH:mm:ss,fff", $null)
            } catch {
                continue
            }

            # Check time window
            if ($timestamp -lt $StartTime -or $timestamp -gt $EndTime) {
                continue
            }

            foreach ($phrase in $SearchPhrases) {
                if ($line -match $phrase) {
                    $startIdx   = [Math]::Max(0, $i - $LinesBefore)
                    $endIdx     = [Math]::Min($lines.Count - 1, $i + $LinesAfter)
                    $matchBlock = $lines[$startIdx..$endIdx] -join "`r`n"

                    $results += [PSCustomObject]@{
                        Hostname  = $hostname
                        File      = $file
                        Timestamp = $timestamp
                        Phrase    = $phrase
                        Context   = $matchBlock
                    }

                    break  # avoid double-counting for multiple phrases on same line
                }
            }
        }
    }

    if ($results.Count -gt 0) {
        $results | Export-Csv -Path $outputPath -NoTypeInformation
        Write-Host "[$hostname] Wrote $($results.Count) hits to $outputPath"
    } else {
        Write-Host "[$hostname] No matches, not writing CSV."
    }
}

Write-Host "Starting log scan on $($servers.Count) servers..."

# --- Kick off the jobs in parallel ---
$job = Invoke-Command -ComputerName $servers `
    -ScriptBlock $remoteScript `
    -ArgumentList $startTime, $endTime, $LinesBefore, $LinesAfter, $searchPhrases, $LogInputRoot, $CentralOutputRoot `
    -AsJob `
    -ThrottleLimit $ThrottleLimit

# Wait and show output
Wait-Job $job | Out-Null
Receive-Job $job | Write-Host

Write-Host "All remote scans finished. Check CSVs in: $CentralOutputRoot"
