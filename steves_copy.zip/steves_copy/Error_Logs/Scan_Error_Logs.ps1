﻿# Define the path to the folder containing the log files on the server 
$logFolderPath = "C:\temp\QCAD\TP\Error_Logs"

# Define the base paths for the output CSV files
$localCsvBasePath = "C:\temp\QCAD\TP\Error_Logs\csv\Vision_Errors_outpu7.csv"
$remoteCsvBasePath = "\\PC556466-1\C$\temp\QCAD\TP\Error_Logs\output\TP_output7.csv"

# Get the hostname of the local server
$hostname = $env:COMPUTERNAME

# Function to scan a file for the word "ERROR"
function Scan-File {
    param (
        [string]$filePath,
        [string]$hostName
    )

    $results = @()
    try {
        # Open the file with shared read access
        $fileStream = [System.IO.File]::Open($filePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $streamReader = New-Object System.IO.StreamReader($fileStream)
        while ($line = $streamReader.ReadLine()) {
            if ($line -match "ERROR") {
                # Extract the date, time, and error message
                if ($line -match '^(?<DateTime>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) \[\d+\] ERROR - (?<Message>.*)$') {
                    $dateTime = $matches['DateTime']
                    $message = $matches['Message']
                    $results += [pscustomobject]@{
                        FileName = $filePath
                        DateTime = $dateTime
                        Message  = $message
                    }
                    Write-Host "Error found: $dateTime - $message"
                }
            }
        }
        $streamReader.Close()
        $fileStream.Close()
    } catch {
        $results += [pscustomobject]@{
            FileName = $filePath
            DateTime = ""
            Message  = "File Locked or Not Accessible"
        }
        Write-Host "Error accessing file: $filePath"
    }

    return $results
}

# Function to scan all log files in a folder
function Scan-Folder {
    param (
        [string]$folderPath,
        [string]$hostName
    )

    $logFiles = Get-ChildItem -Path $folderPath -Filter *.log

    foreach ($logFile in $logFiles) {
        Write-Host "Scanning file: $($logFile.FullName)"
        $fileResults = Scan-File -filePath $logFile.FullName -hostName $hostName
        
        if ($fileResults.Count -gt 0) {
            # Construct the CSV file names based on hostname and log file name
            $localCsvFilePath = "$localCsvBasePath${hostName}_${logFile.Name}.csv"
            $remoteCsvFilePath = "$remoteCsvBasePath${hostName}_${logFile.Name}.csv"
            
            # Read existing entries if the CSV file exists
            $existingEntries = @()
            if (Test-Path $localCsvFilePath) {
                $existingEntries = Import-Csv -Path $localCsvFilePath
            }
            
            # Filter out new results that already exist in the CSV file
            $newResults = $fileResults | Where-Object {
                $result = $_
                -not ($existingEntries | Where-Object { 
                    $_.DateTime -eq $result.DateTime -and 
                    $_.Message -eq $result.Message 
                })
            }

            if ($newResults.Count -gt 0) {
                # Update the local CSV file with the new results
                Write-Host "Saving results to $localCsvFilePath"
                $newResults | Export-Csv -Path $localCsvFilePath -NoTypeInformation -Append -Force

                # Attempt to update the remote CSV file with the new results
                try {
                    Write-Host "Saving results to $remoteCsvFilePath"
                    $newResults | Export-Csv -Path $remoteCsvFilePath -NoTypeInformation -Append -Force
                } catch {
                    Write-Host "Failed to update the remote CSV file: $_"
                }
            } else {
                Write-Host "No new errors to add for file: $($logFile.FullName)"
            }
        } else {
            Write-Host "No errors found in file: $($logFile.FullName)"
        }
    }
}

# Monitor the folder for changes
while ($true) {
    Write-Host "Starting folder scan..."
    Scan-Folder -folderPath $logFolderPath -hostName $hostname
    Write-Host "Folder scan complete. Sleeping for 5 seconds..."
    Start-Sleep -Seconds 5
}
