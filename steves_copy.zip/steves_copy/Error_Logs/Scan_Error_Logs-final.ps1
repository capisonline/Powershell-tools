﻿# Define the path to the folder containing the log files on the local machine 
$logFolderPath = "C:\temp\QCAD\VT\Error_Logs\Logs\full_copy"

# Define the base path for the output CSV files
$localCsvBasePath = "C:\temp\QCAD\VT\Error_Logs\Logs\full_copy\scom2\Vision_scom_output.csv"

# Get the hostname of the local server
$hostname = $env:COMPUTERNAME

# Define the search terms
$searchTerms = @(" ERROR "
)

# Function to scan a file for the specified terms
function Scan-File {
    param (
        [string]$filePath,
        [array]$terms
    )

    $results = @()

    try {
        # Open the file with shared read access
        $fileStream = [System.IO.File]::Open($filePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $streamReader = New-Object System.IO.StreamReader($fileStream)
        while ($line = $streamReader.ReadLine()) {
            foreach ($term in $terms) {
                if ($line -match "$term - ") {
                    # Extract the date, time, and message
                    if ($line -match '^(?<DateTime>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) \[\d+\] ' + $term + ' - (?<Message>.*)$') {
                        $dateTime = $matches['DateTime']
                        $message = $matches['Message']
                        $results += [pscustomobject]@{
                            FileName = $filePath
                            DateTime = $dateTime
                            Message  = $message
                        }
                    }
                }
            }
        }
        $streamReader.Close()
        $fileStream.Close()
    } catch {
        $results += [pscustomobject]@{
            FileName = $filePath
            DateTime = ""
            Message  = "File Locked or Not Accessible"
        }
    }

    return $results
}

# Function to scan all log files in a folder
function Scan-Folder {
    param (
        [string]$folderPath,
        [array]$terms
    )

    $logFiles = Get-ChildItem -Path $folderPath -Filter *.log

    foreach ($logFile in $logFiles) {
        $fileResults = Scan-File -filePath $logFile.FullName -terms $terms

        # Construct the CSV file name based on hostname and log file name
        $localCsvFilePath = "$($localCsvBasePath)_$($hostname)_$($logFile.Name).csv"

        # Update the local CSV file with the scan results
        $fileResults | Export-Csv -Path $localCsvFilePath -NoTypeInformation -Force
    }
}

# Call the function to scan the folder
Scan-Folder -folderPath $logFolderPath -terms $searchTerms
