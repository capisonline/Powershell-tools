﻿# Define applications and corresponding screenshot save locations
$Apps = @(
    @{ Path = "D:\vision\visVT\utilities\FortekCoreServiceMonitor\FortekServiceMonitor.exe"; Screenshot = "D:\Temp\FortekServiceMonitor.png"; ArchivePath = "D:\Temp\Archives\" },
    @{ Path = "D:\vision\visVT\utilities\PacketManagerViewer\PacketManagerViewer.exe"; Screenshot = "D:\Temp\PacketManagerViewer.png"; ArchivePath = "D:\Temp\Archives\" }
)

# Define remote copy destination
$RemotePath = "\\polvcadmgtdv01\D$\Failtesting\FCS_PKTMGR_Screenshots"

# Add WinAPI Type Only Once
if (-not ("WinAPI" -as [Type])) {
    Add-Type @"
    using System;
    using System.Runtime.InteropServices;
    public class WinAPI {
        [DllImport("user32.dll")]
        public static extern int ShowWindow(IntPtr hWnd, int nCmdShow);
    }
"@
}

function Process-App {
    param (
        [string]$AppPath,
        [string]$ScreenshotPath,
        [string]$ArchivePath
    )

    if (!(Test-Path $ArchivePath)) { New-Item -ItemType Directory -Path $ArchivePath | Out-Null }

    if (Test-Path $ScreenshotPath) {
        $Timestamp = (Get-Date -Format "yyyyMMdd_HHmmss")
        $ArchiveFileName = "$ArchivePath\$(Split-Path -Leaf $ScreenshotPath)_$Timestamp.png"
        Move-Item -Path $ScreenshotPath -Destination $ArchiveFileName -Force
    }

    $Process = Start-Process -FilePath $AppPath -PassThru
    Start-Sleep -Seconds 17

    $AppWindow = (Get-Process | Where-Object { $_.Id -eq $Process.Id }).MainWindowHandle
    [WinAPI]::ShowWindow($AppWindow, 3)

    Start-Sleep -Seconds 3

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $bitmap = New-Object System.Drawing.Bitmap([System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width, [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.CopyFromScreen([System.Drawing.Point]::Empty, [System.Drawing.Point]::Empty, $bitmap.Size)

    $font = New-Object System.Drawing.Font("Arial", 30, [System.Drawing.FontStyle]::Bold)
    $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Red)
    $point = New-Object System.Drawing.PointF(10, 10)
    $timestamp = "Captured: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    $graphics.DrawString($timestamp, $font, $brush, $point)

    $bitmap.Save($ScreenshotPath)
    Stop-Process -Id $Process.Id -Force

    Get-ChildItem -Path $ArchivePath -Filter "*.png" | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-7) } | Remove-Item -Force

    if (Test-Path $RemotePath) {
        try {
            Copy-Item -Path $ScreenshotPath -Destination "$RemotePath\" -Force
            Write-Host "Copied: $ScreenshotPath to $RemotePath"
        } catch {
            Write-Host "Copy failed: $_"
        }
    } else {
        Write-Host "Remote path not found: $RemotePath"
    }
}

# Main loop: repeats every 10 minutes
while ($true) {
    foreach ($App in $Apps) {
        try {
            Process-App -AppPath $App.Path -ScreenshotPath $App.Screenshot -ArchivePath $App.ArchivePath
        } catch {
            Write-Host "Error processing $($App.Path): $_"
        }
    }

    # Sleep for 10 minutes (600 seconds)
    Start-Sleep -Seconds 600
}
