﻿$ComputerName = "TWBPCADCCMPR04"

(Get-ADComputer $ComputerName -Properties IPv4Address).IPv4Address
