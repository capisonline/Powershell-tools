﻿# Define the path to the file with the server names 
$serverListPath = "C:\temp\QCAD\PA\Roles_Features\ServerNames.txt"

# Define the destination folder where the new files will be saved
$destinationFolder = "C:\temp\QCAD\PA\Roles_Features\"

# Read the server names from the file
$serverNames = Get-Content -Path $serverListPath

# Iterate over each server name
foreach ($serverName in $serverNames) {
    # Define the full path for the new file, using the server name for the file name
    $newFilePath = Join-Path -Path $destinationFolder -ChildPath ($serverName + ".txt")

    # Create a new file with the server name
    # You can add content inside the Set-Content cmdlet if needed, for example server specific configurations
    Set-Content -Path $newFilePath -Value "Configuration for $serverName"
}
