﻿<#
.SYNOPSIS
Shift every letter and digit in a CSV or YAML file by a fixed amount (default +2).
Symmetric — run with -Decode to reverse.

.DESCRIPTION
WHAT
    Reads <InputFile>, shifts every A-Z / a-z / 0-9 character by a fixed amount
    with wrap-around, writes the result to <OutputFile>. All other characters
    (commas, quotes, dots, dashes, spaces, colons, newlines, indentation, etc.)
    pass through unchanged — so file structure is perfectly preserved.

    Supports two modes based on file extension:
      CSV  (.csv)          — parsed via Import-Csv / Export-Csv
      YAML (.yml, .yaml)   — processed line-by-line, preserving indentation

    The shift is symmetric: encoding with shift +2 and decoding with the same
    script and -Decode returns the exact original bytes.


WHY
    Lets you share a file that looks like gibberish (e.g. a pipeline YAML with
    real prod hostnames/IPs, or a compiled netstat CSV) without giving away the
    values. The structure — indentation, YAML keys shape, column count, row count,
    punctuation — stays perfectly preserved, so someone on the other end can
    design a parser against it and you can decode the output locally.

    This is NOT encryption. It is a Caesar-style shift — trivial to break if
    someone knows the scheme. Use it for anonymising sharable data, not for
    protecting secrets.

HOW
    ShiftChar logic (wrap-safe, handles negative shifts correctly):
        letter c, shift n: c = ((pos + n) mod 26 + 26) mod 26
        digit  d, shift n: d = ((pos + n) mod 10 + 10) mod 10
        other:            unchanged

    CSV mode:  Import-Csv -> shift headers + values -> Export-Csv (BOM-free UTF-8)
    YAML mode: line-by-line shift of all alphanumeric chars, preserving whitespace
               and all YAML structural characters (: - # > | [ ] { } , etc.)

.PARAMETER InputFile
    Path to the file to shift. Accepts .csv, .yml, .yaml extensions.

.PARAMETER OutputFile
    Where to write the shifted result.

.PARAMETER Shift
    Amount to shift. Default 2. Use the same number for encode and decode.

.PARAMETER Decode
    Reverse the shift (i.e. apply -Shift). Use this to recover the original.

.EXAMPLE
    # Encode a CSV
    .\obsfucate.ps1 -InputFile .\netstat-merged.csv -OutputFile .\netstat-shifted.csv

.EXAMPLE
    # Decode a CSV
    .\obsfucate.ps1 -InputFile .\netstat-shifted.csv -OutputFile .\netstat-recovered.csv -Decode

.EXAMPLE
    # Encode a YAML pipeline
    .\obsfucate.ps1 -InputFile .\pipeline.yml -OutputFile .\pipeline-shifted.yml

.EXAMPLE
    # Decode a YAML pipeline
    .\obsfucate.ps1 -InputFile .\pipeline-shifted.yml -OutputFile .\pipeline-recovered.yml -Decode

.EXAMPLE
    # Custom shift
    .\obsfucate.ps1 -InputFile in.csv -OutputFile out.csv -Shift 7
    .\obsfucate.ps1 -InputFile out.csv -OutputFile recovered.csv -Shift 7 -Decode

.NOTES
    - Headers (CSV) are shifted along with data.
    - Non-ASCII letters (accents, CJK, etc.) pass through unchanged.
    - YAML indentation, colons, dashes, pipes, and all structural chars are preserved.
    - Round-trip test: encode then decode should produce a byte-identical file.
#>

param(
    [Parameter(Mandatory=$true)] [string]$InputFile,
    [Parameter(Mandatory=$true)] [string]$OutputFile,
    [int]$Shift = 2,
    [switch]$Decode
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $InputFile)) {
    Write-Error "Input file not found: $InputFile"
    return
}

$effective = if ($Decode) { -$Shift } else { $Shift }
$ext = [System.IO.Path]::GetExtension($InputFile).ToLower()

# ── Shared shift functions ──

function Shift-Char {
    param([char]$Ch, [int]$N)
    $code = [int]$Ch
    if ($Ch -ge [char]'a' -and $Ch -le [char]'z') {
        $pos = $code - 97
        $shifted = ((($pos + $N) % 26) + 26) % 26
        return [char]($shifted + 97)
    }
    if ($Ch -ge [char]'A' -and $Ch -le [char]'Z') {
        $pos = $code - 65
        $shifted = ((($pos + $N) % 26) + 26) % 26
        return [char]($shifted + 65)
    }
    if ($Ch -ge [char]'0' -and $Ch -le [char]'9') {
        $pos = $code - 48
        $shifted = ((($pos + $N) % 10) + 10) % 10
        return [char]($shifted + 48)
    }
    return $Ch
}

function Shift-String {
    param([string]$S, [int]$N)
    if ([string]::IsNullOrEmpty($S)) { return $S }
    $sb = New-Object System.Text.StringBuilder
    foreach ($ch in $S.ToCharArray()) {
        [void]$sb.Append((Shift-Char $ch $N))
    }
    return $sb.ToString()
}

# ── YAML mode ──

function Process-Yaml {
    param([string]$InPath, [string]$OutPath, [int]$N)

    $content = [System.IO.File]::ReadAllText($InPath)
    $sb = New-Object System.Text.StringBuilder($content.Length)

    foreach ($ch in $content.ToCharArray()) {
        [void]$sb.Append((Shift-Char $ch $N))
    }

    $absOut = [System.IO.Path]::GetFullPath($OutPath)
    [System.IO.File]::WriteAllText($absOut, $sb.ToString(), [System.Text.UTF8Encoding]::new($false))

    $lineCount = ($content -split "`n").Count
    return $lineCount
}

# ── CSV mode ──

function Process-Csv {
    param([string]$InPath, [string]$OutPath, [int]$N)

    $rows = Import-Csv -LiteralPath $InPath
    if (-not $rows -or $rows.Count -eq 0) {
        Write-Warning "Input CSV has no rows: $InPath"
        New-Item -ItemType File -Force -Path $OutPath | Out-Null
        return @{ Rows = 0; Cols = 0 }
    }

    $origHeaders = @($rows[0].PSObject.Properties.Name)
    $newHeaders = @($origHeaders | ForEach-Object { Shift-String $_ $N })

    if (($newHeaders | Select-Object -Unique).Count -ne $newHeaders.Count) {
        Write-Error "Shifted headers collide — original headers differ only in non-letter/digit chars. Aborting."
        return
    }

    $shifted = foreach ($row in $rows) {
        $h = [ordered]@{}
        for ($i = 0; $i -lt $origHeaders.Count; $i++) {
            $oh = $origHeaders[$i]
            $nh = $newHeaders[$i]
            $h[$nh] = Shift-String $row.$oh $N
        }
        [PSCustomObject]$h
    }

    $tmp = [System.IO.Path]::GetTempFileName()
    try {
        $shifted | Export-Csv -LiteralPath $tmp -NoTypeInformation -Encoding UTF8
        $csvContent = [System.IO.File]::ReadAllText($tmp)
        if ($csvContent.Length -gt 0 -and $csvContent[0] -eq [char]0xFEFF) { $csvContent = $csvContent.Substring(1) }
        [System.IO.File]::WriteAllText(
            [System.IO.Path]::GetFullPath($OutPath),
            $csvContent,
            [System.Text.UTF8Encoding]::new($false)
        )
    } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force }
    }

    return @{ Rows = $rows.Count; Cols = $origHeaders.Count }
}

# ── Route by file type ──

$action = if ($Decode) { 'Decoded' } else { 'Encoded' }

switch ($ext) {
    { $_ -in '.yml', '.yaml' } {
        $lineCount = Process-Yaml -InPath $InputFile -OutPath $OutputFile -N $effective
        Write-Host "$action $lineCount lines (shift=$effective) -> $OutputFile"
    }
    '.csv' {
        $result = Process-Csv -InPath $InputFile -OutPath $OutputFile -N $effective
        Write-Host "$action $($result.Rows) rows * $($result.Cols) columns (shift=$effective) -> $OutputFile"
    }
    default {
        Write-Error "Unsupported file type: $ext (supported: .csv, .yml, .yaml)"
    }
}
