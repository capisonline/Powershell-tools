﻿<#
.SYNOPSIS
    Compares XML APP.config files located in folders named $hostname to verify consistency of application settings.
    Used during tech refresh cycles to validate configs are being updated / merged correctly
    First copy these files locally for quick processing

.DESCRIPTION
    This script reads a mapping CSV of OldServer/NewServer pairs, then recursively searches for all *.config files
    under each NewServer directory. It looks for matching files in the OldServer directory based on relative path.
    XML settings from <appSettings>, <applicationSettings>, and <connectionStrings> are extracted and compared between files.

.OUTPUTS
    - VT_QCAD_Config_Differences2.csv: comparison results of config settings.
    - Missing_Files.csv: list of files missing from the old environment.


#>

# --- CONFIGURATION (edit these paths for your environment) ---
$OldRoot     = "C:\temp\QCAD\VT\Merge\Merge_Discovery\old_servers"
$NewRoot     = "C:\temp\QCAD\VT\Merge\Merge_Discovery\New_Servers"
$MappingCsv  = "C:\temp\QCAD\VT\Merge\Merge_Discovery\Merge_Match_input.csv"
$OutputCsv   = "C:\temp\QCAD\VT\Merge\Merge_Discovery\VT_QCAD_Config_Differences29.csv"
$MissingLog  = "C:\temp\QCAD\VT\Merge\Merge_Discovery\Missing_Files117.csv"

# --- FUNCTION: Extracts settings from XML-based config files ---
function Get-ConfigSettings {
    param ($FilePath)
    $results = @{}

    try {
        [xml]$xml = Get-Content -LiteralPath $FilePath -Raw

        # From: *.config, web.config
        if ($xml.configuration.appSettings) {
            foreach ($add in $xml.configuration.appSettings.add) {
                $results["appSettings::$($add.key)"] = $add.value
            }
        }

        # From: *.config, *.settings
        if ($xml.configuration.applicationSettings) {
            foreach ($section in $xml.configuration.applicationSettings.ChildNodes) {
                foreach ($setting in $section.ChildNodes) {
                    $name = $setting.name
                    $valueNode = $setting.SelectSingleNode("value")
                    if ($name -and $valueNode) {
                        $results["applicationSettings::$name"] = $valueNode.InnerText.Trim()
                    }
                }
            }
        }

        # From: *.config, web.config
        if ($xml.configuration.connectionStrings) {
            foreach ($conn in $xml.configuration.connectionStrings.add) {
                $results["connectionStrings::$($conn.name)"] = $conn.connectionString
            }
        }

        # From: web.config
        $compilation = $xml.configuration.'system.web'.compilation
        if ($compilation) {
            if ($compilation.debug) {
                $results["system.web::compilation.debug"] = $compilation.debug
            }
            if ($compilation.targetFramework) {
                $results["system.web::compilation.targetFramework"] = $compilation.targetFramework
            }
        }

        # From: web.config
        $authentication = $xml.configuration.'system.web'.authentication
        if ($authentication -and $authentication.mode) {
            $results["system.web::authentication.mode"] = $authentication.mode
        }

        # From: web.config
        $bindings = $xml.configuration.runtime.assemblyBinding.dependentAssembly
        foreach ($dep in $bindings) {
            $name = $dep.assemblyIdentity.name
            $oldVersion = $dep.bindingRedirect.oldVersion
            $newVersion = $dep.bindingRedirect.newVersion
            if ($name -and $oldVersion -and $newVersion) {
                $results["bindingRedirect::$name"] = "$oldVersion => $newVersion"
            }
        }

        # From: *.ini, *.settings
        if ($xml.VISION.Application) {
            foreach ($app in $xml.VISION.Application) {
                $appName = $app.Name
                foreach ($add in $app.add) {
                    $key = "$($appName)::" + $add.key
                    $results["iniSettings::$key"] = $add.value
                }
            }
        }

    } catch {
        $results["__error__"] = $_.Exception.Message
    }

    return $results
}

# --- MAIN LOGIC ---
$rows = @()
$missing = @()
$log = Import-Csv $MappingCsv

foreach ($entry in $log) {
    $oldServer = $entry.OldServer
    $newServer = $entry.NewServer

    $oldServerRoot = Join-Path $OldRoot $oldServer
    $newServerRoot = Join-Path $NewRoot $newServer

    # Get all config-like files to compare
    $newFiles = Get-ChildItem -Path $newServerRoot -Recurse -File | Where-Object {
        $_.Extension -in ".config", ".ini", ".settings"
    }

    foreach ($newFile in $newFiles) {
        $relativePath = $newFile.FullName.Substring($newServerRoot.Length).TrimStart("\\")
        $oldFile = Join-Path $oldServerRoot $relativePath

        Write-Host "Comparing: $relativePath"

        if (-not (Test-Path $oldFile)) {
            Write-Warning "Missing old file: $relativePath"
            $missing += [PSCustomObject]@{
                OldServer     = $oldServer
                NewServer     = $newServer
                MissingPath   = $oldFile
                RelativePath  = $relativePath
            }
            continue
        }

        $oldSettings = Get-ConfigSettings -FilePath $oldFile
        $newSettings = Get-ConfigSettings -FilePath $newFile

        $allKeys = ($oldSettings.Keys + $newSettings.Keys) | Sort-Object -Unique

        foreach ($key in $allKeys) {
            $oldVal = $oldSettings[$key]
            $newVal = $newSettings[$key]

            $status = if ($oldVal -eq $newVal) {
                "Same"
            } elseif ($oldVal -and $newVal) {
                "Changed"
            } elseif ($oldVal -and -not $newVal) {
                "Missing in New"
            } elseif ($newVal -and -not $oldVal) {
                "Missing in Old"
            } else {
                "Unknown"
            }

            $settingType, $settingKey = $key -split '::', 2

            $rows += [PSCustomObject]@{
                SettingType   = $settingType
                SettingKey    = $settingKey
                RelativePath  = $relativePath
                OldServer     = $oldServer
                NewServer     = $newServer
                OldFullPath   = $oldFile
                NewFullPath   = $newFile.FullName
                OldValue      = $oldVal
                NewValue      = $newVal
                Status        = $status
            }
        }
    }
}

# Export Results
$rows | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding Default
$missing | Export-Csv -Path $MissingLog -NoTypeInformation -Encoding Default
Write-Host "Comparison complete. Results saved to:`n $OutputCsv`n $MissingLog"