﻿<#
.SYNOPSIS
    Compares QCAD APP.config files between old and new server folders to verify consistency of application settings.
    First copy these files locally for quick processing

.DESCRIPTION
    This script reads a mapping CSV of OldServer/NewServer pairs, then recursively searches for all *.config files
    under each NewServer directory. It looks for matching files in the OldServer directory based on relative path.
    Settings from <appSettings>, <applicationSettings>, and <connectionStrings> are extracted and compared.

.OUTPUTS
    - VT_QCAD_Config_Differences2.csv: comparison results of config settings.
    - Missing_Files.csv: list of files missing from the old environment.


#>

# run locally - won't work remotely and too slow anyway
$OldRoot     = "C:\temp\QCAD\VT\Merge\Merge_Discovery\old_servers"
$NewRoot     = "C:\temp\QCAD\VT\Merge\Merge_Discovery\New_Servers"
$MappingCsv  = "C:\temp\QCAD\VT\Merge\Merge_Discovery\Merge_Match_input.csv"
$OutputCsv   = "C:\temp\QCAD\VT\Merge\Merge_Discovery\VT_QCAD_Config_Differences27.csv"
$MissingLog  = "C:\temp\QCAD\VT\Merge\Merge_Discovery\Missing_Files15.csv"

# Extracts key-value settings from a config file
function Get-ConfigSettings {
    param ($FilePath)
    $results = @{}
    try {
        [xml]$xml = Get-Content -LiteralPath $FilePath -Raw

        # Extract <appSettings>
        if ($xml.configuration.appSettings) {
            foreach ($add in $xml.configuration.appSettings.add) {
                $results["appSettings::$($add.key)"] = $add.value
            }
        }

        # Extract <applicationSettings>
        if ($xml.configuration.applicationSettings) {
            foreach ($section in $xml.configuration.applicationSettings.ChildNodes) {
                foreach ($setting in $section.ChildNodes) {
                    $name = $setting.name
                    $valueNode = $setting.SelectSingleNode("value")
                    if ($name -and $valueNode) {
                        $results["applicationSettings::$name"] = $valueNode.InnerText.Trim()
                    }
                }
            }
        }

        # Extract <connectionStrings>
        if ($xml.configuration.connectionStrings) {
            foreach ($conn in $xml.configuration.connectionStrings.add) {
                $results["connectionStrings::$($conn.name)"] = $conn.connectionString
            }
        }
    } catch {
        # On error, capture message for inspection
        $results["__error__"] = $_.Exception.Message
    }
    return $results
}

$rows = @()
$missingFiles = @()
$mapping = Import-Csv $MappingCsv
Write-Host "Processing $($mapping.Count) server mappings from CSV..."

# Loop through each server mapping
foreach ($entry in $mapping) {
    $oldServer = $entry.OldServer
    $newServer = $entry.NewServer

    $oldServerRoot = Join-Path $OldRoot $oldServer
    $newServerRoot = Join-Path $NewRoot $newServer

    if (-not (Test-Path $oldServerRoot)) {
        Write-Warning "Old server folder not found: $oldServerRoot"
        continue
    }
    if (-not (Test-Path $newServerRoot)) {
        Write-Warning "New server folder not found: $newServerRoot"
        continue
    }

    # Recursively get all *.config files under the new server directory
    $newFiles = Get-ChildItem -Path $newServerRoot -Recurse -Filter *.config -File

    foreach ($newFile in $newFiles) {
        $relativePath = $newFile.FullName.Substring($newServerRoot.Length).TrimStart('\')
        $oldFile = Join-Path $oldServerRoot $relativePath

        # If the old file doesn't exist, log it for review
        if (-not (Test-Path $oldFile)) {
            Write-Warning "Missing old file:
    Server: $oldServer
    Path:   $oldFile"

            $missingFiles += [PSCustomObject]@{
                OldServer     = $oldServer
                NewServer     = $newServer
                MissingPath   = $oldFile
                RelativePath  = $relativePath
            }
            continue
        }

        Write-Host "Comparing: $relativePath"

        try {
            # Extract key-value settings from each file
            $oldSettings = Get-ConfigSettings -FilePath $oldFile
            $newSettings = Get-ConfigSettings -FilePath $newFile.FullName

            # Compare all keys found in either file
            $allKeys = ($oldSettings.Keys + $newSettings.Keys) | Sort-Object -Unique

            foreach ($key in $allKeys) {
                $oldVal = $oldSettings[$key]
                $newVal = $newSettings[$key]

                # Determine comparison result
                $status = if ($oldVal -eq $newVal) {
                    "Same"
                } elseif ($oldVal -and $newVal) {
                    "Changed"
                } elseif ($oldVal -and -not $newVal) {
                    "Missing in New"
                } elseif ($newVal -and -not $oldVal) {
                    "Missing in Old"
                } else {
                    "Unknown"
                }

                # Split setting name into type and key
                if ($key -match '^([^:]+)::(.+)$') {
                    $settingType = $matches[1]
                    $settingKey  = $matches[2]
                } else {
                    $settingType = "Unknown"
                    $settingKey  = $key
                }

                # Add result to output list
                $rows += [PSCustomObject]@{
                    OldServer     = $oldServer
                    NewServer     = $newServer
                    OldFullPath   = $oldFile
                    NewFullPath   = $newFile.FullName
                    SettingType   = $settingType
                    SettingKey    = $settingKey
                    OldValue      = $oldVal
                    NewValue      = $newVal
                    Status        = $status
                    RelativePath  = $relativePath
                }
            }
        } catch {
            Write-Warning "Error comparing $relativePath — $_"
        }
    }
}

# Write comparison results to file
if ($rows.Count -gt 0) {
    $rows | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding Default
    Write-Host "Config comparison complete. Output saved to: $OutputCsv"
} else {
    Write-Host "No differences or valid .config settings found."
}

# Write missing file list to file
if ($missingFiles.Count -gt 0) {
    $missingFiles | Export-Csv -Path $MissingLog -NoTypeInformation -Encoding Default
    Write-Host "Missing file list saved to: $MissingLog"
}
