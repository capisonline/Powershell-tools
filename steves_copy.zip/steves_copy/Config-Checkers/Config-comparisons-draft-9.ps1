﻿param (
    [string]$OldRoot = "C:\temp\QCAD\VT\Merge\Merge_Discovery\old_servers",
    [string]$NewRoot = "C:\temp\QCAD\VT\Merge\Merge_Discovery\New_Servers",
    [string]$MappingCsv = "C:\temp\QCAD\VT\Merge\Merge_Discovery\Merge_Match_input.csv",  # CSV with OldServer,NewServer
    [string]$OutputCsv = "C:\temp\QCAD\VT\Merge\Merge_Discovery\VT_QCAD_Config_Differences26.csv",
    [string]$MissingLog = "C:\temp\QCAD\VT\Merge\Merge_Discovery\Missing_Files17.csv"
)

function Get-ConfigSettings {
    param ($FilePath)
    $results = @{}
    try {
        [xml]$xml = Get-Content -LiteralPath $FilePath -Raw

        if ($xml.configuration.appSettings) {
            foreach ($add in $xml.configuration.appSettings.add) {
                $results["appSettings::$($add.key)"] = $add.value
            }
        }

        if ($xml.configuration.applicationSettings) {
            foreach ($section in $xml.configuration.applicationSettings.ChildNodes) {
                foreach ($setting in $section.ChildNodes) {
                    $name = $setting.name
                    $valueNode = $setting.SelectSingleNode("value")
                    if ($name -and $valueNode) {
                        $results["applicationSettings::$name"] = $valueNode.InnerText.Trim()
                    }
                }
            }
        }

        if ($xml.configuration.connectionStrings) {
            foreach ($conn in $xml.configuration.connectionStrings.add) {
                $results["connectionStrings::$($conn.name)"] = $conn.connectionString
            }
        }
    } catch {
        $results["__error__"] = $_.Exception.Message
    }
    return $results
}

$rows = @()
$missingFiles = @()
$mapping = Import-Csv $MappingCsv
Write-Host "Processing $($mapping.Count) server mappings from CSV..."

foreach ($entry in $mapping) {
    $oldServer = $entry.OldServer
    $newServer = $entry.NewServer

    $oldServerRoot = Join-Path $OldRoot $oldServer
    $newServerRoot = Join-Path $NewRoot $newServer

    if (-not (Test-Path $oldServerRoot)) {
        Write-Warning "Old server folder not found: $oldServerRoot"
        continue
    }
    if (-not (Test-Path $newServerRoot)) {
        Write-Warning "New server folder not found: $newServerRoot"
        continue
    }

    $newFiles = Get-ChildItem -Path $newServerRoot -Recurse -Filter *.config -File

    foreach ($newFile in $newFiles) {
        $relativePath = $newFile.FullName.Substring($newServerRoot.Length).TrimStart('\')
        $oldFile = Join-Path $oldServerRoot $relativePath

        if (-not (Test-Path $oldFile)) {
            Write-Warning "Missing old file:
    Server: $oldServer
    Path:   $oldFile"

            $missingFiles += [PSCustomObject]@{
                OldServer     = $oldServer
                NewServer     = $newServer
                MissingPath   = $oldFile
                RelativePath  = $relativePath
            }
            continue
        }

        Write-Host "Comparing: $relativePath"

        try {
            $oldSettings = Get-ConfigSettings -FilePath $oldFile
            $newSettings = Get-ConfigSettings -FilePath $newFile.FullName

            $allKeys = ($oldSettings.Keys + $newSettings.Keys) | Sort-Object -Unique

            foreach ($key in $allKeys) {
                $oldVal = $oldSettings[$key]
                $newVal = $newSettings[$key]

                $status = if ($oldVal -eq $newVal) {
                    "Same"
                } elseif ($oldVal -and $newVal) {
                    "Changed"
                } elseif ($oldVal -and -not $newVal) {
                    "Missing in New"
                } elseif ($newVal -and -not $oldVal) {
                    "Missing in Old"
                } else {
                    "Unknown"
                }

                if ($key -match '^([^:]+)::(.+)$') {
                    $settingType = $matches[1]
                    $settingKey  = $matches[2]
                } else {
                    $settingType = "Unknown"
                    $settingKey  = $key
                }

                $rows += [PSCustomObject]@{
                    OldServer     = $oldServer
                    NewServer     = $newServer
                    OldFullPath   = $oldFile
                    NewFullPath   = $newFile.FullName
                    SettingType   = $settingType
                    SettingKey    = $settingKey
                    OldValue      = $oldVal
                    NewValue      = $newVal
                    Status        = $status
                    RelativePath  = $relativePath
                }
            }
        } catch {
            Write-Warning "Error comparing $relativePath — $_"
        }
    }
}

if ($rows.Count -gt 0) {
    $rows | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding Default
    Write-Host "Config comparison complete. Output saved to: $OutputCsv"
} else {
    Write-Host "No differences or valid .config settings found."
}

if ($missingFiles.Count -gt 0) {
    $missingFiles | Export-Csv -Path $MissingLog -NoTypeInformation -Encoding Default
    Write-Host "Missing file list saved to: $MissingLog"
}
