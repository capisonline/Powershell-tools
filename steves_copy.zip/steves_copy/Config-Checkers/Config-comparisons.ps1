﻿# Define paths 
$serverList = "C:\temp\QCAD\tp\TP_NEW_Server_list.txt"  # Update with your server list file
$remoteFolder = "D$\inetpub"  # Folder where new .config files exist
$backupFolder = "E:\backup\2024-12A_1\inetpub"  # Folder where old .config files are stored
$csvOutput = "C:\temp\QCAD\TP\reto-fix\configs\retro-ConfigDifferences-inetpub.csv"  # CSV file to store differences


# Initialize results array
$results = @()

# Read the list of servers
$servers = Get-Content -Path $serverList

foreach ($server in $servers) {
    $remotePath = "\\$server\$remoteFolder"
    $backupPath = "\\$server\$backupFolder"

    # Ensure both paths exist
    if ((Test-Path $remotePath) -and (Test-Path $backupPath)) {
        Write-Host "Comparing .config files on $server..."

        # Recursively get all .config files from the remote folder
        $newConfigFiles = Get-ChildItem -Path $remotePath -Filter "*.config" -File -Recurse

        foreach ($newConfigFile in $newConfigFiles) {
            # Get the relative path of the file within the remote folder
            # Example: if $newConfigFile is \\server\share\Remote\Configs\sub\file.config
            # and $remotePath is \\server\share\Remote\Configs,
            # the relative path is sub\file.config
            $relativePath = $newConfigFile.FullName.Substring($remotePath.Length).TrimStart('\')

            # Build the path to the corresponding old config file using the relative path
            $oldConfigPath = Join-Path -Path $backupPath -ChildPath $relativePath

            if (Test-Path $oldConfigPath) {
                # Read file contents (line by line)
                $oldContent = Get-Content -Path $oldConfigPath -ErrorAction SilentlyContinue
                $newContent = Get-Content -Path $newConfigFile.FullName -ErrorAction SilentlyContinue

                # Compare line by line (removing -PassThru so we can use SideIndicator).
                $differences = Compare-Object -ReferenceObject $oldContent -DifferenceObject $newContent

                foreach ($diff in $differences) {
                    # Only care about lines that differ
                    switch ($diff.SideIndicator) {
                        '<=' {
                            $oldValue = $diff.InputObject
                            $newValue = ""
                        }
                        '=>' {
                            $oldValue = ""
                            $newValue = $diff.InputObject
                        }
                        default {
                            # '==' or anything else means no difference
                            continue
                        }
                    }

                    # Add to results array
                    $results += [PSCustomObject]@{
                        ServerName = $server
                        FileName   = $relativePath
                        OldValue   = $oldValue
                        NewValue   = $newValue
                    }
                }
            }
            else {
                Write-Host "No matching old config file for $($newConfigFile.Name) under path '$relativePath' on $server."
            }
        }
    }
    else {
        Write-Host "Either current or backup folder not found on $server."
    }
}

# Export results to CSV if there are any
if ($results) {
    $results | Export-Csv -Path $csvOutput -NoTypeInformation
    Write-Host "Comparison completed! Differences saved to $csvOutput"
}
else {
    Write-Host "No differences found or no valid config files. CSV not created."
}

