﻿# === CONFIGURATION SECTION ===
$folder       = "D:\"  # Root folder to search
$patterns     = @("*.ini", "*.settings", "*.config")  # File extensions to include
$searchTerms  = @("10.46.205.69", "QPS-VAS-VT-05")     # IPs or hostnames to find
$outputCsv    = "E:\logs\scripts\firewall\firewall_config_matches22.csv" # outfile
# =============================

# Ensure output folder exists
$parentFolder = Split-Path $outputCsv
if (-not (Test-Path $parentFolder)) {
    New-Item -Path $parentFolder -ItemType Directory | Out-Null
}

Write-Host "Scanning folder: $folder"
Write-Host "Looking for extensions: $($patterns -join ', ')"
Write-Host "Searching for terms: $($searchTerms -join ', ')"

# Get all matching files
$files = Get-ChildItem -Path $folder -Recurse -Include $patterns -File -ErrorAction SilentlyContinue
Write-Host "Found $($files.Count) files matching pattern(s)."

# Initialize results
$results = @()
$scanned = 0
$matched = 0

foreach ($file in $files) {
    try {
        $scanned++
        $lines = Get-Content -Path $file.FullName -ErrorAction Stop

        foreach ($term in $searchTerms) {
            # Loose string match instead of regex (safer for IPs and hostnames)
            $matches = $lines | Where-Object { $_ -like "*$term*" }

            foreach ($match in $matches) {
                $results += [pscustomobject]@{
                    FilePath = $file.FullName
                    Match    = $term
                    Line     = $match
                }
                $matched++
                Write-Host "Matched [$term] in: $($file.Name)"
            }
        }
    } catch {
        Write-Warning "Could not read: $($file.FullName)"
    }
}

# Export if there were matches
if ($results.Count -gt 0) {
    $results | Export-Csv -Path $outputCsv -NoTypeInformation -Encoding UTF8
    Write-Host "`n $matched matches found across $scanned files."
    Write-Host " Results saved to: $outputCsv"
} else {
    Write-Host "`n No matches found in $scanned files."
}
