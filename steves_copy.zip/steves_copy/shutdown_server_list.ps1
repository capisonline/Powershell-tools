﻿# Simple remote shutdown for a list of servers (one name per line)
# WARNING: This will SHUT DOWN the target servers.

$filePath = "C:\temp\QCAD\VT\Fail_Testing\25-02-2026\EGL_Server_Shutdownlist.txt"

if (Test-Path $filePath) {
    $computerNames = Get-Content $filePath | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith("#") }

    foreach ($computer in $computerNames) {
        Write-Host "Attempting to shut down $computer..."
        # /s = shutdown, /m = remote machine, /t = timeout seconds, /f = force close apps
        shutdown.exe /s /m "\\$computer" /t 60 /f /c "Planned VT shutdown" 2>$null
        Write-Host "$computer shutdown command sent."
    }
} else {
    Write-Host "File not found: $filePath"
}
