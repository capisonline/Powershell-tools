﻿# Ensure the SqlServer module is loaded 
Import-Module SqlServer -DisableNameChecking -ErrorAction SilentlyContinue

# Define the path to the CSV file
$csvPath = "C:\path\to\yourfile.csv"

# Import the CSV file
$servers = Import-Csv -Path $csvPath

foreach ($server in $servers) {
    $oldServerName = $server.Old_Server
    $newServerName = $server.New_Server

    # Create server connection objects
    $oldServer = New-Object Microsoft.SqlServer.Management.Smo.Server($oldServerName)
    $newServer = New-Object Microsoft.SqlServer.Management.Smo.Server($newServerName)

    # Transfer logins (except system logins)
    foreach ($login in $oldServer.Logins) {
        if (!$login.IsSystemObject) {
            $scriptOptions = New-Object Microsoft.SqlServer.Management.Smo.ScriptingOptions
            $scriptOptions.IncludeIfNotExists = $true
            $loginScript = $login.Script($scriptOptions)
            Invoke-Sqlcmd -ServerInstance $newServerName -Query $loginScript -ErrorAction SilentlyContinue
            Write-Output "Transferred login: $($login.Name)"
        }
    }

    # Loop through each database in the old server
    foreach ($db in $oldServer.Databases) {
        if (!$db.IsSystemObject) { # Avoid system databases
            $dbName = $db.Name
            $timestamp = Get-Date -Format "yyyyMMddHHmmss"
            $backupFile = "C:\Backup\$dbName-$timestamp.bak"

            # Perform backup
            $backup = New-Object Microsoft.SqlServer.Management.Smo.Backup
            $backup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
            $backup.Database = $dbName
            $backup.Devices.AddDevice($backupFile, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
            $backup.SqlBackup($oldServer)
            Write-Output "Backup completed for $dbName on $oldServerName"

            # Ensure the new server does not already have the database
            if ($null -eq $newServer.Databases[$dbName]) {
                # Restore to new server
                $restore = New-Object Microsoft.SqlServer.Management.Smo.Restore
                $restore.Action = [Microsoft.SqlServer.Management.Smo.RestoreActionType]::Database
                $restore.Database = $dbName
                $restore.Devices.AddDevice($backupFile, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
                $restore.ReplaceDatabase = $true
                $restore.SqlRestore($newServer)
                Write-Output "Restore completed for $dbName on $newServerName"
                
                # Fix user mappings and check for orphaned users
                $restoredDb = $newServer.Databases[$dbName]
                foreach ($user in $restoredDb.Users) {
                    if (!$user.IsSystemObject -and $null -eq $newServer.Logins[$user.Name]) {
                        $user.Alter($newServer.Logins[$user.Name])
                        Write-Output "Fixed user mapping for user: $($user.Name)"
                    }
                }
            } else {
                Write-Output "Database $dbName already exists on $newServerName"
            }
        }
    }
}
