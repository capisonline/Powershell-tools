﻿# Define SQL Server and database details 
$sqlInstanceName = "SQLEXPRESS" # Update this with your SQL Server instance name
$databaseName = "master" # Update this with the database name you're targeting

# Path to the text file containing the list of servers
$serversFilePath = "C:\temp\QCAD\PR\SQL\SQL_Input_File.txt" # Update this with the path to your servers list

# CSV file path to save the results
$resultsCsvPath = "C:\temp\QCAD\PR\SQL\PR_SQL_QA_results-PR-folder-final79999.csv" # Update this with your desired output file path

# Define the names of the stored procedures, security entities, and scheduled tasks to check for
$storedProcedures = @("sproc_BackupSysDB", "sproc_BackupUserDB", "sproc_BackupUserDBTrans") # Update with actual Stored Procedure names
$securityEntities = @("PRDS\QPS-A-QCAD Vision Vendor-PR", "PRDS\ISS-Role-ISB PDD Deployment Team Group 5") # Update with actual role/user names
$SQLsecurityEntities = @("PRDS\QPS-A-QCAD Vision Vendor-PR", "PRDS\ISS-Role-ISB PDD Deployment Team Group 5") # Update with actual role/user names
$scheduledTasks = @("SQLEXP_Backup_UserDB", "SQLEXP_Backup_sysDB", "SQLEXP_Backup_DBTrans") # Update with actual task names

# Initialize an array to hold the results
$results = @()

# Read the list of servers from the file
$servers = Get-Content $serversFilePath

foreach ($server in $servers) {
    try {
        # Create SQL connection
        $connectionString = "Server=$server\$sqlInstanceName;Database=$databaseName;Integrated Security=True;"
        $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
        $connection.Open()

        # Check for stored procedures
        foreach ($sp in $storedProcedures) {
            $cmd = $connection.CreateCommand()
            $cmd.CommandText = "SELECT * FROM sys.procedures WHERE name = '$sp'"
            $result = $cmd.ExecuteScalar()
            $status = if ($result -ne $null) { "Found" } else { "Not Found" }
            $results += New-Object PSObject -Property @{
                Server = $server
                Type = "Stored Procedure"
                Name = $sp
                Status = $status
            }
        }
        <## This is for security entities (database roles or users) & can be uncommented / modified 
        foreach ($entity in $SQLsecurityEntities) {
            $cmd = $connection.CreateCommand()
            $cmd.CommandText = "SELECT * FROM sys.database_principals WHERE name = '$entity'"
            $result = $cmd.ExecuteScalar()
            $status = if ($result -ne $null) { "Found" } else { "Not Found" }
            $results += New-Object PSObject -Property @{
                Server = $server
                Type = "SQL Security Entity"
                Name = $entity
                Status = $status
            }
        }#>
        
        # Check for server-level security entities (Windows/SQL logins)
        foreach ($entity in $securityEntities) {
            $cmd = $connection.CreateCommand()
            $cmd.CommandText = "SELECT * FROM sys.server_principals WHERE name = '$entity'"
            $result = $cmd.ExecuteScalar()
            $status = if ($result -ne $null) { "Found" } else { "Not Found" }
            $results += New-Object PSObject -Property @{
                Server = $server
                Type = "Server Security Entity"
                Name = $entity
                Status = $status
            }
        }
    } catch {
        $results += New-Object PSObject -Property @{
            Server = $server
            Type = "SQL or Security Check Error"
            Name = "N/A"
            Status = "Error: $($_.Exception.Message)"
        }
    } finally {
        $connection.Close()
    }

    # Check for scheduled tasks
    try {
        foreach ($taskName in $scheduledTasks) {
            $taskExists = Invoke-Command -ComputerName $server -ScriptBlock {
                param($taskName)
                Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
            } -ArgumentList $taskName

            $status = if ($taskExists) { "Found" } else { "Not Found" }
            $results += New-Object PSObject -Property @{
                Server = $server
                Type = "Scheduled Task"
                Name = $taskName
                Status = $status
            }
        }
    } catch {
        $results += New-Object PSObject -Property @{
            Server = $server
            Type = "Scheduled Task Error"
            Name = "N/A"
            Status = "Error querying task: $($_.Exception.Message)"
        }
    }
}

# Export the results to a CSV file, ensuring column order
$results | Select-Object Server, Type, Name, Status | Export-Csv -Path $resultsCsvPath -NoTypeInformation -Encoding UTF8

Write-Host "Check completed. Results saved to $resultsCsvPath."
