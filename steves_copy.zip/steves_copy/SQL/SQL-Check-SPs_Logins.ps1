﻿
# Define SQL Server and database details 
$sqlInstanceName = "SQLEXPRESS" # Update this with your SQL Server instance name
$databaseName = "master" # Update this with the database name you're targeting

# Path to the text file containing the list of servers
$serversFilePath = "C:\temp\QCAD\TP\SQL\TP_servers.txt" # Update this with the path to your servers list

# CSV file path to save the results
$resultsCsvPath = "C:\temp\QCAD\TP\SQL\TP_SQL_QA_results_Post-Rebuild.csv" # Update this with your desired output file path


# Define the names of the stored procedures and security entities to check for
$storedProcedures = @("sproc_BackupSysDB", "sproc_BackupUserDB", "sproc_BackupUserDBTrans")
$securityEntities = @("PRDS\QPS-A-QCAD Vision Vendor-TP", "PRDS\ISS-Role-ISB PDD Deployment Team Group 5") # Update with actual role/user names

# Initialize an array to hold the results
$results = @()

# Read the list of servers from the file
$servers = Get-Content $serversFilePath

foreach ($server in $servers) {
    # Construct SQL Server connection string for integrated security
    $connectionString = "Server=$server\$sqlInstanceName;Database=$databaseName;Integrated Security=True;"

    $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
    try {
        $connection.Open()

        # Check for stored procedures
        foreach ($sp in $storedProcedures) {
            $cmd = $connection.CreateCommand()
            $cmd.CommandText = "SELECT * FROM sys.procedures WHERE name = '$sp'"
            $result = $cmd.ExecuteScalar()
            $status = if ($result -ne $null) { "Found" } else { "Not Found" }
            $results += New-Object PSObject -Property @{
                Server = $server
                Type = "Stored Procedure"
                Name = $sp
                Status = $status
            }
        }

        <## This is for security entities (database roles or users) & can be uncommented / modified 
        foreach ($entity in $securityEntities) {
            $cmd = $connection.CreateCommand()
            $cmd.CommandText = "SELECT * FROM sys.database_principals WHERE name = '$entity'"
            $result = $cmd.ExecuteScalar()
            $status = if ($result -ne $null) { "Found" } else { "Not Found" }
            $results += New-Object PSObject -Property @{
                Server = $server
                Type = "Security Entity"
                Name = $entity
                Status = $status
            }
        }
        #>
        # This is for server-level security entities (like logins) & can be uncommented / modified
         foreach ($entity in $securityEntities) {
             $cmd = $connection.CreateCommand()
             $cmd.CommandText = "SELECT * FROM sys.server_principals WHERE name = '$entity'"
             $result = $cmd.ExecuteScalar()
             $status = if ($result -ne $null) { "Found" } else { "Not Found" }
             $results += New-Object PSObject -Property @{
                 Server = $server
                 Type = "Server Security Entity"
                 Name = $entity
                 Status = $status
             }
         }

    } catch {
        $results += New-Object PSObject -Property @{
            Server = $server
            Type = "Error"
            Name = "N/A"
            Status = "Error connecting to server: $($_.Exception.Message)"
        }
    } finally {
        $connection.Close()
    }
}

# Export the results to a CSV file, ensuring column order
$results | Select-Object Server, Type, Name, Status | Export-Csv -Path $resultsCsvPath -NoTypeInformation -Encoding UTF8

Write-Host "Check completed. Results saved to $resultsCsvPath."
