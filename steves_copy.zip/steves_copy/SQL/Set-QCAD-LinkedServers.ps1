﻿<#
.SYNOPSIS
Add or remove SQL linked servers with logging.

.DESCRIPTION
Adds missing linked servers or removes existing linked servers based on an input CSV.

For ADD:
- Creates the linked server only if it does not already exist
- Uses current security context
- Sets data access, rpc, rpc out, and use remote collation to true

For REMOVE:
- Removes the linked server only if it exists
- Drops linked logins with it

.INPUT CSV
SourceInstance,LinkedServer

.EXAMPLE
.\Set-QCAD-LinkedServers.ps1 `
  -InputCsv C:\Temp\links.csv `
  -Action Add `
  -LogPath C:\Temp\LinkedServers_Add.log

.EXAMPLE
.\Set-QCAD-LinkedServers.ps1 `
  -InputCsv C:\Temp\links.csv `
  -Action Remove `
  -LogPath C:\Temp\LinkedServers_Remove.log
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$InputCsv,

    [Parameter(Mandatory=$true)]
    [ValidateSet("Add","Remove")]
    [string]$Action,

    [Parameter(Mandatory=$true)]
    [string]$LogPath,

    [switch]$UseTrustedConnection,

    [string]$SqlUsername = "",
    [string]$SqlPassword = ""
)

function Write-Log {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "$ts [$Level] $Message"
    $line | Out-File -FilePath $LogPath -Append -Encoding UTF8
    Write-Host $line
}

function Invoke-SqlcmdText {
    param(
        [string]$SqlInstance,
        [string]$Query
    )

    $args = @(
        "-S", $SqlInstance,
        "-b",
        "-Q", $Query
    )

    if ($UseTrustedConnection) {
        $args += "-E"
    } else {
        if ([string]::IsNullOrWhiteSpace($SqlUsername) -or [string]::IsNullOrWhiteSpace($SqlPassword)) {
            throw "SqlUsername and SqlPassword are required unless -UseTrustedConnection is specified."
        }
        $args += @("-U", $SqlUsername, "-P", $SqlPassword)
    }

    $output = & sqlcmd @args 2>&1
    $exitCode = $LASTEXITCODE

    [PSCustomObject]@{
        ExitCode = $exitCode
        Output   = ($output -join " ")
    }
}

function Escape-SqlLiteral {
    param([string]$Text)
    if ($null -eq $Text) { return "" }
    return $Text.Replace("'", "''")
}

if (-not (Test-Path $InputCsv)) {
    throw "Input CSV not found: $InputCsv"
}

New-Item -ItemType File -Path $LogPath -Force | Out-Null

$rows = Import-Csv $InputCsv
if (-not $rows) {
    throw "Input CSV is empty."
}

Write-Log "Starting action: $Action"
Write-Log "Input CSV: $InputCsv"

foreach ($row in $rows) {
    $sourceInstance = $row.SourceInstance.Trim()
    $linkedServer   = $row.LinkedServer.Trim()

    if ([string]::IsNullOrWhiteSpace($sourceInstance) -or [string]::IsNullOrWhiteSpace($linkedServer)) {
        Write-Log "Skipping invalid row: SourceInstance='$($row.SourceInstance)' LinkedServer='$($row.LinkedServer)'" "ERROR"
        continue
    }

    $lsEsc = Escape-SqlLiteral $linkedServer

    if ($Action -eq "Add") {
        $query = @"
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM sys.servers WHERE name = N'$lsEsc')
BEGIN
    EXEC master.dbo.sp_addlinkedserver
        @server     = N'$lsEsc',
        @srvproduct = N'',
        @provider   = N'SQLNCLI',
        @datasrc    = N'$lsEsc';

    EXEC master.dbo.sp_serveroption @server=N'$lsEsc', @optname=N'data access', @optvalue=N'true';
    EXEC master.dbo.sp_serveroption @server=N'$lsEsc', @optname=N'rpc', @optvalue=N'true';
    EXEC master.dbo.sp_serveroption @server=N'$lsEsc', @optname=N'rpc out', @optvalue=N'true';
    EXEC master.dbo.sp_serveroption @server=N'$lsEsc', @optname=N'use remote collation', @optvalue=N'true';

    EXEC master.dbo.sp_addlinkedsrvlogin
        @rmtsrvname = N'$lsEsc',
        @useself    = N'True',
        @locallogin = NULL;

    PRINT 'CREATED';
END
ELSE
BEGIN
    PRINT 'EXISTS';
END
"@
    }
    else {
        $query = @"
SET NOCOUNT ON;
IF EXISTS (SELECT 1 FROM sys.servers WHERE name = N'$lsEsc')
BEGIN
    EXEC master.dbo.sp_dropserver @server=N'$lsEsc', @droplogins='droplogins';
    PRINT 'REMOVED';
END
ELSE
BEGIN
    PRINT 'NOTFOUND';
END
"@
    }

    try {
        Write-Log "$Action : $sourceInstance -> $linkedServer"
        $result = Invoke-SqlcmdText -SqlInstance $sourceInstance -Query $query

        if ($result.ExitCode -eq 0) {
            Write-Log "$Action success : $sourceInstance -> $linkedServer :: $($result.Output)"
        }
        else {
            Write-Log "$Action failed : $sourceInstance -> $linkedServer :: $($result.Output)" "ERROR"
        }
    }
    catch {
        Write-Log "$Action failed : $sourceInstance -> $linkedServer :: $($_.Exception.Message)" "ERROR"
    }
}

Write-Log "Completed action: $Action"
Write-Host ""
Write-Host "Done. Log: $LogPath"