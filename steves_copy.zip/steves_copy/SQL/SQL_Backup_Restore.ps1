﻿<# 
.SYNOPSIS
    Automates the migration of SQL Express databases from a source server to a destination server.
    The script backs up a specified database from a source SQL Express instance directly to a shared folder on the destination server, then restores the database from that location.
    It also migrates user logins from the source server to the destination server without affecting the users on the source server.
    Outputs logs of the entire migration process, including backup, restore, and login migration, to a specified log file.

.PARAMETER CsvInput
    The path to the CSV input file. The CSV should contain five columns: 
    SourceHostname (e.g., "SourceServer1"), SourceInstanceName (e.g., "sqlexpress"), 
    DestHostname (e.g., "DestServer1"), DestInstanceName (e.g., "sqlexpress"), 
    and Database (the name of the database to migrate).

.PARAMETER LogFile
    The path to the output log file. The migration steps are logged here with timestamps.

.EXAMPLE
    PS> .\Migrate-SQLExpress.ps1 -CsvInput "C:\temp\servers.csv" -LogFile "C:\temp\migration_log.txt"

    This example migrates databases and logins as defined in the CSV input file, logging progress to a text file.

.NOTES
    The script assumes that the backup location is a shared folder on the destination server that is accessible from the source server.
#>

# Set your variables here
$CsvInput = "C:\temp\servers.csv"
$LogFile = "C:\temp\migration_log.txt"

Import-Module SQLPS -DisableNameChecking

function Write-Log {
    param(
        [string]$message
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "$timestamp - $message"
}

function Backup-SqlDatabase {
    param (
        [string]$SourceServerInstance,
        [string]$DatabaseName,
        [string]$DestinationServerInstance
    )

    # Define the shared path on the destination server where the backup will be stored
    $backupFile = "\\$DestinationServerInstance\Backups\$DatabaseName.bak"

    # Ensure the destination server's backup folder exists (the folder needs to be created manually or using remoting prior to the backup)
    Backup-SqlDatabase -ServerInstance $SourceServerInstance -Database $DatabaseName -BackupFile $backupFile -Initialize -ErrorAction Stop

    Write-Log "Backup successful for database [$DatabaseName] on server instance [$SourceServerInstance] to [$backupFile]."
    return $backupFile
}

function Restore-SqlDatabase {
    param (
        [string]$DestinationServerInstance,
        [string]$DatabaseName,
        [string]$BackupFile
    )

    Restore-SqlDatabase -ServerInstance $DestinationServerInstance -Database $DatabaseName -BackupFile $BackupFile -ReplaceDatabase -ErrorAction Stop

    Write-Log "Restore successful for database [$DatabaseName] on server instance [$DestinationServerInstance]."
}

function Migrate-Logins {
    param (
        [string]$SourceServerInstance,
        [string]$DestinationServerInstance
    )

    # Export logins and hashed passwords from source server
    $logins = Invoke-Sqlcmd -Query "
        DECLARE @sql NVARCHAR(MAX)
        SELECT @sql = COALESCE(@sql + CHAR(13), '') +
        'CREATE LOGIN [' + sp.name + '] ' + 
        CASE WHEN sp.type_desc = 'SQL_LOGIN' THEN 'WITH PASSWORD = 0x' + CONVERT(VARCHAR(MAX), sl.password_hash, 2) + ' HASHED' 
        ELSE 'FROM WINDOWS' END + ', DEFAULT_DATABASE=[' + sp.default_database_name + '], CHECK_POLICY=' + 
        CASE WHEN sl.is_policy_checked = 1 THEN 'ON' ELSE 'OFF' END
        FROM sys.server_principals sp
        LEFT JOIN sys.sql_logins sl ON sp.principal_id = sl.principal_id
        WHERE sp.type IN ('S', 'U') AND sp.name NOT LIKE '##%' 
        ORDER BY sp.name

        SELECT @sql" -ServerInstance $SourceServerInstance

    # Execute login creation script on destination server
    foreach ($createLoginQuery in $logins) {
        Invoke-Sqlcmd -Query $createLoginQuery -ServerInstance $DestinationServerInstance
        Write-Log "Login [$($createLoginQuery.name)] migrated to server instance [$DestinationServerInstance]."
    }
}

# Read the CSV input file for source and destination servers
$servers = Import-Csv -Path $CsvInput

foreach ($server in $servers) {
    $SourceHostname = $server.SourceHostname  # Source hostname, e.g., "SourceServer1"
    $SourceInstanceName = $server.SourceInstanceName  # Source instance name, e.g., "sqlexpress"
    $DestHostname = $server.DestHostname  # Destination hostname, e.g., "DestServer1"
    $DestInstanceName = $server.DestInstanceName  # Destination instance name, e.g., "sqlexpress"
    $DatabaseName = $server.Database  # Database name

    # Combine hostname and instance name for SQL Server operations
    $SourceServerInstance = "$SourceHostname\$SourceInstanceName"
    $DestinationServerInstance = "$DestHostname\$DestInstanceName"

    Write-Log "Starting migration from [$SourceServerInstance] to [$DestinationServerInstance] for database [$DatabaseName]."

    # Step 1: Backup the database from source server directly to the destination server's shared folder
    $backupFile = Backup-SqlDatabase -SourceServerInstance $SourceServerInstance -DatabaseName $DatabaseName -DestinationServerInstance $DestHostname

    # Step 2: Restore the database to destination server from the shared folder
    Restore-SqlDatabase -DestinationServerInstance $DestinationServerInstance -DatabaseName $DatabaseName -BackupFile $backupFile

    # Step 3: Migrate logins from source server to destination server
    Migrate-Logins -SourceServerInstance $SourceServerInstance -DestinationServerInstance $DestinationServerInstance

    Write-Log "Migration completed for database [$DatabaseName] from [$SourceServerInstance] to [$DestinationServerInstance]."
}

Write-Log "All migrations completed."
