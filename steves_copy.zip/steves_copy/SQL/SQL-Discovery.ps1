﻿$outputDirectory = "C:\temp\QCAD\BA\SQL"
if (!(Test-Path $outputDirectory)) {
    New-Item -Path $outputDirectory -ItemType Directory | Out-Null
}

# Define the remote SQL Server instance
$SqlServerInstance = "QPS-VAS-BA-02\SQLEXPRESS"

# Queries for discovery
$databasesQuery = @"
SELECT 
    name, 
    compatibility_level,
    collation_name
FROM sys.databases
"@

$authModeQuery = "EXEC xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode'"

# Retrieve the databases information from the remote SQL Server
$databases = Invoke-Sqlcmd -Query $databasesQuery -ServerInstance $SqlServerInstance

# Retrieve the authentication mode
$authMode = Invoke-Sqlcmd -Query $authModeQuery -ServerInstance $SqlServerInstance

# Convert authentication mode to a readable format
$authModeDescription = switch ($authMode.LoginMode) {
    1 { 'Windows Authentication Mode' }
    2 { 'SQL Server and Windows Authentication Mode' }
    default { 'Unknown Authentication Mode' }
}

# Export the databases information to a CSV file on the local system
$databasesCsvPath = Join-Path -Path $outputDirectory -ChildPath "Databases.csv"
$databases | Select-Object name, compatibility_level, collation_name | Export-Csv -Path $databasesCsvPath -NoTypeInformation

# Export the authentication mode to a CSV file on the local system
$authModeCsvPath = Join-Path -Path $outputDirectory -ChildPath "AuthenticationMode.csv"
$authObject = [PSCustomObject]@{ LoginMode = $authModeDescription }
$authObject | Export-Csv -Path $authModeCsvPath -NoTypeInformation

# Retrieve users from all databases
$usersList = @()
foreach ($database in $databases) {
    $dbName = $database.name
    $usersQuery = @"
USE [$dbName];
SELECT 
    '$dbName' AS Database, 
    dp.name AS UserName, 
    dp.type_desc AS UserType 
FROM sys.database_principals dp 
WHERE dp.type IN ('S', 'U', 'G')
"@
    $users = Invoke-Sqlcmd -Query $usersQuery -ServerInstance $SqlServerInstance
    $usersList += $users
}

# Export users list to a CSV file on the local system
$usersCsvPath = Join-Path -Path $outputDirectory -ChildPath "DatabaseUsers.csv"
$usersList | Export-Csv -Path $usersCsvPath -NoTypeInformation

# Export SQL Server Express limitations to a CSV file
$Limitations = @(
    [PSCustomObject]@{ "Limitation" = "Maximum database size"; "Value" = "10 GB" },
    [PSCustomObject]@{ "Limitation" = "Maximum memory utilized"; "Value" = "1410 MB" },
    [PSCustomObject]@{ "Limitation" = "Maximum CPU cores used"; "Value" = "4 cores" }
)
$LimitationsCsvPath = Join-Path -Path $outputDirectory -ChildPath "SqlServerExpressLimitations.csv"
$Limitations | Export-Csv -Path $LimitationsCsvPath -NoTypeInformation

# Print paths to output files
Write-Output "Database information saved to $databasesCsvPath"
Write-Output "Authentication mode information saved to $authModeCsvPath"
Write-Output "Database user information saved to $usersCsvPath"
Write-Output "SQL Server Express limitations saved to $LimitationsCsvPath"
