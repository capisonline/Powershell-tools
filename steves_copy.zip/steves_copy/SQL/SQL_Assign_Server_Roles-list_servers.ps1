﻿<# 

.SYNOPSIS

    This PowerShell script creates missing SQL Server logins and assigns roles based on the input file.

    If the login already exists, the script will skip creation and log the existence of the login.

    For SQL logins, the script requires a password and will prompt the user to input it.

.DESCRIPTION

    The script reads a CSV file with the details of logins and roles that are missing on the new server.

    It then creates the missing logins and assigns the specified roles, while logging all actions.

.PARAMETER inputFile

    The path to the CSV file containing the missing logins and roles. The file should have the following columns:

    - ServerName: The name of the SQL Server instance where the login is missing.

    - LoginName: The name of the login to create.

    - LoginType: The type of login (e.g., SQL_LOGIN, WINDOWS_LOGIN).

    - RoleName: The server role to assign to the login.

. Requirements: 

    Requires SqlServer module. Download using: Invoke-WebRequest -Uri powershellgallery.com/api/v2/package/sqlserver -Out c:\temp\sqlserver.zip
    2. Extract ZIP and save to Program Files\WindowsPowerShell\Modules\sqlserver
    3. Check if Powershell is able to see it: Get-Module -ListAvailable

.EXAMPLE

    $inputFile = "C:\temp\QCAD\PA\PA_MissingLoginsAndRoles.csv"
    $logFile = "C:\temp\QCAD\PA\SQL_LoginCreationLog.txt"

# Run the script to create missing logins and assign roles.

#>

# Load the SQL Server module
Import-Module -Name SqlServer

# Define the input CSV file with missing logins and roles
$inputFile = "C:\temp\QCAD\PS\SQL\PS_MissingLoginsAndRoles.csv"  # Update with the path to your input file

# Define the log file
$logFile = "C:\temp\QCAD\PS\SQL\PS_MissingLoginsAndRoles-added.txt" # Update with the path to your output file


# Function to write to the log file
function Write-Log {
    param (
        [string]$message
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "$timestamp - $message"
    Add-Content -Path $logFile -Value $logEntry
    Write-Host $message
}

# Function to create a login and assign a role
function Create-LoginAndAssignRole {
    param (
        [string]$serverName,
        [string]$loginName,
        [string]$loginType,
        [string]$roleName
    )

    Write-Log "Processing login '$loginName' on server '$serverName'..."

    try {
        # Check if the login already exists
        $loginExistsResult = Invoke-Sqlcmd -ServerInstance $serverName -Query "SELECT COUNT(*) AS LoginCount FROM sys.server_principals WHERE name = '$loginName';" -TrustServerCertificate
        $loginExists = $loginExistsResult.LoginCount

        if ($loginExists -gt 0) {
            Write-Log "Login '$loginName' already exists on server '$serverName'. Skipping creation."
        } else {
            # Create the login
            if ($loginType -eq "SQL_LOGIN") {
                # SQL_LOGIN requires a password
                $password = Read-Host -Prompt "Enter a strong password for SQL login '$loginName'" -AsSecureString
                $passwordText = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($password))
                Invoke-Sqlcmd -ServerInstance $serverName -Query "CREATE LOGIN [$loginName] WITH PASSWORD = '$passwordText';" -TrustServerCertificate
            } elseif ($loginType -eq "WINDOWS_LOGIN" -or $loginType -eq "WINDOWS_GROUP") {
                Invoke-Sqlcmd -ServerInstance $serverName -Query "CREATE LOGIN [$loginName] FROM WINDOWS;" -TrustServerCertificate
            }

            Write-Log "Login '$loginName' created successfully on server '$serverName'."

            # Assign the server role
            if ($roleName) {
                Invoke-Sqlcmd -ServerInstance $serverName -Query "ALTER SERVER ROLE [$roleName] ADD MEMBER [$loginName];" -TrustServerCertificate
                Write-Log "Assigned role '$roleName' to login '$loginName' on server '$serverName'."
            }
        }
    } catch {
        Write-Log "Failed to create login or assign role on server '$serverName': $_"
    }
}

# Read the input file and create logins and assign roles
$loginsAndRoles = Import-Csv -Path $inputFile

foreach ($item in $loginsAndRoles) {
    $serverName = $item.ServerName
    $loginName = $item.LoginName
    $loginType = $item.LoginType
    $roleName  = $item.RoleName

    Create-LoginAndAssignRole -serverName $serverName -loginName $loginName -loginType $loginType -roleName $roleName
}

Write-Log "Login creation and role assignment complete."

