﻿# Define the path to the CSV file 
$csvPath = "C:\temp\QCAD\PA\SQL\Backup_Restore\Server_list.csv"

# Read the CSV file
$servers = Import-Csv -Path $csvPath

# Loop through each row in the CSV
foreach ($server in $servers) {
    $oldServer = $server.OLD_Server
    $newServer = $server.NEW_Servers

    # Define the task action to backup all user databases and copy the backups
    $scriptBlock = {
        param($oldServer, $newServer)
        # Get list of all user databases
        $query = "SELECT name FROM sys.databases WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb');"
        $databases = Invoke-Sqlcmd -ServerInstance $oldServer -Query $query

        foreach ($db in $databases) {
            $dbName = $db.name
            $backupPath = "C:\Temp\$($dbName)_$($oldServer)_$(Get-Date -Format 'yyyyMMdd').bak"
            # Backup each database
            $backupCommand = "SQLCMD -E -S $oldServer -Q `"BACKUP DATABASE [$dbName] TO DISK = '$backupPath' WITH FORMAT;`""
            Invoke-Expression $backupCommand

            # Copy the backup file to the new server
            $destinationPath = "\\$newServer\C$\Backups\"
            Copy-Item -Path $backupPath -Destination $destinationPath
        }
    }

    # Create a scheduled task on the old server to perform the backup
    $action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument "-NoProfile -WindowStyle Hidden -Command `"$scriptBlock -oldServer $oldServer -newServer $newServer`""
    $trigger = New-ScheduledTaskTrigger -At 3:00am -Daily
    $taskName = "Backup All User Databases Task"
    $taskDescription = "Performs a backup of all user SQL databases and copies them to a new server."

    # Register the task remotely on the old server
    Invoke-Command -ComputerName $oldServer -ScriptBlock {
        Param($action, $trigger, $taskName, $taskDescription)
        Register-ScheduledTask -Action $action -Trigger $trigger -TaskName $taskName -Description $taskDescription
    } -ArgumentList $action, $trigger, $taskName, $taskDescription
}
