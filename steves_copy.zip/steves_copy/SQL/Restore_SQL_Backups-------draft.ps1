﻿# Define the path to the CSV file 
$csvPath = "C:\Path\To\Your\NewServers.csv"

# Read the CSV file
$newServers = Import-Csv -Path $csvPath

# Loop through each new server listed in the CSV
foreach ($server in $newServers) {
    $newServer = $server.NEW_Servers

    # Define the task action to restore databases from all backup files in the directory
    $scriptBlock = {
        param($newServer)
        # Get all .bak files in the backup directory
        $backupFiles = Get-ChildItem -Path "C:\temp\sql-db-backup\*.bak"

        foreach ($backupFile in $backupFiles) {
            # Assume the database name is the same as the file name without the extension
            $dbName = $backupFile.BaseName

            # SQLCMD Command to restore the database
            $restoreCommand = "SQLCMD -E -S $newServer -Q `"RESTORE DATABASE [$dbName] FROM DISK = '$($backupFile.FullName)' WITH REPLACE;`""
            Invoke-Expression $restoreCommand
        }
    }

    # Create a scheduled task on the new server to perform the database restore
    $action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument "-NoProfile -WindowStyle Hidden -Command `"$scriptBlock -newServer $newServer`""
    $trigger = New-ScheduledTaskTrigger -At 1:00am -Daily
    $taskName = "Restore All Databases Task"
    $taskDescription = "Restores all databases from backups located at C:\temp\sql-db-backup."

    # Register the task remotely on the new server
    Invoke-Command -ComputerName $newServer -ScriptBlock {
        Param($action, $trigger, $taskName, $taskDescription)
        Register-ScheduledTask -Action $action -Trigger $trigger -TaskName $taskName -Description $taskDescription
    } -ArgumentList $action, $trigger, $taskName, $taskDescription
}
