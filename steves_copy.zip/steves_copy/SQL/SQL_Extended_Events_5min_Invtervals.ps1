﻿-- Point this at your saved XEL files (wildcards OK)
DECLARE @xel nvarchar(260) = N'D:\Temp\EGLVCADVASVT01_SQL_Extended_Events_0.xel';

-- Stage parsed events so we can reuse them
IF OBJECT_ID('tempdb..#shred') IS NOT NULL DROP TABLE #shred;
CREATE TABLE #shred
(
  event_time     datetime2(3) NOT NULL,
  event_name     sysname       NULL,
  statement_text nvarchar(max) NULL
);

INSERT INTO #shred(event_time, event_name, statement_text)
SELECT
  CONVERT(datetime2(3), x.value('(event/@timestamp)[1]','datetime2(3)')) AS event_time,
  x.value('(event/@name)[1]','sysname')                                   AS event_name,
  COALESCE(
    x.value('(event/data[@name="batch_text"]/value)[1]', 'nvarchar(max)'),
    x.value('(event/data[@name="statement"]/value)[1]',   'nvarchar(max)'),
    x.value('(event/action[@name="sql_text"]/value)[1]',  'nvarchar(max)')
  )                                                                        AS statement_text
FROM sys.fn_xe_file_target_read_file(@xel, NULL, NULL, NULL) AS F
CROSS APPLY (SELECT CAST(F.event_data AS xml) AS x) AS CA;

-- A) Count by 5-minute buckets
SELECT
  DATEADD(minute, DATEDIFF(minute, 0, event_time) / 5 * 5, 0) AS five_min_bucket,
  COUNT(*)                                                     AS events_in_bucket
FROM #shred
GROUP BY DATEADD(minute, DATEDIFF(minute, 0, event_time) / 5 * 5, 0)
ORDER BY five_min_bucket;

-- B) Repeating statements & average gap between executions
WITH s AS
(
  SELECT
    statement_text,
    event_time,
    LAG(event_time) OVER (PARTITION BY statement_text ORDER BY event_time) AS prev_time
  FROM #shred
  WHERE statement_text IS NOT NULL
)
SELECT TOP (50)
  statement_text,
  COUNT(*)                                                AS executions,
  AVG(DATEDIFF(SECOND, prev_time, event_time))            AS avg_gap_seconds,
  MIN(event_time)                                         AS first_seen,
  MAX(event_time)                                         AS last_seen
FROM s
GROUP BY statement_text
ORDER BY executions DESC;
