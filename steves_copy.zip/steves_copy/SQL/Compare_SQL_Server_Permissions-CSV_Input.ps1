﻿<# 
.SYNOPSIS
    This PowerShell script compares "server-level" roles and permissions between pairs of SQL Server instances.
    It reads a list of server pairs from a CSV file and generates a consolidated CSV file with the comparison results,
    highlighting any differences in LoginName, LoginType, and RoleName between the "OldServer" and "NewServer".
.DESCRIPTION
    The script is designed to help identify discrepancies in server roles and permissions
    when migrating or upgrading SQL Server instances. The comparison is performed using the `Compare-Object`
    cmdlet, and the results are saved to a single consolidated CSV file.
.PARAMETER inputFile
    The path to the input CSV file containing the server pairs. The file should have two columns:
    - OldServer: The name of the old SQL Server instance.
    - NewServer: The name of the new SQL Server instance.
.OUTPUTS
    A single CSV file comparing the roles and permissions between the old and new servers.
.NOTES
    - Ensure that the SQL Server instances are accessible and that the PowerShell session
      has the necessary permissions to connect to them.
    - The script requires the `SqlServer` module.
. Requirements:
    Requires SqlServer module.
    1: Download using: Invoke-WebRequest -Uri powershellgallery.com/api/v2/package/sqlserver -Out c:\temp\sqlserver.zip
    2. Extract ZIP and save to Program Files\WindowsPowerShell\Modules\sqlserver
    3. Check if Powershell is able to see it: Get-Module -ListAvailable
.EXAMPLE
    # Example usage:
    $inputFile = "C:\temp\ServerList.csv"
  # Example input file contents:
    # OldServer,NewServer
    # OLDVASServer\SQLEXPRESS,NEWVASServer\SQLEXPRESS
    # OLDVASServer2\SQL2014,NEWVASServer2\SQL2019
    # Run the script to compare roles and permissions between the listed server pairs.
#>

# Load the SQL Server module
Import-Module -Name SqlServer

# Define the input CSV file with server pairs
$inputFile = "C:\temp\QCAD\PA\SQL\Permisions\Compare_Servers-Input.csv"  # Update with the path to your input file

# Define the output CSV file for consolidated results
$outputFile = "C:\temp\QCAD\PA\SQL\Permisions\Comparisons\Consolidated_Comparison779999999997777.csv"

# Function to extract server-level roles and permissions
function Get-ServerRolesAndPermissions {
    param (
        [string]$serverName
    )

    $serverInfo = @()

    # Check if SQL Server is accessible
    try {
        $testConnection = Invoke-Sqlcmd -ServerInstance $serverName -Query "SELECT 1" -ErrorAction Stop -TrustServerCertificate
    } catch {
        Write-Host "No SQL found on $serverName. Skipping..."
        return "No SQL found"
    }

    # Get server roles and logins
    $rolesAndLogins = Invoke-Sqlcmd -ServerInstance $serverName -Query @"
        SELECT
            sp.name AS LoginName,
            sp.type_desc AS LoginType,
            sr.name AS RoleName
        FROM
            sys.server_role_members srm
        JOIN
            sys.server_principals sr ON srm.role_principal_id = sr.principal_id
        JOIN
            sys.server_principals sp ON srm.member_principal_id = sp.principal_id
        ORDER BY
            sp.name, sr.name;
"@ -TrustServerCertificate

    foreach ($row in $rolesAndLogins) {
        $serverInfo += [PSCustomObject]@{
            ServerName = $serverName
            LoginName  = $row.LoginName
            LoginType  = $row.LoginType
            RoleName   = $row.RoleName
        }
    }

    return $serverInfo
}

# Function to compare roles and permissions between two servers
function Compare-ServerRolesAndPermissions {
    param (
        [string]$oldServer,
        [string]$newServer
    )

    $oldServerInfo = Get-ServerRolesAndPermissions -serverName $oldServer
    $newServerInfo = Get-ServerRolesAndPermissions -serverName $newServer

    if ($oldServerInfo -eq "No SQL found" -or $newServerInfo -eq "No SQL found") {
        return @()
    }

    # Compare roles and permissions
    $comparison = Compare-Object -ReferenceObject $oldServerInfo -DifferenceObject $newServerInfo -Property LoginName, LoginType, RoleName -PassThru

    # Add custom indicator for missing roles and permissions
    foreach ($item in $comparison) {
        if ($item.SideIndicator -eq "<=") {
           $item.SideIndicator = "Missing in $newServer"
        } elseif ($item.SideIndicator -eq "=>") {
            $item.SideIndicator = "Missing in $oldServer"
        }
    }

    # Return the comparison results
    return $comparison
}

# Initialize the output file
"OldServer,NewServer,ServerName,LoginName,LoginType,RoleName,SideIndicator" | Out-File -FilePath $outputFile

# Read the input file and compare roles and permissions for each pair of servers
$serverPairs = Import-Csv -Path $inputFile

foreach ($pair in $serverPairs) {
    $oldServer = $pair.OldServer
    $newServer = $pair.NewServer

    Write-Host "Comparing roles and permissions between $oldServer and $newServer..."

    $comparisonResults = Compare-ServerRolesAndPermissions -oldServer $oldServer -newServer $newServer

    if ($comparisonResults.Count -eq 0) {
        Write-Host "No valid comparison data found for $oldServer and $newServer. Skipping..."
        continue
    }

    # Add server pair info to each result row
    $comparisonResults | ForEach-Object {
        $_ | Add-Member -MemberType NoteProperty -Name OldServer -Value $oldServer -Force
        $_ | Add-Member -MemberType NoteProperty -Name NewServer -Value $newServer -Force
    }

    # Export the comparison results to the consolidated CSV
    $comparisonResults | Select-Object OldServer, NewServer, ServerName, LoginName, LoginType, RoleName, SideIndicator |
    Export-Csv -Path $outputFile -NoTypeInformation -Append

    Write-Host "Comparison complete. Results appended to $outputFile"
}
