﻿<#
.SYNOPSIS
Back up QCAD SQL databases from one chosen source server, distribute the .bak files
to a target list, and restore on each target using suffix-based DB resolution.

.DESCRIPTION
- Prompts for source backup server and SQL instance if not supplied
- Requires a restore target CSV via -RestoreToList
- Backs up:
    VisVT_VisionPacketManager
    VisVT_VisionServer
- Copies those .bak files to all target servers
- Restores over the local target databases matching:
    %VisionPacketManager
    %VisionServer
Note: restores to FBVAS with correct sitecode variable :D 

.PARAMETER RestoreToList
CSV containing target restore servers.

Expected columns:
TargetServer,SqlInstance,BackupDestPath,Enabled

.PARAMETER SourceServer
Optional. If omitted, the script prompts for it.

.PARAMETER SourceSqlInstance
Optional. If omitted, the script prompts for it.

.PARAMETER SourceBackupPath
Optional. Defaults to E:\Temp\SQL_Backups

.PARAMETER DryRun
Shows what would happen without making changes.

.EXAMPLE
.\SQL_Backup_Restore_dynamic.ps1 -RestoreToList C:\Temp\QCAD_Targets.csv

.EXAMPLE
.\SQL_Backup_Restore_dynamic.ps1 `
    -SourceServer QPS-VAS-VT-05 `
    -SourceSqlInstance QPS-VAS-VT-05\SQLEXPRESS `
    -RestoreToList C:\temp\QCAD\VT\SQL\Backup_Restore\NEW_VT_Server_list.csv
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$SourceServer,

    [Parameter(Mandatory = $false)]
    [string]$SourceSqlInstance,

    [Parameter(Mandatory = $true)]
    [string]$RestoreToList,

    [string]$SourceBackupPath = "E:\Temp\SQL_Backups",

    [string]$LogFolder = "C:\Temp\QCAD_SQL_Orchestration",

    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

# =========================
# HELPERS
# =========================
function Join-RemotePath {
    param(
        [Parameter(Mandatory = $true)][string]$BasePath,
        [Parameter(Mandatory = $true)][string]$Child
    )

    return ($BasePath.TrimEnd('\') + "\" + $Child)
}

function Write-Log {
    param(
        [string]$Stage,
        [string]$Target,
        [string]$Status,
        [string]$Message
    )

    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    switch ($Status) {
        "SUCCESS" { Write-Host "[$ts] [$Stage] [$Target] $Message" -ForegroundColor Green }
        "WARN"    { Write-Host "[$ts] [$Stage] [$Target] $Message" -ForegroundColor Yellow }
        "FAILED"  { Write-Host "[$ts] [$Stage] [$Target] $Message" -ForegroundColor Red }
        default   { Write-Host "[$ts] [$Stage] [$Target] $Message" -ForegroundColor Cyan }
    }

    $script:ActionLog += [pscustomobject]@{
        Timestamp = $ts
        Stage     = $Stage
        Target    = $Target
        Status    = $Status
        Message   = $Message
    }
}

function Convert-LocalPathToUNC {
    param(
        [Parameter(Mandatory = $true)][string]$Server,
        [Parameter(Mandatory = $true)][string]$LocalPath
    )

    if ($LocalPath -notmatch '^[A-Za-z]:\\') {
        throw "Invalid local path: $LocalPath"
    }

    $drive = $LocalPath.Substring(0,1)
    $rest  = $LocalPath.Substring(2).TrimStart('\')
    return "\\$Server\$($drive)`$\$rest"
}

function Escape-SqlLiteral {
    param([string]$Value)
    return $Value.Replace("'", "''")
}

function Invoke-QcadSql {
    param(
        [Parameter(Mandatory = $true)][string]$ServerInstance,
        [Parameter(Mandatory = $true)][string]$Database,
        [Parameter(Mandatory = $true)][string]$Query
    )

    if ($DryRun) {
        return $null
    }

    return Invoke-Sqlcmd `
        -ServerInstance $ServerInstance `
        -Database $Database `
        -Query $Query `
        -TrustServerCertificate `
        -ErrorAction Stop
}

# =========================
# PROMPTS
# =========================
if ([string]::IsNullOrWhiteSpace($SourceServer)) {
    $SourceServer = Read-Host "Enter SOURCE server hostname (where backups will be taken from)"
}

if ([string]::IsNullOrWhiteSpace($SourceSqlInstance)) {
    $SourceSqlInstance = Read-Host "Enter SOURCE SQL instance (example: SERVER\SQLEXPRESS)"
}

if (-not (Test-Path $RestoreToList)) {
    throw "Restore target list not found: $RestoreToList"
}

# =========================
# INIT
# =========================
if (-not (Get-Module -ListAvailable -Name SqlServer)) {
    throw "SqlServer module is not installed. Install it with: Install-Module SqlServer -Scope CurrentUser -Force"
}
Import-Module SqlServer -ErrorAction Stop

if (-not (Test-Path $LogFolder)) {
    New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
}

$RunStamp   = Get-Date -Format "yyyyMMdd_HHmmss"
$CsvLogPath = Join-Path $LogFolder "QCAD_SQL_Orchestration_$RunStamp.csv"
$TxtLogPath = Join-Path $LogFolder "QCAD_SQL_Orchestration_$RunStamp.log"

Start-Transcript -Path $TxtLogPath -Append | Out-Null

$ActionLog = @()

$TargetRows = Import-Csv -Path $RestoreToList | Where-Object {
    $_.Enabled -match '^(Yes|Y|True|1)$'
}

if (-not $TargetRows) {
    throw "No enabled targets found in $RestoreToList"
}

$SourceDatabases = @(
    "VisVT_VisionPacketManager",
    "VisVT_VisionServer"
)

$SourceBackupUNC = Convert-LocalPathToUNC -Server $SourceServer -LocalPath $SourceBackupPath

Write-Log -Stage "INIT" -Target "LOCAL" -Status "INFO" -Message "Source server: $SourceServer"
Write-Log -Stage "INIT" -Target "LOCAL" -Status "INFO" -Message "Source SQL instance: $SourceSqlInstance"
Write-Log -Stage "INIT" -Target "LOCAL" -Status "INFO" -Message "Restore list: $RestoreToList"
Write-Log -Stage "INIT" -Target "LOCAL" -Status "INFO" -Message "Source backup path: $SourceBackupPath"
Write-Log -Stage "INIT" -Target "LOCAL" -Status "INFO" -Message "Targets loaded: $($TargetRows.Count)"

# =========================
# 1. BACKUP FROM SOURCE
# =========================
foreach ($db in $SourceDatabases) {
    try {
        $backupFile = Join-RemotePath -BasePath $SourceBackupPath -Child ($db + ".bak")

        $backupSql = @"
BACKUP DATABASE [$db]
TO DISK = N'$(Escape-SqlLiteral $backupFile)'
WITH INIT, FORMAT, CHECKSUM, STATS = 10;
"@

        if ($DryRun) {
            Write-Log -Stage "BACKUP" -Target $db -Status "INFO" -Message "DRY RUN - would back up to $backupFile"
        }
        else {
            Write-Log -Stage "BACKUP" -Target $db -Status "INFO" -Message "Starting backup to $backupFile"
            Invoke-QcadSql -ServerInstance $SourceSqlInstance -Database "master" -Query $backupSql

            $backupUNC = Convert-LocalPathToUNC -Server $SourceServer -LocalPath $backupFile
            if (-not (Test-Path $backupUNC)) {
                throw "Backup file not found after backup: $backupUNC"
            }

            Write-Log -Stage "BACKUP" -Target $db -Status "SUCCESS" -Message "Created $backupUNC"
        }
    }
    catch {
        Write-Log -Stage "BACKUP" -Target $db -Status "FAILED" -Message $_.Exception.Message
        $ActionLog | Export-Csv -Path $CsvLogPath -NoTypeInformation -Encoding UTF8
        Stop-Transcript | Out-Null
        throw
    }
}

# =========================
# 2. DISTRIBUTE TO TARGETS
# =========================
foreach ($row in $TargetRows) {
    $targetServer = $row.TargetServer.Trim()
    $backupDest   = $row.BackupDestPath.Trim()

    try {
        $targetUNC = Convert-LocalPathToUNC -Server $targetServer -LocalPath $backupDest

        if ($DryRun) {
            Write-Log -Stage "COPY" -Target $targetServer -Status "INFO" -Message "DRY RUN - would copy .bak files to $targetUNC"
            continue
        }

        if (-not (Test-Path $targetUNC)) {
            New-Item -ItemType Directory -Path $targetUNC -Force | Out-Null
        }

        Write-Log -Stage "COPY" -Target $targetServer -Status "INFO" -Message "Copying .bak files to $targetUNC"
        robocopy $SourceBackupUNC $targetUNC *.bak /R:2 /W:5 /Z /FFT /NP /NJH /NJS | Out-Null
        $rc = $LASTEXITCODE

        if ($rc -ge 8) {
            throw "Robocopy failed with exit code $rc"
        }

        foreach ($db in $SourceDatabases) {
            $expectedFile = Join-RemotePath -BasePath $targetUNC -Child ($db + ".bak")
            if (-not (Test-Path $expectedFile)) {
                throw "Expected copied file not found: $expectedFile"
            }
        }

        Write-Log -Stage "COPY" -Target $targetServer -Status "SUCCESS" -Message "Copied backup files"
    }
    catch {
        Write-Log -Stage "COPY" -Target $targetServer -Status "FAILED" -Message $_.Exception.Message
    }
}

# =========================
# 3. RESTORE TO TARGETS
# =========================
foreach ($row in $TargetRows) {
    $targetServer   = $row.TargetServer.Trim()
    $targetInstance = $row.SqlInstance.Trim()
    $backupDest     = $row.BackupDestPath.Trim()

    try {
        $packetBak = Join-RemotePath -BasePath $backupDest -Child "VisVT_VisionPacketManager.bak"
        $serverBak = Join-RemotePath -BasePath $backupDest -Child "VisVT_VisionServer.bak"

        $restoreSql = @"
USE [master];

DECLARE @RestoreList TABLE
(
    DbSuffix   sysname,
    BackupFile nvarchar(4000)
);

INSERT INTO @RestoreList (DbSuffix, BackupFile)
VALUES
    (N'VisionPacketManager', N'$(Escape-SqlLiteral $packetBak)'),
    (N'VisionServer',        N'$(Escape-SqlLiteral $serverBak)');

DECLARE @DbSuffix     sysname;
DECLARE @BackupFile   nvarchar(4000);
DECLARE @DatabaseName sysname;
DECLARE @MatchCount   int;
DECLARE @sql          nvarchar(max);

DECLARE restore_cursor CURSOR FAST_FORWARD FOR
    SELECT DbSuffix, BackupFile
    FROM @RestoreList;

OPEN restore_cursor;
FETCH NEXT FROM restore_cursor INTO @DbSuffix, @BackupFile;

WHILE @@FETCH_STATUS = 0
BEGIN
    BEGIN TRY
        SELECT
            @MatchCount = COUNT(*),
            @DatabaseName = MIN(name)
        FROM sys.databases
        WHERE name LIKE N'%' + @DbSuffix
          AND database_id > 4;

        IF @MatchCount = 0
            RAISERROR('No database found matching suffix %s', 16, 1, @DbSuffix);

        IF @MatchCount > 1
            RAISERROR('More than one database found matching suffix %s. Restore aborted.', 16, 1, @DbSuffix);

        SET @sql = N'ALTER DATABASE [' + @DatabaseName + N'] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;';
        EXEC (@sql);

        SET @sql = N'
        RESTORE DATABASE [' + @DatabaseName + N']
        FROM DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N'''
        WITH REPLACE, RECOVERY, STATS = 10;';
        EXEC (@sql);

        SET @sql = N'ALTER DATABASE [' + @DatabaseName + N'] SET MULTI_USER;';
        EXEC (@sql);
    END TRY
    BEGIN CATCH
        BEGIN TRY
            IF @DatabaseName IS NOT NULL AND DB_ID(@DatabaseName) IS NOT NULL
            BEGIN
                SET @sql = N'ALTER DATABASE [' + @DatabaseName + N'] SET MULTI_USER;';
                EXEC (@sql);
            END
        END TRY
        BEGIN CATCH
        END CATCH;

        THROW;
    END CATCH;

    SET @DatabaseName = NULL;
    SET @MatchCount = NULL;

    FETCH NEXT FROM restore_cursor INTO @DbSuffix, @BackupFile;
END

CLOSE restore_cursor;
DEALLOCATE restore_cursor;
"@

        if ($DryRun) {
            Write-Log -Stage "RESTORE" -Target $targetServer -Status "INFO" -Message "DRY RUN - would restore on $targetInstance"
            continue
        }

        Write-Log -Stage "RESTORE" -Target $targetServer -Status "INFO" -Message "Starting restore on $targetInstance"
        Invoke-QcadSql -ServerInstance $targetInstance -Database "master" -Query $restoreSql
        Write-Log -Stage "RESTORE" -Target $targetServer -Status "SUCCESS" -Message "Restore completed"
    }
    catch {
        Write-Log -Stage "RESTORE" -Target $targetServer -Status "FAILED" -Message $_.Exception.Message
    }
}

# =========================
# 4. VERIFY
# =========================
foreach ($row in $TargetRows) {
    $targetServer   = $row.TargetServer.Trim()
    $targetInstance = $row.SqlInstance.Trim()

    try {
        $verifySql = @"
SELECT name, state_desc, user_access_desc
FROM sys.databases
WHERE name LIKE '%VisionPacketManager'
   OR name LIKE '%VisionServer'
ORDER BY name;
"@

        if ($DryRun) {
            Write-Log -Stage "VERIFY" -Target $targetServer -Status "INFO" -Message "DRY RUN - would verify DB state"
            continue
        }

        $result = Invoke-QcadSql -ServerInstance $targetInstance -Database "master" -Query $verifySql
        $summary = ($result | ForEach-Object { "$($_.name) [$($_.state_desc)/$($_.user_access_desc)]" }) -join "; "
        Write-Log -Stage "VERIFY" -Target $targetServer -Status "SUCCESS" -Message $summary
    }
    catch {
        Write-Log -Stage "VERIFY" -Target $targetServer -Status "FAILED" -Message $_.Exception.Message
    }
}

$ActionLog | Export-Csv -Path $CsvLogPath -NoTypeInformation -Encoding UTF8

Write-Host ""
Write-Host "CSV log: $CsvLogPath" -ForegroundColor Cyan
Write-Host "Transcript: $TxtLogPath" -ForegroundColor Cyan

Stop-Transcript | Out-Null