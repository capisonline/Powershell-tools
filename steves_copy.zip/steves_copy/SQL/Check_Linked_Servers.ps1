﻿# Path to the input text file containing the list of SQL Server instances 
$inputFilePath = "C:\Path\To\Your\ServersList.txt"

# Path to the output text file for the results
$outputFilePath = "C:\Path\To\Your\OutputResults.txt"

# Initialize the output file
New-Item -Path $outputFilePath -ItemType File -Force

# Read the list of SQL Server instances from the input text file
$servers = Get-Content -Path $inputFilePath

# Function to test linked server connections
function Test-LinkedServerConnections {
    param (
        [string]$serverInstance,
        [string]$outputFile
    )
    
    try {
        # Load the SQL Server Management Objects (SMO) assembly
        Import-Module SqlServer

        # Create a new SQL Server object
        $server = New-Object Microsoft.SqlServer.Management.Smo.Server $serverInstance
        
        # Loop through each linked server
        foreach ($linkedServer in $server.LinkedServers) {
            $message = "Testing connection from $serverInstance to linked server $($linkedServer.Name)..."
            Write-Output $message
            Add-Content -Path $outputFile -Value $message
            
            try {
                # Attempt to connect to the linked server
                $query = "SELECT TOP 1 * FROM OPENQUERY([$($linkedServer.Name)], 'SELECT 1 AS TestConnection')"
                $result = Invoke-Sqlcmd -ServerInstance $serverInstance -Query $query
                
                if ($result) {
                    $message = "Connection to linked server $($linkedServer.Name) succeeded."
                } else {
                    $message = "Connection to linked server $($linkedServer.Name) failed."
                }
                Write-Output $message
                Add-Content -Path $outputFile -Value $message
            } catch {
                $message = "Connection to linked server $($linkedServer.Name) failed: $_"
                Write-Output $message
                Add-Content -Path $outputFile -Value $message
            }
        }
    } catch {
        $message = "Failed to connect to SQL Server instance $serverInstance: $_"
        Write-Output $message
        Add-Content -Path $outputFile -Value $message
    }
}

# Loop through each server in the list and test the linked server connections
foreach ($server in $servers) {
    Test-LinkedServerConnections -serverInstance $server -outputFile $outputFilePath
}

# Indicate completion
$message = "Completed testing linked server connections. Results are saved to $outputFilePath"
Write-Output $message
Add-Content -Path $outputFilePath -Value $message
