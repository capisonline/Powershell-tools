﻿# Load necessary assemblies for SQL Server Management 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null
Import-Module SqlServer -DisableNameChecking -ErrorAction SilentlyContinue

# Ensure the backup directory exists
$backupDirectory = "D:\SQL_Backup"
if (-Not (Test-Path $backupDirectory)) {
    New-Item -Path $backupDirectory -ItemType Directory
}

# Create an SMO Server object for the local instance
$server = New-Object Microsoft.SqlServer.Management.Smo.Server($env:COMPUTERNAME)

# Backup all non-system databases
foreach ($db in $server.Databases) {
    if ($db.IsSystemObject -eq $false) {
        $dbName = $db.Name
        $backupFile = Join-Path $backupDirectory "$dbName.bak"
        
        $backup = New-Object Microsoft.SqlServer.Management.Smo.Backup
        $backup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
        $backup.Database = $dbName
        $backup.Devices.AddDevice($backupFile, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
        $backup.SqlBackup($server)
        Write-Output "Backup completed for $dbName"
    }
}
