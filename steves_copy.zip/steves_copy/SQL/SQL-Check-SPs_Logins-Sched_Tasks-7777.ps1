﻿# Configuration variables 
$inputCsvPath = "C:\path\to\server_list.csv"
$outputCsvPath = "C:\path\to\backup_restore_results.csv"
$backupDirectory = "D:\Path\To\Backup"
$databaseName = "YourDatabaseName"  # Update this with the actual database name
$port = "153"  # Specify the SQL Server port

# Load necessary SQL Server modules
Import-Module SqlServer -DisableNameChecking -ErrorAction SilentlyContinue

# Read the list of servers from the CSV file
$servers = Import-Csv -Path $inputCsvPath

# Array to hold the results for output to CSV
$results = @()

# Process each server pair for backup and restore
foreach ($server in $servers) {
    $oldServerInstance = "$($server.Old_Server),$port"
    $newServerInstance = "$($server.New_Server),$port"
    $backupFilePath = Join-Path $backupDirectory "$databaseName.bak"

    # Initialize result object
    $result = New-Object PSObject -Property @{
        Old_Server = $server.Old_Server
        New_Server = $server.New_Server
        Backup_Status = $null
        Restore_Status = $null
        Error_Details = $null
    }

    # Ensure backup directory exists
    if (-not (Test-Path -Path $backupDirectory)) {
        New-Item -Path $backupDirectory -ItemType Directory
    }

    # Backup process
    try {
        $serverObject = New-Object Microsoft.SqlServer.Management.Smo.Server($oldServerInstance)
        $db = $serverObject.Databases[$databaseName]
        $backup = New-Object Microsoft.SqlServer.Management.Smo.Backup
        $backup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
        $backup.Database = $db.Name
        $backup.Devices.AddDevice($backupFilePath, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
        $backup.SqlBackup($serverObject)
        $result.Backup_Status = "Success"
    } catch {
        $result.Backup_Status = "Failed"
        $result.Error_Details = $_.Exception.Message
    }

    # Restore process (not performed if backup failed)
    if ($result.Backup_Status -eq "Success") {
        try {
            $serverObject = New-Object Microsoft.SqlServer.Management.Smo.Server($newServerInstance)
            $restore = New-Object Microsoft.SqlServer.Management.Smo.Restore
            $restore.Action = [Microsoft.SqlServer.Management.Smo.RestoreActionType]::Database
            $restore.Database = $db.Name
            $restore.Devices.AddDevice($backupFilePath, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
            $restore.SqlRestore($serverObject)
            $result.Restore_Status = "Success"
        } catch {
            $result.Restore_Status = "Failed"
            $result.Error_Details = $_.Exception.Message
        }
    } else {
        $result.Restore_Status = "Skipped due to backup failure"
    }

    # Add the result to the results array
    $results += $result
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

Write-Output "Backup and restore results have been saved to $outputCsvPath"
