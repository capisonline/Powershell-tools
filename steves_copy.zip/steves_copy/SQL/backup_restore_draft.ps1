﻿# Load the SQL Server Management Objects assembly 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null
Import-Module SQLPS -DisableNameChecking -ErrorAction SilentlyContinue

# Define the path to the CSV file
$csvPath = "C:\path\to\yourfile.csv"

# Import the CSV file
$servers = Import-Csv -Path $csvPath

foreach ($server in $servers) {
    $oldServerName = $server.Old_Server
    $newServerName = $server.New_Server

    # Create server connection objects
    $oldServer = New-Object Microsoft.SqlServer.Management.Smo.Server($oldServerName)
    $newServer = New-Object Microsoft.SqlServer.Management.Smo.Server($newServerName)

    # Transfer SQL Logins (except system logins)
    foreach ($login in $oldServer.Logins) {
        if ($login.IsSystemObject -eq $false -and $login.LoginType -eq "SqlLogin") {
            $newLogin = New-Object Microsoft.SqlServer.Management.Smo.Login($newServer, $login.Name)
            if ($null -eq $newServer.Logins[$login.Name]) {
                $newLogin.LoginType = $login.LoginType
                $newLogin.PasswordHash = $login.PasswordHash
                $newLogin.MustChangePassword = $false
                $newLogin.PasswordPolicyEnforced = $login.PasswordPolicyEnforced
                $newLogin.PasswordExpirationEnabled = $login.PasswordExpirationEnabled
                $newLogin.Create()
                $newLogin.Alter()
                Write-Output "Login transferred: $($login.Name)"
            } else {
                Write-Output "Login already exists on new server: $($login.Name)"
            }
        }
    }

    # Loop through each database in the old server
    foreach ($db in $oldServer.Databases) {
        if ($db.IsSystemObject -eq $false) { # Avoid system databases
            $dbName = $db.Name
            $timestamp = Get-Date -Format "yyyyMMddHHmmss"
            $backupFile = "C:\Backup\$dbName-$timestamp.bak"

            # Perform backup
            $backup = New-Object Microsoft.SqlServer.Management.Smo.Backup
            $backup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
            $backup.Database = $dbName
            $backup.Devices.AddDevice($backupFile, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
            $backup.SqlBackup($oldServer)
            Write-Output "Backup completed for $dbName on $oldServerName"

            # Restore to new server
            $restore = New-Object Microsoft.SqlServer.Management.Smo.Restore
            $restore.Action = [Microsoft.SqlServer.Management.Smo.RestoreActionType]::Database
            $restore.Database = $dbName
            $restore.Devices.AddDevice($backupFile, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
            $restore.ReplaceDatabase = $true
            $restore.SqlRestore($newServer)
            Write-Output "Restore completed for $dbName on $newServerName"
        }
    }
}
