﻿# Define the path to the server list file 
$serverListPath = "C:\temp\QCAD\QCAD_Servers_ALLLLL.txt"

# Define the output CSV file
$outputCsv = "C:\temp\QCAD\QCAD_Servers_ALLLLLl_SQL_Alias-reg.csv"

# Read the server names from the text file
$servers = Get-Content $serverListPath

# Prepare an array to hold the results
$results = @()

foreach ($server in $servers) {
    # Use Invoke-Command to run the commands remotely on each server
    $aliases = Invoke-Command -ComputerName $server -ScriptBlock {
        # Navigate to the SQL Server Alias registry keys
        $paths = @(
            'HKLM:\SOFTWARE\Microsoft\MSSQLServer\Client\ConnectTo',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\MSSQLServer\Client\ConnectTo'
        )
        
        # Collect aliases from both 32-bit and 64-bit registry paths
        $results = @()
        foreach ($path in $paths) {
            if (Test-Path $path) {
                $aliasData = Get-ItemProperty -Path $path
                foreach ($alias in $aliasData.PSObject.Properties) {
                    $results += [PSCustomObject]@{
                        Server = $using:server
                        AliasName = $alias.Name
                        ConnectionString = $alias.Value
                        RegistryPath = $path
                    }
                }
            }
        }
        return $results
    }

    # Add results from this server to the overall results array
    $results += $aliases
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsv -NoTypeInformation

Write-Host "SQL Aliases have been saved to $outputCsv"

