﻿# Load necessary assemblies for SQL Server Management 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null
Import-Module SqlServer -DisableNameChecking -ErrorAction SilentlyContinue

# Specify the server instance where the databases will be restored
$serverInstance = "NewServer\InstanceName"  # Update with your actual server and instance name

# Create an SMO Server object
$server = New-Object Microsoft.SqlServer.Management.Smo.Server($serverInstance)

# Directory containing the backup files
$backupDirectory = "D:\SQL_Backup"

# Get a list of backup files from the directory
$backupFiles = Get-ChildItem -Path $backupDirectory -Filter *.bak

# Loop through each backup file to restore the database
foreach ($file in $backupFiles) {
    $dbName = $file.BaseName  # Assumes the file name is the database name
    $backupFilePath = $file.FullName

    # Define the restore operation
    $restore = New-Object Microsoft.SqlServer.Management.Smo.Restore
    $restore.Database = $dbName
    $restore.Action = [Microsoft.SqlServer.Management.Smo.RestoreActionType]::Database
    $restore.Devices.AddDevice($backupFilePath, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
    $restore.ReplaceDatabase = $true  # Use this cautiously; it allows overwriting existing databases

    # Optional: Kill all connections to the database to allow restore
    $killAllConnectionsQuery = "ALTER DATABASE [$dbName] SET SINGLE_USER WITH ROLLBACK IMMEDIATE"
    $server.ConnectionContext.ExecuteNonQuery($killAllConnectionsQuery)

    # Execute the restore
    $restore.SqlRestore($server)
    
    # Optional: Set the database back to multi-user mode after restore
    $multiUserQuery = "ALTER DATABASE [$dbName] SET MULTI_USER"
    $server.ConnectionContext.ExecuteNonQuery($multiUserQuery)

    Write-Output "Database restored successfully: $dbName"
}

Write-Output "All databases have been restored."
