﻿<#
This runs a check on who restored a SQL d-base remotely. 
The T-SQL Script below is the SQL version to be ran locally
#> 


# Load SQL Server module 
Import-Module SqlServer -DisableNameChecking -ErrorAction SilentlyContinue

# Define the SQL Server instance and the query
$serverInstance = "YourServerInstance"  # Replace with your actual server instance
$query = @"
USE msdb;
SELECT 
    rh.destination_database_name AS [Database],
    rh.restore_date AS [Last Restore Date],
    rh.user_name AS [Restored By],
    rh.restore_type AS [Restore Type],
    CASE rh.restore_type
        WHEN 'D' THEN 'Database'
        WHEN 'L' THEN 'Log'
        WHEN 'I' THEN 'Differential'
        ELSE 'Other'
    END AS [Restore Type Description],
    bmf.physical_device_name AS [Backup Source]
FROM 
    restorehistory rh
JOIN 
    backupset bs ON rh.backup_set_id = bs.backup_set_id
JOIN 
    backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
ORDER BY 
    rh.restore_date DESC;
"@

# Execute the query and display results
$results = Invoke-Sqlcmd -Query $query -ServerInstance $serverInstance
$results | Format-Table -AutoSize



<#

This is the T-SQL Script to be ran on SQL server locally

USE msdb; 
GO

SELECT 
    rh.destination_database_name AS [Database],
    rh.restore_date AS [Last Restore Date],
    rh.user_name AS [Restored By],
    rh.restore_type AS [Restore Type],
    CASE rh.restore_type
        WHEN 'D' THEN 'Database'
        WHEN 'L' THEN 'Log'
        WHEN 'I' THEN 'Differential'
        ELSE 'Other'
    END AS [Restore Type Description],
    bmf.physical_device_name AS [Backup Source]
FROM 
    restorehistory rh
JOIN 
    backupset bs ON rh.backup_set_id = bs.backup_set_id
JOIN 
    backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
ORDER BY 
    rh.restore_date DESC;


    #>