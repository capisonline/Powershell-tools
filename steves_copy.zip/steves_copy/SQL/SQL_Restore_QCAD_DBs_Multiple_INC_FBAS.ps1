﻿USE [master];
GO

DECLARE @RestoreList TABLE
(
    DbSuffix   sysname,
    BackupFile nvarchar(4000)
);

INSERT INTO @RestoreList (DbSuffix, BackupFile)
VALUES
    (N'VisionPacketManager', N'E:\Temp\SQL_Backups\VisVT_VisionPacketManager.bak'),
    (N'VisionServer',        N'E:\Temp\SQL_Backups\VisVT_VisionServer.bak');

DECLARE @DbSuffix     sysname;
DECLARE @BackupFile   nvarchar(4000);
DECLARE @DatabaseName sysname;
DECLARE @MatchCount   int;
DECLARE @sql          nvarchar(max);

DECLARE restore_cursor CURSOR FAST_FORWARD FOR
    SELECT DbSuffix, BackupFile
    FROM @RestoreList;

OPEN restore_cursor;
FETCH NEXT FROM restore_cursor INTO @DbSuffix, @BackupFile;

WHILE @@FETCH_STATUS = 0
BEGIN
    BEGIN TRY
        PRINT '==================================================';
        PRINT 'Resolving database for suffix: ' + @DbSuffix;
        PRINT 'Backup file: ' + @BackupFile;

        SELECT
            @MatchCount = COUNT(*),
            @DatabaseName = MIN(name)
        FROM sys.databases
        WHERE name LIKE N'%' + @DbSuffix
          AND database_id > 4; -- exclude system DBs

        IF @MatchCount = 0
        BEGIN
            RAISERROR('No database found matching suffix %s', 16, 1, @DbSuffix);
        END

        IF @MatchCount > 1
        BEGIN
            RAISERROR('More than one database found matching suffix %s. Restore aborted.', 16, 1, @DbSuffix);
        END

        PRINT 'Resolved target database: ' + @DatabaseName;

        SET @sql = N'ALTER DATABASE [' + @DatabaseName + N'] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;';
        EXEC (@sql);

        SET @sql = N'
        RESTORE DATABASE [' + @DatabaseName + N']
        FROM DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N'''
        WITH REPLACE, RECOVERY, STATS = 10;';
        EXEC (@sql);

        SET @sql = N'ALTER DATABASE [' + @DatabaseName + N'] SET MULTI_USER;';
        EXEC (@sql);

        PRINT 'Completed restore: ' + @DatabaseName;
    END TRY
    BEGIN CATCH
        PRINT 'FAILED restore for suffix: ' + ISNULL(@DbSuffix, N'<NULL>');
        PRINT ERROR_MESSAGE();

        BEGIN TRY
            IF @DatabaseName IS NOT NULL AND DB_ID(@DatabaseName) IS NOT NULL
            BEGIN
                SET @sql = N'ALTER DATABASE [' + @DatabaseName + N'] SET MULTI_USER;';
                EXEC (@sql);
            END
        END TRY
        BEGIN CATCH
            PRINT 'Also failed to return database to MULTI_USER: ' + ISNULL(@DatabaseName, N'<NULL>');
            PRINT ERROR_MESSAGE();
        END CATCH
    END CATCH

    SET @DatabaseName = NULL;
    SET @MatchCount = NULL;

    FETCH NEXT FROM restore_cursor INTO @DbSuffix, @BackupFile;
END

CLOSE restore_cursor;
DEALLOCATE restore_cursor;
GO