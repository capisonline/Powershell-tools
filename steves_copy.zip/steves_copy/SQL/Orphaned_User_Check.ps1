﻿# Path to the file containing the list of server names 
$serversListPath = "C:\path\to\servers.txt"

# Path where the results CSV will be saved
$resultsCsvPath = "C:\path\to\orphaned_users_report.csv"

# Read the list of server names from the file
$servers = Get-Content -Path $serversListPath

# Credentials for remoting, if needed
$credential = Get-Credential  # This prompts for credentials

# Initialize an array to store the results
$results = @()

# Loop through each server and check for orphaned users
foreach ($server in $servers) {
    # Establish a remote session with each server
    $session = New-PSSession -ComputerName $server -Credential $credential
    
    # Define the script block to check for orphaned users
    $scriptBlock = {
        Import-Module SqlServer -DisableNameChecking -ErrorAction SilentlyContinue
        $databases = Invoke-Sqlcmd -Query "SELECT name FROM sys.databases WHERE state = 0 AND is_distributor = 0;" -ServerInstance "localhost"
        foreach ($db in $databases.name) {
            $query = "USE [$db]; EXEC sp_change_users_login 'Report';"
            $orphanedUsers = Invoke-Sqlcmd -Query $query -ServerInstance "localhost"
            foreach ($user in $orphanedUsers) {
                $result = @{
                    Server = $env:COMPUTERNAME
                    Database = $db
                    OrphanedUser = $user.UserName
                }
                [PSCustomObject]$result
            }
        }
    }

    # Execute the script block remotely and gather results
    $serverResults = Invoke-Command -Session $session -ScriptBlock $scriptBlock

    # Add results from this server to the main results array
    $results += $serverResults

    # Clean up the session
    Remove-PSSession -Session $session
}

# Output the results to a CSV file
$results | Export-Csv -Path $resultsCsvPath -NoTypeInformation

Write-Output "All results have been saved to $resultsCsvPath"
