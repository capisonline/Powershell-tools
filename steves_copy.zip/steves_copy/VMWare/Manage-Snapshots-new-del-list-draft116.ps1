﻿<#
.SYNOPSIS
    VMware PowerCLI Snapshot Manager with Full CLI Logging
    This script automates snapshot management for VMs in a vCenter environment.

.DESCRIPTION
    This script manages VMware virtual machine (VM) snapshots in a vCenter environment. 
    It allows users to perform snapshot operations such as creating, deleting, listing, and cleaning up snapshots. 
    The script also handles CLI logging, including stdout & stderr output, for easy auditing. 

    Specifically, the script:
    - Connects to a selected vCenter server.
    - Reads a pre-existing CSV file (`snapshot_deletion_csv.csv`) containing the VM names and Snapshot IDs to be deleted.
    - Displays the contents of the CSV file.
    - Asks for a single confirmation to delete all snapshots listed in the CSV.
    - Handles snapshot creation, listing, and cleanup tasks.
    - Logs all actions and errors to a log file (`SnapshotManager.log`).

.OUTPUTS
    - A log file (`SnapshotManager.log`) that captures both stdout & stderr.
    - A CSV file (`snapshot_deletion_csv.csv`) listing snapshot deletion results.

.NOTES
    - Requires VMware PowerCLI to be installed.
    - The script uses `vCenters.txt` to store a list of vCenter servers and attempts to connect to one based on user input.
    - A CSV file (`snapshot_deletion_csv.csv`) should be pre-created with the VM names and Snapshot IDs for deletions.

.AUTHOR
    Created by Cap
#>

Import-Module VMware.PowerCLI -ErrorAction Stop
# Disable VMware customer improvement (No telemetry data is sent to VMware and stops the annoying questions from VMware)
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null

# Define file paths for required resources
$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$VMListFile = "$ScriptDirectory\VMList.txt"
$LogFile = "$ScriptDirectory\SnapshotManager.log"
$SnapshotCSV = "$ScriptDirectory\Snapshots.csv"
$SnapshotDeletionCSV = "$ScriptDirectory\snapshot_deletion_csv.csv"
$VCentersFile = "$ScriptDirectory\vCenters.txt"

# Ensure vCenters.txt exists and prompt the user to input data if it doesn't
if (-not (Test-Path $VCentersFile)) {
    Write-Host "`nvCenters list file not found! Creating a new one in $ScriptDirectory..."
    "Enter one vCenter per line, then save and close the file." | Out-File -FilePath $VCentersFile -Encoding UTF8
    notepad.exe $VCentersFile
    Write-Host "`n Please add vCenters to the file and restart the script."
    exit
}

# Load vCenter list and check if it's not empty
$VCenters = Get-Content $VCentersFile | Where-Object {$_ -ne ""}
if (-not $VCenters) {
    Write-Host "`n No vCenters found in vCenters.txt. Please update the file and restart the script."
    exit
}

# Display vCenter options to the user for selection
Write-Host "`n Select a vCenter Server:"
for ($i = 0; $i -lt $VCenters.Count; $i++) {
    Write-Host " [$($i+1)] $($VCenters[$i])"
}

# Prompt the user to select a vCenter
$selection = Read-Host "`n Enter the number of the vCenter to connect to"
if ($selection -match "^\d+$" -and [int]$selection -ge 1 -and [int]$selection -le $VCenters.Count) {
    $vCenter = $VCenters[[int]$selection - 1]
    Write-Host "`n Selected vCenter: $vCenter"
} else {
    Write-Host "`n Invalid selection. Exiting script."
    exit
}

# Prompt for username and password upfront using Get-Credential
$credential = Get-Credential

# Accept Invalid SSL Certificates without user intervention
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

# Start logging all CLI output (stdout & stderr)
Start-Transcript -Path $LogFile -Append -Force | Out-Null

# Ensure snapshot_deletion_csv exists and prompt the user to input snapshot deletion data if it doesn't
if (-not (Test-Path $SnapshotDeletionCSV)) {
    Write-Host "`nSnapshot deletion CSV file not found! Please ensure it has been created beforehand."
    Stop-Transcript
    exit
}

# Prompt the user for the action they want to perform
$action = Read-Host "Enter the action to perform (create, delete, list, cleanup)"
if ($action -notin @("create", "delete", "list", "cleanup")) {
    Write-Host "Invalid action entered. Exiting script."
    Stop-Transcript
    exit
}

# Handle the snapshot deletion action
if ($action.ToLower() -eq "delete") {
    # Import the snapshot deletions from the CSV
    $snapshotDeletions = Import-Csv -Path $SnapshotDeletionCSV

    # Display the contents of the CSV file
    Write-Host "`nThe following snapshots are listed for deletion:"
    $snapshotDeletions | ForEach-Object { Write-Host "VM: $($_.VM_Name), Snapshot ID: $($_.Snapshot_ID)" }

    # Prompt the user for confirmation to delete all snapshots listed in the CSV
    $confirmation = Read-Host "`nDo you want to delete all of these snapshots? (Y/N)"
    if ($confirmation.ToLower() -ne "y") {
        Write-Host "`n User declined deletion. Exiting script."
        Stop-Transcript
        exit
    }

    # Perform the snapshot deletions as per the CSV
    foreach ($entry in $snapshotDeletions) {
        $vmName = $entry.VM_Name
        $snapshotID = $entry.Snapshot_ID

        # Check if the VM exists
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            Write-Host "`nFound VM: $vmName. Checking for snapshot '$snapshotID'..."

            # Get all snapshots for the VM
            $snapshots = Get-Snapshot -VM $vm -ErrorAction SilentlyContinue

            # Find the snapshot by the ID
            $snapshot = $snapshots | Where-Object { $_.Name -eq $snapshotID }

            if ($snapshot) {
                # Delete the snapshot if confirmed
                try {
                    Remove-Snapshot -Snapshot $snapshot -Confirm:$false -ErrorAction Stop
                    Write-Host "Snapshot '$snapshotID' deleted for VM: $vmName"
                } catch {
                    Write-Host "Failed to delete snapshot '$snapshotID' for VM: $vmName. $_"
                }
            } else {
                Write-Host "Snapshot '$snapshotID' not found for VM: $vmName."
            }
        } else {
            Write-Host "VM '$vmName' not found."
        }
    }
}

# Handle the snapshot creation action
if ($action.ToLower() -eq "create") {
    # Logic for creating snapshots
    foreach ($vm in $VMList) {
        $snapshotName = Read-Host "Enter snapshot name for VM: $vm"
        $snapshotDescription = Read-Host "Enter snapshot description for VM: $vm"
        Write-Host " Creating snapshot for $vm..."
        New-Snapshot -VM $vm -Name $snapshotName -Description $snapshotDescription -Quiesce:$false -Memory:$true -ErrorAction Stop
        Write-Host " Snapshot '$snapshotName' created for VM: $vm"
    }
}

# Handle the snapshot listing action
if ($action.ToLower() -eq "list") {
    # Logic for listing snapshots
    foreach ($vm in $VMList) {
        $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
        $SnapshotCSVWithTimestamp = "$ScriptDirectory\Snapshots_$timestamp.csv"
        Get-Snapshot -VM $vm | 
            Select-Object VM, Name, Created, PowerState, Description, Id | 
            Export-Csv -Path $SnapshotCSVWithTimestamp -NoTypeInformation -Append
        Write-Host " Snapshot list for VM: $vm exported to $SnapshotCSVWithTimestamp"
    }
}

# Handle the snapshot cleanup action
if ($action.ToLower() -eq "cleanup") {
    # Logic for cleaning up old snapshots
    $RetentionDays = Read-Host "Enter retention period (days)"
    Cleanup-OldSnapshots -RetentionDays $RetentionDays
    Write-Host " Deleted snapshots older than $RetentionDays days"
}

# Disconnect from the vCenter server
Disconnect-VIServer -Server $vCenter -Confirm:$false
Write-Host " Disconnected from vCenter: $vCenter"
Stop-Transcript
