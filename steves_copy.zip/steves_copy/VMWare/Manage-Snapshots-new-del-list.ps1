﻿<#
.SYNOPSIS
    VMware PowerCLI Snapshot Manager
    This script automates snapshot management for VMs in a vCenter environment.
    It allows users to create, delete, list, and clean up old snapshots.

.DESCRIPTION
    The script connects to a specified vCenter Server and performs snapshot operations 
    on a list of VMs provided in `VMList.txt`. It supports:
    
    - Creating snapshots with user-defined names and descriptions.
    - Deleting specific snapshots or all snapshots for selected VMs.
    - Listing snapshots and exporting them to a CSV file.
    - Cleaning up old snapshots beyond a user-defined retention period.

    The script also logs all operations to `SnapshotManager.log` for audit tracking.

.PARAMETER vCenter
    Prompts the user for the vCenter Server name before executing any actions.

.PARAMETER VMList.txt
    A text file that contains the list of VMs (one per line) that the script will process.

.PARAMETER Logging
    Logs all operations to `SnapshotManager.log` to maintain records of actions performed.

.PARAMETER Cleanup
    If selected, the script will delete snapshots older than a user-specified number of days.

.OUTPUTS
    - A log file (`SnapshotManager.log`) containing a history of actions performed.
    - A CSV file (`Snapshots.csv`) listing all snapshots when using the "List" option.

.USAGE
    1. Ensure `VMList.txt` exists in the same directory and contains VM names (one per line).
    2. Run the script:
       .\SnapshotManager.ps1
      
    3. Enter the vCenter Server name.
    4. Confirm the VM list.
    5. Choose an action: Create, Delete, List, or Cleanup.
    6. Follow the on-screen prompts.

.NOTES
    - If `VMList.txt` does not exist, the script will create it and open Notepad for editing.
    - If no vCenter is entered, the script will exit to prevent accidental execution.
    - The script requires VMware PowerCLI to be installed and loaded.

.AUTHOR
    Created by Cap
    
#>

# Prompt user for vCenter Server
$vCenter = Read-Host "Enter your vCenter Server"
if ([string]::IsNullOrWhiteSpace($vCenter)) {
    Write-Host "`n No vCenter Server entered. Exiting script."
    exit
}

# Define file paths
$VMListFile = ".\VMList.txt"
$LogFile = ".\SnapshotManager.log"
$SnapshotCSV = ".\Snapshots.csv"

# Function to log actions
function Write-Log {
    param (
        [string]$Message
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp - $Message" | Out-File -Append -FilePath $LogFile
    Write-Host $Message
}

# Check if VM list file exists, else create and open it
if (-not (Test-Path $VMListFile)) {
    Write-Host "`n VM list file not found! Creating a new one...`n"
    Write-Output "Enter VM names (one per line), then save and close the file." | Out-File -FilePath $VMListFile
    notepad.exe $VMListFile
    Write-Host "`n Please add VM names to the file and restart the script.`n"
    exit
}

# Load VM list from the file
$VMList = Get-Content $VMListFile | Where-Object {$_ -ne ""}
if (-not $VMList) {
    Write-Host "`n No VMs found in VMList.txt. Please update the file and restart the script.`n"
    exit
}

# Display VM list and confirm before proceeding
Write-Host "`n The following VMs will be processed:"
$VMList | ForEach-Object { Write-Host " - $_" }

$confirmation = Read-Host "`n Is this correct? (Y/N)"
if ($confirmation.ToLower() -ne "y") {
    Write-Host "`n Please update `VMList.txt` and run the script again.`n"
    exit
}

# Prompt user for the action
$action = Read-Host "`n Choose an action: Create, Delete, List, Cleanup"

# Connect to vCenter
Connect-VIServer -Server $vCenter
Write-Log "Connected to vCenter: $vCenter"

# Function to clean up old snapshots beyond retention period
function Cleanup-OldSnapshots {
    param (
        [int]$RetentionDays
    )
    foreach ($vm in $VMList) {
        $snapshots = Get-Snapshot -VM $vm -ErrorAction SilentlyContinue
        if ($snapshots) {
            foreach ($snapshot in $snapshots) {
                if ($snapshot.Created -lt (Get-Date).AddDays(-$RetentionDays)) {
                    Remove-Snapshot -Snapshot $snapshot -Confirm:$false
                    Write-Log "Deleted old snapshot '$($snapshot.Name)' on VM: $vm (Older than $RetentionDays days)"
                }
            }
        }
    }
}

# Process each VM in the list
foreach ($vm in $VMList) {
    switch ($action.ToLower()) {
        "create" {
            $snapshotName = Read-Host "Enter snapshot name"
            $snapshotDescription = Read-Host "Enter snapshot description"

            Write-Host "Creating snapshot for $vm..."
            New-Snapshot -VM $vm -Name $snapshotName -Description $snapshotDescription -Quiesce:$true -Memory:$false
            Write-Log "Snapshot '$snapshotName' created for VM: $vm"
        }

        "delete" {
            $snapshotToDelete = Read-Host "Enter snapshot name to delete (or type 'all' to remove all snapshots)"
            
            if ($snapshotToDelete -eq "all") {
                Get-Snapshot -VM $vm | Remove-Snapshot -Confirm:$false
                Write-Log "All snapshots deleted for VM: $vm"
            } else {
                $snapshot = Get-Snapshot -VM $vm -Name $snapshotToDelete -ErrorAction SilentlyContinue
                if ($snapshot) {
                    Remove-Snapshot -Snapshot $snapshot -Confirm:$false
                    Write-Log "Snapshot '$snapshotToDelete' deleted for VM: $vm"
                } else {
                    Write-Log "Snapshot '$snapshotToDelete' not found on VM: $vm"
                }
            }
        }

        "list" {
            $snapshots = Get-Snapshot -VM $vm -ErrorAction SilentlyContinue
            if ($snapshots) {
                Write-Host "Snapshots for VM: $vm"
                $snapshots | Format-Table VM, Name, Created, SizeMB -AutoSize
                
                # Export snapshots to CSV
                $snapshots | Select-Object VM, Name, Created, SizeMB | Export-Csv -Path $SnapshotCSV -NoTypeInformation -Append
                Write-Log "Snapshot list exported to $SnapshotCSV"
            } else {
                Write-Host "No snapshots found for VM: $vm"
                Write-Log "No snapshots found for VM: $vm"
            }
        }

        "cleanup" {
            $autoCleanup = Read-Host "`nDo you want to automatically delete old snapshots? (Y/N)"
            if ($autoCleanup.ToLower() -eq "y") {
                $RetentionDays = Read-Host "Enter the number of days after which snapshots should be deleted"
                if ($RetentionDays -match "^\d+$") {
                    Write-Host "`n Deleting snapshots older than $RetentionDays days..."
                    Cleanup-OldSnapshots -RetentionDays $RetentionDays
                    Write-Log "Auto-cleanup completed: Deleted snapshots older than $RetentionDays days."
                } else {
                    Write-Host "`n Invalid input. Please enter a valid number of days."
                }
            } else {
                Write-Host "`nSkipping auto-cleanup. No snapshots will be deleted."
                Write-Log "User chose not to auto-clean old snapshots."
            }
        }

        default {
            Write-Host "Invalid action selected. Please choose Create, Delete, List, or Cleanup."
            Write-Log "Invalid action selected by user."
        }
    }
}

# Disconnect from vCenter
Disconnect-VIServer -Server $vCenter -Confirm:$false
Write-Log "Disconnected from vCenter: $vCenter"
