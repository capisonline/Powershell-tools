﻿<#
.SYNOPSIS
    VMware Snapshot Manager with Logging for QCAD Disaster Recovery and Maintenance

.DESCRIPTION
    This PowerShell script automates VMware snapshot operations for virtual machines managed in a vCenter environment.
    It supports snapshot creation, deletion, listing, and cleanup, with full CLI logging and result tracking.
    This script is tailored for QCAD DR use cases where precise control, traceability, and minimal user error are critical.

    Key Features:
    - Connects to vCenter from a selectable list stored in a text file.
    - Uses predefined file paths for VM lists and snapshot definitions (hardcoded paths).
    - Deletes snapshots based on a prefilled CSV list.
    - Supports snapshot creation for rollback, listing for audit, and cleanup by retention.
    - Logs all activity and errors with timestamps.
    - Outputs deletion results to a separate CSV for verification/auditing.

.PARAMETERS
    This script uses hardcoded file paths:
      - VM List File:             C:\temp\QCAD\VT\VMWare\VMList.txt
      - vCenters File:           C:\temp\QCAD\VT\VMWare\vCenters.txt
      - Snapshot Deletion CSV:  C:\temp\QCAD\VT\VMWare\snapshot_deletion_csv.csv
      - Output Log:             C:\temp\QCAD\VT\VMWare\SnapshotManager.log

    The user is prompted to:
      - Select a vCenter to connect to
      - Enter vCenter credentials
      - Choose an action: create, delete, list, or cleanup

    Action Modes:
      - create:  Creates snapshots for each VM in the VM list.
      - delete:  Deletes snapshots listed in the snapshot deletion CSV (with confirmation).
      - list:    Exports current snapshot details for each VM to a timestamped CSV.
      - cleanup: Deletes snapshots older than a user-defined number of days.

.NOTES
    Author: Cap
    Requirements: PowerShell, VMware PowerCLI module, vSphere privileges to manage snapshots.
    Version: 1.1
    Use in QCAD DR Test/Production with change management approval.

.EXAMPLE
    Run the script in an elevated PowerShell session:
    PS> .\SnapshotManager.ps1

    Follow prompts to select vCenter, authenticate, and choose snapshot action.
#>

Import-Module VMware.PowerCLI -ErrorAction Stop
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

# --- Hardcoded Paths ---
$VMListFile = 'C:\temp\QCAD\VT\VMWare\VMList.txt'
$LogFile = 'C:\temp\QCAD\VT\VMWare\SnapshotManager.log'
$SnapshotCSV = 'C:\temp\QCAD\VT\VMWare\Snapshots.csv'
$SnapshotDeletionCSV = 'C:\temp\QCAD\VT\VMWare\snapshot_deletion_csv.csv'
$VCentersFile = 'C:\temp\QCAD\VT\VMWare\vCenters.txt'

# --- Logging Functions ---
function Log-Info($msg) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [INFO] $msg"
}
function Log-Error($msg) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [ERROR] $msg" -ForegroundColor Red
}

Start-Transcript -Path $LogFile -Append -Force | Out-Null

# --- Validate vCenters File ---
if (-not (Test-Path $VCentersFile)) {
    Log-Error "vCenters list file not found at $VCentersFile."
    Stop-Transcript
    exit 1
}
$VCenters = Get-Content $VCentersFile | Where-Object { $_ -ne "" }
if (-not $VCenters) {
    Log-Error "No vCenters listed in $VCentersFile."
    Stop-Transcript
    exit 1
}

# --- Select vCenter ---
Write-Host "`n Select a vCenter Server:"
for ($i = 0; $i -lt $VCenters.Count; $i++) {
    Write-Host " [$($i+1)] $($VCenters[$i])"
}
$selection = Read-Host "`n Enter the number of the vCenter to connect to"
if ($selection -match "^\d+$" -and [int]$selection -ge 1 -and [int]$selection -le $VCenters.Count) {
    $vCenter = $VCenters[[int]$selection - 1]
    Log-Info "Selected vCenter: $vCenter"
} else {
    Log-Error "Invalid selection. Exiting."
    Stop-Transcript
    exit 1
}

# --- Connect ---
$credential = Get-Credential
try {
    Connect-VIServer -Server $vCenter -Credential $credential -ErrorAction Stop
} catch {
    Log-Error "Connection failed: $_"
    Stop-Transcript
    exit 1
}

function Delete-SnapshotsFromCSV {
    if (-not (Test-Path $SnapshotDeletionCSV)) {
        Log-Error "Snapshot deletion CSV not found."
        return
    }

    $snapshotDeletions = Import-Csv -Path $SnapshotDeletionCSV
    if ($snapshotDeletions[0].PSObject.Properties.Name -notcontains 'VM_Name' -or
        $snapshotDeletions[0].PSObject.Properties.Name -notcontains 'Snapshot_ID') {
        Log-Error "CSV missing required columns 'VM_Name' and 'Snapshot_ID'."
        return
    }

    Write-Host "`nSnapshots listed for deletion:"
    $snapshotDeletions | ForEach-Object { Log-Info "VM: $($_.VM_Name), Snapshot ID: $($_.Snapshot_ID)" }

    $confirmation = Read-Host "`nConfirm deletion of these snapshots? (Y/N)"
    if ($confirmation.ToLower() -ne 'y') {
        Log-Info "User declined deletion."
        return
    }

    $results = @()
    foreach ($entry in $snapshotDeletions) {
        $vmName = $entry.VM_Name
        $snapshotID = $entry.Snapshot_ID
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            $snapshot = Get-Snapshot -VM $vm | Where-Object { $_.Id -eq $snapshotID }
            if ($snapshot) {
                try {
                    Remove-Snapshot -Snapshot $snapshot -Confirm:$false -ErrorAction Stop
                    Log-Info "Deleted snapshot ID '$snapshotID' from VM: $vmName"
                    $results += [PSCustomObject]@{ VMName = $vmName; SnapshotID = $snapshotID; Status = "Deleted" }
                } catch {
                    Log-Error "Failed to delete snapshot ID '$snapshotID' for VM: $vmName - $_"
                    $results += [PSCustomObject]@{ VMName = $vmName; SnapshotID = $snapshotID; Status = "Failed: $_" }
                }
            } else {
                Log-Error "Snapshot ID '$snapshotID' not found on $vmName."
            }
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }

    $results | Export-Csv -Path "$SnapshotDeletionCSV.results.csv" -NoTypeInformation
}

function Create-Snapshots {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            $snapshotName = "PrePatch_${vmName}_$(Get-Date -Format 'yyyyMMdd_HHmm')"
            try {
                New-Snapshot -VM $vm -Name $snapshotName -Description "PrePatch" -Quiesce:$false -Memory:$true -ErrorAction Stop
                Log-Info "Snapshot '$snapshotName' created for VM: $vmName"
            } catch {
                Log-Error "Failed to create snapshot for $vmName - $_"
            }
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function List-Snapshots {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
    $SnapshotCSVWithTimestamp = "C:\temp\QCAD\VT\VMWare\Snapshots_$timestamp.csv"
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            Get-Snapshot -VM $vm | Select-Object VM, Name, Created, PowerState, Description, Id |
                Export-Csv -Path $SnapshotCSVWithTimestamp -NoTypeInformation -Append
            Log-Info "Snapshot list exported for VM: $vmName"
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function Cleanup-Snapshots {
    $RetentionDays = Read-Host "Enter retention period (days)"
    $cutoff = (Get-Date).AddDays(-[int]$RetentionDays)
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            $oldSnaps = Get-Snapshot -VM $vm | Where-Object { $_.Created -lt $cutoff }
            foreach ($snap in $oldSnaps) {
                try {
                    Remove-Snapshot -Snapshot $snap -Confirm:$false -ErrorAction Stop
                    Log-Info "Deleted old snapshot '$($snap.Name)' for VM: $vmName"
                } catch {
                    Log-Error "Failed to delete old snapshot '$($snap.Name)' - $_"
                }
            }
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

# --- Main Menu Loop ---
do {
    $action = Read-Host "Enter the action to perform (create, delete, list, cleanup, quit)"
    switch ($action.ToLower()) {
        'delete'  { Delete-SnapshotsFromCSV }
        'create'  { Create-Snapshots }
        'list'    { List-Snapshots }
        'cleanup' { Cleanup-Snapshots }
        'quit'    { Log-Info "Exiting script on user request." }
        default   { Log-Error "Invalid action. Try again." }
    }
} while ($action.ToLower() -ne 'quit')

# --- Disconnect and End ---
Disconnect-VIServer -Server $vCenter -Confirm:$false
Log-Info "Disconnected from vCenter: $vCenter"
Stop-Transcript
