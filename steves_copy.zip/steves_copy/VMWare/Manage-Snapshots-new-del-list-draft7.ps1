﻿<#
.SYNOPSIS
    VMware PowerCLI Snapshot Manager with Full CLI Logging
    This script automates snapshot management for VMs in a vCenter environment.

.DESCRIPTION
    This script manages VMware virtual machine (VM) snapshots in a vCenter environment. 
    It allows users to perform snapshot operations such as creating, deleting, listing, and cleaning up snapshots. 
    Additionally, the script captures all output (standard and error logs) into a log file for easy auditing. 

.OUTPUTS
    - A log file (`SnapshotManager.log`) that captures both stdout & stderr.
    - A CSV file (`Snapshots.csv`) listing all snapshots when using the "List" option.

.NOTES
    - Requires VMware PowerCLI to be installed.
    - The script uses `vCenters.txt` to store a list of vCenter servers and attempts to connect to one based on user input.
    - If `VMList.txt` is missing, the script creates the file and prompts the user to edit it.

.AUTHOR
    Created by Cap
#>

Import-Module VMware.PowerCLI -ErrorAction Stop
# Disable VMware customer improvement (No telemetry data is sent to vmware and stops the annoying questions from vmware)
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null

# Define file paths for required resources
$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$VMListFile = "$ScriptDirectory\VMList.txt"
$LogFile = "$ScriptDirectory\SnapshotManager.log"
$SnapshotCSV = "$ScriptDirectory\Snapshots.csv"
$VCentersFile = "$ScriptDirectory\vCenters.txt"

# Ensure vCenters.txt exists and prompt the user to input data if it doesn't
if (-not (Test-Path $VCentersFile)) {
    Write-Host "`nvCenters list file not found! Creating a new one in $ScriptDirectory..."
    "Enter one vCenter per line, then save and close the file." | Out-File -FilePath $VCentersFile -Encoding UTF8
    notepad.exe $VCentersFile
    Write-Host "`n Please add vCenters to the file and restart the script."
    exit
}

# Load vCenter list and check if it's not empty
$VCenters = Get-Content $VCentersFile | Where-Object {$_ -ne ""}
if (-not $VCenters) {
    Write-Host "`n No vCenters found in vCenters.txt. Please update the file and restart the script."
    exit
}

# Display vCenter options to the user for selection
Write-Host "`n Select a vCenter Server:"
for ($i = 0; $i -lt $VCenters.Count; $i++) {
    Write-Host " [$($i+1)] $($VCenters[$i])"
}

# Prompt the user to select a vCenter
$selection = Read-Host "`n Enter the number of the vCenter to connect to"
if ($selection -match "^\d+$" -and [int]$selection -ge 1 -and [int]$selection -le $VCenters.Count) {
    $vCenter = $VCenters[[int]$selection - 1]
    Write-Host "`n Selected vCenter: $vCenter"
} else {
    Write-Host "`n Invalid selection. Exiting script."
    exit
}

# Prompt for username and password upfront
$vCenterUsername = Read-Host "Enter your vCenter username"
$vCenterPassword = Read-Host "Enter your vCenter password" -AsSecureString

# Accept Invalid SSL Certificates without user intervention
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

# Start logging all CLI output (stdout & stderr)
Start-Transcript -Path $LogFile -Append -Force | Out-Null

# Ensure VM list file exists and prompt the user to input VM names if it doesn't
if (-not (Test-Path $VMListFile)) {
    Write-Host "`nVM list file not found! Creating a new one in $ScriptDirectory..."
    "Enter VM names (one per line), then save and close the file." | Out-File -FilePath $VMListFile -Encoding UTF8
    notepad.exe $VMListFile
    Write-Host "`nPlease add VM names to the file and restart the script."
    Stop-Transcript
    exit
}

# Load VM list from the file and check for empty entries
$VMList = Get-Content $VMListFile | Where-Object {$_ -ne ""}
if (-not $VMList) {
    Write-Host "`n No VMs found in VMList.txt. Please update the file and restart the script."
    Stop-Transcript
    exit
}

# Display the list of VMs that will be processed
Write-Host "`n The following VMs will be processed:"
$VMList | ForEach-Object { Write-Host " - $_" }

# Prompt for confirmation before proceeding
$confirmation = Read-Host "`nIs this correct? (Y/N)"
if ($confirmation.ToLower() -ne "y") {
    Write-Host "`n User declined VM list. Exiting script."
    Stop-Transcript
    exit
}

# Prompt the user to select an action (Create, Delete, List, Cleanup)
$action = Read-Host "`n Choose an action: Create, Delete, List, Cleanup"

# Connect to the selected vCenter server using provided credentials
$connection = $null
try {
    $connection = Connect-VIServer -Server $vCenter -User $vCenterUsername -Password $vCenterPassword -ErrorAction Stop
    Write-Host "`n Connected to vCenter: $vCenter"
} catch {
    Write-Host "`n Failed to connect to vCenter: $vCenter. $_"
    Stop-Transcript
    exit
}

# Function to clean up old snapshots older than a specified number of days
function Cleanup-OldSnapshots {
    param ([int]$RetentionDays)
    foreach ($vm in $VMList) {
        $snapshots = Get-Snapshot -VM $vm -ErrorAction SilentlyContinue
        if ($snapshots) {
            foreach ($snapshot in $snapshots) {
                if ($snapshot.Created -lt (Get-Date).AddDays(-$RetentionDays)) {
                    try {
                        Remove-Snapshot -Snapshot $snapshot -Confirm:$false
                        Write-Host " Deleted old snapshot '$($snapshot.Name)' on VM: $vm (Older than $RetentionDays days)"
                    } catch {
                        Write-Host " Failed to delete old snapshot '$($snapshot.Name)' on VM: $vm. $_"
                    }
                }
            }
        }
    }
}

# Process each VM based on the selected action
foreach ($vm in $VMList) {
    try {
        switch ($action.ToLower()) {
            "create" {
                $snapshotName = Read-Host "Enter snapshot name"
                $snapshotDescription = Read-Host "Enter snapshot description"
                Write-Host " Creating snapshot for $vm..."
                $snapshot = New-Snapshot -VM $vm -Name $snapshotName -Description $snapshotDescription -Quiesce:$false -Memory:$true -ErrorAction Stop
                Write-Host " Snapshot '$snapshotName' created for VM: $vm"
            }

            "delete" {
                $snapshotInput = Read-Host "Enter snapshot ID(s) to delete (comma-separated) or type 'all' to remove all snapshots"
                if ($snapshotInput -eq "all") {
                    Get-Snapshot -VM $vm | Remove-Snapshot -Confirm:$false
                    Write-Host "All snapshots deleted for VM: $vm"
                } else {
                    $snapshotIDs = $snapshotInput -split "," | ForEach-Object { $_.Trim() }
                    foreach ($snapshotID in $snapshotIDs) {
                        $snapshot = Get-Snapshot -VM $vm | Where-Object { $_.Id -eq $snapshotID }
                        if ($snapshot) {
                            Remove-Snapshot -Snapshot $snapshot -Confirm:$false
                            Write-Host " Snapshot '$snapshotID' deleted for VM: $vm"
                        } else {
                            Write-Host "Snapshot ID '$snapshotID' not found on VM: $vm"
                        }
                    }
                }
            }

            "list" {
                Get-Snapshot -VM $vm | Export-Csv -Path $SnapshotCSV -NoTypeInformation -Append
                Write-Host " Snapshot list for VM: $vm exported to $SnapshotCSV"
            }

            "cleanup" {
                $RetentionDays = Read-Host "Enter retention period (days)"
                Cleanup-OldSnapshots -RetentionDays $RetentionDays
                Write-Host " Deleted snapshots older than $RetentionDays days"
            }
        }
    } catch {
        Write-Host " Error processing VM ${vm}: $_"
    }
}

# Disconnect from the vCenter server
Disconnect-VIServer -Server $vCenter -Confirm:$false
Write-Host " Disconnected from vCenter: $vCenter"
Stop-Transcript
