<#
.SYNOPSIS
    Hypervisor Control & Snapshot Manager (VMware PowerCLI) (made for QCAD - designed for flexibility & expansion)

.DESCRIPTION
    This PowerShell script provides hypervisor-level orchestration for QCAD virtual machines
    using VMware PowerCLI. It supports controlled recovery operations, patch rollback via
    snapshots, and guest-level service management.

    Designed for both planned maintenance (e.g. patching) and break-glass disaster recovery
    scenarios, the script offers safe, traceable, and repeatable automation of the QCAD
    virtual infrastructure through vCenter.

    Key Functions:
    - Interactively connect to one or more vCenters (Simply select 1,2 or 3,5 etc etc)
    - Create, list, delete, or clean up snapshots for rollback and auditing
    - Start, stop, or force shutdown VMs in a controlled sequence
    - Toggle NIC "connect at power on" for full control over Windows OS
    - Disable services inside guest OS 
    - Log all events, actions, and errors with timestamps
    - Export snapshot deletion results for audit review
    
    Supports recovery workflows during:
        - DR failover between datacentres
        - Controlled patching cycles with pre/post snapshot
        - Emergency recovery of QCAD EGL or POL environments

.PARAMETERS
    The script uses the following hardcoded paths and inputs:
      - VM List File: C:\temp\QCAD\VT\VMWare\VMList.txt << Master list of VMs to manage (power on/off, snapshot, etc.)
      - vCenters File: C:\temp\QCAD\VT\VMWare\vCenters.txt << List of available vCenters — user selects one or many interactively.
      - Snapshot Deletion CSV: C:\temp\QCAD\VT\VMWare\snapshot_deletion_csv.csv << Used to delete snapshots — created using 'snapshot-list'. Must include `Snapshot_ID`.
      - Snapshot List Output (generated): C:\temp\QCAD\VT\VMWare\Snapshots_YYYY-MM-DD_HH-MM.csv << Created using the 'snapshot-list' action. Includes snapshot UUIDs.
      - Output Log: C:\temp\QCAD\VT\VMWare\VMWare_PowerCLI_Automation.log << Full command-line transcript and error output for audit/review.
      - Service Management CSV: C:\temp\QCAD\VT\VMWare\services_to_disable.csv << Used by `disable-services` action to stop services inside guest VMs before recovery - 1 service / line.
                VMName	ServiceName
                EGLVCADAPLVT01	VisVT_APLParser
                EGLVCADAPLVT01	VisVT_AVLUpdater


    Prompts:
    - Select one or more vCenters
    - Authenticate to vCenter
    - Choose an action from the main menu

    Available Action Modes:
      - snapshot-create         : Create rollback snapshots for each VM
      - snapshot-list           : Export list of active snapshots with UUIDs
      - snapshot-delete         : Remove snapshots listed in snapshot_deletion_csv.csv
      - snapshot-cleanup        : Delete snapshots older than specified retention days
      - disable / enable-nic    : Toggle NIC "Connect at power on"
      - start-vms               : Power on all VMs in list
      - stop / force-stop-vms   : Graceful or forced shutdown of all VMs
      - disable-services        : Disable in-guest services listed in CSV
      - vm-powerstate           : Report VM state and host location

.NOTES
    Author: Cap
    Requirements: 
      - PowerShell 5.x or higher
      - VMware PowerCLI module installed
      - vCenter access with VM and snapshot privileges
      - Guest credentials for in-VM service control (stored securely in Passwordstate)

    Version: 1.3
    Usage: QCAD DR Test/Production environments under approved change control
    Notes:
      - Designed for break-glass emergency failover and patching rollback use
      - Intended to replace manual recovery sequencing with hypervisor-level scripting

.EXAMPLE
    Run from elevated PowerShell session:
    Follow prompts to connect to vCenter, choose recovery or maintenance task, and execute.

.FUTURE_ENHANCEMENTS
    Reduce overweight synopsis
    Join gym
    GUIfy it
    Add more functionality 
    
#>


# --- Load PowerCLI Module Safely ---
if (-not (Get-Module -ListAvailable -Name VMware.PowerCLI)) {
    Write-Host "VMware PowerCLI module not found. Please install it first." -ForegroundColor Red
    exit 1
}

if (-not (Get-Module -Name VMware.PowerCLI)) {
    Import-Module VMware.PowerCLI -ErrorAction Stop
}

# --- Apply PowerCLI Settings Once Per Session ---
if (-not $Global:PowerCLIConfigured) {
    Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
    $Global:PowerCLIConfigured = $true
}
# --- Display ASCII Shield Banner ---
$capShield = @'
<YOUR ASCII SHIELD HERE>
'@

Write-Host $capShield -ForegroundColor Red

# --- Hardcoded Paths ---
$VMListFile = 'C:\temp\QCAD\VT\VMWare\VMList.txt'
$LogFile = 'C:\temp\QCAD\VT\VMWare\VMWare_PowerCLI_Automation.log'
$SnapshotCSV = 'C:\temp\QCAD\VT\VMWare\Snapshots.csv'
$SnapshotDeletionCSV = 'C:\temp\QCAD\VT\VMWare\snapshot_deletion_csv.csv'
$VCentersFile = 'C:\temp\QCAD\VT\VMWare\vCenters.txt'
$ServiceListCSV = 'C:\temp\QCAD\VT\VMWare\services_to_disable.csv'

# --- Logging Functions ---
function Log-Info($msg) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [INFO] $msg"
}
function Log-Error($msg) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [ERROR] $msg" -ForegroundColor Red
}

Start-Transcript -Path $LogFile -Append -Force | Out-Null

# --- Validate vCenters File ---
if (-not (Test-Path $VCentersFile)) {
    Log-Error "vCenters list file not found at $VCentersFile."
    Stop-Transcript
    exit 1
}
$VCenters = Get-Content $VCentersFile | Where-Object { $_ -ne "" }
if (-not $VCenters) {
    Log-Error "No vCenters listed in $VCentersFile."
    Stop-Transcript
    exit 1
}

# --- Select One or More vCenters ---
Write-Host "`n Select one or more vCenter Servers (comma-separated):"
for ($i = 0; $i -lt $VCenters.Count; $i++) {
    Write-Host " [$($i+1)] $($VCenters[$i])"
}

$selection = Read-Host "`n Enter the number(s) of the vCenters to connect to (e.g., 1,2)"
$indices = $selection -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' }

if ($indices.Count -eq 0 -or ($indices | Where-Object { [int]$_ -lt 1 -or [int]$_ -gt $VCenters.Count })) {
    Log-Error "Invalid selection. Exiting."
    Stop-Transcript
    exit 1
}

# Set PowerCLI to allow multi-vCenter mode
Set-PowerCLIConfiguration -DefaultVIServerMode Multiple -Confirm:$false | Out-Null

# Connect to each selected vCenter
$connectedVCs = @()
$credential = Get-Credential
foreach ($index in $indices) {
    $vc = $VCenters[[int]$index - 1]
    try {
        Connect-VIServer -Server $vc -Credential $credential -ErrorAction Stop | Out-Null
        $connectedVCs += $vc
        Log-Info "Connected to vCenter: $vc"
    } catch {
        Log-Error "Failed to connect to vCenter $vc - $_"
    }
}

if ($connectedVCs.Count -eq 0) {
    Log-Error "No vCenters connected successfully. Exiting."
    Stop-Transcript
    exit 1
}

function Delete-SnapshotsFromCSV {
    if (-not (Test-Path $SnapshotDeletionCSV)) {
        Log-Error "Snapshot deletion CSV not found."
        return
    }
    $snapshotDeletions = Import-Csv -Path $SnapshotDeletionCSV
    if ($snapshotDeletions[0].PSObject.Properties.Name -notcontains 'VM_Name' -or
        $snapshotDeletions[0].PSObject.Properties.Name -notcontains 'Snapshot_ID') {
        Log-Error "CSV missing required columns 'VM_Name' and 'Snapshot_ID'."
        return
    }
    Write-Host "`nSnapshots listed for deletion:"
    $snapshotDeletions | ForEach-Object { Log-Info "VM: $($_.VM_Name), Snapshot ID: $($_.Snapshot_ID)" }
    $confirmation = Read-Host "`nConfirm deletion of these snapshots? (Y/N)"
    if ($confirmation.ToLower() -ne 'y') {
        Log-Info "User declined deletion."
        return
    }
    $results = @()
    foreach ($entry in $snapshotDeletions) {
        $vmName = $entry.VM_Name
        $snapshotID = $entry.Snapshot_ID
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            $snapshot = Get-Snapshot -VM $vm | Where-Object { $_.Id -eq $snapshotID }
            if ($snapshot) {
                try {
                    Remove-Snapshot -Snapshot $snapshot -Confirm:$false -ErrorAction Stop
                    Log-Info "Deleted snapshot ID '$snapshotID' from VM: $vmName"
                    $results += [PSCustomObject]@{ VMName = $vmName; SnapshotID = $snapshotID; Status = "Deleted" }
                } catch {
                    Log-Error "Failed to delete snapshot ID '$snapshotID' for VM: $vmName - $_"
                    $results += [PSCustomObject]@{ VMName = $vmName; SnapshotID = $snapshotID; Status = "Failed: $_" }
                }
            } else {
                Log-Error "Snapshot ID '$snapshotID' not found on $vmName."
            }
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
    $results | Export-Csv -Path "$SnapshotDeletionCSV.results.csv" -NoTypeInformation
}

function Create-Snapshots {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            $snapshotName = "PrePatch_${vmName}_$(Get-Date -Format 'yyyyMMdd_HHmm')"
            try {
                New-Snapshot -VM $vm -Name $snapshotName -Description "PrePatch" -Quiesce:$false -Memory:$true -ErrorAction Stop
                Log-Info "Snapshot '$snapshotName' created for VM: $vmName"
            } catch {
                Log-Error "Failed to create snapshot for $vmName - $_"
            }
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function List-Snapshots {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
    $SnapshotCSVWithTimestamp = "C:\temp\QCAD\VT\VMWare\Snapshots_$timestamp.csv"
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            Get-Snapshot -VM $vm | Select-Object VM, Name, Created, PowerState, Description, Id |
                Export-Csv -Path $SnapshotCSVWithTimestamp -NoTypeInformation -Append
            Log-Info "Snapshot list exported for VM: $vmName"
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function Cleanup-Snapshots {
    $RetentionDays = Read-Host "Enter retention period (days)"
    $cutoff = (Get-Date).AddDays(-[int]$RetentionDays)
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            $oldSnaps = Get-Snapshot -VM $vm | Where-Object { $_.Created -lt $cutoff }
            foreach ($snap in $oldSnaps) {
                try {
                    Remove-Snapshot -Snapshot $snap -Confirm:$false -ErrorAction Stop
                    Log-Info "Deleted old snapshot '$($snap.Name)' for VM: $vmName"
                } catch {
                    Log-Error "Failed to delete old snapshot '$($snap.Name)' - $_"
                }
            }
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function Disable-NICStartup {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            Get-NetworkAdapter -VM $vm | ForEach-Object {
                Set-NetworkAdapter -NetworkAdapter $_ -StartConnected:$false -Confirm:$false
                Log-Info "Disabled 'connect at power on' for NIC on $vmName"
            }
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function Start-VMList {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            Start-VM -VM $vm -Confirm:$false
            Log-Info "Powered on $vmName"
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function Disable-ServicesInGuest {
    if (-not (Test-Path $ServiceListCSV)) {
        Log-Error "Service list CSV not found."
        return
    }
    $entries = Import-Csv -Path $ServiceListCSV
    $guestCred = Get-Credential
    foreach ($entry in $entries) {
        $vm = Get-VM -Name $entry.VMName -ErrorAction SilentlyContinue
        if ($vm) {
            $script = "Stop-Service -Name '$($entry.ServiceName)' -Force -ErrorAction SilentlyContinue; Set-Service -Name '$($entry.ServiceName)' -StartupType Disabled"
            try {
                Invoke-VMScript -VM $vm -ScriptText $script -ScriptType PowerShell -GuestCredential $guestCred -ErrorAction Stop
                Log-Info "Disabled service '$($entry.ServiceName)' on $($entry.VMName)"
            } catch {
                Log-Error "Failed to disable service '$($entry.ServiceName)' on $($entry.VMName) - $_"
            }
        } else {
            Log-Error "VM '$($entry.VMName)' not found."
        }
    }
}

function Enable-NICStartup {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            Get-NetworkAdapter -VM $vm | ForEach-Object {
                Set-NetworkAdapter -NetworkAdapter $_ -StartConnected:$true -Confirm:$false
                Log-Info "Enabled 'connect at power on' for NIC on $vmName"
            }
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function Stop-VMListGracefully {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            Shutdown-VMGuest -VM $vm -Confirm:$false -ErrorAction SilentlyContinue
            Log-Info "Sent shutdown request to $vmName"
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function Stop-VMListForce {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            Stop-VM -VM $vm -Kill -Confirm:$false
            Log-Info "Force powered off $vmName"
        } else {
            Log-Error "VM '$vmName' not found."
        }
    }
}

function Report-VMStates {
    $VMList = Get-Content $VMListFile | Where-Object { $_ -ne "" }
    $report = foreach ($vmName in $VMList) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            [PSCustomObject]@{
                VMName     = $vm.Name
                PowerState = $vm.PowerState
                Host       = $vm.VMHost.Name
            }
        }
    }
    $report | Format-Table -AutoSize
}


<#
# --- TEMPLATE FUNCTION SECTION ---

Copy paste to add new functions.... don't forget to include it down in the main loop and the write host section to declare it

function Custom-FunctionName {
    Log-Info "[Template] Starting Custom Function..."
    # Example: Retrieve a VM
    # $vm = Get-VM -Name "MyVM"
    # Perform your logic here
    Log-Info "[Template] Completed Custom Function."
}

# To enable this in the menu below, add:
# 'custom-function' { Custom-FunctionName }
# And update the prompt:
# Write-Host "..., custom-function, quit"
#>

# --- Main Menu Loop ---
do {
    Write-Host "`nSelect action: snapshot-create, snapshot-delete, snapshot-list, snapshot-cleanup, disable-nic, enable-nic, start-vms, stop-vms, force-stop-vms, disable-services, check-tools, vm-powerstate, quit"
    $action = Read-Host "Enter your choice"
    switch ($action.ToLower()) {
        'snapshot-delete'    { Delete-SnapshotsFromCSV }
        'snapshot-create'    { Create-Snapshots }
        'snapshot-list'      { List-Snapshots }
        'snapshot-cleanup'   { Cleanup-Snapshots }
        'disable-nic'        { Disable-NICStartup }
        'enable-nic'         { Enable-NICStartup }
        'start-vms'          { Start-VMList }
        'stop-vms'           { Stop-VMListGracefully }
        'force-stop-vms'     { Stop-VMListForce }
        'disable-services'   { Disable-ServicesInGuest }
        'check-tools'        { Check-ToolsStatus }
        'vm-powerstate'      { Report-VMStates }
        # 'custom-function' { Custom-FunctionName }
        'quit'               { Log-Info "Exiting script on user request." }
        default              { Log-Error "Invalid action. Try again." }
    }
} while ($action.ToLower() -ne 'quit')

Disconnect-VIServer -Server * -Confirm:$false
Log-Info "Disconnected from all vCenters"
Stop-Transcript