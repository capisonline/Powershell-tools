Import-Module vcf.PowerCLI -ErrorAction Stop
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
$vm = Get-VM -Name "POLVCADVASVT04"
$guestUsername = "prds.qldpol\907429a"
$guestPassword = "@llFvck3d1!"  # use Get-Credential for production

$scriptText = 'Stop-Service -Name "VisVT_Arbitrator" -Force'

Invoke-VMScript -VM $vm `
    -ScriptText $scriptText `
    -GuestUser $guestUsername `
    -GuestPassword $guestPassword `
    -ScriptType Powershell
