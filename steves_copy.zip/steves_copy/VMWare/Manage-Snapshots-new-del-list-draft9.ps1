﻿<#
.SYNOPSIS
    VMware PowerCLI Snapshot Manager with Full CLI Logging
    This script automates snapshot management for VMs in a vCenter environment.

.DESCRIPTION
    This script manages VMware virtual machine (VM) snapshots in a vCenter environment. 
    It allows users to perform snapshot operations such as creating, deleting, listing, and cleaning up snapshots. 
    Additionally, the script captures all output (standard and error logs) into a log file for easy auditing. 

.OUTPUTS
    - A log file (`SnapshotManager.log`) that captures both stdout & stderr.
    - A CSV file (`Snapshots.csv`) listing all snapshots when using the "List" option.

.NOTES
    - Requires VMware PowerCLI to be installed.
    - The script uses `vCenters.txt` to store a list of vCenter servers and attempts to connect to one based on user input.
    - If `VMList.txt` is missing, the script creates the file and prompts the user to edit it.

.AUTHOR
    Created by Cap
#>

Import-Module VMware.PowerCLI -ErrorAction Stop
# Disable VMware customer improvement (No telemetry data is sent to VMware and stops the annoying questions from VMware)
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null

# Define file paths for required resources
$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$VMListFile = "$ScriptDirectory\VMList.txt"
$LogFile = "$ScriptDirectory\SnapshotManager.log"
$SnapshotCSV = "$ScriptDirectory\Snapshots.csv"
$VCentersFile = "$ScriptDirectory\vCenters.txt"

# Ensure vCenters.txt exists and prompt the user to input data if it doesn't
if (-not (Test-Path $VCentersFile)) {
    Write-Host "`nvCenters list file not found! Creating a new one in $ScriptDirectory..."
    "Enter one vCenter per line, then save and close the file." | Out-File -FilePath $VCentersFile -Encoding UTF8
    notepad.exe $VCentersFile
    Write-Host "`n Please add vCenters to the file and restart the script."
    exit
}

# Load vCenter list and check if it's not empty
$VCenters = Get-Content $VCentersFile | Where-Object {$_ -ne ""}
if (-not $VCenters) {
    Write-Host "`n No vCenters found in vCenters.txt. Please update the file and restart the script."
    exit
}

# Display vCenter options to the user for selection
Write-Host "`n Select a vCenter Server:"
for ($i = 0; $i -lt $VCenters.Count; $i++) {
    Write-Host " [$($i+1)] $($VCenters[$i])"
}

# Prompt the user to select a vCenter
$selection = Read-Host "`n Enter the number of the vCenter to connect to"
if ($selection -match "^\d+$" -and [int]$selection -ge 1 -and [int]$selection -le $VCenters.Count) {
    $vCenter = $VCenters[[int]$selection - 1]
    Write-Host "`n Selected vCenter: $vCenter"
} else {
    Write-Host "`n Invalid selection. Exiting script."
    exit
}

# Prompt for username and password upfront using Get-Credential
$credential = Get-Credential

# Accept Invalid SSL Certificates without user intervention
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

# Start logging all CLI output (stdout & stderr)
Start-Transcript -Path $LogFile -Append -Force | Out-Null

# Ensure VM list file exists and prompt the user to input VM names if it doesn't
if (-not (Test-Path $VMListFile)) {
    Write-Host "`nVM list file not found! Creating a new one in $ScriptDirectory..."
    "Enter VM names (one per line), then save and close the file." | Out-File -FilePath $VMListFile -Encoding UTF8
    notepad.exe $VMListFile
    Write-Host "`nPlease add VM names to the file and restart the script."
    Stop-Transcript
    exit
}

# Load VM list from the file and check for empty entries
$VMList = Get-Content $VMListFile | Where-Object {$_ -ne ""}
if (-not $VMList) {
    Write-Host "`n No VMs found in VMList.txt. Please update the file and restart the script."
    Stop-Transcript
    exit
}

# Display the list of VMs that will be processed
Write-Host "`n The following VMs will be processed:"
$VMList | ForEach-Object { Write-Host " - $_" }

# Prompt for confirmation before proceeding
$confirmation = Read-Host "`nIs this correct? (Y/N)"
if ($confirmation.ToLower() -ne "y") {
    Write-Host "`n User declined VM list. Exiting script."
    Stop-Transcript
    exit
}

# Connect to the selected vCenter server using provided credentials
$connection = $null
try {
    $connection = Connect-VIServer -Server $vCenter -User $credential.UserName -Password $credential.GetNetworkCredential().Password -ErrorAction Stop
    Write-Host "`n Connected to vCenter: $vCenter"
} catch {
    Write-Host "`n Failed to connect to vCenter: $vCenter. $_"
    Stop-Transcript
    exit
}

# Prompt the user for the action they want to perform
# if you spell it incorrectly it will stop
$action = Read-Host "Enter the action to perform (create, delete, list, cleanup)"
if ($action -notin @("create", "delete", "list", "cleanup")) {
    Write-Host "Invalid action entered. Exiting script."
    Stop-Transcript
    exit
}

# Function to clean up old snapshots older than a specified number of days
function Cleanup-OldSnapshots {
    param ([int]$RetentionDays)
    foreach ($vm in $VMList) {
        $snapshots = Get-Snapshot -VM $vm -ErrorAction SilentlyContinue
        if ($snapshots) {
            foreach ($snapshot in $snapshots) {
                if ($snapshot.Created -lt (Get-Date).AddDays(-$RetentionDays)) {
                    try {
                        Remove-Snapshot -Snapshot $snapshot -Confirm:$false
                        Write-Host " Deleted old snapshot '$($snapshot.Name)' on VM: $vm (Older than $RetentionDays days)"
                    } catch {
                        Write-Host " Failed to delete old snapshot '$($snapshot.Name)' on VM: $vm. $_"
                    }
                }
            }
        }
    }
}

# Process each VM based on the selected action
foreach ($vm in $VMList) {
    try {
        switch ($action.ToLower()) {
            "create" {
                $snapshotName = Read-Host "Enter snapshot name"
                $snapshotDescription = Read-Host "Enter snapshot description"
                Write-Host " Creating snapshot for $vm..."
                $snapshot = New-Snapshot -VM $vm -Name $snapshotName -Description $snapshotDescription -Quiesce:$false -Memory:$true -ErrorAction Stop
                Write-Host " Snapshot '$snapshotName' created for VM: $vm"
            }

                "delete" {
                    # Enter snapshot IDs (comma-separated) only once
                    $snapshotInput = Read-Host "Enter snapshot ID(s) to delete (comma-separated)"
                    $snapshotIDs = $snapshotInput -split "," | ForEach-Object { $_.Trim() }

                    # Loop through each snapshot ID entered
                    foreach ($snapshotID in $snapshotIDs) {
                        $snapshotDeleted = $false

                        # Loop through each VM in the VM list
                        foreach ($vm in $VMList) {
                            Write-Host "Checking snapshots for VM: $vm"

                            # Get all snapshots for the current VM
                            $snapshots = Get-Snapshot -VM $vm -ErrorAction SilentlyContinue

                            # Find the snapshot by ID for this VM
                            $snapshot = $snapshots | Where-Object { $_.Name -eq $snapshotID }

                            if ($snapshot) {
                                # If the snapshot exists, delete it without confirmation
                                try {
                                    Remove-Snapshot -Snapshot $snapshot -Confirm:$false -ErrorAction Stop
                                    Write-Host "Snapshot '$snapshotID' deleted for VM: $vm"
                                    $snapshotDeleted = $true
                                } catch {
                                    Write-Host "Failed to delete snapshot '$snapshotID' for VM: $vm. $_"
                                }
                            }
                        }

                        if (-not $snapshotDeleted) {
                            # If no snapshot is found for the provided ID across all VMs
                            Write-Host "Snapshot ID '$snapshotID' not found on any VM."
                        }
                    }
                }




            "list" {
                # Generate timestamp in the format 'yyyy-MM-dd_HH-mm'
                $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"

                # Create a CSV filename with the timestamp
                $SnapshotCSVWithTimestamp = "$ScriptDirectory\Snapshots_$timestamp.csv"

                # Export snapshots with the new filename
                Get-Snapshot -VM $vm | 
                Select-Object VM, Name, Created, PowerState, Description, Id | 
                Export-Csv -Path $SnapshotCSVWithTimestamp -NoTypeInformation -Append
                Write-Host " Snapshot list for VM: $vm exported to $SnapshotCSVWithTimestamp"
            }

            "cleanup" {
                $RetentionDays = Read-Host "Enter retention period (days)"
                Cleanup-OldSnapshots -RetentionDays $RetentionDays
                Write-Host " Deleted snapshots older than $RetentionDays days"
            }
        }
    } catch {
        Write-Host " Error processing VM ${vm}: $_"
    }
}

# Disconnect from the vCenter server
Disconnect-VIServer -Server $vCenter -Confirm:$false
Write-Host " Disconnected from vCenter: $vCenter"
Stop-Transcript
