﻿Add-Type -AssemblyName System.Windows.Forms

# Create Form
$form = New-Object System.Windows.Forms.Form
$form.Text = "QCAD Hypervisor Control Panel"
$form.Size = New-Object System.Drawing.Size(480,300)
$form.StartPosition = "CenterScreen"

# Dropdown for Actions
$comboBox = New-Object System.Windows.Forms.ComboBox
$comboBox.Width = 400
$comboBox.Location = New-Object System.Drawing.Point(30,40)
$comboBox.DropDownStyle = 'DropDownList'
$comboBox.Items.AddRange(@(
    "snapshot-create",
    "snapshot-delete",
    "snapshot-list",
    "snapshot-cleanup",
    "disable-nic",
    "enable-nic",
    "start-vms",
    "stop-vms",
    "force-stop-vms",
    "disable-services",
    "vm-powerstate"
))
$form.Controls.Add($comboBox)

# Run Button
$runButton = New-Object System.Windows.Forms.Button
$runButton.Location = New-Object System.Drawing.Point(180, 100)
$runButton.Size = New-Object System.Drawing.Size(100,40)
$runButton.Text = "Run"
$runButton.Add_Click({
    $selectedAction = $comboBox.SelectedItem
    if (-not $selectedAction) {
        [System.Windows.Forms.MessageBox]::Show("Please select an action.","Validation Error")
        return
    }

    $confirmation = [System.Windows.Forms.MessageBox]::Show("Are you sure you want to run: $selectedAction?","Confirm Action",[System.Windows.Forms.MessageBoxButtons]::YesNo)
    if ($confirmation -eq "Yes") {
        # You can route to your functions here like:
        switch ($selectedAction) {
            "snapshot-create"    { Create-Snapshots }
            "snapshot-delete"    { Delete-SnapshotsFromCSV }
            "snapshot-list"      { List-Snapshots }
            "snapshot-cleanup"   { Cleanup-Snapshots }
            "disable-nic"        { Disable-NICStartup }
            "enable-nic"         { Enable-NICStartup }
            "start-vms"          { Start-VMList }
            "stop-vms"           { Stop-VMListGracefully }
            "force-stop-vms"     { Stop-VMListForce }
            "disable-services"   { Disable-ServicesInGuest }
            "vm-powerstate"      { Report-VMStates }
        }
    }
})
$form.Controls.Add($runButton)

# Run it
$form.Topmost = $true
$form.Add_Shown({$form.Activate()})
[void]$form.ShowDialog()
