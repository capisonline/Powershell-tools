﻿# QCAD VMware GUI Tool with Background Image and Scaling

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Create the form
$form = New-Object System.Windows.Forms.Form
$form.Text = "QCAD VMware GUI Tool"
$form.Width = 900
$form.Height = 600
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = 'Sizable'

# Load and set the background image
$backgroundPath = "C:\\temp\\scripts\\VMWare\\Cap_shield.png"
if (Test-Path $backgroundPath) {
    $form.BackgroundImage = [System.Drawing.Image]::FromFile($backgroundPath)
    $form.BackgroundImageLayout = 'Stretch'
}

# Define button font size scaling
function Get-ScaledFontSize {
    param ($formWidth)
    return [Math]::Max(10, [Math]::Floor($formWidth / 35))
}

# Button Configuration Helper
function New-ScaledButton {
    param (
        [string]$text,
        [int]$top,
        [ScriptBlock]$onClick
    )
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $text
    $btn.Width = $form.ClientSize.Width - 40
    $btn.Height = 40
    $btn.Left = 20
    $btn.Top = $top
    $btn.Anchor = "Top,Left,Right"
    $btn.Font = New-Object System.Drawing.Font("Segoe UI", (Get-ScaledFontSize $form.ClientSize.Width))
    $btn.Add_Click($onClick)
    $form.Controls.Add($btn)
    return $btn
}

# Create Buttons
$buttons = @()
$buttons += New-ScaledButton "Create Snapshots" 40 { Write-Host "Call Create-Snapshots function here" }
$buttons += New-ScaledButton "Delete Snapshots" 100 { Write-Host "Call Delete-SnapshotsFromCSV function here" }
$buttons += New-ScaledButton "List Snapshots" 160 { Write-Host "Call List-Snapshots function here" }
$buttons += New-ScaledButton "Cleanup Snapshots" 220 { Write-Host "Call Cleanup-Snapshots function here" }
$buttons += New-ScaledButton "Disable NIC on Boot" 280 { Write-Host "Call Disable-NICStartup function here" }
$buttons += New-ScaledButton "Enable NIC on Boot" 340 { Write-Host "Call Enable-NICStartup function here" }
$buttons += New-ScaledButton "Start VMs" 400 { Write-Host "Call Start-VMList function here" }
$buttons += New-ScaledButton "Stop VMs Gracefully" 460 { Write-Host "Call Stop-VMListGracefully function here" }
$buttons += New-ScaledButton "Force Stop VMs" 520 { Write-Host "Call Stop-VMListForce function here" }

# Resize Event for Auto Scaling
$form.Add_Resize({
    $fontSize = Get-ScaledFontSize $form.ClientSize.Width
    $top = 40
    foreach ($btn in $buttons) {
        $btn.Width = $form.ClientSize.Width - 40
        $btn.Font = New-Object System.Drawing.Font("Segoe UI", $fontSize)
        $btn.Top = $top
        $top += 60
    }
})

# Show the form
[void]$form.ShowDialog()
