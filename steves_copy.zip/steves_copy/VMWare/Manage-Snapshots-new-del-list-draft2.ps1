﻿<#
.SYNOPSIS
    VMware PowerCLI Snapshot Manager with Full CLI Logging
    This script automates snapshot management for VMs in a vCenter environment.

.DESCRIPTION
    - Connects to a vCenter Server and performs snapshot operations.
    - Logs all output including errors to a log file.
    - Supports Create, Delete, List, and Cleanup for VM snapshots.

.OUTPUTS
    - A log file (`SnapshotManager.log`) capturing stdout & stderr.
    - A CSV file (`Snapshots.csv`) listing all snapshots when using the "List" option.

.NOTES
    - Requires VMware PowerCLI to be installed.
    - If `VMList.txt` is missing, it is created and opened for editing.

.AUTHOR
    Created by [Your Name or Team]
    Last Updated: [Date]
#>

Import-Module VMware.PowerCLI -ErrorAction Stop

# Prompt user for vCenter Server
$vCenter = Read-Host "Enter your vCenter Server"
if ([string]::IsNullOrWhiteSpace($vCenter)) {
    Write-Host "`n No vCenter Server entered. Exiting script."
    exit
}

# Accept Invalid SSL Certificates
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

# Define file paths
$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$VMListFile = "$ScriptDirectory\VMList.txt"
$LogFile = "$ScriptDirectory\SnapshotManager.log"
$SnapshotCSV = "$ScriptDirectory\Snapshots.csv"

# Start Logging ALL CLI Output (StdOut & StdErr)
Start-Transcript -Path $LogFile -Append -Force | Out-Null

# Check if VM list file exists, else create and open it
if (-not (Test-Path $VMListFile)) {
    Write-Host "`n VM list file not found! Creating a new one in $ScriptDirectory..."
    "Enter VM names (one per line), then save and close the file." | Out-File -FilePath $VMListFile -Encoding UTF8
    notepad.exe $VMListFile
    Write-Host "`nPlease add VM names to the file and restart the script."
    Stop-Transcript
    exit
}

# Load VM list from the file
$VMList = Get-Content $VMListFile | Where-Object {$_ -ne ""}
if (-not $VMList) {
    Write-Host "`n No VMs found in VMList.txt. Please update the file and restart the script."
    Stop-Transcript
    exit
}

# Display VM list and confirm before proceeding
Write-Host "`n The following VMs will be processed:"
$VMList | ForEach-Object { Write-Host " - $_" }

$confirmation = Read-Host "`nIs this correct? (Y/N)"
if ($confirmation.ToLower() -ne "y") {
    Write-Host "`n User declined VM list. Exiting script."
    Stop-Transcript
    exit
}

# Prompt user for the action
$action = Read-Host "`nChoose an action: Create, Delete, List, Cleanup"

# Connect to vCenter
$connection = $null
try {
    $connection = Connect-VIServer -Server $vCenter -ErrorAction Stop
    Write-Host "`n Connected to vCenter: $vCenter"
} catch {
    Write-Host "`n Failed to connect to vCenter: $vCenter. $_"
    Stop-Transcript
    exit
}

# Function to clean up old snapshots beyond retention period
function Cleanup-OldSnapshots {
    param (
        [int]$RetentionDays
    )
    foreach ($vm in $VMList) {
        $snapshots = Get-Snapshot -VM $vm -ErrorAction SilentlyContinue
        if ($snapshots) {
            foreach ($snapshot in $snapshots) {
                if ($snapshot.Created -lt (Get-Date).AddDays(-$RetentionDays)) {
                    try {
                        Remove-Snapshot -Snapshot $snapshot -Confirm:$false
                        Write-Host "Deleted old snapshot '$($snapshot.Name)' on VM: $vm (Older than $RetentionDays days)"
                    } catch {
                        Write-Host "Failed to delete old snapshot '$($snapshot.Name)' on VM: $vm. $_"
                    }
                }
            }
        }
    }
}

# Process each VM in the list
foreach ($vm in $VMList) {
    try {
        switch ($action.ToLower()) {
            "create" {
                $snapshotName = Read-Host "Enter snapshot name"
                $snapshotDescription = Read-Host "Enter snapshot description"

                Write-Host "Creating snapshot for $vm..."
                $snapshot = New-Snapshot -VM $vm -Name $snapshotName -Description $snapshotDescription -Quiesce:$true -Memory:$false -ErrorAction Stop
                Write-Host "Snapshot '$snapshotName' created for VM: $vm"
            }

            "delete" {
                $snapshotToDelete = Read-Host "Enter snapshot name to delete (or type 'all' to remove all snapshots)"
                if ($snapshotToDelete -eq "all") {
                    Get-Snapshot -VM $vm | Remove-Snapshot -Confirm:$false
                    Write-Host "All snapshots deleted for VM: $vm"
                } else {
                    $snapshot = Get-Snapshot -VM $vm -Name $snapshotToDelete -ErrorAction SilentlyContinue
                    if ($snapshot) {
                        Remove-Snapshot -Snapshot $snapshot -Confirm:$false
                        Write-Host "Snapshot '$snapshotToDelete' deleted for VM: $vm"
                    } else {
                        Write-Host "Snapshot '$snapshotToDelete' not found on VM: $vm"
                    }
                }
            }

            "list" {
                $snapshots = Get-Snapshot -VM $vm -ErrorAction SilentlyContinue
                if ($snapshots) {
                    $snapshots | Export-Csv -Path $SnapshotCSV -NoTypeInformation -Append
                    Write-Host "Snapshot list for VM: $vm exported to $SnapshotCSV"
                } else {
                    Write-Host "No snapshots found for VM: $vm"
                }
            }

            "cleanup" {
                $RetentionDays = Read-Host "Enter retention period (days)"
                Cleanup-OldSnapshots -RetentionDays $RetentionDays
                Write-Host "Deleted snapshots older than $RetentionDays days"
            }

            default {
                Write-Host "❌ Invalid action selected: $action"
                Stop-Transcript
                exit
            }
        }
    } catch {
        Write-Host "❌ Error processing VM ${vm}: $_"
    }
}

# Only disconnect if connected
if ($connection) {
    Disconnect-VIServer -Server $vCenter -Confirm:$false
    Write-Host "Disconnected from vCenter: $vCenter"
}

# Stop logging
Stop-Transcript
