﻿<#
.SYNOPSIS
    QCAD Hypervisor Control & Snapshot Manager (VMware PowerCLI)

.DESCRIPTION
    This PowerShell script provides hypervisor-level automation for QCAD environments using VMware PowerCLI.
    It enables precise control over virtual machine recovery, service states, and snapshot management during
    disaster recovery events, patching windows, or emergency break-glass scenarios.

    The script is designed to minimise user error, enforce consistency across recovery workflows,
    and allow controlled orchestration directly via the hypervisor layer (vSphere/vCenter),
    without requiring in-console interaction.

    Key Features:
    - Connects to one or more vCenters from a selectable list.
    - Creates, lists, deletes, and cleans up VM snapshots.
    - Controls VM power state and network adapter startup behaviour.
    - Starts/stops services inside guest OS via `Invoke-VMScript`.
    - Logs all activity and errors with timestamps.
    - Outputs snapshot deletion results to a CSV for auditing.
    - Supports both DR failover and patching operations.

.PARAMETERS
    This script uses hardcoded file paths:
      - VM List File:            C:\temp\QCAD\VT\VMWare\VMList.txt  << Master file. 
      - vCenters File:           C:\temp\QCAD\VT\VMWare\vCenters.txt << Put all VCenters in here. Can select single or many by numbers
      - Snapshot Deletion CSV:   C:\temp\QCAD\VT\VMWare\snapshot_deletion_csv.csv << First create $SnapshotCSVWithTimestamp by using "snapshot-list" - this gives UUID for snapshots
      - Output Log:              C:\temp\QCAD\VT\VMWare\SnapshotManager.log 
      - Service management       C:\temp\QCAD\VT\VMWare\services_to_disable.csv << 

.NOTES
    Author: Cap
    Requirements: PowerShell, VMware PowerCLI, vSphere privileges, guest credentials for service control
    Version: 1.2
    Use in QCAD DR Test/Production with change management approval
    Supports patching rollback scenarios and full datacentre failover recovery

.EXAMPLE
    Run the script in an elevated PowerShell session:
    PS> .\SnapshotManager.ps1

    Follow prompts to select vCenter(s), authenticate, and execute desired recovery or maintenance action.
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Create form
$form = New-Object System.Windows.Forms.Form
$form.Text = "QCAD Hypervisor & Snapshot Manager"
$form.Size = New-Object System.Drawing.Size(750, 750)
$form.StartPosition = "CenterScreen"

# Set background image
$imagePath = "C:\temp\scripts\VMWare\Cap_shield.png"
if (Test-Path $imagePath) {
    $form.BackgroundImage = [System.Drawing.Image]::FromFile($imagePath)
    $form.BackgroundImageLayout = "Stretch"
} else {
    [System.Windows.Forms.MessageBox]::Show("Could not find background image: $imagePath")
}

# Add ComboBox for actions
$comboBox = New-Object System.Windows.Forms.ComboBox
$comboBox.Location = New-Object System.Drawing.Point(50, 40)
$comboBox.Size = New-Object System.Drawing.Size(300, 90)
$comboBox.Font = 'Microsoft Sans Serif, 14'
$comboBox.DropDownStyle = 'DropDownList'
$comboBox.Items.AddRange(@(
    'snapshot-create',
    'snapshot-delete',
    'snapshot-list',
    'snapshot-cleanup',
    'disable-nic',
    'enable-nic',
    'start-vms',
    'stop-vms',
    'force-stop-vms',
    'disable-services',
    'vm-powerstate',
    'quit'
))
$form.Controls.Add($comboBox)

# Add Run button
$runButton = New-Object System.Windows.Forms.Button
$runButton.Text = "Run"
$runButton.Font = 'Microsoft Sans Serif, 12'
$runButton.Location = New-Object System.Drawing.Point(670, 100)
$runButton.Size = New-Object System.Drawing.Size(100, 40)
$runButton.Add_Click({
    $selectedAction = $comboBox.SelectedItem
    if (-not $selectedAction) {
        [System.Windows.Forms.MessageBox]::Show("Please select an action before running.")
        return
    }

    # Call the actual PowerCLI script here (ideally in a modular design)
    # Example placeholder:
    [System.Windows.Forms.MessageBox]::Show("Would call function: $selectedAction")
})
$form.Controls.Add($runButton)

# Run the GUI
$form.Topmost = $true
$form.Add_Shown({ $form.Activate() })
[void]$form.ShowDialog()
