﻿# Load VMware PowerCLI 
Import-Module VMware.PowerCLI

# Disable SSL warnings (optional)
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false

# Ask for vCenter details
$vCenterServer = Read-Host "Enter vCenter Server"
$User = Read-Host "Enter Username"
$Password = Read-Host "Enter Password" -AsSecureString

# Convert secure string password to plain text (needed for Connect-VIServer)
$Cred = New-Object PSCredential ($User, $Password)

# Connect to vCenter
Connect-VIServer -Server $vCenterServer -Credential $Cred

# File containing the list of VMs
$VMListFile = "C:\Path\to\VMList.txt"  # Replace with actual file path
$VMs = Get-Content $VMListFile

# Log file setup
$LogFile = "C:\Path\to\SnapshotLog_$(Get-Date -Format 'yyyy-MM-dd_HH-mm-ss').log"

# Function to log messages
Function Write-Log {
    param (
        [string]$Message
    )
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "$Timestamp - $Message"
    Add-Content -Path $LogFile -Value $LogEntry
    Write-Host $LogEntry
}

Write-Log "Script started. Connecting to vCenter: $vCenterServer"

# Snapshot details
$SnapshotName = "Automated-Snapshot"
$Description = "Snapshot created via PowerCLI"
$Quiesce = $true  # Set to $false if you don't want to quiesce
$Memory = $false  # Set to $true if you want to capture VM memory

# Loop through each VM and create a snapshot
foreach ($VM in $VMs) {
    if ($VM -ne "") {
        Write-Log "Processing VM: $VM"

        try {
            $VMObject = Get-VM -Name $VM -ErrorAction Stop
            New-Snapshot -VM $VMObject -Name $SnapshotName -Description $Description -Memory:$Memory -Quiesce:$Quiesce -Confirm:$false
            Write-Log "SUCCESS: Snapshot created for $VM"
        }
        catch {
            Write-Log "ERROR: Failed to create snapshot for $VM. Error: $_"
        }
    }
}

Write-Log "All snapshots processed. Disconnecting from vCenter."

# Disconnect from vCenter
Disconnect-VIServer -Server $vCenterServer -Confirm:$false

Write-Log "Script completed successfully."
