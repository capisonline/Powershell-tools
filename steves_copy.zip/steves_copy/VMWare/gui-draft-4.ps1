﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form              = New-Object System.Windows.Forms.Form
$form.Text         = "QCAD Hypervisor GUI - Disaster Recovery"
$form.Size         = New-Object System.Drawing.Size(1440, 900)
$form.StartPosition = "CenterScreen"
$form.Font         = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)

$comboBox          = New-Object System.Windows.Forms.ComboBox
$comboBox.Location = New-Object System.Drawing.Point(100, 100)
$comboBox.Size     = New-Object System.Drawing.Size(1200, 60)
$comboBox.DropDownStyle = 'DropDownList'
$comboBox.Items.AddRange(@(
    "snapshot-create",
    "snapshot-delete",
    "snapshot-list",
    "snapshot-cleanup",
    "disable-nic",
    "enable-nic",
    "start-vms",
    "stop-vms",
    "force-stop-vms",
    "disable-services",
    "vm-powerstate",
    "quit"
))
$form.Controls.Add($comboBox)

$runButton          = New-Object System.Windows.Forms.Button
$runButton.Text     = "RUN SELECTED ACTION"
$runButton.Size     = New-Object System.Drawing.Size(500, 100)
$runButton.Location = New-Object System.Drawing.Point(470, 200)
$runButton.BackColor = 'DarkRed'
$runButton.ForeColor = 'White'

$runButton.Add_Click({
    $selected = $comboBox.SelectedItem
    if (-not $selected) {
        [System.Windows.Forms.MessageBox]::Show("Please select an action.", "Missing Selection")
        return
    }
    [System.Windows.Forms.MessageBox]::Show("Executing: $selected", "Confirm")
    # Replace with actual function call logic
})

$form.Controls.Add($runButton)
$form.Topmost = $true
$form.ShowDialog()
