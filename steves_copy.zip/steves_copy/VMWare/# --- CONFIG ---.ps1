# --- CONFIG ---
$vCenter    = "eglqpsvcs01.prds.qldpol"               # <-- Replace with your vCenter FQDN or IP
$VMName     = "EGLVCADVASVT01"                  # <-- Replace with your test VM name
$Service    = "VisVT_Arbitrator"                       # <-- Replace with a test service name

# --- Prompt for Credentials ---
$vCenterCred = Get-Credential -Message "Enter vCenter credentials"
$GuestCred   = Get-Credential -Message "Enter guest VM credentials"

# --- Connect to vCenter ---
try {
    Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

    Connect-VIServer -Server $vCenter -Credential $vCenterCred -ErrorAction Stop | Out-Null
    Write-Host "[INFO] Connected to vCenter: $vCenter" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Could not connect to vCenter: $($_.Exception.Message)" -ForegroundColor Red
    return
}

# --- GET VM ---
try {
    $vm = Get-VM -Name $VMName -ErrorAction Stop
} catch {
    Write-Host "[ERROR] VM '$VMName' not found in vCenter." -ForegroundColor Red
    return
}

<# --- CHECK VMWARE TOOLS STATUS ---
if ($vm.ExtensionData.Guest.ToolsStatus -ne 'toolsOk') {
    Write-Host "[ERROR] VMware Tools is not OK on '$VMName'. Current status: $($vm.ExtensionData.Guest.ToolsStatus)" -ForegroundColor Red
    return
}#>
# --- SCRIPT TO DISABLE SERVICE ---
$script = @"
Try {
    Stop-Service -Name `"$Service`" -Force -ErrorAction Stop
    Set-Service -Name `"$Service`" -StartupType Disabled -ErrorAction Stop
    Write-Output "SUCCESS: Service '$Service' stopped and disabled"
} Catch {
    Write-Output "FAILURE: $($_.Exception.Message)"
}
"@

# --- EXECUTE SCRIPT INSIDE GUEST ---
try {
    $result = Invoke-VMScript -VM $vm -ScriptText $script -ScriptType PowerShell -GuestCredential $GuestCred -ErrorAction Stop
    Write-Host "[INFO] Output from guest:" -ForegroundColor Cyan
    Write-Host $result.ScriptOutput
} catch {
    Write-Host "[ERROR] Failed to run script in guest: $($_.Exception.Message)" -ForegroundColor Red
}

# --- Disconnect cleanly ---
Disconnect-VIServer -Server * -Confirm:$false | Out-Null
Write-Host "[INFO] Disconnected from vCenter" -ForegroundColor Green
