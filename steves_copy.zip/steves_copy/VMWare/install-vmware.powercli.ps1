﻿<# 
.SYNOPSIS
    Downloads PowerShell modules as `.zip` files from the PowerShell Gallery for offline use,
    then extracts them into a standard `<ModuleName>\<Version>` folder structure.

.DESCRIPTION
    This script loops through a list of modules (name + version), constructs the download URL
    (`https://powershellgallery.com/api/v2/package/<ModuleName>/<Version>`), and saves each as a
    `.zip` file. After downloading, it uses `Expand-Archive` to unzip them. Typically, the actual
    module files reside in the `package\tools` subfolder within each archive.

    The extracted modules are placed in `<ModuleInstallPath>\<ModuleName>\<Version>`. You can
    then copy this folder structure to your offline environment (e.g., `C:\Program Files\PowerShell\Modules\`)
    to enable `Import-Module <ModuleName>` without needing an internet connection.

.NOTES

    After running, copy `C:\Temp\PowerCLI-Offline\Modules` to your offline machine. 
    For example, place it in `C:\Program Files\PowerShell\Modules\` and run:
        Import-Module VMware.PowerCLI
#>

# Where to download the .zip files
$downloadPath = 'C:\Temp\PowerCLI-Offline\nupkgs'
New-Item -ItemType Directory -Path $downloadPath -Force | Out-Null

# Where to unzip/install the modules ultimately
$modulesInstallPath = 'C:\Program Files\WindowsPowerShell\Modules'
#New-Item -ItemType Directory -Path $modulesInstallPath -Force | Out-Null

# Define the modules you want to download
$RequiredModules = @(
    @{ModuleName = "VMware.PowerCLI";              RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Sdk";      RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Common";   RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.Vim";                    RequiredVersion = "8.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Core";     RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Srm";      RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.License";  RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Vds";      RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.CloudServices";          RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Vmc";      RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Nsxt";     RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.vROps";    RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Cis.Core"; RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Cloud";    RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.DeployAutomation";       RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.ImageBuilder";           RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Storage";  RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.StorageUtility"; RequiredVersion = "1.6.0.0"},
    @{ModuleName = "VMware.VumAutomation";          RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Security"; RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.Hcx";      RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.VimAutomation.WorkloadManagement"; RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.Sdk.Runtime";            RequiredVersion = "1.0.2099.24145081"},
    @{ModuleName = "VMware.Sdk.vSphere";            RequiredVersion = "13.3.2099.24145081"},
    @{ModuleName = "VMware.PowerCLI.VCenter";       RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.Sdk.Nsx.Policy";         RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.Sdk.Srm";                RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.Sdk.Vr";                 RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.Sdk.Vcf.CloudBuilder";   RequiredVersion = "13.3.0.24145081"},
    @{ModuleName = "VMware.Sdk.vSphere.Appliance";   RequiredVersion = "8.0.1111.21624264"},
    @{ModuleName = "VMware.Sdk.vSphereRuntime";   RequiredVersion = "8.0.2099.24145081"},
    @{ModuleName = "VMware.Sdk.Vcf.SddcManager";    RequiredVersion = "13.3.0.24145081"}
)

foreach ($mod in $RequiredModules) {
    $moduleName  = $mod.ModuleName
    $version     = $mod.RequiredVersion

    # e.g. https://powershellgallery.com/api/v2/package/VMware.VimAutomation.Sdk/13.3.0.24145081
    $uri         = "https://powershellgallery.com/api/v2/package/$($moduleName)/$($version)"

    # Download as .zip instead of .nupkg
    $outputFile  = Join-Path $downloadPath "$($moduleName).$($version).zip"
    
    Write-Host "`nDownloading $moduleName $version ..."
    Write-Host "URL: $uri"
    Write-Host "Out: $outputFile"

    Invoke-WebRequest -Uri $uri -OutFile $outputFile -UseBasicParsing
}

Write-Host "`nAll modules downloaded as .zip files into: $downloadPath"
Write-Host "Unzipping them into module folders under: $modulesInstallPath ..."

# Expand each .zip file
Get-ChildItem -Path $downloadPath -Filter "*.zip" | ForEach-Object {
    $zipPath = $_.FullName

    # e.g. "C:\Temp\PowerCLI-Offline\nupkgs\VMware.VimAutomation.Sdk.13.3.0.24145081.zip"
    # We'll extract into a subfolder named "<ModuleName>.<Version>"
    $unzipFolder = Join-Path $modulesInstallPath ($_.BaseName) 
    # For example: "C:\Temp\PowerCLI-Offline\Modules\VMware.VimAutomation.Sdk.13.3.0.24145081"

    Write-Host "Extracting $zipPath -> $unzipFolder"
    Expand-Archive -Path $zipPath -DestinationPath $unzipFolder -Force

    # Typically, the actual module files are in `package\tools` inside that folder. 
    # We might want to move them into a standard structure: <ModuleName>\<Version>\[files]

    # Create the final module folder
    # We already have $mod data, but since this block doesn't know which mod entry it belongs to,
    # let's parse from the filename or do a more advanced approach. 
    # We'll assume the user is only using this script once (so the ForEach loop for each file 
    # is basically in sync with the modules array). If you want a robust approach, you'd store 
    # a dictionary or match by file name. For simplicity, we'll reuse the same logic below:

    $baseParts = $_.BaseName -split "\."
    # e.g. ["VMware","VimAutomation","Sdk","13","3","0","24145081"]
    # We'll assume the last 4 numeric parts are the version: "13.3.0.24145081"
    # The rest is the module name: "VMware.VimAutomation.Sdk"

    $versionParts = $baseParts[($baseParts.Count - 4)..($baseParts.Count - 1)]
    $actualVersion = $versionParts -join '.'

    $nameParts = $baseParts[0..($baseParts.Count - 5)]
    $actualModuleName = $nameParts -join '.'

    $finalModulePath = Join-Path (Join-Path $modulesInstallPath $actualModuleName) $actualVersion

    Write-Host "Copying module files to $finalModulePath ..."
    New-Item -ItemType Directory -Path $finalModulePath -Force | Out-Null

    # The actual module is usually in "package\tools"
    $toolsPath = Join-Path $unzipFolder "package\tools"

    if (Test-Path $toolsPath) {
        Copy-Item -Path (Join-Path $toolsPath '*') -Destination $finalModulePath -Recurse
    }
    else {
        # Fallback: maybe the structure is slightly different
        Copy-Item -Path (Join-Path $unzipFolder '*') -Destination $finalModulePath -Recurse
    }

    # Clean up the expanded folder (the "<ModuleName>.<Version>" intermediate)
    Remove-Item $unzipFolder -Recurse -Force

    Write-Host "Done processing: $actualModuleName $actualVersion"
}

Write-Host "`nDONE. Modules are unzipped in $modulesInstallPath\<ModuleName>\<Version>."
Write-Host "Copy that folder structure to your offline environment’s PowerShell module path, then:"
Write-Host "`tImport-Module <ModuleName>"

