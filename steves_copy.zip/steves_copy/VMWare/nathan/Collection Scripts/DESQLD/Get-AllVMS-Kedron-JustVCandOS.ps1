# PowerShell script to connect to vCenter Server, retrieve VM information, collect system, network, disk, shared folders, local users, local groups, services, certificates, installed applications, firewall status, firewall rules, and additional information, and export it to text files.

# Import VMware PowerCLI module
Import-Module VMware.PowerCLI

# Opt out of CEIP
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false

# Suppress SSL certificate warnings
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false

# Prompt for credentials for each domain
$vCenterCredentials = Get-Credential -Message "Enter credentials for connecting to the vCenter server"
$desqldCredentials = Get-Credential -Message "Enter credentials for desqld.internal domain - Please use DESQLD\\username"
$psbaCredentials = Get-Credential -Message "Enter credentials for psba.qld.gov.au domain - Please use PSBA\\username"
$volunteersCredentials = Get-Credential -Message "Enter credentials for volunteers.internal domain - Please use VOLS\\username"

# Connect to vCenter Server using the provided credentials
$vCenterServer = "kedshrvcs01.desqld.internal"
Connect-VIServer -Server $vCenterServer -Credential $vCenterCredentials

# Specify the base directory for output
$baseOutputDir = "E:\\nathan\\kedron\\"

# Variable to limit the number of servers processed (for testing purposes)
$limitServersToProcess = 1000  # Change this number to limit the number of VMs processed

# Initialize an empty array to hold VM information
$vmList = @()

# Step 1: Get the list of servers
Write-Output "Step 1: Starting collection of base VM information..."
$vmCollection = Get-VM | Select-Object -First $limitServersToProcess

$vmCollection | ForEach-Object {
    $vm = $_

    # Ensure $vm is a valid VirtualMachine object
    if ($vm -is [VMware.VimAutomation.ViCore.Types.V1.Inventory.VirtualMachine]) {
        Write-Output "Processing VM: $($vm.Name)"

        # Collect the base VM data
        $dnsName = $vm.Guest.HostName

        # Store the base information in a temporary object
        $vmInfo = New-Object PSObject -Property @{
            VMWare_Name               = $vm.Name
            VMWare_CPU                = $vm.ExtensionData.Config.Hardware.NumCPU
            VMWare_MemoryGB           = $vm.ExtensionData.Config.Hardware.MemoryMB / 1KB
            VMWare_DiskGB             = [math]::Round(($vm.ExtensionData.Summary.Storage.Committed / 1GB), 2)
            VMWare_GuestOS            = $vm.ExtensionData.Config.GuestFullName
            VMWare_PowerState         = $vm.PowerState
            VMWare_Host               = $vm.VMHost.Name
            VMWare_Cluster            = $vm.VMHost.Parent.Name
            VMWare_Datastore          = ($vm | Get-Datastore).Name -join ","
            VMWare_Network            = ($vm | Get-NetworkAdapter | ForEach-Object { $_.NetworkName }) -join ","
            VMWare_IPAddresses        = ($vm.Guest.IPAddress -join ",")
            VMWare_DNSName            = $dnsName
            SysInfo_OSName            = ""
            SysInfo_OSVersion         = ""
            SysInfo_Domain            = ""  # Updated to capture domain instead of processor
            CollectionResult          = ""  # Initializing the CollectionResult property
            ErrorOutput               = ""  # Also initializing ErrorOutput
        }

        # Check Power State before proceeding with System, Network, Disk Information, Share, and User collection
        if ($vmInfo.VMWare_PowerState -ne "PoweredOn") {
            $vmInfo.ErrorOutput += "VM is in a Powered Off State. "
            Write-Output "VM: $($vmInfo.VMWare_Name) is powered off. Skipping information collection."
            $vmInfo.CollectionResult = "Failure"
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Check if the Guest OS is a Windows machine
        if ($vmInfo.VMWare_GuestOS -notlike "Microsoft Windows*") {
            $vmInfo.ErrorOutput += "VM is not running a Windows OS: $($vmInfo.VMWare_GuestOS). "
            Write-Output "VM: $($vmInfo.VMWare_Name) is not running a Windows OS. Skipping information collection."
            $vmInfo.CollectionResult = "Skipped - Non-Windows OS"
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Validate DNS Name before proceeding
        if (-not $vmInfo.VMWare_DNSName -or $vmInfo.VMWare_DNSName -notmatch "\.") {
            $vmInfo.ErrorOutput += "VM has an invalid DNS name: $($vmInfo.VMWare_DNSName). "
            Write-Output "VM: $($vmInfo.VMWare_Name) has an invalid DNS name. Skipping information collection."
            $vmInfo.CollectionResult = "Failure"
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Skip all Windows Server 2003 Servers
        if ($vmInfo.VMWare_GuestOS -like "Microsoft Windows Server 2003*") {
            $vmInfo.ErrorOutput += "VM is running Windows Server 2003: $($vmInfo.VMWare_GuestOS). "
            Write-Output "VM: $($vmInfo.VMWare_Name) is running Windows Server 2003. Skipping information collection."
            $vmInfo.CollectionResult = "Skipped - Windows Server 2003"
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Create a directory for this server (only if powered on and DNS is valid)
        $serverOutputDir = Join-Path -Path $baseOutputDir -ChildPath $vm.Name
        if (-not (Test-Path -Path $serverOutputDir)) {
            New-Item -Path $serverOutputDir -ItemType Directory | Out-Null
        }

        # Create subdirectories for different steps
        $vmwareDir = Join-Path -Path $serverOutputDir -ChildPath "vmware"
        $sysinfoDir = Join-Path -Path $serverOutputDir -ChildPath "sysinfo"

        # Create all directories if they don't exist
        foreach ($dir in @($vmwareDir, $sysinfoDir)) {
            if (-not (Test-Path -Path $dir)) {
                New-Item -Path $dir -ItemType Directory | Out-Null
            }
        }

        # Step 2: Export VMware Data to vmware.txt
        try {
            $vmwareData = $vm | Format-List -Property *
            $vmwareFilePath = Join-Path -Path $vmwareDir -ChildPath "vmwaredata.txt"
            $vmwareData | Out-File -FilePath $vmwareFilePath -Force
            Write-Output "Exported VMware data to $vmwareFilePath"
        } catch {
            Write-Output "Failed to export VMware data for VM: $($vmInfo.VMWare_Name)"
            $vmInfo.ErrorOutput += "Failed to export VMware data. "
        }

        # Step 3: Collect System Information
        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            Write-Output "Step 3: Collecting system information for VM: $($vmInfo.VMWare_Name)"
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "desqld.internal" { $desqldCredentials }
                "psba.qld.gov.au" { $psbaCredentials }
                "volunteers.internal" { $volunteersCredentials }
                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # Detect guest OS and execute appropriate command
            if ($vm.ExtensionData.Summary.Config.GuestFullName -like "*2003*") {
                # Windows Server 2003 - Batch Script
                $script = @'
@echo off
for /f "tokens=2 delims==" %%A in ('wmic computersystem get Domain /value') do set domain=%%A
for /f "tokens=2 delims==" %%A in ('wmic os get Caption /value') do set osName=%%A
for /f "tokens=2 delims==" %%A in ('wmic os get Version /value') do set osVersion=%%A

echo %osName%
echo %osVersion%
echo %domain%
'@
                $scriptType = 'Bat'
            } elseif ($vm.ExtensionData.Summary.Config.GuestFullName -like "*2008*") {
                # Windows Server 2008 - PowerShell 1.0
                $script = @'
$osName = (Get-WmiObject Win32_OperatingSystem).Caption
$osVersion = (Get-WmiObject Win32_OperatingSystem).Version
$domain = (Get-WmiObject Win32_ComputerSystem).Domain

echo $osName
echo $osVersion
echo $domain
'@
                $scriptType = 'Powershell'
            } else {
                # Windows Server 2012 and later - PowerShell 2.0+
                $script = @'
$osName = (Get-WmiObject Win32_OperatingSystem).Caption
$osVersion = (Get-WmiObject Win32_OperatingSystem).Version
$domain = (Get-WmiObject Win32_ComputerSystem).Domain

echo $osName
echo $osVersion
echo $domain
'@
                $scriptType = 'Powershell'
            }

            try {
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
                $scriptOutput = $scriptResult.ScriptOutput -split "`r`n"
                $vmInfo.SysInfo_OSName = $scriptOutput[0].Trim()
                $vmInfo.SysInfo_OSVersion = $scriptOutput[1].Trim()
                $vmInfo.SysInfo_Domain = $scriptOutput[2].Trim()

                # Save command output to file
                $sysinfoFilePath = Join-Path -Path $sysinfoDir -ChildPath "sysinfo.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $sysinfoFilePath -Force

                Write-Output "Step 3: Collected system information for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 3: Failed to collect system information for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect system information. "
            }
        } else {
            Write-Output "Step 3: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping system information collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        # Ensure $vmInfo is added to the list after the successful collection
        $vmInfo.CollectionResult = "Success"
        $vmList += $vmInfo  # Ensure the $vmInfo is added to $vmList
    }
}

# Step 13: Export VM configuration information to a CSV file with columns ordered as per the property order in $vmInfo
Write-Output "Step 13: Exporting VM configuration information to CSV..."
$vmList | Select-Object `
VMWare_Name,
VMWare_CPU,
VMWare_MemoryGB,
VMWare_DiskGB,
VMWare_GuestOS,
VMWare_PowerState,
VMWare_Host,
VMWare_Cluster,
VMWare_Datastore,
VMWare_Network,
VMWare_IPAddresses,
VMWare_DNSName,
SysInfo_OSName,
SysInfo_OSVersion,
SysInfo_Domain,
ErrorOutput |
Export-Csv -Path "$($baseOutputDir)VM_Configuration_VCOS.csv" -NoTypeInformation -UseCulture

# Disconnect from vCenter Server
Disconnect-VIServer -Server $vCenterServer -Confirm:$false

# Output the location of the CSV file
Write-Output "VM configuration information exported to $($baseOutputDir)VM_Configuration.csv"
