# Variables 
$serverListPath = "C:\temp\nathan\servers.txt"  # Path to the text file containing server names 
$taskName = "SystemInfoCollectionTask"   # Name of the scheduled task 
$sourcescriptpath = "\\desqld.internal\DFSShare_DCDevopsRepo\scriptsource\GetSystemInfo.ps1" # Source of the collection script copied to remote server 
$finaloutputbasepath = "\\bnejmp01\IBG_QA_reports" # Base path for final outputs 
$credential = Get-Credential             # Prompt for a credential once at the start 
$schedtaskuser = "SYSTEM"                # Scheduled task user 
$outputDirectory = "c:\temp"

# Check if the server list file exists 
if (-Not (Test-Path $serverListPath)) { 
    Write-Host "Error: Server list file not found at $serverListPath" -ForegroundColor Red 
    exit 
} 

# Read the list of servers from the file 
$servers = Get-Content -Path $serverListPath 

# Process each server 
foreach ($remoteServer in $servers) { 
    Write-Host "Processing server: $remoteServer" -ForegroundColor Yellow 

    # Define paths specific to the current server 
    $remotescriptpath = "\\$remoteServer\c$\temp\GetSystemInfo.ps1"  # Remote Path used to copy script 
    $remoteoutputpath = "\\$remoteServer\c$\temp\$($remoteServer)_Discovery_Report.txt" 
    $localoutputpath = "c:\temp\$($remoteServer)_Discovery_Report.txt" 
    $finaloutputpath = Join-Path -Path $finaloutputbasepath -ChildPath "$($remoteServer)_Discovery_Report.txt" 

    # Step 1: Copy the Script to the Remote Server 
    Write-Host "Copying script to $remoteServer..."  
    try { 
        # Ensure the output directory exists
        if (-not (Test-Path -Path $outputDirectory)) {
        New-Item -ItemType Directory -Path $outputDirectory
        }
        Copy-Item -Path $sourcescriptpath -Destination $remotescriptpath -Force 
        Write-Host "Script copied to $remotescriptpath" 
    } catch { 
        Write-Host "Error copying script to $remoteServer" -ForegroundColor Red 
        continue 
    } 

    Start-Sleep -Seconds 30

    # Step 2: Create the Scheduled Task on the Remote Server 
    Write-Host "Creating scheduled task on $remoteServer..." 
    try { 
        Invoke-Command -ComputerName $remoteServer -Credential $credential -ScriptBlock { 
            param ($scriptPath, $taskName, $schedtaskuser) 
            $action = New-ScheduledTaskAction -Execute "%SystemRoot%\system32\WindowsPowerShell\v1.0\powershell.exe" -Argument "-executionpolicy bypass -file $scriptPath" 
            $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) 
            $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable 
            Register-ScheduledTask -Action $action -Trigger $trigger -TaskName $taskName -Settings $settings -RunLevel Highest -User $schedtaskuser 
            Write-Host "Scheduled task $taskName created." 
        } -ArgumentList $remotescriptpath, $taskName, $schedtaskuser 
    } catch { 
        Write-Host "Error creating scheduled task on $remoteServer" -ForegroundColor Red 
        continue 
    } 

    Start-Sleep -Seconds 30

    # Step 3: Run the Scheduled Task 
    Write-Host "Running the scheduled task on $remoteServer..." 
    try { 
        Invoke-Command -ComputerName $remoteServer -Credential $credential -ScriptBlock { 
            param ($taskName) 
            Start-ScheduledTask -TaskName $taskName 
            Write-Host "Task $taskName started." 
        } -ArgumentList $taskName 
    } catch { 
        Write-Host "Error starting scheduled task on $remoteServer" -ForegroundColor Red 
        continue 
    } 

    Start-Sleep -Seconds 10

    # Step 4: Monitor Task Completion 
    Write-Host "Monitoring task status on $remoteServer..." 
    try { 
        Invoke-Command -ComputerName $remoteServer -Credential $credential -ScriptBlock { 
            param ($taskName) 
            do { 
                $status = Get-ScheduledTask -TaskName $taskName | Select-Object -ExpandProperty State 
                Write-Host "Task status: $status" 
                Start-Sleep -Seconds 5 
            } while ($status -eq "Running") 
            Write-Host "Task $taskName completed." 
        } -ArgumentList $taskName 
    } catch { 
        Write-Host "Error monitoring task on $remoteServer" -ForegroundColor Red 
        continue 
    } 

    Write-Host "Pausing for 2 mins to allow file locks to clear..." 
    Start-Sleep -Seconds 120
 
    # Step 5: Copy Output to Final Location 
    Write-Host "Copying output from $remoteServer to final location..." 
    try { 
        Copy-Item -Path $remoteoutputpath -Destination $finaloutputpath -Force 
        Write-Host "Output copied to $finaloutputpath" 
    } catch { 
        Write-Host "Error copying output from $remoteServer" -ForegroundColor Red 
        continue 
    } 

    # Step 6: Clean Up (Optional) 
    Write-Host "Cleaning up on $remoteServer..." 
    try { 
        Invoke-Command -ComputerName $remoteServer -Credential $credential -ScriptBlock { 
            param ($taskName, $scriptPath, $localoutputpath) 
            Unregister-ScheduledTask -TaskName $taskName -Confirm:$false 
            Remove-Item -Path $scriptPath -Force 
            Remove-Item -Path $localoutputpath -Force 
            Write-Host "Scheduled task and script cleaned up." 
        } -ArgumentList $taskName, $remotescriptpath, $localoutputpath 
    } catch { 
        Write-Host "Error cleaning up on $remoteServer" -ForegroundColor Red 
    } 
    Write-Host "Processing completed for $remoteServer." -ForegroundColor Green 
} 

Write-Host "All servers processed." -ForegroundColor Green 