<# 
.SYNOPSIS
  ********************************************************************************  
  *                                                                              *  
  *  This script gets the info required to complete the Server QA report         *
  *                                                                              *  
  ********************************************************************************    

.DESCRIPTION
      This script gets the info required to complete the Server QA report    
      Outputs all the results to c:\temp\<Servername>_QA_report.txt
      
.NOTES
    Author: Gary Chau
                
    Date:   25 Aug 2021

   ******* Update Version number below when a change is done.*******
   
.HISTORY
            Version    Date               Name           Detail
            ------------------------------------------------------------------------------------
            1.0      25 Aug 2021        Gary Chau       Initial Coding
            1.1      06 Sep 2021        Gary Chau       Edit Nutanix process check
            1.2      27 Oct 2021        Gary Chau       Added disk partition information
            1.3      24 Nov 2021        Gary Chau       Merge copy result function
            1.4      13 Jun 2022        Gary Chau       Added local group check
            1.5      28 Jul 2022        Gary Chau       Added windows defender check
            1.6      26 Oct 2022        Gary Chau       Added 2 application logs for checking
            1.7      09 Nov 2022        Gary Chau       Added AppSense agent check
            1.8      09 Dec 2022        Gary Chau       Added Sentinel agent check and modify FireEye check
            1.9      08 Mar 2023        Gary Chau       Added Power Plan setting check
            2.0      23 May 2023        Gary Chau       Added .Net version check
            2.2      14 Jun 2023        Gary Chau       Added .Net Core version check
#>

$clientname = "ARCROF01"         # Replace with the target server name
$path = "c:\temp" # Network share for combined outputs

function Titlebox ([string]$SubjectTitle) { 
    $blank = " " 
    $ln1 = [char]0x2554 # Left top 
    $ln2 = [char]0x2557 # Right Top 
    $ln3 = [char]0x255A # Left bottom 
    $ln4 = [char]0x255D # Right Bottom 
    $ln5 = [char]0x2551 # Center 
    $ln6 = [char]0x2550 # = 
    $ln10 = Repeat-string $ln6 76 
    $s = $SubjectTitle.Length 
    $i = 66 - $s 
    $titlespace = Repeat-string $blank $i 
    $titleline = "$ln5          $SubjectTitle$titlespace$ln5" 
    $output = "$ln1$ln10$ln2`r`n$titleline`r`n$ln3$ln10$ln4" 
    $output | Out-File $Report -Append 
} 

function Repeat-string ([string]$str, [int]$repeat) { 
    return $str * $repeat 
} 

function CPU{

    # Get SystemInfo
    $SystemInfo = Get-CimInstance -ClassName Win32_ComputerSystem

    # Get processor information 
    $processorInfo = Get-CimInstance -ClassName Win32_Processor 

    # Calculate the total number of logical processors 
    $totalLogicalProcessors = ($processorInfo | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum 

    # Count the number of physical processors 
    $numberOfProcessors = ($processorInfo | Measure-Object).Count 

    # Get the total number of cores per processor (if available) 
    $totalCores = ($processorInfo | Measure-Object -Property NumberOfCores -Sum).Sum 
    $coresPerProcessor = if ($numberOfProcessors -gt 0) { $totalCores / $numberOfProcessors } else { 0 } 

    # Get the processor name (assumes all CPUs have the same name) 
    $processorName = $processorInfo[0].Name  

    $cpu_prop = [ordered]@{
                "Manufacturer"                  = $SystemInfo.Manufacturer
                "Machine Type"                  = $SystemInfo.Model
                "Number of Logicial Processors" = $totalLogicalProcessors   
                "Number of Cores per Processor" = $coresPerProcessor
                "Number of Physical Processors" = $numberOfProcessors
                "Physical Processors Name"      = $processorName  
    }

    Titlebox -SubjectTitle "CPU"     
    [PScustomobject]$cpu_prop | Out-file $Report -Append  
    
    Titlebox -SubjectTitle "Memory"
    $mem =  ([math]::Round(($SystemInfo.TotalPhysicalMemory /1GB)))
    $memory = "`r`nThis system has $mem GB RAM`r`n`r`n "     
    $memory | out-file $Report -Append    
    
    Titlebox -SubjectTitle "Disk & Volume configuration"          
    $disks = get-disk | select * | where-object {$_.number -ne $null } | sort -property number | ft -Wrap number, @{name = " DiskSize(GB) "; expression = { "{0,8:N0}" -f ($_.size / 1gb) } }, operationalstatus, Healthstatus, partitionstyle
    $drvs = get-wmiobject win32_volume | where { $_.driveletter -ne "X:" -and $_.label -ne "System Reserved" } | sort driveletter | Ft -Wrap  Driveletter, label, 
    @{name = "  Disk Size(GB) "; Expression = { "{0,8:N0}" -f ($_.Capacity / 1gb) } } ,
    @{name = "  Free Disk Size(GB) "; Expression = { "{0,8:N0}" -f ($_.FreeSpace / 1gb) } } ,
    @{name = "  Block Size (KB) "; Expression = { "{0,8:N0}" -f ($_.Blocksize / 1kb) } } 
    $disks | out-file $Report -append
    $drvs | Out-File $Report -Append                  

    $Pagesize = get-wmiobject win32_pagefileusage | select @{name = "Volume"; Expression = { $_.Name } }, @{name = "Allocated Size(MB)"; Expression = { $_.AllocatedBaseSize } } 
    $total = 0
    (get-wmiobject win32_pagefileusage).Allocatedbasesize | foreach { $total += $_ }
    $TotalPagesize = "Total paging file size: $total MB"
    $AutoManage = get-wmiobject Win32_ComputerSystem   
    $AutoManage1 = $AutoManage.AutomaticManagedPagefile
    titlebox -SubjectTitle "Page File"    

    $pagesize | out-file $Report -Append

    $TotalPageSize | out-file $Report -Append
    if ($AutoManage1){
        "`r`nPagefile is set as AUTO managed.`r`n`r`n" | out-file $Report -Append
    } else {
        "`r`nPagefile is set as MANUAL managed.`r`n`r`n" | out-file $Report -Append
    }
}

function DDBoostcheck{

if (($env:computername | select-string "sql") -and ($domain -ne "deqld.internal")){
    titlebox -SubjectTitle "Checking DDBoost is configured"
    $DDlogPath = "C:\Program Files\DPSAPPS\MSAPPAGENT\logs\msagentadmin.messages.log"
$DDBoostlog = gc $DDlogPath
$checklog = $DDBoostlog | select-string "has been registered in the lockbox"
if ($checklog){
"`r`nDD Boost is installed and registered`r`n`r`n" | out-file $Report -Append
} elseif (test-path $DDlogpath) {
"`r`nDD Boost is installed but not registered`r`n`r`n" | out-file $Report -Append
} else {
"`r`nDD Boost is not installed`r`n`r`n" | out-file $Report -Append
}
}


}

function NetworkConfig{

    titlebox -SubjectTitle "Network Config - Summary"

    if (Get-NetAdapterBinding | where {$_.DisplayName -match "IPv6" -and $_.enabled } ){
        "`r`nFailed: IPv6 Enabled. *** Please Disable ***`r`n" | Out-File $Report -Append
    } else {
        "`r`nPassed: IPv6 is Disabled.`r`n" | Out-File $Report -Append
    }
  
    Get-NetIPConfiguration -WarningAction SilentlyContinue -ErrorAction SilentlyContinue | Out-String | out-file $Report -Append

    #network Teaming 
    titlebox -SubjectTitle "Network Teaming - Summary"
    $teamname = (Get-NetLbfoTeam).name
    if ($teamname -ne $null) {
        $j=1        
        foreach ($i in $teamname) {            
            $Teamstatus = Get-NetAdapter (Get-NetLbfoTeamMember -team $i).name | ft -wrap | Out-String
            "`r`nNetwork Adapters in the Team #$j ($i):`r`n$teamstatus`r`n`r`n" | Out-File $Report -Append
            $j += $j
        } 
    }
    else {
        "`r`nNo Network Teaming is configured on this server.`r`n`r`n" | Out-File $Report -Append
    }
}

function NetworkConfigDetailed { 
    titlebox -SubjectTitle "Network Config - Detailed" 

    if (Get-NetAdapterBinding | where {$_.DisplayName -match "IPv6" -and $_.enabled } ){ 
        "`r`nFailed: IPv6 Enabled. *** Please Disable ***`r`n" | Out-File $Report -Append 
    } else { 
        "`r`nPassed: IPv6 is Disabled.`r`n" | Out-File $Report -Append 
    } 

    Get-NetIPConfiguration -detailed -WarningAction SilentlyContinue -ErrorAction SilentlyContinue | Out-String | Out-File $Report -Append 

    #network Teaming  
    titlebox -SubjectTitle "Network Teaming - Detailed" 
    $teamname = (Get-NetLbfoTeam).name 
    if ($teamname -ne $null) { 
        $j=1         
        foreach ($i in $teamname) {             
            $Teamstatus = Get-NetAdapter (Get-NetLbfoTeamMember -team $i).name | Select-Object -Property * | Out-String 
            "`r`nNetwork Adapters in the Team #$j ($i):`r`n$Teamstatus`r`n`r`n" | Out-File $Report -Append 
            $j++ 
        }  
    } 
    else { 
        "`r`nNo Network Teaming is configured on this server.`r`n`r`n" | Out-File $Report -Append 
    } 
} 

function Domain_OU{
    
    Titlebox -SubjectTitle "Server Domain and OU"
    $domain = $CPUinfo.CsDomain.tostring()
            
    "`r`nDomain: $domain`r`n" | out-file $Report -append

<# OU reporting moved to Ansible play
    $ps = New-PSSession $dc
    Import-Module activedirectory -PSSession $ps
    $ad = Get-ADComputer $servername -Properties *
    $oulocal = $ad.CanonicalName
    "`r`nOU: $oulocal`r`n" | Out-File $Report -Append
    Get-PSSession | Remove-PSSession
    #>
}

function LocalGroup{

    Titlebox -SubjectTitle "Local Group Membership"

    if ($psversiontable.psversion.major -ge 5) {
        "`r`n Administrators: `r`n" | out-file $Report -Append
        get-localgroupmember "Administrators" | out-file $Report -Append
        "`r`n Remote Desktop Users: `r`n" | out-file $Report -Append
        $RDU = get-localgroupmember "Remote Desktop Users"
        if ($RDU -eq $null) {"`r`n None `r`n`r`n" | out-file $Report -append}
        else {"`r`n $RDU `r`n`r`n" | out-file $Report -append} 
    } else {
        $localadmin = net localgroup Administrators | where {$_ -NotMatch "command completed successfully"}
        $RDU = net localgroup "Remote Desktop Users" | where {$_ -NotMatch "command completed successfully"}
        "`r`n $localadmin `r`n $RDU `r`n`r`n" | out-file $Report -append
    }
}

function PowerPlanSetting{
    
    Titlebox -SubjectTitle "Power Plan Setting"
    $powerplansetting = powercfg /getactivescheme
    "`r`n$powerplansetting`r`n`r`n" | out-file $Report -Append
}


function WinodwsActivation{

    Titlebox -SubjectTitle "Windows Activation Status"

    $windowsversion = $CPUinfo.OsName

    "`r`n$windowsversion`r`n" | Out-File $Report -Append

    $activ = Get-CIMInstance -query "select Name, Description, LicenseStatus from SoftwareLicensingProduct where LicenseStatus=1" | select -ExpandProperty LicenseStatus
    $ActivationStatus = "Failed: Windows Operating System Version is NOT Activated. ***Please rectify***"
    if ($activ -eq "1") { $ActivationStatus = "Passed: Windows Operating System Version is Activated" }
    
    "`r`n$ActivationStatus`r`n`r`n" | out-file $Report -Append
}

#function FailoverCluster{
#
 #   Titlebox -SubjectTitle "Failover Cluster Setting"
#
#    if ((Get-WindowsFeature RSAT-Clustering).InstallState -eq "Installed") {    
#        $error[0] = $null            
#        $cluster = (Get-Cluster).name 
 #   
#        if ($error[0] -eq $null) {
#    
#            $clusternode = get-clusternode -cluster $cluster | Out-String
 #           $clustergroup = get-clustergroup -cluster $cluster | Out-String
 #           $clusterresource = get-clusterresource -cluster $cluster | Out-String
#     
#            $clusteraccount = "SQL_$cluster"
#            $clusterSPN = setspn -l $clusteraccount
#     
#            "`r`nCluster name: $cluster`r`nCluster nodes:`r`n$($clusternode.ToString())`r`nCluster Groups:`r`n$clustergroup`r`nCluster Resource:`r`n$clusterresource`r`nCluster SPNs:`r`n" | Out-File $Report -Append
#            $clusterSPN | % {$_ } | Out-File $Report -Append
#
 #           } else {            
#            "`r`nFailover Cluster feature is installed but not configured.`r`n`r`n" | Out-File $Report -Append
#        }
#    } else { 
#        "`r`nNo Failover Cluster service on this server`r`n`r`n" | Out-File $Report -Append
#    }
#}

function AdminPwdExpire{    
    
    Titlebox -SubjectTitle "Local Admin password expiration"       
    $ex = get-localuser -Name Administrator | select -ExpandProperty passwordexpires   
    if (!($ex) ) { 
        "`r`nPassed: Password set to never expire.`r`n" | Out-File $Report -Append
    } else {
        "`r`nFailed: Password was NOT set to never expire. ***Please rectify***`r`n"| Out-File $Report -Append
    }   
}  

function WindowsUpdates{
    try {
    $NotificationLevels = @{ 0="0 - Not configured"; 1="1 - Disabled"; 2="2 - Notify before download"; 3="3 - Notify before installation"; 4="4 - Scheduled installation"; 5="5 - Users configure" }
    $ScheduledInstallationDays = @{ 0="0 - Every Day"; 1="1 - Every Sunday"; 2="2 - Every Monday"; 3="3 - Every Tuesday"; 4="4 - Every Wednesday"; 5="5 - Every Thursday"; 6="6 - Every Friday"; 7="7 - EverySaturday" }
    $RegistryKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]"LocalMachine",$servername) 
    $RegistrySubKey1 = $RegistryKey.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\") 
    $RegistrySubKey2 = $RegistryKey.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU\")                
       
    Titlebox -SubjectTitle "Windows Update"
    
    $Result = New-Object -TypeName PSObject
        Try {
            Foreach($RegName in $RegistrySubKey1.GetValueNames()) { 
                $Value = $RegistrySubKey1.GetValue($RegName) 
                $Result | Add-Member -MemberType NoteProperty -Name $RegName -Value $Value
            }
            Foreach($RegName in $RegistrySubKey2.GetValueNames()) { 
                $Value = $RegistrySubKey2.GetValue($RegName) 
                Switch($RegName) {
                    "AUOptions" { $Value = $NotificationLevels[$Value] }
                    "ScheduledInstallDay" { $Value = $ScheduledInstallationDays[$Value] }
                }
                $Result | Add-Member -MemberType NoteProperty -Name $RegName -Value $Value
            }
        } Catch {
            $result = "Could not find registry subkey: HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate. Probably you are not using Group Policy for Windows Update settings."
        }
    $result | Out-file $Report -Append
    } Catch {
        "Could not get Windows Update Registry values." | Out-file $Report -Append
    } 
                         
    $winhotfix = Get-HotFix | sort -Property InstalledOn -Descending
    "`r`n$($winhotfix.count) updates Installed" | Out-file $Report -Append
    $winhotfix | select "HotfixID", "InstalledON" | Out-file $Report -Append  
    $pendingupdates = Get-WindowsUpdate
                if ($pendingupdates -ne $NULL){
                "`r`nUpdates pending `r`n" | Out-file $Report -Append  
                $pendingupdates | % {$_ | select KB,Title} | Out-file $Report -Append  
                } else{
                "`r`nThere is no pending updates" | Out-file $Report -Append  
                }


}

function FeaturesInstalled{
    
    Titlebox -SubjectTitle "Extra Windows Feature installed"
    $ExcluedFeatures = @("FileAndStorage-Services", 
                         "File-Services", 
                         "FS-FileServer", 
                         "Storage-Services",
                         "RDC",
                         "RSAT",  
                         "RSAT-Feature-Tools",
                         "RSAT-Role-Tools",
                         "RSAT-AD-Tools",
                         "RSAT-AD-PowerShell",
                         "FS-SMB1",
                         "User-Interfaces-Infra",
                         "Server-Gui-Mgmt-Infra",
                         "Server-Gui-Shell",
                         "PowerShellRoot",
                         "PowerShell",
                         "PowerShell-ISE",
                         "WoW64-Support")     

    $InstalledFeatures = Get-WindowsFeature | where-object { $_.installed -eq $true } | where name -NotIn $ExcluedFeatures | Out-String
    $InstalledFeatures | Out-File $Report -Append
    If ( Get-WindowsFeature | where-object { ($_.name -like "Windows-Defender*") -and ($_.installstate -eq "Installed")} ) {
        "`r`nWinodws Defender is installed. Please removed this feature.`r`n" | Out-File $Report -append
    }
}

function BGinfo{

    Titlebox -SubjectTitle "BG info"            
    $bgin = get-ItemProperty -path HKLM:\SOFTWARE\BGinfo
    $bgin | Out-File $Report -Append  
    
}

function SharesInfo{

    Titlebox -SubjectTitle "File Share configuration"
    $smbshare = $null
    $smbshare = Get-SmbShare | where {$_.special -eq $False}
    if ($smbshare -eq $null) {
        "`r`nNo extra share configured.`r`n`r`n" | Out-File $Report -Append
    } else {
        foreach ($smb in $smbshare){
            $output += "`r`nShare Name: $($smb.name)`r`n`r`n"
            $output += "Share Permissions($($smb.name)):`r`n"
            $output += repeat-string "=" 70 + "`r`n`r`n"
            $output += Get-SmbShareAccess ($smb).name | select Accountname, AccessControlType, AccessRight | ft -wrap | out-string
            $output += "Folder NTFS Permissions($($smb.name)):`r`n"
            $output += repeat-string "=" 70 + "`r`n`r`n" 
            $output += (get-acl ($smb).Path).Access | select IdentityReference, AccessControlType, FileSystemRights | ft -wrap | out-string            
        }
        $output | Out-File $Report -Append
    }
} 

function SchedTask{

    Titlebox -SubjectTitle "Task Scheduler"
            
    $SchedTasks = @();
    ForEach ($Task in (Get-ChildItem -Path "C:\Windows\System32\Tasks" -File)){
        $TaskPrincipal = ([XML](Get-Content -Path $Task.FullName)).Task.Principals.Principal
        $TaskRegistrationInfo = ([XML](Get-Content -Path $Task.FullName)).Task.RegistrationInfo
        $usersid = $TaskPrincipal.UserId | select-string "S-1"
        if ($usersid){
            if ($usersid -eq "S-1-5-8"){
                $TaskPrincipal.UserId = "System"} else {
                    $username = (Get-ADUser -Filter * | Select-Object -Property SID,Name | Where-Object -Property SID -like "$usersid").name
                    if (!($username)){$username = "Unknown user"
                }
            $TaskPrincipal.UserId = "$username"
            }
        }
        $SchedTasks += [PSCustomObject]@{"TaskName" = "$($Task.Name)"; "Author" = $TaskRegistrationInfo.Author; "User" = $TaskPrincipal.UserId; "RunLevel" = $TaskPrincipal.RunLevel; }
    }

    $SchedTasks = $SchedTasks | Where {($_.User -notlike "") -or ($_.User -ne "system" ) -or ($_.User -notlike "s-1-5-21*") -or ($_.Taskname -notlike "Optimize Start Menu Cache Files-S-1-5-21-*-500")} | Out-String
         
    if (!($SchedTasks)){
        "`r`nThere are no non-default Scheduled Tasks.`r`n`r`n" | Out-File -width 230 $Report -Append
    } else{
        "`r`nThere are non-default scheduled tasks.`r`n`r`n $SchedTasks" | Out-File -width 230 $Report -Append
    }              
} 

function EventlogSizeCheck{

    Titlebox -SubjectTitle "Event Log Configuration"

    $output = Get-Eventlog -list | Where {($_.LogDisplayName -eq "Application") -or ($_.LogDisplayName -eq "Security") -or ($_.LogDisplayName -eq "System")}
    $output = $output | Select LogDisplayName, MaximumKilobytes, OverflowAction
    $output | Out-String | Out-File $Report -Append 
    if ($output | Where { $_.MaximumKilobytes -lt 50Mb / 1Kb }){
        "Failed: One or more event log size setting is less than 50MB.***Please rectify settings***`r`n" | Out-File $Report -Append 
    }else { 
        "Passed: Eventlog size check`r`n" | Out-File $Report -Append 
    }    
}

function Privilegesassigned{
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zipfile = "c:\temp\PoshPrivilege.zip"
    $unzipfolder = "c:\temp\PoshPrivilege"
    $outpath = "c:\temp"
    $modulefolder = "C:\Program Files\WindowsPowerShell\Modules"
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipfile, $outpath)
    Copy-Item $unzipfolder $modulefolder -Recurse -Force
    Remove-item $zipfile
    Remove-item $unzipfolder
    import-module poshprivilege

    Titlebox -SubjectTitle "Privilege assigned accounts"

    $results = get-privilege -computername $clientname -privilege SeBatchLogonRight,SeServiceLogonRight 

    $results | %{
        if ($_.privilege -like "SeBatchLogonRight"){$privilege = '"Logon as a batch"'}
        if ($_.privilege -like "SeServiceLogonRight"){$privilege = '"Logon as a service"'}
        $Accounts = $_.Accounts
        if ($Accounts){
            "`nMembers of $($privilege):`n" | out-file $Report -append
            $Accounts | out-file $Report -append
            } else {
            "`n$privilege does not contain any members`n" | out-file $Report -append
        }
    }

}

function VMtoolCheck{

    Titlebox -SubjectTitle "VMware/Nutanix tool check"
    
    if ($SystemInfo.Manufacturer -like "*VMware*"){
        
        if (!(Get-Process | where name -like "*vmtool*")){
            $VMTools = "`r`nFailed: VMware Tools are NOT running! Please rectify!`r`n"
        } else {
            $VMTools = "`r`nPassed: VMware Tools are running.`r`n"
        }
    }
    
    if ($SystemInfo.Manufacturer -like "*nutan*"){
        
        if (!(Get-Process | where name -like "*pythonservice*")){
            $VMTools = "`r`nFailed: Nutanix Tools are NOT running! Please rectify!`r`n"
        } else {
            $VMTools = "`r`nPassed: Nutanix Tools are running.`r`n"
        }    
    }

    if ($SystemInfo.Manufacturer -like "Dell*"){
        $VMTools = "`r`nPassed: Not require for physical server.`r`n"   
    }
    
    $vmtools | Out-File $Report -Append
} 

function AppsAgentCheck {

    titlebox -SubjectTitle "Applications agent check"

    if (!(Get-Process | where name -like "xagt")){
            $FireEye = "`r`nPassed: Obsolete FireEyeHX agent is not presented. `r`n"
        } else {
            $FireEye = "`r`nFailed: Obsolete FireEyeHX agent is running. Please ensure that SentinelOne is running.`r`n"
        } 
    $FireEye | Out-File $Report -Append

    if (!(Get-Process | where {$_.processname -like "cca" -or $_.processname -like "amagent"})){
            $Appsense = "`r`nFailed: Appsense agent is NOT running! Please rectify!`r`n"
        } else {
            $Appsense = "`r`nPassed: Appsense agent is running.`r`n"
        } 
    $Appsense | Out-file $Report -Append

    if (!(Get-Process | where name -like "sentinelagent")){
            $SentinelOne = "`r`nFailed: SentinelOne agent processes are NOT running! Please rectify!`r`n"
        } else {
            $SentinelOne = "`r`nPassed: SentinelOne agent processes are running.`r`n"
        } 
    $SentinelOne | Out-file $Report -Append

}

function Uptime{

    Titlebox -SubjectTitle "System Up time"

    $lastRebootDate = (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime 
    "`r`nLast rebooted occurred $($lastrebootdate.tostring("dd MMM yyyy")) at time this QA report generated $(get-date -UFormat '%c')`r`n" | Out-File $Report -Append
}

#function Cleanup-install-folders{
#    
#    param([string]$cleanpath)
#
#    if ( $(Try { Test-Path $cleanpath } Catch { $false })){
#        
#        rmdir $cleanpath -force -Recurse
#    }    
#}

#function CleanupAgentInstall{
#  
#    Cleanup-install-folders "C:\temp\hppa"
#    Cleanup-install-folders "C:\temp\sccm"
#    Cleanup-install-folders "C:\temp\ODAC110203_x64"
#    Cleanup-install-folders "c:\temp\OracleClient_11.2.0.4_x86"
#    Cleanup-install-folders "C:\temp\SQLEXPRWT_x64_ENU"
#    Cleanup-install-folders "C:\temp\networker"
#}

function IISLogFolder{
        
    if (Get-Command get-webconfiguration -ErrorAction SilentlyContinue){                  
        Titlebox -SubjectTitle "IIS Log folder location"                                  
        $iisdef = get-webconfiguration /System.Applicationhost/Sites/SiteDefaults/logfile | select dir* | Out-String
        $iisdef | Out-File $Report -Append
    }   
}

function ServicesCheck{
    
    Titlebox -SubjectTitle "Service Check"
    
    $string = Get-WmiObject win32_service | where Startname -notlike "NT AUTHORITY\*"  | where Startname -ne  "LocalSystem" | where Startname -notlike  "NT Service\*" | ft name, Displayname, startname -wrap
    if ($string) { $servicesrunning = $string } 
    else 
    { $servicesrunning = "`r`nThere are No Services running as a user.`r`n" }     
    $servicesrunning | Out-File $Report -Append        
}

function EventlogErrorsCheck{   
    $ReportPeriod=1
    Titlebox -SubjectTitle "Event Logs for the last $ReportPeriod day/s from $(get-date -UFormat '%c')"
            
    $evt0 = Get-WinEvent -ListLog "Application", "System", "Security", "AppSense", "ManageSoft" -ErrorAction SilentlyContinue | Where RecordCount -gt 0 |`
        ForEach-Object -Process { Get-WinEvent -FilterHashtable @{LogName = $_.LogName; StartTime = (Get-Date).AddDays(-$reportperiod); Level = 1, 2, 3 } -ErrorAction SilentlyContinue }
        
    if ($evt0.Count -gt 0) {
        $evt1 = $evt0 | Select-Object LogName, LevelDisplayName, Id, Level, TimeCreated, Message | sort LogName | ft -auto | Out-String -width 230
    }else {
        $evt1 = "`r`nNo errors detected in the last $ReportPeriod day/s`r`n"
    }
    $evt1 | Out-File -width 230 $Report -Append   
}

function VisualPerformance{

    Titlebox -SubjectTitle "Windows Visual Effect Performance"
         
    #$perf = Get-ItemProperty -path registry::HKEY_USERS\.default\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects
    
    $perf = Get-ItemProperty -path registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects -ErrorAction SilentlyContinue
                 
    if ( $perf.VisualFXSetting -eq "2"){
        "`r`nPassed: Server visual effect is set for Best Performance. `r`n" | Out-File $Report -Append
    } else {
        "`r`nFailed: Visual effects is NOT set correctly. Please set it for Best Performance.`r`n" | Out-File $Report -Append
    }                                                              
}

function SoftwareInstalled{

    Titlebox -SubjectTitle "Software Installed"

    $smallline = repeat-string "=" 12
    $x64Apps = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | sort displayname | Select-Object DisplayName, Publisher, DisplayVersion | Where-Object {$_.DisplayName -ne $null} | ft -wrap | Out-String
    $x32Apps = Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName, Publisher, DisplayVersion | Where-Object {$_.DisplayName -ne $null} | ft -wrap | Out-String 
 
    $oracleversion = "`r`nNo Oracle client installed."

    $64 = get-itemproperty -path Registry::HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE\*

    $32 = get-itemproperty -path Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\ORACLE\*
    function oracleinstalled{
    "Oracle client installed `n" | Out-File $Report -Append
    }
    if ($64){
    oracleinstalled
    $oracleversion = $64.ORACLE_GROUP_NAME}
    if ($32){
    oracleinstalled
    $oracleversion = $32.ORACLE_GROUP_NAME}

    $oracleversion  | Out-File $Report -Append          
    "`r`n64 BIT Apps`r`n$smallline`r`n$x64Apps" | Out-File $Report -Append             
    "32 BIT Apps`r`n$smallline`r`n$x32Apps" | Out-File $Report -Append          
}   

function CheckNTP{

    Titlebox -SubjectTitle "NTP setting"
    "`r`n" | Out-File $Report -Append
    w32tm /query /status | Out-File $Report -Append    
    "`r`n" | Out-File $Report -Append
}

#function HQR{
#    $outline = "$servername,,Deploying,$CPUinfo.OsName,"
#
#}

#function dotNetVersion{
#    Titlebox -SubjectTitle ".Net Framework"
#    "`r`n" | Out-File $Report -Append
#    ####Testing .NET 2.0.%#######
#    foreach ($netitem in gci -Path 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP'){
#        if ($netitem.name -like "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v2.0*"){
#        $version = $netitem.name.trimstart("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\")
#        ".NET framework version: $version" | Out-File $Report -Append
#        }

#    }
#    ####Testing .NET 3 and 3.5#####
#   $dotnetver = @("3.0","3.5")
#    foreach ($version in $dotnetver){
#        test-path "HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v$version"
#        ".NET framework version: $version" | Out-File $Report -Append
#        }

#    $release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
#    switch ($release) {
#        { $_ -ge 460798 } { $version = '4.7'}
#        { $_ -ge 461308 } { $version = '4.7.1'}
#        { $_ -ge 461808 } { $version = '4.7.2'}
#        { $_ -ge 528040 } { $version = '4.8'}
 #       { $_ -ge 533320 } { $version = '4.8.1 or later'}
 #       default { $version = $null}
#    }
#    if ($version){
#        ".NET framework version: $version" | Out-File $Report -Append
#    } else {
 #       ".NET framework version 4.7 or later is not detected." | Out-File $Report -Append
 #   }
#    try{ if (get-command dotnet -erroraction stop) {
#            $core_version=dotnet --info
#      	    ".net Core $($core_version[5])" | Out-File $Report -Append}    
#    } catch [System.Management.Automation.CommandNotFoundException] {".net Core is not installed" | Out-File $Report -Append}
#    "`r`n" | Out-File $Report -Append
#}

function SCOMAgentCheck{
    Titlebox -SubjectTitle "SCOM Monitoring service check"
    $scomcheck = get-service | where {$_.name -like "HealthService"} | select Displayname,name,status
        if ($scomcheck){
        "`r`n" | Out-File $Report -Append
        $scomcheck | Out-File $Report -Append
            } else {
                "`r`nSCOM service is not installed on the server`r`n" | Out-File $Report -Append
      }
}

function SCCMAgentCheck{
Titlebox -SubjectTitle "SCCM Monitoring service check"
$sccmstate = (Get-WmiObject Win32_Service -ErrorAction silentlycontinue |Where-Object {$_.name -eq "ccmexec"}).state
if($sccmstate){
    "`r`n" | Out-File $Report -Append
    "SCCM client is installed and $sccmstate" | Out-File $Report -Append
    $sccmversion = (Get-WMIObject -namespace "root\ccm" -class sms_client).clientversion
    "SCCM client version is $sccmversion" | Out-File $Report -Append
    $sccmclient = Get-WmiObject -list -Namespace root\ccm -Class SMS_client -ErrorAction silentlycontinue
        try {
            $SCCMSite = ($sccmclient.GetAssignedSite()).sSiteCode
                } catch {
            }
        if ($SCCMSite -ne $NULL){
            "SCCM client is connected to $SCCMSite site" | Out-File $Report -Append
            } else {
            "SCCM client is not connected to any SCCM site" | Out-File $Report -Append
            }
                } else {
                "SCCM client is not installed" | Out-File $Report -Append
            }
}

#function CopyResult{
#    $dest = "\\$($Mgtserver)\temp"
#    $src = "$($path)\$($clientname)_QA_report.txt"
#    copy-item $src $dest
#    
#    remove-item $src
#}

function Main{
    Titlebox -SubjectTitle "Discovery report of $servername on $date"
    "`r`nDiscovery Script ver $qa_ver`r`n" | Out-File $Report -Append
    CPU
    NetworkConfig
    NetworkConfigDetailed
    Uptime       
    CheckNTP
    PowerPlanSetting
    #WinodwsActivation
    #WindowsUpdates    
    #FailoverCluster
    #AdminPwdExpire
    FeaturesInstalled
    #Privilegesassigned
    #BGinfo
    SharesInfo
    LocalGroup
    #DDBoostcheck
    #SchedTask
    #EventlogSizeCheck
    #EventlogErrorsCheck
    #VMtoolCheck
    AppsAgentCheck
    SCOMAgentCheck
    SCCMAgentCheck   
    #IISLogFolder
    ServicesCheck
    #VisualPerformance
    #dotNetVersion
    SoftwareInstalled
    #Domain_OU 
    #CleanupAgentInstall
    #Cleanup-install-folders
}
        
$servername = $env:COMPUTERNAME
$date = get-date -Format "dd MMM yyyy"
$Report = "$path\$($servername)_Discovery_Report.txt"
Out-File $Report
$qa_ver = "2.0"

 
main
#CopyResult