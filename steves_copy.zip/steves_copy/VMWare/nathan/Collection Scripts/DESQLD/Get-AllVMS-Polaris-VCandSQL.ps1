# Import VMware PowerCLI module
Import-Module VMware.PowerCLI

# Opt out of CEIP
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false

# Suppress SSL certificate warnings
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false

# Prompt for credentials for each domain
$vCenterCredentials = Get-Credential -Message "Enter credentials for connecting to the vCenter server"
$desqldCredentials = Get-Credential -Message "Enter credentials for desqld.internal domain - Please use DESQLD\\username"
$psbaCredentials = Get-Credential -Message "Enter credentials for psba.qld.gov.au domain - Please use PSBA\\username"
$volunteersCredentials = Get-Credential -Message "Enter credentials for volunteers.internal domain - Please use VOLS\\username"

# Connect to vCenter Server using the provided credentials
$vCenterServer = "polshrvcs01.desqld.internal"
Connect-VIServer -Server $vCenterServer -Credential $vCenterCredentials

# Specify the base directory for output
$baseOutputDir = "E:\\nathan\\polaris\\"

# Variable to limit the number of servers processed (for testing purposes)
$limitServersToProcess = 5000  # Change this number to limit the number of VMs processed

# Initialize an empty array to hold VM information
$vmList = @()

# Step 1: Get the list of servers
Write-Output "Step 1: Starting collection of base VM information..."
$vmCollection = Get-VM | Select-Object -First $limitServersToProcess

$vmCollection | ForEach-Object {
    $vm = $_

    # Ensure $vm is a valid VirtualMachine object
    if ($vm -is [VMware.VimAutomation.ViCore.Types.V1.Inventory.VirtualMachine]) {
        Write-Output "Processing VM: $($vm.Name)"

        # Collect the base VM data
        $dnsName = $vm.Guest.HostName

        # Store the base information in a temporary object
        $vmInfo = New-Object PSObject -Property @{
            VMWare_Name               = $vm.Name
            VMWare_GuestOS            = $vm.ExtensionData.Config.GuestFullName
            VMWare_PowerState         = $vm.PowerState
            VMWare_DNSName            = $dnsName
            Netstat_0_0_0_0           = ""
            Netstat_Other             = ""
            ErrorOutput               = ""
        }

        # Check VM Guest is on skip list - Specifically exclude them
        if ($vmInfo.VMWare_Name -eq "SOCCFIL10" -or $vmInfo.VMWare_Name -eq "BNEAPP22" -or $vmInfo.VMWare_Name -eq "BNEEVP01") {
            $vmInfo.ErrorOutput += "VM is in on the skip guest list. "
            Write-Output "VM: $($vmInfo.VMWare_Name) is on the skip guest list. Skipping information collection."
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Check Power State before proceeding
        if ($vmInfo.VMWare_PowerState -ne "PoweredOn") {
            $vmInfo.ErrorOutput += "VM is in a Powered Off State. "
            Write-Output "VM: $($vmInfo.VMWare_Name) is powered off. Skipping information collection."
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Check if the Guest OS is a Windows machine
        if ($vmInfo.VMWare_GuestOS -notlike "Microsoft Windows*") {
            $vmInfo.ErrorOutput += "VM is not running a Windows OS: $($vmInfo.VMWare_GuestOS). "
            Write-Output "VM: $($vmInfo.VMWare_Name) is not running a Windows OS. Skipping information collection."
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Validate DNS Name before proceeding
        if (-not $vmInfo.VMWare_DNSName -or $vmInfo.VMWare_DNSName -notmatch "\.") {
            $vmInfo.ErrorOutput += "VM has an invalid DNS name: $($vmInfo.VMWare_DNSName). "
            Write-Output "VM: $($vmInfo.VMWare_Name) has an invalid DNS name. Skipping information collection."
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Determine the appropriate domain credentials based on DNS name
        $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)
        $credential = switch ($domainName) {
            "desqld.internal" { $desqldCredentials }
            "psba.qld.gov.au" { $psbaCredentials }
            "volunteers.internal" { $volunteersCredentials }
            default { 
                $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                continue
            }
        }

        # Step 2: Collect Netstat -a information and process it
        $script = @"
netstat -a | Select-String -Pattern ':1471'
"@

        try {
            $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType 'Powershell'
            $netstatLines = $scriptResult.ScriptOutput.Split("`n") | Where-Object { $_ -match ':1471' }

            # Arrays to hold the results for 0.0.0.0 and others
            $netstat_0_0_0_0 = @()
            $netstat_Other = @()

            # Process each line to extract the value before ':1471'
            foreach ($line in $netstatLines) {
                if ($line -match '(\S+):1471') {
                    $value = $matches[1]
                    if ($value -eq '0.0.0.0') {
                        $netstat_0_0_0_0 += $value
                    } else {
                        $netstat_Other += $value
                    }
                }
            }

            # Assign the results to the VM object
            $vmInfo.Netstat_0_0_0_0 = $netstat_0_0_0_0 -join ", "
            $vmInfo.Netstat_Other = $netstat_Other -join ", "

            Write-Output "Collected Netstat information for VM: $($vmInfo.VMWare_Name)"
        } catch {
            Write-Output "Failed to collect Netstat information for VM: $($vmInfo.VMWare_Name)"
            $vmInfo.ErrorOutput += "Failed to collect Netstat information. Error: $_"
        }

        # Ensure $vmInfo is added to the list after the collection
        $vmList += $vmInfo  # Ensure the $vmInfo is added to $vmList
    }
}

# Step 3: Export VM configuration information to a CSV file
Write-Output "Step 3: Exporting VM configuration information to CSV..."
$vmList | Select-Object `
    VMWare_Name,
    VMWare_GuestOS,
    VMWare_PowerState,
    VMWare_DNSName,
    Netstat_0_0_0_0,
    Netstat_Other,
    ErrorOutput |
    Export-Csv -Path "$($baseOutputDir)VM_Netstat_Info.csv" -NoTypeInformation -UseCulture

# Disconnect from vCenter Server
Disconnect-VIServer -Server $vCenterServer -Confirm:$false

# Output the location of the CSV file
Write-Output "VM Netstat information exported to $($baseOutputDir)VM_Netstat_Info.csv"
