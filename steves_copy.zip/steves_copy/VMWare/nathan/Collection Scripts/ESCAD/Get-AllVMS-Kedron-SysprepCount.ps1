# Import VMware PowerCLI module
#Import-Module VMware.PowerCLI

# Opt out of CEIP
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false

# Suppress SSL certificate warnings
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false

# Prompt for credentials for each domain
$vCenterCredentials = Get-Credential -Message "Enter credentials for connecting to the vCenter server"
$escadCredentials = Get-Credential -Message "Enter credentials for escad.internal domain - Please use ESCAD\\username"


# Connect to vCenter Server using the provided credentials
$vCenterServer = "kedpreshrvms01.precad.internal"
Connect-VIServer -Server $vCenterServer -Credential $vCenterCredentials

# Specify the base directory for output
$baseOutputDir = "C:\\temp\\nathan\\kedron\\"

# Variable to limit the number of servers processed (for testing purposes)
$limitServersToProcess = 30  # Change this number to limit the number of VMs processed

# Initialize an empty array to hold VM information
$vmList = @()

# Step 1: Get the list of servers
Write-Output "Step 1: Starting collection of base VM information..."
$vmCollection = Get-VM | Select-Object -First $limitServersToProcess

$vmCollection | ForEach-Object {
    $vm = $_

    # Ensure $vm is a valid VirtualMachine object
    if ($vm -is [VMware.VimAutomation.ViCore.Types.V1.Inventory.VirtualMachine]) {
        Write-Output "Processing VM: $($vm.Name)"

        # Collect the base VM data
        $dnsName = $vm.Guest.HostName

        # Store the base information in a temporary object
        $vmInfo = New-Object PSObject -Property @{
            VMWare_Name               = $vm.Name
            VMWare_GuestOS            = $vm.ExtensionData.Config.GuestFullName
            VMWare_PowerState         = $vm.PowerState
            VMWare_DNSName            = $dnsName
            SysprepGeneralizedCount   = ""
            ErrorOutput               = ""
        }

        # Check Power State before proceeding
        if ($vmInfo.VMWare_PowerState -ne "PoweredOn") {
            $vmInfo.ErrorOutput += "VM is in a Powered Off State. "
            Write-Output "VM: $($vmInfo.VMWare_Name) is powered off. Skipping information collection."
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Check if the Guest OS is a Windows machine
        if ($vmInfo.VMWare_GuestOS -notlike "Microsoft Windows*") {
            $vmInfo.ErrorOutput += "VM is not running a Windows OS: $($vmInfo.VMWare_GuestOS). "
            Write-Output "VM: $($vmInfo.VMWare_Name) is not running a Windows OS. Skipping information collection."
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Validate DNS Name before proceeding
        if (-not $vmInfo.VMWare_DNSName -or $vmInfo.VMWare_DNSName -notmatch "\.") {
            $vmInfo.ErrorOutput += "VM has an invalid DNS name: $($vmInfo.VMWare_DNSName). "
            Write-Output "VM: $($vmInfo.VMWare_Name) has an invalid DNS name. Skipping information collection."
            $vmList += $vmInfo  # Ensure $vmInfo is added to the list
            return
        }

        # Determine the appropriate domain credentials based on DNS name
        $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)
        $credential = switch ($domainName) {
            "escad.internal" { $escadCredentials }
            default { 
                $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                continue
            }
        }

        # Step 2: Collect Sysprep Generalize Count
        $logFilePath = "C:\Windows\System32\Sysprep\Panther\setupact.log"
        $script = @"
if (Test-Path -Path '$logFilePath') {
    (Select-String -Path '$logFilePath' -Pattern 'SYSPRP RunGeneralize').Count
} else {
    'Log file not found'
}
"@

        try {
            $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType 'Powershell'
            $sysprepCount = $scriptResult.ScriptOutput.Trim()

            # Print the output of the script to the console for debugging
            Write-Output "Sysprep count script output for VM $($vmInfo.VMWare_Name): $sysprepCount"

            if ($sysprepCount -match '\d+') {
                $vmInfo.SysprepGeneralizedCount = [int]$sysprepCount
            } else {
                $vmInfo.SysprepGeneralizedCount = "Error: $sysprepCount"
            }

            Write-Output "Collected Sysprep count for VM: $($vmInfo.VMWare_Name)"
        } catch {
            Write-Output "Failed to collect Sysprep count for VM: $($vmInfo.VMWare_Name)"
            $vmInfo.ErrorOutput += "Failed to collect Sysprep count. Error: $_"
        }

        # Ensure $vmInfo is added to the list after the collection
        $vmList += $vmInfo  # Ensure the $vmInfo is added to $vmList
    }
}

# Step 3: Export VM configuration information to a CSV file
Write-Output "Step 3: Exporting VM configuration information to CSV..."
$vmList | Select-Object `
    VMWare_Name,
    VMWare_GuestOS,
    VMWare_PowerState,
    VMWare_DNSName,
    SysprepGeneralizedCount,
    ErrorOutput |
    Export-Csv -Path "$($baseOutputDir)VM_Sysprep_Count.csv" -NoTypeInformation -UseCulture

# Disconnect from vCenter Server
Disconnect-VIServer -Server $vCenterServer -Confirm:$false

# Output the location of the CSV file
Write-Output "VM Sysprep count information exported to $($baseOutputDir)VM_Sysprep_Count.csv"
