# Get the hostname 
$hostname = $env:COMPUTERNAME 
$outputFile = "\\kedcadshrjmp01\c$\temp\nathan\IBG_QA_reports\$hostname.txt" 

# Initialize the output file 
Out-File -FilePath $outputFile -Force 

# Collect system information using 'systeminfo' 
Write-Output "=== System Information ===" | Out-File -Append -FilePath $outputFile 
systeminfo | Out-File -Append -FilePath $outputFile 

# Collect CPU Information
Write-Output "=== CPU Information ===" | Out-File -Append -FilePath $outputFile 
Get-WmiObject Win32_Processor | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed | ft -wrap | Out-File -Append -FilePath $outputFile

# Collect Network Information
Write-Output "`n=== Network Information ===" | Out-File -Append -FilePath $outputFile 
Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled = TRUE" | ForEach-Object { 

    [PSCustomObject]@{ 
        InterfaceIndex = $_.InterfaceIndex 
        Description    = $_.Description 
        MACAddress     = $_.MACAddress 
        IPAddress      = ($_.IPAddress -join ", ") 
        SubnetMask     = ($_.IPSubnet -join ", ") 
        DefaultGateway = ($_.DefaultIPGateway -join ", ") 
        DHCPEnabled    = $_.DHCPEnabled 
    } 
} | Format-Table -AutoSize | Out-String | Out-File -Append -FilePath $outputFile 

# Collect disk information 
Write-Output "`n=== Disk Information ===" | Out-File -Append -FilePath $outputFile 
Get-WmiObject Win32_LogicalDisk | Select-Object DeviceID, @{Name='SizeGB';Expression={[math]::round($_.Size/1GB, 2)}}, @{Name='FreeSpaceGB';Expression={[math]::round($_.FreeSpace/1GB, 2)}}, FileSystem | Format-Table -AutoSize | Out-String | Out-File -Append -FilePath $outputFile 

# Collect installed software information 
Write-Output "`n=== Installed Software ===" | Out-File -Append -FilePath $outputFile 
Get-WmiObject -Class Win32_Product | Select-Object Name, Version, Vendor | ft -wrap | Out-File -Append -FilePath $outputFile

# Completion message 
Write-Output "Information has been saved to $outputFile" 
