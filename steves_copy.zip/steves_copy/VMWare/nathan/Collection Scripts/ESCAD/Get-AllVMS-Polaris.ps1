# PowerShell script to connect to vCenter Server, retrieve VM information, collect system, network, disk, shared folders, local users, local groups, services, certificates, installed applications, firewall status, firewall rules, and additional information, and export it to text files.

# Import VMware PowerCLI module
#Import-Module VMware.PowerCLI

# Opt out of CEIP
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false

# Suppress SSL certificate warnings
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false

# Prompt for credentials for each domain
$vCenterCredentials = Get-Credential -Message "Enter credentials for connecting to the vCenter server"
$escadCredentials = Get-Credential -Message "Enter credentials for escad.internal domain - Please use ESCAD\\username"


# Connect to vCenter Server using the provided credentials
$vCenterServer = "polcadshrvms01.escad.internal"
Connect-VIServer -Server $vCenterServer -Credential $vCenterCredentials

# Specify the base directory for output
$baseOutputDir = "C:\\temp\\nathan\\polaris\\"

# Variable to limit the number of servers processed (for testing purposes)
$limitServersToProcess = 1000  # Change this number to limit the number of VMs processed

# Initialize an empty array to hold VM information
$vmList = @()

# Step 1: Get the list of servers
Write-Output "Step 1: Starting collection of base VM information..."
$vmCollection = Get-VM | Select-Object -First $limitServersToProcess

$vmCollection | ForEach-Object {
    $vm = $_

    # Ensure $vm is a valid VirtualMachine object
    if ($vm -is [VMware.VimAutomation.ViCore.Types.V1.Inventory.VirtualMachine]) {
        Write-Output "Processing VM: $($vm.Name)"

        # Collect the base VM data
        $dnsName = $vm.Guest.HostName

        # Store the base information in a temporary object
        $vmInfo = New-Object PSObject -Property @{
            VMWare_Name               = $vm.Name
            VMWare_CPU                = $vm.ExtensionData.Config.Hardware.NumCPU
            VMWare_MemoryGB           = $vm.ExtensionData.Config.Hardware.MemoryMB / 1KB
            VMWare_DiskGB             = [math]::Round(($vm.ExtensionData.Summary.Storage.Committed / 1GB), 2)
            VMWare_GuestOS            = $vm.ExtensionData.Config.GuestFullName
            VMWare_PowerState         = $vm.PowerState
            VMWare_Host               = $vm.VMHost.Name
            VMWare_Cluster            = $vm.VMHost.Parent.Name
            VMWare_Datastore          = ($vm | Get-Datastore).Name -join ","
            VMWare_Network            = ($vm | Get-NetworkAdapter | ForEach-Object { $_.NetworkName }) -join ","
            VMWare_IPAddresses        = ($vm.Guest.IPAddress -join ",")
            VMWare_DNSName            = $dnsName
            SysInfo_OSName            = "N/A"
            SysInfo_OSVersion         = "N/A"
            SysInfo_Processor         = "N/A"
            Network_Interface1_IP     = "N/A"
            Network_Interface1_Subnet = "N/A"
            Network_Interface1_Gateway= "N/A"
            Network_Interface1_DNS1   = "N/A"
            Network_Interface1_DNS2   = "N/A"
            Network_Interface1_WINS1  = "N/A"
            Network_Interface1_WINS2  = "N/A"
            Network_Interface1_DNSDomain = "N/A"
            Network_Interface1_DNSSuffixes = "N/A"
            Network_Interface2_IP     = "N/A"
            Network_Interface2_Subnet = "N/A"
            Network_Interface2_Gateway= "N/A"
            Network_Interface2_DNS1   = "N/A"
            Network_Interface2_DNS2   = "N/A"
            Network_Interface2_WINS1  = "N/A"
            Network_Interface2_WINS2  = "N/A"
            Network_Interface2_DNSDomain = "N/A"
            Network_Interface2_DNSSuffixes = "N/A"
            Network_Interface3_IP     = "N/A"
            Network_Interface3_Subnet = "N/A"
            Network_Interface3_Gateway= "N/A"
            Network_Interface3_DNS1   = "N/A"
            Network_Interface3_DNS2   = "N/A"
            Network_Interface3_WINS1  = "N/A"
            Network_Interface3_WINS2  = "N/A"
            Network_Interface3_DNSDomain = "N/A"
            Network_Interface3_DNSSuffixes = "N/A"
            Network_Interface4_IP     = "N/A"
            Network_Interface4_Subnet = "N/A"
            Network_Interface4_Gateway= "N/A"
            Network_Interface4_DNS1   = "N/A"
            Network_Interface4_DNS2   = "N/A"
            Network_Interface4_WINS1  = "N/A"
            Network_Interface4_WINS2  = "N/A"
            Network_Interface4_DNSDomain = "N/A"
            Network_Interface4_DNSSuffixes = "N/A"
            Disk1_Letter              = "N/A"
            Disk1_Name                = "N/A"
            Disk1_TotalGB             = "N/A"
            Disk1_UsedGB              = "N/A"
            Disk2_Letter              = "N/A"
            Disk2_Name                = "N/A"
            Disk2_TotalGB             = "N/A"
            Disk2_UsedGB              = "N/A"
            Disk3_Letter              = "N/A"
            Disk3_Name                = "N/A"
            Disk3_TotalGB             = "N/A"
            Disk3_UsedGB              = "N/A"
            Disk4_Letter              = "N/A"
            Disk4_Name                = "N/A"
            Disk4_TotalGB             = "N/A"
            Disk4_UsedGB              = "N/A"
            Disk5_Letter              = "N/A"
            Disk5_Name                = "N/A"
            Disk5_TotalGB             = "N/A"
            Disk5_UsedGB              = "N/A"
            Disk6_Letter              = "N/A"
            Disk6_Name                = "N/A"
            Disk6_TotalGB             = "N/A"
            Disk6_UsedGB              = "N/A"
            Disk7_Letter              = "N/A"
            Disk7_Name                = "N/A"
            Disk7_TotalGB             = "N/A"
            Disk7_UsedGB              = "N/A"
            Disk8_Letter              = "N/A"
            Disk8_Name                = "N/A"
            Disk8_TotalGB             = "N/A"
            Disk8_UsedGB              = "N/A"
            Disk9_Letter              = "N/A"
            Disk9_Name                = "N/A"
            Disk9_TotalGB             = "N/A"
            Disk9_UsedGB              = "N/A"
            Disk10_Letter             = "N/A"
            Disk10_Name               = "N/A"
            Disk10_TotalGB            = "N/A"
            Disk10_UsedGB             = "N/A"
            Share1_Name               = "N/A"
            Share1_Path               = "N/A"
            Share1_Desc               = "N/A"
            Share2_Name               = "N/A"
            Share2_Path               = "N/A"
            Share2_Desc               = "N/A"
            Share3_Name               = "N/A"
            Share3_Path               = "N/A"
            Share3_Desc               = "N/A"
            Share4_Name               = "N/A"
            Share4_Path               = "N/A"
            Share4_Desc               = "N/A"
            Share5_Name               = "N/A"
            Share5_Path               = "N/A"
            Share5_Desc               = "N/A"
            Share6_Name               = "N/A"
            Share6_Path               = "N/A"
            Share6_Desc               = "N/A"
            Share7_Name               = "N/A"
            Share7_Path               = "N/A"
            Share7_Desc               = "N/A"
            Share8_Name               = "N/A"
            Share8_Path               = "N/A"
            Share8_Desc               = "N/A"
            Share9_Name               = "N/A"
            Share9_Path               = "N/A"
            Share9_Desc               = "N/A"
            Share10_Name              = "N/A"
            Share10_Path              = "N/A"
            Share10_Desc              = "N/A"
            Share11_Name              = "N/A"
            Share11_Path              = "N/A"
            Share11_Desc              = "N/A"
            Share12_Name              = "N/A"
            Share12_Path              = "N/A"
            Share12_Desc              = "N/A"
            Share13_Name              = "N/A"
            Share13_Path              = "N/A"
            Share13_Desc              = "N/A"
            Share14_Name              = "N/A"
            Share14_Path              = "N/A"
            Share14_Desc              = "N/A"
            Share15_Name              = "N/A"
            Share15_Path              = "N/A"
            Share15_Desc              = "N/A"
            User1                    = "N/A"
            User2                    = "N/A"
            User3                    = "N/A"
            User4                    = "N/A"
            User5                    = "N/A"
            User6                    = "N/A"
            User7                    = "N/A"
            User8                    = "N/A"
            User9                    = "N/A"
            User10                   = "N/A"
            LocalGroups              = "N/A"
            CollectionResult         = "Failure"
            ErrorOutput              = ""
        }

        # Check Power State before proceeding with System, Network, Disk Information, Share, and User collection
        if ($vmInfo.VMWare_PowerState -ne "PoweredOn") {
            $vmInfo.ErrorOutput += "VM is in a Powered Off State. "
            Write-Output "VM: $($vmInfo.VMWare_Name) is powered off. Skipping information collection."
            $vmInfo.CollectionResult = "Failure"
            $vmList += $vmInfo
            return
        }

        # Check if the Guest OS is a Windows machine
        if ($vmInfo.VMWare_GuestOS -notlike "Microsoft Windows*") {
            $vmInfo.ErrorOutput += "VM is not running a Windows OS: $($vmInfo.VMWare_GuestOS). "
            Write-Output "VM: $($vmInfo.VMWare_Name) is not running a Windows OS. Skipping information collection."
            $vmInfo.CollectionResult = "Skipped - Non-Windows OS"
            $vmList += $vmInfo
            return
        }

        # Validate DNS Name before proceeding
        if (-not $vmInfo.VMWare_DNSName -or $vmInfo.VMWare_DNSName -notmatch "\.") {
            $vmInfo.ErrorOutput += "VM has an invalid DNS name: $($vmInfo.VMWare_DNSName). "
            Write-Output "VM: $($vmInfo.VMWare_Name) has an invalid DNS name. Skipping information collection."
            $vmInfo.CollectionResult = "Failure"
            $vmList += $vmInfo
            return
        }

        # Skip all Windows Server 2003 Servers
        if ($vmInfo.VMWare_GuestOS -like "Microsoft Windows Server 2003*") {
            $vmInfo.ErrorOutput += "VM is running Windows Server 2003: $($vmInfo.VMWare_GuestOS). "
            Write-Output "VM: $($vmInfo.VMWare_Name) is running Windows Server 2003. Skipping information collection."
            $vmInfo.CollectionResult = "Skipped - Windows Server 2003"
            $vmList += $vmInfo
            return
        }

        # Create a directory for this server (only if powered on and DNS is valid)
        $serverOutputDir = Join-Path -Path $baseOutputDir -ChildPath $vm.Name
        if (-not (Test-Path -Path $serverOutputDir)) {
            New-Item -Path $serverOutputDir -ItemType Directory | Out-Null
        }

        # Create subdirectories for different steps
        $sharePermissionsDir = Join-Path -Path $serverOutputDir -ChildPath "sharepermissions"
        $groupMembersDir = Join-Path -Path $serverOutputDir -ChildPath "groupmembers"
        $vmwareDir = Join-Path -Path $serverOutputDir -ChildPath "vmware"
        $sysinfoDir = Join-Path -Path $serverOutputDir -ChildPath "sysinfo"
        $networkDir = Join-Path -Path $serverOutputDir -ChildPath "network"
        $diskDir = Join-Path -Path $serverOutputDir -ChildPath "disk"
        $userDir = Join-Path -Path $serverOutputDir -ChildPath "user"
        $groupsDir = Join-Path -Path $serverOutputDir -ChildPath "groups"
        $sharesDir = Join-Path -Path $serverOutputDir -ChildPath "shares"
        $servicesDir = Join-Path -Path $serverOutputDir -ChildPath "services"
        $certificatesDir = Join-Path -Path $serverOutputDir -ChildPath "certificates"
        $applicationsDir = Join-Path -Path $serverOutputDir -ChildPath "applications"
        $firewallDir = Join-Path -Path $serverOutputDir -ChildPath "firewall"

        # Create all directories if they don't exist
        foreach ($dir in @($sharePermissionsDir, $groupMembersDir, $vmwareDir, $sysinfoDir, $networkDir, $diskDir, $userDir, $groupsDir, $sharesDir, $servicesDir, $certificatesDir, $applicationsDir, $firewallDir)) {
            if (-not (Test-Path -Path $dir)) {
                New-Item -Path $dir -ItemType Directory | Out-Null
            }
        }

        # Step 2: Export VMware Data to vmware.txt
        try {
            $vmwareData = $vm | Format-List -Property *
            $vmwareFilePath = Join-Path -Path $vmwareDir -ChildPath "vmwaredata.txt"
            $vmwareData | Out-File -FilePath $vmwareFilePath -Force

            Write-Output "Exported VMware data to $vmwareFilePath"
        } catch {
            Write-Output "Failed to export VMware data for VM: $($vmInfo.VMWare_Name)"
            $vmInfo.ErrorOutput += "Failed to export VMware data. "
        }

        # Step 3: Collect System Information
        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            Write-Output "Step 3: Collecting system information for VM: $($vmInfo.VMWare_Name)"
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }
                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # Detect guest OS and execute appropriate command
            if ($vm.ExtensionData.Summary.Config.GuestFullName -like "*2003*") {
                # Windows Server 2003 - Batch Script
                $script = @'
@echo off
for /f "tokens=2 delims==" %%A in ('wmic os get Caption /value') do set osName=%%A
for /f "tokens=2 delims==" %%A in ('wmic os get Version /value') do set osVersion=%%A
for /f "tokens=2 delims==" %%A in ('wmic cpu get Name /value') do set processor=%%A

echo %osName%
echo %osVersion%
echo %processor%
'@
                $scriptType = 'Bat'
            } elseif ($vm.ExtensionData.Summary.Config.GuestFullName -like "*2008*") {
                # Windows Server 2008 - PowerShell 1.0
                $script = @'
$osName = (Get-WmiObject Win32_OperatingSystem).Caption
$osVersion = (Get-WmiObject Win32_OperatingSystem).Version
$processor = (Get-WmiObject Win32_Processor).Name

echo $osName
echo $osVersion
echo $processor
'@
                $scriptType = 'Powershell'
            } else {
                # Windows Server 2012 and later - PowerShell 2.0+
                $script = @'
$osName = (Get-WmiObject Win32_OperatingSystem).Caption
$osVersion = (Get-WmiObject Win32_OperatingSystem).Version
$processor = (Get-WmiObject Win32_Processor).Name

echo $osName
echo $osVersion
echo $processor
'@
                $scriptType = 'Powershell'
            }

            try {
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
                $scriptOutput = $scriptResult.ScriptOutput -split "`r`n"
                $vmInfo.SysInfo_OSName = $scriptOutput[0].Trim()
                $vmInfo.SysInfo_OSVersion = $scriptOutput[1].Trim()
                $vmInfo.SysInfo_Processor = $scriptOutput[2].Trim()

                # Save command output to file
                $sysinfoFilePath = Join-Path -Path $sysinfoDir -ChildPath "sysinfo.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $sysinfoFilePath -Force

                Write-Output "Step 3: Collected system information for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 3: Failed to collect system information for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect system information. "
            }
        } else {
            Write-Output "Step 3: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping system information collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        
        # Step 4: Collect Network Information using ipconfig /all
        Write-Output "Step 4: Collecting network information for VM: $($vmInfo.VMWare_Name)"

        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }

                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # Run ipconfig /all and parse the output
            $script = 'ipconfig /all'
            $scriptType = 'Bat'

            try {
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
                $scriptOutput = $scriptResult.ScriptOutput -split "`r`n"

                # Parse the ipconfig /all output
                $interfaceIndex = 1
                $dnsServerCount = 0

                foreach ($line in $scriptOutput) {
                    if ($line -match "Ethernet adapter (.+):") {
                        $currentInterface = $matches[1]
                    } elseif ($line -match "IPv4 Address.*: (.+)") {
                        $ipAddress = $matches[1].Trim()
                        $vmInfo."Network_Interface${interfaceIndex}_IP" = $ipAddress -replace "\(.+\)", ""
                    } elseif ($line -match "Subnet Mask.*: (.+)") {
                        $vmInfo."Network_Interface${interfaceIndex}_Subnet" = $matches[1].Trim()
                    } elseif ($line -match "Default Gateway.*: (.+)") {
                        $vmInfo."Network_Interface${interfaceIndex}_Gateway" = $matches[1].Trim()
                    } elseif ($line -match "DNS Servers.*: (.+)") {
                        $dnsServerCount++
                        if ($dnsServerCount -eq 1) {
                            $vmInfo."Network_Interface${interfaceIndex}_DNS1" = $matches[1].Trim()
                        } elseif ($dnsServerCount -eq 2) {
                            $vmInfo."Network_Interface${interfaceIndex}_DNS2" = $matches[1].Trim()
                        }
                    } elseif ($dnsServerCount -ge 1 -and $line.Trim() -match "^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$") {
                        $dnsServerCount++
                        if ($dnsServerCount -eq 2) {
                            $vmInfo."Network_Interface${interfaceIndex}_DNS2" = $line.Trim()
                        }
                    } elseif ($line -match "Primary Dns Suffix.*: (.+)") {
                        $vmInfo."Network_Interface${interfaceIndex}_DNSDomain" = $matches[1].Trim()
                    } elseif ($line -match "DNS Suffix Search List.*: (.+)") {
                        $vmInfo."Network_Interface${interfaceIndex}_DNSSuffixes" = $matches[1].Trim()
                    }

                    if ($line -match "NetBIOS over Tcpip.*: Enabled") {
                        $interfaceIndex++
                        $dnsServerCount = 0
                        if ($interfaceIndex -gt 4) { break }
                    }
                }

                # Save command output to file
                $networkFilePath = Join-Path -Path $networkDir -ChildPath "ipconfig.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $networkFilePath -Force

                Write-Output "Step 4: Collected network information for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 4: Failed to collect network information for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect network information. "
            }
        } else {
            Write-Output "Step 4: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping network information collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        # Step 5: Collect Disk Information using PowerShell (WMI)
        Write-Output "Step 5: Collecting disk information for VM: $($vmInfo.VMWare_Name)"

        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }

                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # PowerShell script to get disk information using WMI
            $script = @'
$logicalDisks = Get-WmiObject -Class Win32_LogicalDisk
foreach ($disk in $logicalDisks) {
    $disk.DeviceID + ";" + $disk.VolumeName + ";" + [math]::Round($disk.Size / 1GB, 2) + ";" + [math]::Round($disk.FreeSpace / 1GB, 2)
}
'@
            $scriptType = 'Powershell'

            try {
                # Execute the PowerShell script in the guest VM
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType

                # Parse the output directly instead of converting from JSON
                $diskData = $scriptResult.ScriptOutput -split "`r`n"

                # Initialize disk index
                $diskIndex = 1

                # Iterate through each line of disk data
                foreach ($disk in $diskData) {
                    if (-not [string]::IsNullOrEmpty($disk)) {
                        $diskParts = $disk -split ";"
                        $vmInfo."Disk${diskIndex}_Letter" = $diskParts[0].Trim()
                        $vmInfo."Disk${diskIndex}_Name" = $diskParts[1].Trim()
                        $vmInfo."Disk${diskIndex}_TotalGB" = $diskParts[2].Trim()
                        $vmInfo."Disk${diskIndex}_UsedGB" = ([double]$diskParts[2] - [double]$diskParts[3]).ToString("F2") # Calculate UsedGB

                        # Increment disk index
                        $diskIndex++
                        if ($diskIndex -gt 10) { break }  # Limit to 10 disks as per your property names
                    }
                }

                # Save the output to a file
                $diskFilePath = Join-Path -Path $diskDir -ChildPath "logicaldisk.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $diskFilePath -Force

                Write-Output "Step 5: Collected disk information for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 5: Failed to collect disk information for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect disk information. "
            }
        } else {
            Write-Output "Step 5: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping disk information collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        # Step 6: Collect Shared Folders using net share and Share Permissions using icacls
        Write-Output "Step 6: Collecting shared folders and permissions for VM: $($vmInfo.VMWare_Name)"

        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            $domainName = $dnsName.Split('.')[-2..-1] -join "."
            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }

                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # Run net share and parse the output
            $script = 'net share'
            $scriptType = 'Bat'

            try {
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
                $scriptOutput = $scriptResult.ScriptOutput -split "`r`n"

                # Save command output to file
                $netshareFilePath = Join-Path -Path $sharesDir -ChildPath "netshare.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $netshareFilePath -Force

                # Parse the net share output
                $shareIndex = 1
                $currentShare = @{
                    Name = ""
                    Path = ""
                    Remark = ""
                }
                $headerFound = $false
                $processingShare = $false

                foreach ($line in $scriptOutput) {
                    $line = $line.Trim()

                    # Identify the header and skip lines until after the separator
                    if (-not $headerFound) {
                        if ($line -match "^Share name\s+Resource\s+Remark$") {
                            $headerFound = $true
                        }
                        continue
                    }

                    # Skip the separator line
                    if ($headerFound -and $line -match "^-+$") {
                        $processingShare = $true
                        continue
                    }

                    if ($processingShare) {
                        # If it's a new share (name + path), handle it
                        if ($line -match "^(\S+)\s+(\S*:\\\S*)\s*(.*)$") {
                            $currentShare.Name = $matches[1].Trim()
                            $currentShare.Path = $matches[2].Trim()
                            $currentShare.Remark = $matches[3].Trim()

                            # Skip system-generated shares with $
                            if ($currentShare.Name -like "*$") {
                                continue
                            }

                            # Store the share information in the CSV output variables
                            $vmInfo."Share${shareIndex}_Name" = $currentShare.Name
                            $vmInfo."Share${shareIndex}_Path" = $currentShare.Path
                            $vmInfo."Share${shareIndex}_Desc" = if ($currentShare.Remark) { $currentShare.Remark } else { "N/A" }

                            # Sanitize the share name to remove special characters for the text file name
                            $sanitizedShareName = ($currentShare.Name -replace '[^a-zA-Z0-9]', '')

                            # DEBUG: Print share details
                            Write-Output "Processing Share: Name='$($currentShare.Name)', Path='$($currentShare.Path)', Remark='$($currentShare.Remark)'"

                            # Collect share permissions using icacls
                            try {
                                # Ensure the path is correctly escaped and formatted
                                $permScript = "icacls `"$($currentShare.Path)`""
                                Write-Output "Running icacls on path: $permScript"

                                $permResult = Invoke-VMScript -VM $vm -ScriptText $permScript -GuestCredential $credential -ScriptType $scriptType
                                $permOutput = $permResult.ScriptOutput

                                # Write the permissions to a text file
                                $shareOutputPath = Join-Path -Path $sharePermissionsDir -ChildPath "${sanitizedShareName}.txt"
                                $permOutput | Out-File -FilePath $shareOutputPath -Force

                                Write-Output "Exported Share Permissions to $shareOutputPath"
                            } catch {
                                Write-Output "Failed to collect permissions for share: $($currentShare.Name)"
                                $vmInfo.ErrorOutput += "Failed to collect permissions for share: $($currentShare.Name). "
                            }

                            # Reset the current share data and increment the share index
                            $currentShare = @{
                                Name = ""
                                Path = ""
                                Remark = ""
                            }
                            $shareIndex++
                            if ($shareIndex -gt 15) { break }
                        } 
                        elseif ($line -match "^\S*:\\\S*$") {
                            # Handle the case where the path is on the next line
                            $currentShare.Path = $line.Trim()
                        } 
                        else {
                            # This line could be the remark for the previous share
                            $currentShare.Remark = $line.Trim()
                        }
                    }
                }

                Write-Output "Step 6: Collected shared folders and permissions for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 6: Failed to collect shared folders for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect shared folders. Error: $_"
            }
        } else {
            Write-Output "Step 6: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping shared folders collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }


        # Step 7: Collect Local Users using net user and Local Groups using net localgroup
        Write-Output "Step 7: Collecting local users and local groups for VM: $($vmInfo.VMWare_Name)"

        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }

                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # Collect Local Users using net user
            $script = 'net user'
            $scriptType = 'Bat'

            try {
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
                $scriptOutput = $scriptResult.ScriptOutput -split "`r`n"

                # Save command output to file
                $netuserFilePath = Join-Path -Path $userDir -ChildPath "netuser.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $netuserFilePath -Force

                # Parse the net user output, looking for the "User accounts for" line, then skipping the separator line
                $userIndex = 1
                $headerFound = $false

                foreach ($line in $scriptOutput) {
                    if ($line -match "^User accounts for") {
                        $headerFound = $true
                        continue
                    }
                    if ($headerFound -and $line -match "^-+$") {
                        $headerFound = $false
                        continue
                    }
                    if (-not $headerFound) {
                        $users = $line -split "\s{2,}"
                        foreach ($user in $users) {
                            if ($user.Trim() -and $user -ne "The command completed successfully.") {
                                $vmInfo."User${userIndex}" = $user.Trim()
                                $userIndex++
                                if ($userIndex -gt 10) { break }
                            }
                        }
                    }
                }

                Write-Output "Step 7: Collected local users for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 7: Failed to collect local users for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect local users. "
            }

            # Collect Local Groups using net localgroup
            $script = 'net localgroup'
            $scriptType = 'Bat'

            try {
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
                $scriptOutput = $scriptResult.ScriptOutput -split "`r`n"

                # Save command output to file
                $netlocalgroupFilePath = Join-Path -Path $groupsDir -ChildPath "netlocalgroup.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $netlocalgroupFilePath -Force

                # Parse the net localgroup output and collect group names
                $groups = $scriptOutput | Where-Object { $_ -match "^\*" } | ForEach-Object { $_.TrimStart("*").Trim() }
                $vmInfo.LocalGroups = $groups -join ", "

                # Collect users for the "Administrators" and "Remote Desktop Users" groups, if they exist
                foreach ($group in @("Administrators", "Remote Desktop Users")) {
                    if ($groups -contains $group) {
                        try {
                            $groupScript = "net localgroup `"$group`""
                            $groupResult = Invoke-VMScript -VM $vm -ScriptText $groupScript -GuestCredential $credential -ScriptType $scriptType
                            $groupOutput = $groupResult.ScriptOutput -split "`r`n"

                            $groupUsers = $groupOutput | Where-Object { $_ -match "^\s{3,}" } | ForEach-Object { $_.Trim() } | Where-Object { $_ -and $_ -ne "The command completed successfully." }
                            $groupUsers = $groupUsers -join ", "

                            # Write the group members to a text file
                            $groupOutputPath = Join-Path -Path $groupMembersDir -ChildPath "${group}.txt"
                            $groupResult.ScriptOutput | Out-File -FilePath $groupOutputPath -Force

                            Write-Output "Exported Group Members to $groupOutputPath"
                        } catch {
                            $vmInfo.ErrorOutput += "Failed to collect users for group $group. "
                        }
                    }
                }

                Write-Output "Step 7: Collected local groups for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 7: Failed to collect local groups for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect local groups. "
            }
        } else {
            Write-Output "Step 7: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping local users and groups collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        # Step 8: Collect Services Information using PowerShell
        Write-Output "Step 8: Collecting services information for VM: $($vmInfo.VMWare_Name)"

        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }

                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # PowerShell script to get detailed service information
            $script = @'
        $services = Get-WmiObject -Class Win32_Service
        foreach ($service in $services) {
            $output = "========================================================="
            $output += "`nService Name: " + $service.Name
            $output += "`nStatus: " + $service.State
            $output += "`nStartup State: " + $service.StartMode
            $output += "`nRun As Account: " + $service.StartName
            $output += "`nDescription: " + $service.Description
            $output += "`n========================================================="
            $output
        }
'@

            $scriptType = 'Powershell'

            try {
                # Execute the PowerShell script in the guest VM
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
        
                # DEBUG: Write the raw script output to the console for debugging
                Write-Output $scriptResult.ScriptOutput

                # Save the output to a file
                $serviceFilePath = Join-Path -Path $servicesDir -ChildPath "services.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $serviceFilePath -Force

                Write-Output "Step 8: Collected services information for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 8: Failed to collect services information for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect services information. "
            }
        } else {
            Write-Output "Step 8: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping services collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        # Step 9: Collect Certificates Information from Multiple Stores
        Write-Output "Step 9: Collecting certificates information for VM: $($vmInfo.VMWare_Name)"
        
        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }

                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # Simplified and escaped batch script to list certificates from various machine stores
            $script = @'
call certutil -store My
call certutil -store Root
call certutil -store CA
call certutil -store TrustedPublisher
call certutil -store AuthRoot
call certutil -store Disallowed
call certutil -store TrustedDevices
call certutil -store "Remote Desktop"
call certutil -store SmartCardRoot
call certutil -store WebHosting
'@

            $scriptType = 'Bat'

            try {
                # Execute the batch script in the guest VM
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
        
                # DEBUG: Write the raw script output to the console for debugging
                Write-Output $scriptResult.ScriptOutput

                # Save the output to a file
                $certificatesFilePath = Join-Path -Path $certificatesDir -ChildPath "certificates.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $certificatesFilePath -Force

                Write-Output "Step 9: Collected certificates information for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 9: Failed to collect certificates information for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect certificates information. "
            }
        } else {
            Write-Output "Step 9: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping certificates collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        # Step 10: Collect Installed Applications Information
        Write-Output "Step 10: Collecting installed applications information for VM: $($vmInfo.VMWare_Name)"
        
        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }

                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # Run WMIC to get installed applications information
            $script = 'wmic product get name,version'
            $scriptType = 'Bat'

            try {
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
                $applicationsFilePath = Join-Path -Path $applicationsDir -ChildPath "applications.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $applicationsFilePath -Force

                Write-Output "Step 10: Collected installed applications information for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 10: Failed to collect installed applications information for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect installed applications information. "
            }
        } else {
            Write-Output "Step 10: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping installed applications collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        # Step 11: Collect Firewall Status Information
        Write-Output "Step 11: Collecting firewall status information for VM: $($vmInfo.VMWare_Name)"
        
        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }

                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # Run netsh to get firewall status information
            $script = 'netsh advfirewall show allprofiles state'
            $scriptType = 'Bat'

            try {
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
                $firewallStatusFilePath = Join-Path -Path $firewallDir -ChildPath "firewallstatus.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $firewallStatusFilePath -Force

                Write-Output "Step 11: Collected firewall status information for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 11: Failed to collect firewall status information for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect firewall status information. "
            }
        } else {
            Write-Output "Step 11: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping firewall status collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        # Step 12: Collect Firewall Rules Information
        Write-Output "Step 12: Collecting firewall rules information for VM: $($vmInfo.VMWare_Name)"
        
        if ($vmInfo.VMWare_PowerState -eq "PoweredOn" -and -not [string]::IsNullOrEmpty($dnsName)) {
            $domainName = $dnsName.Substring($dnsName.IndexOf('.') + 1)

            $credential = switch ($domainName) {
                "escad.internal" { $escadCredentials }

                default { 
                    $vmInfo.ErrorOutput += "Unknown domain for DNS name: $dnsName. "
                    continue
                }
            }

            # Run netsh to get firewall rules information
            $script = 'netsh advfirewall firewall show rule name=all'
            $scriptType = 'Bat'

            try {
                $scriptResult = Invoke-VMScript -VM $vm -ScriptText $script -GuestCredential $credential -ScriptType $scriptType
                $firewallRulesFilePath = Join-Path -Path $firewallDir -ChildPath "firewallrules.txt"
                $scriptResult.ScriptOutput | Out-File -FilePath $firewallRulesFilePath -Force

                Write-Output "Step 12: Collected firewall rules information for VM: $($vmInfo.VMWare_Name)"
            } catch {
                Write-Output "Step 12: Failed to collect firewall rules information for VM: $($vmInfo.VMWare_Name)"
                $vmInfo.ErrorOutput += "Failed to collect firewall rules information. "
            }
        } else {
            Write-Output "Step 12: DNS name is missing for VM: $($vmInfo.VMWare_Name) - Skipping firewall rules collection."
            $vmInfo.ErrorOutput += "DNS name is missing. "
        }

        # Add VM info to the list
        $vmList += $vmInfo
    }
}

# Step 13: Export VM configuration information to a CSV file with columns ordered as per the property order in $vmInfo
Write-Output "Step 13: Exporting VM configuration information to CSV..."
$vmList | Select-Object `
VMWare_Name,
VMWare_CPU,
VMWare_MemoryGB,
VMWare_DiskGB,
VMWare_GuestOS,
VMWare_PowerState,
VMWare_Host,
VMWare_Cluster,
VMWare_Datastore,
VMWare_Network,
VMWare_IPAddresses,
VMWare_DNSName,
SysInfo_OSName,
SysInfo_OSVersion,
SysInfo_Processor,
Network_Interface1_IP,
Network_Interface1_Subnet,
Network_Interface1_Gateway,
Network_Interface1_DNS1,
Network_Interface1_DNS2,
Network_Interface1_WINS1,
Network_Interface1_WINS2,
Network_Interface1_DNSDomain,
Network_Interface1_DNSSuffixes,
Network_Interface2_IP,
Network_Interface2_Subnet,
Network_Interface2_Gateway,
Network_Interface2_DNS1,
Network_Interface2_DNS2,
Network_Interface2_WINS1,
Network_Interface2_WINS2,
Network_Interface2_DNSDomain,
Network_Interface2_DNSSuffixes,
Network_Interface3_IP,
Network_Interface3_Subnet,
Network_Interface3_Gateway,
Network_Interface3_DNS1,
Network_Interface3_DNS2,
Network_Interface3_WINS1,
Network_Interface3_WINS2,
Network_Interface3_DNSDomain,
Network_Interface3_DNSSuffixes,
Network_Interface4_IP,
Network_Interface4_Subnet,
Network_Interface4_Gateway,
Network_Interface4_DNS1,
Network_Interface4_DNS2,
Network_Interface4_WINS1,
Network_Interface4_WINS2,
Network_Interface4_DNSDomain,
Network_Interface4_DNSSuffixes,
Disk1_Letter,
Disk1_Name,
Disk1_TotalGB,
Disk1_UsedGB,
Disk2_Letter,
Disk2_Name,
Disk2_TotalGB,
Disk2_UsedGB,
Disk3_Letter,
Disk3_Name,
Disk3_TotalGB,
Disk3_UsedGB,
Disk4_Letter,
Disk4_Name,
Disk4_TotalGB,
Disk4_UsedGB,
Disk5_Letter,
Disk5_Name,
Disk5_TotalGB,
Disk5_UsedGB,
Disk6_Letter,
Disk6_Name,
Disk6_TotalGB,
Disk6_UsedGB,
Disk7_Letter,
Disk7_Name,
Disk7_TotalGB,
Disk7_UsedGB,
Disk8_Letter,
Disk8_Name,
Disk8_TotalGB,
Disk8_UsedGB,
Disk9_Letter,
Disk9_Name,
Disk9_TotalGB,
Disk9_UsedGB,
Disk10_Letter,
Disk10_Name,
Disk10_TotalGB,
Disk10_UsedGB,
Share1_Name,
Share1_Path,
Share1_Desc,
Share2_Name,
Share2_Path,
Share2_Desc,
Share3_Name,
Share3_Path,
Share3_Desc,
Share4_Name,
Share4_Path,
Share4_Desc,
Share5_Name,
Share5_Path,
Share5_Desc,
Share6_Name,
Share6_Path,
Share6_Desc,
Share7_Name,
Share7_Path,
Share7_Desc,
Share8_Name,
Share8_Path,
Share8_Desc,
Share9_Name,
Share9_Path,
Share9_Desc,
Share10_Name,
Share10_Path,
Share10_Desc,
Share11_Name,
Share11_Path,
Share11_Desc,
Share12_Name,
Share12_Path,
Share12_Desc,
Share13_Name,
Share13_Path,
Share13_Desc,
Share14_Name,
Share14_Path,
Share14_Desc,
Share15_Name,
Share15_Path,
Share15_Desc,
User1,
User2,
User3,
User4,
User5,
User6,
User7,
User8,
User9,
User10,
LocalGroups,
CollectionResult,
ErrorOutput |
Export-Csv -Path "$($baseOutputDir)VM_Configuration.csv" -NoTypeInformation -UseCulture

# Disconnect from vCenter Server
Disconnect-VIServer -Server $vCenterServer -Confirm:$false

# Output the location of the CSV file
Write-Output "VM configuration information exported to $($baseOutputDir)VM_Configuration.csv"
