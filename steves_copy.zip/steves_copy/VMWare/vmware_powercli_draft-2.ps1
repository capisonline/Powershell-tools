﻿<#
QCAD VMware/VCF PowerCLI Orchestrator (Bedded-Down Core)
- NO long synopsis (as requested)
- HARD SAFETY: Will not touch any VM not present in VMList.txt (even if typed)
- All actions support targeting a subset of VMs using comma/semicolon input
- Robust "single object vs array" handling (no .Count surprises)
- Avoids StrictMode breaking vendor modules; uses safe defaults
- Prefers VCF.PowerCLI if installed, otherwise falls back to VMware.PowerCLI
- Includes Check-ToolsStatus (used to gate Invoke-VMScript operations)
#>

$ErrorActionPreference = "Stop"

# -----------------------------
# Paths
# -----------------------------
$VMListFile           = 'C:\temp\QCAD\VT\VMWare\VMList.txt'
$LogFile              = 'C:\temp\QCAD\VT\VMWare\VMWare_PowerCLI_Automation.log'
$SnapshotDeletionCSV  = 'C:\temp\QCAD\VT\VMWare\snapshot_deletion_csv.csv'
$VCentersFile         = 'C:\temp\QCAD\VT\VMWare\vCenters.txt'
$ServiceListCSV       = 'C:\temp\QCAD\VT\VMWare\services_to_disable.csv'

# -----------------------------
# Logging
# -----------------------------
function Log-Info([string]$msg) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [INFO] $msg"
}
function Log-Error([string]$msg) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [ERROR] $msg" -ForegroundColor Red
}
function Ensure-Directory([string]$path) {
    $dir = Split-Path -Path $path -Parent
    if ($dir -and -not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
}
function Confirm-Action([string]$Message = "Proceed? (Y/N)") {
    $c = Read-Host $Message
    return ($c.Trim().ToLower() -eq 'y')
}

# -----------------------------
# Start transcript
# -----------------------------
try {
    Ensure-Directory $LogFile
    Start-Transcript -Path $LogFile -Append -Force | Out-Null
} catch {
    Write-Host "WARNING: Failed to start transcript: $($_.Exception.Message)" -ForegroundColor Yellow
}

# -----------------------------
# Helpers: safety + selection
# -----------------------------
function Read-NonEmptyFileLines([string]$path) {
    if (-not (Test-Path $path)) { return @() }
    return @(
        Get-Content $path |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ }
    )
}

function Get-AllowedVMNames {
    if (-not (Test-Path $VMListFile)) {
        Log-Error "VM list file not found at $VMListFile"
        return @()
    }

    $names = @(
        Get-Content $VMListFile |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ } |
        Select-Object -Unique
    )

    if ($names.Count -eq 0) {
        Log-Error "VM list file is empty: $VMListFile"
        return @()
    }
    return $names
}

function Resolve-TargetVMNames {
    param(
        [string]$Prompt = "Enter VM names (, or ;) OR press Enter for ALL from VMList.txt"
    )

    $allowed = Get-AllowedVMNames
    if ($allowed.Count -eq 0) { return @() }

    $raw = Read-Host $Prompt

    if ([string]::IsNullOrWhiteSpace($raw)) {
        Log-Info "Target set: ALL ($($allowed.Count)) from VMList.txt"
        return $allowed
    }

    $requested = @(
        $raw -split '[,;]' |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ }
    )

    if ($requested.Count -eq 0) {
        Log-Error "No valid VM names entered."
        return @()
    }

    $valid   = New-Object System.Collections.Generic.List[string]
    $invalid = New-Object System.Collections.Generic.List[string]

    foreach ($name in $requested) {
        if ($allowed -contains $name) { [void]$valid.Add($name) } else { [void]$invalid.Add($name) }
    }

    if ($invalid.Count -gt 0) {
        Log-Error "Blocked (NOT in VMList.txt): $($invalid -join ', ')"
    }
    if ($valid.Count -eq 0) {
        Log-Error "No valid targets after safety filter."
        return @()
    }

    Log-Info "Target set: $($valid.Count) VM(s): $($valid -join ', ')"
    return $valid.ToArray()
}

function Get-VMObjects {
    param([string[]]$VMNames)

    $vms = @()
    foreach ($vmName in @($VMNames)) {
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            $vms += $vm
        } else {
            Log-Error "VM '$vmName' not found in connected vCenter(s)."
        }
    }
    return @($vms)
}

# -----------------------------
# PowerCLI init (VCF preferred)
# -----------------------------
try {
    $hasVCF    = [bool](Get-Module -ListAvailable -Name VCF.PowerCLI)
    $hasVMware = [bool](Get-Module -ListAvailable -Name VMware.PowerCLI)

    if (-not $hasVCF -and -not $hasVMware) {
        throw "No PowerCLI module found. Install VCF.PowerCLI (preferred) or VMware.PowerCLI."
    }

    if ($hasVCF) {
        Import-Module VCF.PowerCLI -ErrorAction Stop
    } else {
        Import-Module VMware.PowerCLI -ErrorAction Stop
    }

    # Configure once per session (do NOT rely on undefined variables)
    if (-not (Get-Variable -Name PowerCLIConfigured -Scope Global -ErrorAction SilentlyContinue)) {
        Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null
        Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
        Set-PowerCLIConfiguration -DefaultVIServerMode Multiple -Confirm:$false | Out-Null
        Set-Variable -Name PowerCLIConfigured -Scope Global -Value $true -Force
    }
}
catch {
    Write-Host "PowerCLI init failed: $($_.Exception.Message)" -ForegroundColor Red
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}

# -----------------------------
# vCenter connect
# -----------------------------
try {
    if (-not (Test-Path $VCentersFile)) { throw "vCenters list file not found at $VCentersFile" }

    $VCenters = Read-NonEmptyFileLines $VCentersFile
    if ($VCenters.Count -eq 0) { throw "No vCenters listed in $VCentersFile" }

    Write-Host ""
    Write-Host "Select one or more vCenter Servers (comma-separated):"
    for ($i = 0; $i -lt $VCenters.Count; $i++) {
        Write-Host " [$($i+1)] $($VCenters[$i])"
    }

    $selection = Read-Host "`nEnter number(s) (e.g., 1,2)"
    $indices = @(
        $selection -split '[,;]' |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -match '^\d+$' }
    )

    if ($indices.Count -eq 0) { throw "Invalid selection (no numbers provided)." }

    $bad = @($indices | Where-Object { [int]$_ -lt 1 -or [int]$_ -gt $VCenters.Count })
    if ($bad.Count -gt 0) { throw "Invalid selection (out of range): $($bad -join ', ')" }

    $cred = Get-Credential
    $connectedVCs = @()

    foreach ($idx in $indices) {
        $vc = $VCenters[[int]$idx - 1]
        try {
            Connect-VIServer -Server $vc -Credential $cred -ErrorAction Stop | Out-Null
            $connectedVCs += $vc
            Log-Info "Connected to vCenter: $vc"
        } catch {
            Log-Error "Failed to connect to vCenter $vc - $($_.Exception.Message)"
        }
    }

    if ($connectedVCs.Count -eq 0) { throw "No vCenters connected successfully." }
}
catch {
    Log-Error $_.Exception.Message
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}

# -----------------------------
# Core actions
# -----------------------------
function Check-ToolsStatus {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to CHECK tools (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    $vms = Get-VMObjects -VMNames $targets

    $report = foreach ($vm in $vms) {
        $g = $vm.ExtensionData.Guest
        [PSCustomObject]@{
            VMName             = $vm.Name
            PowerState         = $vm.PowerState
            ToolsRunningStatus = $g.ToolsRunningStatus
            ToolsVersionStatus = $g.ToolsVersionStatus2
            ToolsVersion       = $g.ToolsVersion
        }
    }

    $report | Sort-Object ToolsVersionStatus, ToolsRunningStatus, VMName | Format-Table -AutoSize

    $out = "C:\temp\QCAD\VT\VMWare\ToolsStatus_$(Get-Date -Format 'yyyy-MM-dd_HH-mm').csv"
    Ensure-Directory $out
    $report | Export-Csv -Path $out -NoTypeInformation
    Log-Info "Tools status exported: $out"
}

function Create-Snapshots {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to SNAPSHOT (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    if (-not (Confirm-Action "Create snapshots on $($targets.Count) VM(s)? (Y/N)")) {
        Log-Info "User cancelled."
        return
    }

    $vms = Get-VMObjects -VMNames $targets
    foreach ($vm in $vms) {
        $snapshotName = "PrePatch_$($vm.Name)_$(Get-Date -Format 'yyyyMMdd_HHmm')"
        try {
            New-Snapshot -VM $vm -Name $snapshotName -Description "PrePatch" -Quiesce:$false -Memory:$true -ErrorAction Stop | Out-Null
            Log-Info "Snapshot created: '$snapshotName' on $($vm.Name)"
        } catch {
            Log-Error "Snapshot create failed on $($vm.Name) - $($_.Exception.Message)"
        }
    }
}

function List-Snapshots {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to LIST snapshots (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    $timestamp = Get-Date -Format 'yyyy-MM-dd_HH-mm'
    $out = "C:\temp\QCAD\VT\VMWare\Snapshots_$timestamp.csv"
    Ensure-Directory $out

    $vms = Get-VMObjects -VMNames $targets
    foreach ($vm in $vms) {
        try {
            $snaps = @()
            try { $snaps = @(Get-Snapshot -VM $vm -ErrorAction Stop) } catch { $snaps = @() }

            foreach ($s in $snaps) {
                [PSCustomObject]@{
                    VMName      = $vm.Name
                    Name        = $s.Name
                    Created     = $s.Created
                    PowerState  = $s.PowerState
                    Description = $s.Description
                    Id          = $s.Id
                } | Export-Csv -Path $out -NoTypeInformation -Append
            }

            Log-Info "Snapshot list exported for $($vm.Name)"
        } catch {
            Log-Error "Snapshot list failed for $($vm.Name) - $($_.Exception.Message)"
        }
    }

    Log-Info "Snapshot list output: $out"
}

function Delete-SnapshotsFromCSV {
    if (-not (Test-Path $SnapshotDeletionCSV)) {
        Log-Error "Snapshot deletion CSV not found: $SnapshotDeletionCSV"
        return
    }

    $allowed = Get-AllowedVMNames
    if ($allowed.Count -eq 0) { return }

    $rows = @(Import-Csv -Path $SnapshotDeletionCSV)
    if ($rows.Count -eq 0) {
        Log-Error "Snapshot deletion CSV is empty."
        return
    }

    $cols = $rows[0].PSObject.Properties.Name
    if ($cols -notcontains 'VM_Name' -or $cols -notcontains 'Snapshot_ID') {
        Log-Error "CSV must contain columns: VM_Name, Snapshot_ID"
        return
    }

    # HARD SAFETY: only allow rows for VMs in VMList.txt
    $blocked = @($rows | Where-Object { $allowed -notcontains $_.VM_Name })
    if ($blocked.Count -gt 0) {
        Log-Error "Blocked CSV rows (VM not in VMList.txt): $($blocked.VM_Name -join ', ')"
    }

    $rows = @($rows | Where-Object { $allowed -contains $_.VM_Name })
    if ($rows.Count -eq 0) {
        Log-Error "No valid rows after safety filter."
        return
    }

    # Optional: also target subset interactively
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to apply CSV deletions to (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    $rows = @($rows | Where-Object { $targets -contains $_.VM_Name })
    if ($rows.Count -eq 0) {
        Log-Error "No CSV rows match selected targets."
        return
    }

    Write-Host ""
    Write-Host "Snapshots queued for deletion (post-safety):"
    foreach ($r in $rows) { Log-Info "VM: $($r.VM_Name) SnapshotID: $($r.Snapshot_ID)" }

    if (-not (Confirm-Action "CONFIRM delete these snapshots? (Y/N)")) {
        Log-Info "User declined deletion."
        return
    }

    $results = @()
    foreach ($r in $rows) {
        $vm = Get-VM -Name $r.VM_Name -ErrorAction SilentlyContinue
        if (-not $vm) {
            Log-Error "VM not found in vCenter: $($r.VM_Name)"
            $results += [PSCustomObject]@{ VMName=$r.VM_Name; SnapshotID=$r.Snapshot_ID; Status="VM not found" }
            continue
        }

        try {
            $snaps = @()
            try { $snaps = @(Get-Snapshot -VM $vm -ErrorAction Stop) } catch { $snaps = @() }

            $snap = $snaps | Where-Object { $_.Id -eq $r.Snapshot_ID }
            if (-not $snap) {
                Log-Error "Snapshot ID not found on $($vm.Name): $($r.Snapshot_ID)"
                $results += [PSCustomObject]@{ VMName=$vm.Name; SnapshotID=$r.Snapshot_ID; Status="Snapshot not found" }
                continue
            }

            Remove-Snapshot -Snapshot $snap -Confirm:$false -ErrorAction Stop | Out-Null
            Log-Info "Deleted snapshot $($r.Snapshot_ID) on $($vm.Name)"
            $results += [PSCustomObject]@{ VMName=$vm.Name; SnapshotID=$r.Snapshot_ID; Status="Deleted" }
        }
        catch {
            Log-Error "Delete failed on $($vm.Name) snapshot $($r.Snapshot_ID) - $($_.Exception.Message)"
            $results += [PSCustomObject]@{ VMName=$vm.Name; SnapshotID=$r.Snapshot_ID; Status="Failed: $($_.Exception.Message)" }
        }
    }

    $out = "$SnapshotDeletionCSV.results.csv"
    Ensure-Directory $out
    $results | Export-Csv -Path $out -NoTypeInformation
    Log-Info "Deletion results exported: $out"
}

function Cleanup-Snapshots {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to CLEANUP snapshots (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    $RetentionDaysRaw = Read-Host "Enter retention period (days) - snapshots older than this will be deleted"
    if ($RetentionDaysRaw -notmatch '^\d+$') {
        Log-Error "Retention must be a whole number."
        return
    }
    $RetentionDays = [int]$RetentionDaysRaw
    $cutoff = (Get-Date).AddDays(-$RetentionDays)

    if (-not (Confirm-Action "Delete snapshots older than $RetentionDays day(s) on $($targets.Count) VM(s)? (Y/N)")) {
        Log-Info "User cancelled."
        return
    }

    $vms = Get-VMObjects -VMNames $targets
    foreach ($vm in $vms) {
        try {
            $snaps = @()
            try { $snaps = @(Get-Snapshot -VM $vm -ErrorAction Stop) } catch { $snaps = @() }

            $old = @($snaps | Where-Object { $_.Created -lt $cutoff })
            foreach ($snap in $old) {
                try {
                    Remove-Snapshot -Snapshot $snap -Confirm:$false -ErrorAction Stop | Out-Null
                    Log-Info "Deleted old snapshot '$($snap.Name)' on $($vm.Name)"
                } catch {
                    Log-Error "Failed deleting snapshot '$($snap.Name)' on $($vm.Name) - $($_.Exception.Message)"
                }
            }
        } catch {
            Log-Error "Cleanup snapshot query failed for $($vm.Name) - $($_.Exception.Message)"
        }
    }
}

function Disable-NICStartup {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to DISABLE NIC StartConnected (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    if (-not (Confirm-Action "Disable NIC StartConnected on $($targets.Count) VM(s)? (Y/N)")) {
        Log-Info "User cancelled."
        return
    }

    $vms = Get-VMObjects -VMNames $targets
    foreach ($vm in $vms) {
        try {
            $adapters = @(Get-NetworkAdapter -VM $vm -ErrorAction Stop)
            foreach ($a in $adapters) {
                Set-NetworkAdapter -NetworkAdapter $a -StartConnected:$false -Confirm:$false -ErrorAction Stop | Out-Null
            }
            Log-Info "NIC StartConnected disabled on $($vm.Name)"
        } catch {
            Log-Error "Disable NIC failed on $($vm.Name) - $($_.Exception.Message)"
        }
    }
}

function Enable-NICStartup {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to ENABLE NIC StartConnected (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    if (-not (Confirm-Action "Enable NIC StartConnected on $($targets.Count) VM(s)? (Y/N)")) {
        Log-Info "User cancelled."
        return
    }

    $vms = Get-VMObjects -VMNames $targets
    foreach ($vm in $vms) {
        try {
            $adapters = @(Get-NetworkAdapter -VM $vm -ErrorAction Stop)
            foreach ($a in $adapters) {
                Set-NetworkAdapter -NetworkAdapter $a -StartConnected:$true -Confirm:$false -ErrorAction Stop | Out-Null
            }
            Log-Info "NIC StartConnected enabled on $($vm.Name)"
        } catch {
            Log-Error "Enable NIC failed on $($vm.Name) - $($_.Exception.Message)"
        }
    }
}

function Start-VMList {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to POWER ON (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    if (-not (Confirm-Action "Power ON $($targets.Count) VM(s)? (Y/N)")) {
        Log-Info "User cancelled."
        return
    }

    $vms = Get-VMObjects -VMNames $targets
    foreach ($vm in $vms) {
        try {
            Start-VM -VM $vm -Confirm:$false -ErrorAction Stop | Out-Null
            Log-Info "Powered on $($vm.Name)"
        } catch {
            Log-Error "Power on failed for $($vm.Name) - $($_.Exception.Message)"
        }
    }
}

function Stop-VMListGracefully {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to GUEST SHUTDOWN (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    if (-not (Confirm-Action "Send guest shutdown to $($targets.Count) VM(s)? (Y/N)")) {
        Log-Info "User cancelled."
        return
    }

    $vms = Get-VMObjects -VMNames $targets
    foreach ($vm in $vms) {
        try {
            Shutdown-VMGuest -VM $vm -Confirm:$false -ErrorAction Stop | Out-Null
            Log-Info "Guest shutdown requested: $($vm.Name)"
        } catch {
            Log-Error "Guest shutdown failed for $($vm.Name) - $($_.Exception.Message)"
        }
    }
}

function Stop-VMListForce {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to FORCE POWER OFF (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    Write-Host ""
    Write-Host "WARNING: Force power-off is disruptive." -ForegroundColor Yellow
    if (-not (Confirm-Action "Force POWER OFF $($targets.Count) VM(s)? (Y/N)")) {
        Log-Info "User cancelled."
        return
    }

    $vms = Get-VMObjects -VMNames $targets
    foreach ($vm in $vms) {
        try {
            Stop-VM -VM $vm -Kill -Confirm:$false -ErrorAction Stop | Out-Null
            Log-Info "Force powered off $($vm.Name)"
        } catch {
            Log-Error "Force power off failed for $($vm.Name) - $($_.Exception.Message)"
        }
    }
}

function Disable-ServicesInGuest {
    if (-not (Test-Path $ServiceListCSV)) {
        Log-Error "Service list CSV not found: $ServiceListCSV"
        return
    }

    $allowed = Get-AllowedVMNames
    if ($allowed.Count -eq 0) { return }

    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to DISABLE services on (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    $entries = @(Import-Csv -Path $ServiceListCSV)
    if ($entries.Count -eq 0) {
        Log-Error "Service list CSV is empty."
        return
    }

    $cols = $entries[0].PSObject.Properties.Name
    if ($cols -notcontains 'VMName' -or $cols -notcontains 'ServiceName') {
        Log-Error "Service CSV must contain columns: VMName, ServiceName"
        return
    }

    # HARD SAFETY FILTER: only rows where VMName is in VMList.txt
    $blockedRows = @($entries | Where-Object { $allowed -notcontains $_.VMName })
    if ($blockedRows.Count -gt 0) {
        Log-Error "Blocked CSV rows (VM not in VMList.txt): $($blockedRows.VMName -join ', ')"
    }

    # Additional filter: only selected targets
    $work = @($entries | Where-Object { ($allowed -contains $_.VMName) -and ($targets -contains $_.VMName) })
    if ($work.Count -eq 0) {
        Log-Error "No service rows match the safety filter (VMList.txt + selected targets)."
        return
    }

    Write-Host ""
    Log-Info "Will disable services on $($work.Count) row(s) across selected targets."
    if (-not (Confirm-Action "Proceed to run in-guest service disable? (Y/N)")) {
        Log-Info "User cancelled."
        return
    }

    $guestCred = Get-Credential

    foreach ($row in $work) {
        $vm = Get-VM -Name $row.VMName -ErrorAction SilentlyContinue
        if (-not $vm) {
            Log-Error "VM '$($row.VMName)' not found in vCenter."
            continue
        }

        # Gate on VMware Tools running (predictable behaviour)
        $g = $vm.ExtensionData.Guest
        if ($g.ToolsRunningStatus -ne "guestToolsRunning") {
            Log-Error "Skipping $($vm.Name): VMware Tools not running ($($g.ToolsRunningStatus))."
            continue
        }

        $script = @"
Stop-Service -Name '$($row.ServiceName)' -Force -ErrorAction SilentlyContinue
Set-Service  -Name '$($row.ServiceName)' -StartupType Disabled -ErrorAction SilentlyContinue
"@

        try {
            Invoke-VMScript -VM $vm -ScriptText $script -ScriptType PowerShell -GuestCredential $guestCred -ErrorAction Stop | Out-Null
            Log-Info "Disabled service '$($row.ServiceName)' on $($row.VMName)"
        } catch {
            Log-Error "Failed disabling '$($row.ServiceName)' on $($row.VMName) - $($_.Exception.Message)"
        }
    }
}

function Report-VMStates {
    $targets = Resolve-TargetVMNames -Prompt "Enter VM names to REPORT power state (, or ;) OR Enter for ALL"
    if ($targets.Count -eq 0) { return }

    $vms = Get-VMObjects -VMNames $targets
    $report = foreach ($vm in $vms) {
        [PSCustomObject]@{
            VMName     = $vm.Name
            PowerState = $vm.PowerState
            Host       = $vm.VMHost.Name
        }
    }

    $report | Sort-Object VMName | Format-Table -AutoSize
}

# -----------------------------
# Main menu
# -----------------------------
do {
    Write-Host ""
    Write-Host "Select action:"
    Write-Host "  snapshot-create"
    Write-Host "  snapshot-list"
    Write-Host "  snapshot-delete"
    Write-Host "  snapshot-cleanup"
    Write-Host "  disable-nic"
    Write-Host "  enable-nic"
    Write-Host "  start-vms"
    Write-Host "  stop-vms"
    Write-Host "  force-stop-vms"
    Write-Host "  disable-services"
    Write-Host "  check-tools"
    Write-Host "  vm-powerstate"
    Write-Host "  quit"

    $action = Read-Host "Enter your choice"
    switch ($action.Trim().ToLower()) {
        'snapshot-create'   { Create-Snapshots }
        'snapshot-list'     { List-Snapshots }
        'snapshot-delete'   { Delete-SnapshotsFromCSV }
        'snapshot-cleanup'  { Cleanup-Snapshots }
        'disable-nic'       { Disable-NICStartup }
        'enable-nic'        { Enable-NICStartup }
        'start-vms'         { Start-VMList }
        'stop-vms'          { Stop-VMListGracefully }
        'force-stop-vms'    { Stop-VMListForce }
        'disable-services'  { Disable-ServicesInGuest }
        'check-tools'       { Check-ToolsStatus }
        'vm-powerstate'     { Report-VMStates }
        'quit'              { Log-Info "Exiting on user request." }
        default             { Log-Error "Invalid action. Try again." }
    }
} while ($action.Trim().ToLower() -ne 'quit')

# -----------------------------
# Disconnect + end transcript
# -----------------------------
try {
    Disconnect-VIServer -Server * -Confirm:$false | Out-Null
    Log-Info "Disconnected from all vCenters"
} catch {
    Log-Error "Disconnect-VIServer failed - $($_.Exception.Message)"
}

try { Stop-Transcript | Out-Null } catch {}