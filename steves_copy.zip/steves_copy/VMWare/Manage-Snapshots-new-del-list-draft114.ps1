﻿<#
.SYNOPSIS
    VMware PowerCLI Snapshot Manager with Full CLI Logging
    This script automates snapshot management for VMs in a vCenter environment.

.DESCRIPTION
    This script manages VMware virtual machine (VM) snapshots in a vCenter environment. 
    It allows users to perform snapshot operations such as creating, deleting, listing, and cleaning up snapshots. 
    The script also handles CLI logging, including stdout & stderr output, for easy auditing. 

    Specifically, the script:
    - Connects to a selected vCenter server.
    - Reads a pre-existing CSV file (`Snapshots.csv`) listing the VM names and Snapshot IDs to be deleted.
    - Prompts the user for confirmation before deleting snapshots.
    - Handles snapshot creation, listing, and cleanup tasks.
    - Logs all actions and errors to a log file (`SnapshotManager.log`).

.OUTPUTS
    - A log file (`SnapshotManager.log`) that captures both stdout & stderr.
    - CSV files for snapshot listings when using the "list" action.

.NOTES
    - Requires VMware PowerCLI to be installed.
    - The script uses `vCenters.txt` to store a list of vCenter servers and attempts to connect to one based on user input.
    - A CSV file (`Snapshots.csv`) should be pre-created with the VM names and snapshot IDs for deletions.

.AUTHOR
    Created by Cap
#>

Import-Module VMware.PowerCLI -ErrorAction Stop
# Disable VMware customer improvement (No telemetry data is sent to VMware and stops the annoying questions from VMware)
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null

# Define file paths for required resources
$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$VMListFile = "$ScriptDirectory\VMList.txt"
$LogFile = "$ScriptDirectory\SnapshotManager.log"
$SnapshotCSV = "$ScriptDirectory\Snapshots.csv"
$VCentersFile = "$ScriptDirectory\vCenters.txt"

# Ensure vCenters.txt exists and prompt the user to input data if it doesn't
if (-not (Test-Path $VCentersFile)) {
    Write-Host "`nvCenters list file not found! Creating a new one in $ScriptDirectory..."
    "Enter one vCenter per line, then save and close the file." | Out-File -FilePath $VCentersFile -Encoding UTF8
    notepad.exe $VCentersFile
    Write-Host "`n Please add vCenters to the file and restart the script."
    exit
}

# Load vCenter list and check if it's not empty
$VCenters = Get-Content $VCentersFile | Where-Object {$_ -ne ""}
if (-not $VCenters) {
    Write-Host "`n No vCenters found in vCenters.txt. Please update the file and restart the script."
    exit
}

# Display vCenter options to the user for selection
Write-Host "`n Select a vCenter Server:"
for ($i = 0; $i -lt $VCenters.Count; $i++) {
    Write-Host " [$($i+1)] $($VCenters[$i])"
}

# Prompt the user to select a vCenter
$selection = Read-Host "`n Enter the number of the vCenter to connect to"
if ($selection -match "^\d+$" -and [int]$selection -ge 1 -and [int]$selection -le $VCenters.Count) {
    $vCenter = $VCenters[[int]$selection - 1]
    Write-Host "`n Selected vCenter: $vCenter"
} else {
    Write-Host "`n Invalid selection. Exiting script."
    exit
}

# Prompt for username and password upfront using Get-Credential
$credential = Get-Credential

# Accept Invalid SSL Certificates without user intervention
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

# Start logging all CLI output (stdout & stderr)
Start-Transcript -Path $LogFile -Append -Force | Out-Null

# Ensure VM list file exists and prompt the user to input VM names if it doesn't
if (-not (Test-Path $VMListFile)) {
    Write-Host "`nVM list file not found! Creating a new one in $ScriptDirectory..."
    "Enter VM names (one per line), then save and close the file." | Out-File -FilePath $VMListFile -Encoding UTF8
    notepad.exe $VMListFile
    Write-Host "`nPlease add VM names to the file and restart the script."
    Stop-Transcript
    exit
}

# Load VM list from the file and check for empty entries
$VMList = Get-Content $VMListFile | Where-Object {$_ -ne ""}
if (-not $VMList) {
    Write-Host "`n No VMs found in VMList.txt. Please update the file and restart the script."
    Stop-Transcript
    exit
}

# Display the list of VMs that will be processed
Write-Host "`n The following VMs will be processed:"
$VMList | ForEach-Object { Write-Host " - $_" }

# Prompt for confirmation before proceeding
$confirmation = Read-Host "`nIs this correct? (Y/N)"
if ($confirmation.ToLower() -ne "y") {
    Write-Host "`n User declined VM list. Exiting script."
    Stop-Transcript
    exit
}

# Connect to the selected vCenter server using provided credentials
$connection = $null
try {
    $connection = Connect-VIServer -Server $vCenter -User $credential.UserName -Password $credential.GetNetworkCredential().Password -ErrorAction Stop
    Write-Host "`n Connected to vCenter: $vCenter"
} catch {
    Write-Host "`n Failed to connect to vCenter: $vCenter. $_"
    Stop-Transcript
    exit
}

# Prompt the user for the action they want to perform
$action = Read-Host "Enter the action to perform (create, delete, list, cleanup)"
if ($action -notin @("create", "delete", "list", "cleanup")) {
    Write-Host "Invalid action entered. Exiting script."
    Stop-Transcript
    exit
}

# Define the snapshot deletion logic for the "delete" action
if ($action.ToLower() -eq "delete") {
    # Ensure the Snapshots CSV exists before proceeding
    if (-not (Test-Path $SnapshotCSV)) {
        Write-Host "`nSnapshots CSV file not found! Please ensure it has been created beforehand."
        Stop-Transcript
        exit
    }

    # Import the snapshot deletions from the CSV
    $snapshotDeletions = Import-Csv -Path $SnapshotCSV

    # Loop through each snapshot entry and prompt for confirmation before deletion
    foreach ($entry in $snapshotDeletions) {
        $vmName = $entry.VM_Name
        $snapshotID = $entry.Snapshot_ID

        # Check if the VM exists
        $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
        if ($vm) {
            Write-Host "`nFound VM: $vmName. Checking for snapshot '$snapshotID'..."

            # Get all snapshots for the VM
            $snapshots = Get-Snapshot -VM $vm -ErrorAction SilentlyContinue

            # Find the snapshot by the ID
            $snapshot = $snapshots | Where-Object { $_.Name -eq $snapshotID }

            if ($snapshot) {
                # Ask the user for confirmation before deleting the snapshot
                $confirmation = Read-Host "`nDo you want to delete snapshot '$snapshotID' for VM '$vmName'? (Y/N)"
                if ($confirmation.ToLower() -eq 'y') {
                    try {
                        # Delete the snapshot if confirmed
                        Remove-Snapshot -Snapshot $snapshot -Confirm:$false -ErrorAction Stop
                        Write-Host "Snapshot '$snapshotID' deleted for VM: $vmName"
                    } catch {
                        Write-Host "Failed to delete snapshot '$snapshotID' for VM: $vmName. $_"
                    }
                } else {
                    Write-Host "Skipped deletion of snapshot '$snapshotID' for VM: $vmName."
                }
            } else {
                Write-Host "Snapshot '$snapshotID' not found for VM: $vmName."
            }
        } else {
            Write-Host "VM '$vmName' not found."
        }
    }
}

# Other actions: Create, List, Cleanup
switch ($action.ToLower()) {
    "create" {
        # Logic for creating snapshots
        foreach ($vm in $VMList) {
            $snapshotName = Read-Host "Enter snapshot name for VM: $vm"
            $snapshotDescription = Read-Host "Enter snapshot description for VM: $vm"
            Write-Host " Creating snapshot for $vm..."
            New-Snapshot -VM $vm -Name $snapshotName -Description $snapshotDescription -Quiesce:$false -Memory:$true -ErrorAction Stop
            Write-Host " Snapshot '$snapshotName' created for VM: $vm"
        }
    }

    "list" {
        # Logic for listing snapshots
        foreach ($vm in $VMList) {
            $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
            $SnapshotCSVWithTimestamp = "$ScriptDirectory\Snapshots_$timestamp.csv"
            Get-Snapshot -VM $vm | 
                Select-Object VM, Name, Created, PowerState, Description, Id | 
                Export-Csv -Path $SnapshotCSVWithTimestamp -NoTypeInformation -Append
            Write-Host " Snapshot list for VM: $vm exported to $SnapshotCSVWithTimestamp"
        }
    }

    "cleanup" {
        # Logic for cleaning up old snapshots
        $RetentionDays = Read-Host "Enter retention period (days)"
        Cleanup-OldSnapshots -RetentionDays $RetentionDays
        Write-Host " Deleted snapshots older than $RetentionDays days"
    }
}

# Disconnect from the vCenter server
Disconnect-VIServer -Server $vCenter -Confirm:$false
Write-Host " Disconnected from vCenter: $vCenter"
Stop-Transcript
