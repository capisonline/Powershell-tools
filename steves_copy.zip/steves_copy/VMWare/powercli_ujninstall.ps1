﻿# Unregister VMware PowerCLI repository (if present)
Unregister-PSRepository -Name 'VMwarePowerCLI' -ErrorAction SilentlyContinue

# Define all known PowerCLI-related module name patterns
$modulePrefixes = @(
    'VMware.',
    'VCF-PowerCLI'
)

# System and user module paths
$pathsToSearch = @(
    "$env:ProgramFiles\\WindowsPowerShell\\Modules",
    "$env:USERPROFILE\\Documents\\WindowsPowerShell\\Modules"
)

foreach ($path in $pathsToSearch) {
    if (Test-Path $path) {
        Get-ChildItem -Path $path -Directory | Where-Object {
            $moduleName = $_.Name
            $modulePrefixes | Where-Object { $moduleName -like "$_*" }
        } | ForEach-Object {
            try {
                Write-Host "Removing module folder: $($_.FullName)"
                Remove-Item -Path $_.FullName -Recurse -Force
            } catch {
                Write-Warning "Failed to remove $($_.FullName): $_"
            }
        }
    }
}

# Clean up manual packages folder if present
$manualPkgFolder = "C:\\Program Files\\WindowsPowerShell\\Modules\\PowerCLI\\nupkgs"
if (Test-Path $manualPkgFolder) {
    Remove-Item -Path $manualPkgFolder -Recurse -Force -ErrorAction SilentlyContinue
}

# Optional: Clear user settings/logs
$userConfig = "$env:APPDATA\\VMware\\PowerCLI"
if (Test-Path $userConfig) {
    Remove-Item -Path $userConfig -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "✅ PowerCLI uninstalled from all known locations."
