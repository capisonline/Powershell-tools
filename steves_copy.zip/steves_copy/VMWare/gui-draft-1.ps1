﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Load PowerCLI Module Safely ---
if (-not (Get-Module -ListAvailable -Name VMware.PowerCLI.VCenter)) {
    [System.Windows.Forms.MessageBox]::Show("VMware PowerCLI module not found. Please install it first.", "Module Missing", 'OK', 'Error')
    exit 1
}

if (-not (Get-Module -Name VMware.PowerCLI.VCenter)) {
    Import-Module VMware.PowerCLI.VCenter -ErrorAction Stop
}

# --- Apply PowerCLI Settings Once Per Session ---
if (-not $Global:PowerCLIConfigured) {
    Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
    $Global:PowerCLIConfigured = $true
}

# --- Hardcoded Paths ---
$ScriptRoot = 'C:\temp\QCAD\VT\VMWare'
$VMListFile = Join-Path $ScriptRoot 'VMList.txt'
$LogFile = Join-Path $ScriptRoot 'VMWare_PowerCLI_Automation.log'
$SnapshotCSV = Join-Path $ScriptRoot 'Snapshots.csv'
$SnapshotDeletionCSV = Join-Path $ScriptRoot 'snapshot_deletion_csv.csv'
$VCentersFile = Join-Path $ScriptRoot 'vCenters.txt'
$ServiceListCSV = Join-Path $ScriptRoot 'services_to_disable.csv'

# --- Logging Functions ---
function Log-Info($msg) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [INFO] $msg"
}
function Log-Error($msg) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [ERROR] $msg" -ForegroundColor Red
}

# --- Placeholder Functions ---
function Prepare-VMListFile {
    if (-not (Test-Path $VMListFile)) {
        Set-Content -Path $VMListFile -Value "# Enter one VM name per line"
    }
    Start-Process notepad.exe $VMListFile
    Read-Host "Press Enter after editing and saving the VM list file"
}

function Create-Snapshots {
    Prepare-VMListFile
    # Real snapshot logic here
    Log-Info "[Mock] Snapshot creation executed using $VMListFile"
}

function List-Snapshots {
    Prepare-VMListFile
    Log-Info "[Mock] Snapshot listing executed using $VMListFile"
}

function Cleanup-Snapshots {
    Prepare-VMListFile
    Log-Info "[Mock] Snapshot cleanup executed using $VMListFile"
}

function Delete-SnapshotsFromCSV {
    if (-not (Test-Path $SnapshotDeletionCSV)) {
        Set-Content -Path $SnapshotDeletionCSV -Value "VM_Name,Snapshot_ID"
    }
    Start-Process notepad.exe $SnapshotDeletionCSV
    Read-Host "Press Enter after editing and saving the snapshot deletion CSV"
    Log-Info "[Mock] Snapshot deletion executed using $SnapshotDeletionCSV"
}

function Disable-ServicesInGuest {
    if (-not (Test-Path $ServiceListCSV)) {
        Set-Content -Path $ServiceListCSV -Value "VMName,ServiceName"
    }
    Start-Process notepad.exe $ServiceListCSV
    Read-Host "Press Enter after editing and saving the services CSV"
    Log-Info "[Mock] Disable services executed using $ServiceListCSV"
}

# --- GUI Setup ---
$form = New-Object System.Windows.Forms.Form
$form.Text = "QCAD VM GUI Tool"
$form.Size = New-Object System.Drawing.Size(720, 900)
$form.StartPosition = "CenterScreen"
$form.AutoScaleMode = 'Dpi'
$form.AutoScroll = $true

$backgroundPath = 'C:\temp\scripts\VMWare\Cap_shield.png'
if (Test-Path $backgroundPath) {
    $image = [System.Drawing.Image]::FromFile($backgroundPath)
    $form.BackgroundImage = $image
    $form.BackgroundImageLayout = 'Stretch'
}

$buttons = @(
    @{ Text = "snapshot-create"; Action = { Create-Snapshots } },
    @{ Text = "snapshot-list";   Action = { List-Snapshots } },
    @{ Text = "snapshot-delete"; Action = { Delete-SnapshotsFromCSV } },
    @{ Text = "snapshot-cleanup";Action = { Cleanup-Snapshots } },
    @{ Text = "disable-services";Action = { Disable-ServicesInGuest } },
    @{ Text = "quit";             Action = { $form.Close() } }
)

$top = 40
$fontSize = 18
$buttonWidth = 300
$buttonHeight = 50

foreach ($btnInfo in $buttons) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $btnInfo.Text
    $btn.Width = $buttonWidth
    $btn.Height = $buttonHeight
    $btn.Top = $top
    $btn.Left = ($form.ClientSize.Width - $btn.Width) / 2
    $btn.Anchor = 'Top,Left,Right'
    $btn.Font = New-Object System.Drawing.Font("Segoe UI", $fontSize, [System.Drawing.FontStyle]::Bold)
    $btn.Add_Click($btnInfo.Action)
    $form.Controls.Add($btn)
    $top += $btn.Height + 20
}

$form.Add_Shown({ $form.Activate() })
[void]$form.ShowDialog()
