﻿<# This script performs QA against the input CSV. 
It's intended as a quick method to verify TIG Designs V Actuals
Inputfile structure: 
Hostname	CPU	   RAM  	C	    D	 E
EGLVCADCCMTP01	2	8	    100 	20	 50

Outputfile Structure:
Hostname	    IP_Address	    CPU	 CPU_Actual	RAM	 RAM_Actual C	C_Actual D	D_Actual E	E_Actual
EGLVCADCCMTP01	10.46.195.13	2	 2	        8	 8	        100 99.94	 20 19.98	 50	49.98


#>
# Define the path to the input and output CSV files 
$inputCsvPath = "C:\temp\QCAD\PR\Infa\Infra_QA_Input.csv"
$outputCsvPath = "C:\temp\QCAD\PR\Infa\PR_Infra_QA_Results-fina999.csv"

# Import the CSV file
$servers = Import-Csv -Path $inputCsvPath

# Prepare an array to hold the updated server information
$updatedServers = @()

# Iterate through each server entry in the CSV
foreach ($server in $servers) {
    # Get IP address based on the hostname
    $ipAddress = Resolve-DnsName $server.Hostname | Select-Object -ExpandProperty IPAddress -ErrorAction SilentlyContinue

    # Query actual CPU count and RAM from the server using WMI
    $actualCpuCount = (Get-WmiObject -Class Win32_Processor -ComputerName $server.Hostname -ErrorAction SilentlyContinue | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum
    $actualRam = (Get-WmiObject -Class Win32_ComputerSystem -ComputerName $server.Hostname -ErrorAction SilentlyContinue).TotalPhysicalMemory / 1GB

    # Query disk sizes for C:, D:, E:
    $cDrive = Get-WmiObject -Class Win32_LogicalDisk -ComputerName $server.Hostname -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
    $dDrive = Get-WmiObject -Class Win32_LogicalDisk -ComputerName $server.Hostname -Filter "DeviceID='D:'" -ErrorAction SilentlyContinue
    $eDrive = Get-WmiObject -Class Win32_LogicalDisk -ComputerName $server.Hostname -Filter "DeviceID='E:'" -ErrorAction SilentlyContinue

    # Build the server info object with specified column order
    $serverInfo = [ordered]@{
        Hostname    = $server.Hostname
        IP_Address  = $ipAddress
        CPU         = $server.CPU
        CPU_Actual  = $actualCpuCount
        RAM         = $server.RAM
        RAM_Actual  = [math]::Round($actualRam, 2)
        C           = $server.C
        C_Actual    = [math]::Round(($cDrive.Size / 1GB), 2)
        D           = $server.D
        D_Actual    = [math]::Round(($dDrive.Size / 1GB), 2)
        E           = $server.E
        E_Actual    = [math]::Round(($eDrive.Size / 1GB), 2)
    }

    # Convert the hashtable to a custom object and add to the array
    $updatedServers += New-Object -TypeName PSObject -Property $serverInfo
}

# Export the updated server information to a new CSV file
$updatedServers | Export-Csv -Path $outputCsvPath -NoTypeInformation -Delimiter ","

# Display a message indicating completion
Write-Host "Server check results have been saved to $outputCsvPath"

