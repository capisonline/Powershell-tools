﻿Import-Module OperationsManager 

# Connect to the SCOM management server
$scomServer = "QPS-MGT-PR-20.prds.qldpol"
New-SCOMManagementGroupConnection -ComputerName $scomServer

# Path to the text file with the list of server names
$serverListPath = "C:\temp\QCAD\PR\SCOM\Servers.txt"

# Read the list of server names
$servers = Get-Content -Path $serverListPath

# Create directories to store the exported data
$exportPath = "C:\temp\QCAD\PR\SCOM\"
$monitorsPath = Join-Path -Path $exportPath -ChildPath "Monitors"
$rulesPath = Join-Path -Path $exportPath -ChildPath "Rules"
New-Item -ItemType Directory -Path $monitorsPath -Force
New-Item -ItemType Directory -Path $rulesPath -Force

foreach ($server in $servers) {
    Write-Host "Processing server: $server"

    # Get the class instance for the server
    $serverInstance = Get-SCOMClassInstance -Name $server

    if ($serverInstance -ne $null) {
        # Get all monitors applied to the server
        $monitors = $serverInstance | Get-SCOMMonitor
        $monitors | Export-Csv -Path (Join-Path -Path $monitorsPath -ChildPath "$server-Monitors.csv") -NoTypeInformation

        # Get all rules applied to the server
        $rules = $serverInstance | Get-SCOMRule
        $rules | Export-Csv -Path (Join-Path -Path $rulesPath -ChildPath "$server-Rules.csv") -NoTypeInformation
    } else {
        Write-Host "Server $server not found in SCOM"
    }
}

Write-Host "Export complete. Check the $exportPath directory for details."
