﻿# Path to the discovery script 
$scriptPath = "C:\temp\scripts\Discovery\Discovery_Physical_OS-etc.ps1"
# Path to the input file with the list of servers
$inputFile = "C:\temp\QCAD\PA\Issues\PA_OLD_New_Serverlist.txt"
# Local folder to store the results
$localTempDir = "C:\temp\QCAD\PA\Issues\test"

# Ensure the local temp directory exists
if (-Not (Test-Path -Path $localTempDir)) {
    New-Item -ItemType Directory -Path $localTempDir
}

# Read the list of servers from the input file
$servers = Get-Content -Path $inputFile

# Function to run the discovery script on a remote server
function Run-DiscoveryScript {
    param (
        [string]$server
    )

    try {
        Write-Output "Running discovery script on $server..."

        # Copy the discovery script to the server
        Copy-Item -Path $scriptPath -Destination "\\$server\C$\temp\DiscoveryScript.ps1" -Force -ErrorAction Stop
        
        # Execute the discovery script on the remote server
        Invoke-Command -ComputerName $server -ScriptBlock {
            Write-Output "Executing discovery script..."
            & "C:\temp\DiscoveryScript.ps1"
        } -ErrorAction Stop

        Write-Output "Execution completed on $server. Copying results back to local machine..."

        # Define remote and local directories
        $remoteDiscoveryFolder = "\\$server\C$\temp\Discovery"
        $localDiscoveryFolder = "$localTempDir\$server`_Discovery"

        # Copy the Discovery folder back to the local temp directory
        if (Test-Path -Path $remoteDiscoveryFolder) {
            Copy-Item -Path $remoteDiscoveryFolder -Destination $localDiscoveryFolder -Recurse -Force -ErrorAction Stop
            Write-Output "Copied Discovery folder from $server to $localDiscoveryFolder."
        } else {
            Write-Output "Discovery folder not found on $server."
        }
    }
    catch {
        Write-Output "An error occurred on ${server}: $_"
    }
}

# Loop through each server and run the discovery script
foreach ($server in $servers) {
    Run-DiscoveryScript -server $server
}

Write-Output "All tasks completed."
