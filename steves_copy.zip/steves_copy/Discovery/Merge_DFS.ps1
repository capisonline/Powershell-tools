﻿# ================== EDIT THESE ==================
$Root         = "C:\temp\QCAD\PR\Discovery\telemetry_capture\01-8-25"               # root folder containing all servers' logs (recurses)
$OutDir       = "C:\temp\QCAD\PR\Discovery\telemetry_capture\"  
$OutCsv = Join-Path $OutDir "dfs_merged_unique.csv"
$Chunk  = 5000   # rows per flush

# ======= SETUP =======
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

# Output columns (Server kept for VLOOKUP). We ignore Timestamp/Session churn for uniqueness.
$cols = 'Server','ClientComputer','User','FilePath'
Set-Content -LiteralPath $OutCsv -Value ($cols -join ',') -Encoding UTF8

# Find input files:
#   HOST_dfs.csv
#   HOST_dfs_YYYYMMDD_HHMMSS.rolledlog
$files = Get-ChildItem -Path $Root -Recurse -File | Where-Object {
  $_.Name -match '_dfs\.csv$' -or
  ($_.Extension -eq '.rolledlog' -and $_.BaseName -match '_dfs_\d{8}_\d{6}$')
} | Sort-Object FullName

if (-not $files) {
  Write-Host "No DFS logs found under $Root"
  return
}

function Norm([string]$s) { if ($null -eq $s) { '' } else { $s.Trim() } }

# Dedupe key (ignores Timestamp, SessionId, NumFilesOpen)
# Key = Server|ClientComputer|User|FilePath
$seen = New-Object System.Collections.Generic.HashSet[string]
$buf = New-Object System.Collections.Generic.List[object]
$inRows = 0; $keptRows = 0

foreach ($f in $files) {
  $server = [regex]::Match($f.BaseName,'^[^_]+').Value

  try {
    Import-Csv -LiteralPath $f.FullName | ForEach-Object {
      $inRows++

      # Your DFS capture headers:
      # Timestamp,ClientComputer,User,FilePath,SessionId,NumFilesOpen
      $client = Norm $_.ClientComputer
      $user   = Norm $_.User
      $path   = Norm $_.FilePath

      $key = '{0}|{1}|{2}|{3}' -f $server,$client,$user,$path

      if ($seen.Add($key)) {
        $obj = [pscustomobject]@{
          Server         = $server
          ClientComputer = $client
          User           = $user
          FilePath       = $path
        }
        $buf.Add($obj)
        $keptRows++

        if ($buf.Count -ge $Chunk) {
          ($buf | Select-Object $cols | ConvertTo-Csv -NoTypeInformation) |
            Select-Object -Skip 1 | Add-Content -LiteralPath $OutCsv -Encoding UTF8
          $buf.Clear()
        }
      }
    }
  } catch {
    Write-Warning "Failed to import $($f.FullName): $_"
  }
}

if ($buf.Count -gt 0) {
  ($buf | Select-Object $cols | ConvertTo-Csv -NoTypeInformation) |
    Select-Object -Skip 1 | Add-Content -LiteralPath $OutCsv -Encoding UTF8
}

Write-Host "Done."
Write-Host "Input rows scanned : $inRows"
Write-Host "Unique rows kept   : $keptRows"
Write-Host "Output CSV         : $OutCsv"
