﻿# ======= EDIT THESE =======
$Root   = "C:\temp\QCAD\PR\Discovery\telemetry_capture\01-8-25"         # where the server folders live (recurses)
$OutDir = "C:\temp\QCAD\PR\Discovery\telemetry_capture\processes_merged_OUT"
$OutCsv = Join-Path $OutDir "processes_merged_unique.csv"
$Chunk  = 5000   # rows per flush

# ======= SETUP =======
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

# Output columns (Server kept for VLOOKUP)
$cols = 'Server','Name','Id','ExecutablePath','CommandLine','UserName','HostedServices'
Set-Content -LiteralPath $OutCsv -Value ($cols -join ',') -Encoding UTF8

# Find input files:
#   HOST_processes.csv
#   HOST_processes_YYYYMMDD_HHMMSS.rolledlog
$files = Get-ChildItem -Path $Root -Recurse -File | Where-Object {
  $_.Name -match '_processes\.csv$' -or
  ($_.Extension -eq '.rolledlog' -and $_.BaseName -match '_processes_\d{8}_\d{6}$')
} | Sort-Object FullName

if (-not $files) {
  Write-Host "No process logs found under $Root"
  return
}

# Dedup set: ignore Timestamp; dedupe on Server + the other fields
# Key = Server|Name|ExecutablePath|CommandLine|UserName|HostedServices
$seen = New-Object System.Collections.Generic.HashSet[string]

$buf = New-Object System.Collections.Generic.List[object]
$inRows = 0; $keptRows = 0

function Norm([string]$s) {
  if ($null -eq $s) { return '' }
  return $s.Trim()
}

foreach ($f in $files) {
  $server = [regex]::Match($f.BaseName,'^[^_]+').Value

  try {
    Import-Csv -LiteralPath $f.FullName | ForEach-Object {
      $inRows++

      $name = Norm $_.Name
      $id   = $_.Id
      $exe  = Norm $_.ExecutablePath
      $cmd  = Norm $_.CommandLine
      $user = Norm $_.UserName
      $svc  = Norm $_.HostedServices

      # Build dedupe key (no Timestamp, and NOT using Id so we collapse across snapshots even if PID changes)
      $key = '{0}|{1}|{2}|{3}|{4}|{5}' -f $server, $name, $exe, $cmd, $user, $svc

      if ($seen.Add($key)) {
        $obj = [pscustomobject]@{
          Server         = $server
          Name           = $name
          Id             = $id
          ExecutablePath = $exe
          CommandLine    = $cmd
          UserName       = $user
          HostedServices = $svc
        }
        $buf.Add($obj)
        $keptRows++

        if ($buf.Count -ge $Chunk) {
          ($buf | Select-Object $cols | ConvertTo-Csv -NoTypeInformation) |
            Select-Object -Skip 1 | Add-Content -LiteralPath $OutCsv -Encoding UTF8
          $buf.Clear()
        }
      }
    }
  } catch {
    Write-Warning "Failed to import $($f.FullName): $_"
  }
}

if ($buf.Count -gt 0) {
  ($buf | Select-Object $cols | ConvertTo-Csv -NoTypeInformation) |
    Select-Object -Skip 1 | Add-Content -LiteralPath $OutCsv -Encoding UTF8
  $buf.Clear()
}

Write-Host "Done."
Write-Host "Input rows scanned : $inRows"
Write-Host "Unique rows kept   : $keptRows"
Write-Host "Output CSV         : $OutCsv"
