﻿# Ensure the temp directory exists 
$tempDir = "C:\temp\Discovery"
if (-Not (Test-Path -Path $tempDir)) {
    New-Item -ItemType Directory -Path $tempDir
}

# Get the hostname of the server
$hostname = $env:COMPUTERNAME

# Function to gather system information
function Get-SystemInfo {
    Write-Output "Gathering system information..."
    $sysInfo = Get-WmiObject -Class Win32_ComputerSystem
    $sysInfo | Select-Object Name, Manufacturer, Model, @{Name="TotalPhysicalMemoryGB";Expression={[math]::Round($_.TotalPhysicalMemory / 1GB, 2)}} |
        Export-Csv -Path "$tempDir\$hostname`_SystemInfo.csv" -NoTypeInformation
}

# Function to check CPU, RAM, and disks
function Check-CPU-RAM-Disks {
    Write-Output "Checking CPU, RAM, and Disks..."
    $cpu = Get-WmiObject -Class Win32_Processor
    $ram = Get-WmiObject -Class Win32_PhysicalMemory
    $disks = Get-WmiObject -Class Win32_LogicalDisk -Filter "DriveType=3"
    
    $cpu | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed |
        Export-Csv -Path "$tempDir\$hostname`_CPUInfo.csv" -NoTypeInformation
    $ram | Select-Object @{Name="CapacityGB";Expression={[math]::Round($_.Capacity / 1GB, 2)}}, Manufacturer, Speed, PartNumber |
        Export-Csv -Path "$tempDir\$hostname`_RAMInfo.csv" -NoTypeInformation
    $disks | Select-Object DeviceID, VolumeName, @{Name="SizeGB";Expression={[math]::Round($_.Size / 1GB, 2)}}, @{Name="FreeSpaceGB";Expression={[math]::Round($_.FreeSpace / 1GB, 2)}} |
        Export-Csv -Path "$tempDir\$hostname`_DiskInfo.csv" -NoTypeInformation
}

# Function to gather server shares list
function Get-ServerShares {
    Write-Output "Gathering server shares list..."
    $shares = Get-WmiObject -Class Win32_Share
    $shares | Select-Object Name, Path, Description |
        Export-Csv -Path "$tempDir\$hostname`_ServerShares.csv" -NoTypeInformation
}

# Function to gather Group Policy results in HTML format
function Get-GPResult {
    Write-Output "Gathering Group Policy results..."
    gpresult /h "$tempDir\$hostname`_GPResult.html"
}

# Function to check network statistics with formatting
function Check-NetStat {
    Write-Output "Checking network statistics..."
    $netStat = (netstat -bano | Out-String) -replace '(?m)^  (TCP|UDP)', '$1' -replace '\r?\n\s+([^\[])', "`t`$1" -replace '\r?\n\s+\[', "`t["
    $netStat | Out-File -FilePath "$tempDir\$hostname`_NetStat.txt"
}

# Function to gather uninstall registry keys including Wow64 keys
function Get-UninstallKeys {
    Write-Output "Gathering uninstall registry keys..."
    $standardUninstallKeys = Get-ChildItem "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall" |
        Get-ItemProperty |
        Select-Object DisplayName, DisplayVersion, Publisher, InstallDate, @{Name="RegistryPath";Expression={"HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall"}}
    $wow64UninstallKeys = Get-ChildItem "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall" |
        Get-ItemProperty |
        Select-Object DisplayName, DisplayVersion, Publisher, InstallDate, @{Name="RegistryPath";Expression={"HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"}}
    
    $allUninstallKeys = $standardUninstallKeys + $wow64UninstallKeys
    $allUninstallKeys | Export-Csv -Path "$tempDir\$hostname`_UninstallKeys.csv" -NoTypeInformation
}

# Function to get service information including the account the service runs as and executable path
function Get-ServiceInfo {
    Write-Output "Gathering service information..."
    $services = Get-WmiObject -Class Win32_Service
    $serviceInfo = $services | Select-Object Name, DisplayName, StartName, State, PathName
    $serviceInfo | Export-Csv -Path "$tempDir\$hostname`_Services.csv" -NoTypeInformation
}

# Function to gather patch and update status
function Get-PatchStatus {
    Write-Output "Gathering patch and update status..."
    $patches = Get-HotFix
    $patches | Export-Csv -Path "$tempDir\$hostname`_PatchStatus.csv" -NoTypeInformation
}

# Function to gather event logs
function Get-EventLogs {
    Write-Output "Gathering recent event logs..."
    $events = Get-EventLog -LogName System -Newest 100
    $events | Export-Csv -Path "$tempDir\$hostname`_EventLogs.csv" -NoTypeInformation
}

# Function to gather running processes
function Get-RunningProcesses {
    Write-Output "Gathering running processes..."
    $processes = Get-Process
    $processes | Select-Object Name, Id, Handles, WorkingSet, CPU, FileVersion | Export-Csv -Path "$tempDir\$hostname`_RunningProcesses.csv" -NoTypeInformation
}

# Function to gather network configuration
function Get-NetworkConfig {
    Write-Output "Gathering network configuration..."
    $network = Get-WmiObject -Class Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled }
    $network | Select-Object Description, MACAddress, IPAddress, IPSubnet, DefaultIPGateway, DNSServerSearchOrder | Export-Csv -Path "$tempDir\$hostname`_NetworkConfig.csv" -NoTypeInformation
}

# Function to gather members of the Administrators group using net localgroup command
function Get-AdminGroupMembers {
    Write-Output "Gathering members of the Administrators group..."

    $adminGroupInfo = net localgroup Administrators
    $adminMembers = $adminGroupInfo -split "`r`n" | Where-Object { $_ -notmatch "Alias name|---|command completed successfully" -and $_ -ne "" }
    $adminMembers | ForEach-Object {
        [PSCustomObject]@{
            GroupName = "Administrators"
            Member = $_.Trim()
        }
    } | Export-Csv -Path "$tempDir\$hostname`_AdminGroupMembers.csv" -NoTypeInformation
}

# Function to gather firewall rules
function Get-FirewallRules {
    Write-Output "Gathering firewall rules..."
    $firewallRules = Get-NetFirewallRule
    $firewallRules | Select-Object DisplayName, Enabled, Direction, Action, Profile | Export-Csv -Path "$tempDir\$hostname`_FirewallRules.csv" -NoTypeInformation
}

# Function to gather scheduled tasks
function Get-ScheduledTasks {
    Write-Output "Gathering scheduled tasks..."
    $tasks = Get-ScheduledTask
    $tasks | Select-Object TaskName, TaskPath, State, LastRunTime, NextRunTime | Export-Csv -Path "$tempDir\$hostname`_ScheduledTasks.csv" -NoTypeInformation
}

# Function to gather system uptime and reboot history
function Get-UptimeAndRebootHistory {
    Write-Output "Gathering system uptime and reboot history..."
    $uptime = Get-CimInstance -ClassName Win32_OperatingSystem | Select-Object @{Name="LastBootUpTime";Expression={($_.LastBootUpTime)}}
    $uptime | Export-Csv -Path "$tempDir\$hostname`_Uptime.csv" -NoTypeInformation

    $rebootHistory = Get-EventLog -LogName System -Source "EventLog" -Newest 100 | Where-Object { $_.EventID -eq 6005 -or $_.EventID -eq 6006 } | Select-Object TimeGenerated, EntryType, Message
    $rebootHistory | Export-Csv -Path "$tempDir\$hostname`_RebootHistory.csv" -NoTypeInformation
}

# Main Execution Block
Write-Output "Starting discovery script..."

Get-SystemInfo
Check-CPU-RAM-Disks
Get-ServerShares
Get-GPResult
Check-NetStat
Get-UninstallKeys
Get-ServiceInfo
Get-PatchStatus
Get-EventLogs
Get-RunningProcesses
Get-NetworkConfig
Get-AdminGroupMembers
Get-FirewallRules
Get-ScheduledTasks
Get-UptimeAndRebootHistory

Write-Output "Discovery script completed. Reports saved to $tempDir."
