﻿# Define the path to the input file and output CSV 
$inputFile = "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"
$outputFile = "C:\temp\QCAD\VT\Sys_Variables\VT_EnvironmentVariables22.csv"

# Read server names from the text file
$servers = Get-Content $inputFile

# Prepare the results array
$results = @()

# Loop through each server and gather environment variables
foreach ($server in $servers) {
    # Check if we can establish a session
    if (Test-Connection $server -Count 1 -Quiet) {
        # Use Invoke-Command to execute remotely
        $envVars = Invoke-Command -ComputerName $server -ScriptBlock {
            Get-ChildItem Env: | Select-Object Name, Value
        }
        # Add server information and environment variables to results
        foreach ($var in $envVars) {
            $results += [PSCustomObject]@{
                Server = $server
                Variable = $var.Name
                Value = $var.Value
            }
        }
    } else {
        # If server is not reachable, note it in the results
        $results += [PSCustomObject]@{
            Server = $server
            Variable = "N/A"
            Value = "Server not reachable"
        }
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputFile -NoTypeInformation

# Output the location of the CSV file
Write-Host "Environment variables saved to $outputFile"
