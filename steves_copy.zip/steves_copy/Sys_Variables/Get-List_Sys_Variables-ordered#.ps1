﻿# Define input and output file paths 
$serverList = "C:\temp\QCAD\VT\VT_Old_Servers.txt"  # Update with the path to your server list
$outputCSV = "C:\temp\QCAD\VT\Sys_Variables\VT_OLD_env_variables.csv"  # Update with the desired output path

# Initialize an array to store the results
$results = @()

# Get environment variables from each server
foreach ($server in Get-Content $serverList) {
    try {
        # Check if the server is reachable
        if (Test-Connection -ComputerName $server -Count 2 -Quiet) {
            # Get system and user environment variables from the server
            $envVars = Invoke-Command -ComputerName $server -ScriptBlock {
                [System.Environment]::GetEnvironmentVariables()
            }

            # Iterate over each environment variable and store results
            foreach ($envVar in $envVars.GetEnumerator()) {
                if ($envVar.Key -eq "PATH") {
                    # If it's the PATH variable, split its values for order
                    $pathEntries = $envVar.Value -split ";"
                    for ($i = 0; $i -lt $pathEntries.Count; $i++) {
                        $results += [pscustomobject]@{
                            Hostname      = $server
                            VariableName  = "PATH"
                            Value         = $pathEntries[$i]
                            Order         = $i + 1
                        }
                    }
                } else {
                    # Store other variables
                    $results += [pscustomobject]@{
                        Hostname      = $server
                        VariableName  = $envVar.Key
                        Value         = $envVar.Value
                        Order         = $null
                    }
                }
            }
        } else {
            Write-Host "Server $server is unreachable"
        }
    } catch {
        Write-Host "Failed to retrieve variables from ${server}: $_"
    }
}

# Export results to a CSV file
$results | Export-Csv -Path $outputCSV -NoTypeInformation

Write-Host "Environment variables have been saved to $outputCSV"
