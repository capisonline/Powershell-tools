﻿# This script will connect to a list of servers listed in the input csv 
# and try to register the DLLs listed in the 2nd column. 
# Structure the csv as so:
# Column A          Column B
# Servername	    dll path
# EGLVCADVASPA02	D:\oracle\product\19.0.0\client_1\ODP.NET\bin\2.x\Oracle.DataAccess.dll

# Define the path to the input CSV file 
$InputCSV = "C:\temp\scripts\DLL\DLL_Register_QCAD.csv"

# Import the CSV file
$dllEntries = Import-Csv -Path $InputCSV

# Loop through each entry in the CSV
foreach ($entry in $dllEntries) {
    $server = $entry.Servername
    $dllPath = $entry."dll path"
    $command = "oraprovcfg.exe /action:gac /providerpath:`"$dllPath`""

    Write-Host "Registering DLL on server ${server}: $dllPath"
    
    # Use Invoke-Command to run the command on the remote server
    try {
        Invoke-Command -ComputerName $server -ScriptBlock {
            param ($cmd)
            Invoke-Expression $cmd
        } -ArgumentList $command

        Write-Host "Successfully registered $dllPath on $server" -ForegroundColor Green
    } catch {
        Write-Host "Failed to register $dllPath on $server. Error: $_" -ForegroundColor Red
    }
}
