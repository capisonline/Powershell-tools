﻿# Specify the path to the text file containing server names 
$serversFile = "C:\temp\QCAD\PA\PA_New_Server_list.txt"

# Specify the local path to store the copied files
$localPath = "C:\temp\QCAD\PA\Group_Policy\"

# Check if the file exists
if (Test-Path $serversFile) {
    # Read the list of server names from the file
    $servers = Get-Content $serversFile

    # Loop through each server
    foreach ($server in $servers) {
        # Construct the remote PowerShell session
        $session = New-PSSession -ComputerName $server

        # Check if C:\temp exists on the remote server, create if not
        Invoke-Command -Session $session -ScriptBlock {
            if (-Not (Test-Path "C:\temp")) {
                New-Item -Path "C:\temp" -ItemType Directory
            }
        }

        # Execute gpupdate /force on the remote server
        Invoke-Command -Session $session -ScriptBlock {
            gpupdate /force
        }

        # Check if the gpresult file already exists and rename it if it does
        $commandCheckAndRename = {
            $filepath = "C:\temp\$($env:COMPUTERNAME)_gpresult.html"
            if (Test-Path $filepath) {
                $timestamp = Get-Date -Format "yy-MM-dd-HH-mm"
                Rename-Item -Path $filepath -NewName ("$($env:COMPUTERNAME)_gpresult_" + $timestamp + ".html")
            }
        }

        # Invoke the check and rename command
        Invoke-Command -Session $session -ScriptBlock $commandCheckAndRename

        # Generate a new gpresult file
        $commandGenerate = "gpresult /h C:\temp\$($server)_gpresult.html"

        # Execute the command on the remote server
        Invoke-Command -Session $session -ScriptBlock {
            param($command)
            Invoke-Expression $command
        } -ArgumentList $commandGenerate

        # Copy the generated file back to the local machine
        $remoteFilePath = "\\$server\C$\temp\$($server)_gpresult.html"
        Copy-Item -Path $remoteFilePath -Destination $localPath -Force

        # Close the remote PowerShell session
        Remove-PSSession $session
    }
} else {
    Write-Host "Server list file not found: $serversFile"
}
