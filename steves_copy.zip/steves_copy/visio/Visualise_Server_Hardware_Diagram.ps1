# ===== iDRAC XML -> Visio Diagrams (Topology + Components) =====
# Run as Admin on a machine with Microsoft Visio installed.

# ---------- CONFIG ----------
$XmlPath  = "C:\temp\QCAD\PR\Oracle\7YLVXW3-HardwareInventory.xml"    # <-- change me
$OutVsdx  = "C:\temp\QCAD\PR\Oracle\Server-Diagrams.vsdx"   # <-- change me
$ServerLabelOverride = $null                  # e.g. "BNE-CAD-APP-01"; if null, use XML Model/ServiceTag

# ---------- HELPERS ----------
function New-VisioApp {
  $visio = New-Object -ComObject Visio.Application
  $visio.Visible = $true
  $doc = $visio.Documents.Add("")
  return @{App=$visio;Doc=$doc}
}
function OpenStencil([string]$name){ $global:BasicStencil = $global:BasicStencil ?? $null; if(-not $global:BasicStencil){ $global:BasicStencil = $visio.App.Documents.OpenEx("BASIC_U.VSSX",64) }; return $global:BasicStencil }
function DropBox($page, $text, [double]$x, [double]$y, [double]$w=2, [double]$h=1) {
  $stn = OpenStencil "BASIC_U.VSSX"
  $master = $stn.Masters.ItemU("Rectangle")
  $shape = $page.Drop($master, $x, $y)
  $shape.CellsU("Width").Result("in") = $w
  $shape.CellsU("Height").Result("in") = $h
  $shape.Text = $text
  return $shape
}
function Connector($page, $fromShape, $toShape, [string]$label="") {
  $connMaster = (OpenStencil).Masters.ItemU("Dynamic connector")
  $conn = $page.Drop($connMaster,0,0)
  $conn.CellsU("EndArrow").FormulaU = "5"
  $conn.CellsU("LineColor").FormulaU = "THEMEGUARD(RGB(0,0,0))"
  $conn.CellsU("LineWeight").Result("pt") = 1
  $conn.CellsU("LinePattern").Result("") = 1
  $fromShape.AutoConnect($toShape, 0, $conn) | Out-Null
  if($label){ $conn.Text = $label }
  return $conn
}

# ---------- PARSE XML ----------
if (-not (Test-Path $XmlPath)) { throw "XML not found: $XmlPath" }
[xml]$x = Get-Content -Path $XmlPath

# Try to accommodate common iDRAC export layouts:
# Adjust your XPath here if your file differs. The idea is to pull:
# - System: Model, ServiceTag
# - CPUs
# - Memory DIMMs
# - NICs (name, mac, speed, port/slot)
# - Storage Controllers & PhysicalDisks
# - PowerSupplies, Fans
$sys = @{
  Model      = ($x.SelectSingleNode("//System[1]/Model")?.InnerText) -as [string]
  ServiceTag = ($x.SelectSingleNode("//System[1]/ServiceTag")?.InnerText) -as [string]
  Hostname   = ($x.SelectSingleNode("//System[1]/HostName")?.InnerText) -as [string]
}
$label = $ServerLabelOverride
if (-not $label) {
  $label = @($sys.Hostname, $sys.Model, $sys.ServiceTag) | Where-Object { $_ } | Select-Object -First 1
  if (-not $label) { $label = "Server" }
}

$cpus   = $x.SelectNodes("//CPU | //Processors/CPU")
$dimms  = $x.SelectNodes("//Memory/DIMM | //Memory/Device")
$nics   = $x.SelectNodes("//NICs/NIC | //NetworkAdapters/NetworkAdapter | //NIC")
$ctls   = $x.SelectNodes("//Storage/Controller | //RAID/Controller")
$disks  = $x.SelectNodes("//Storage/PhysicalDisk | //PhysicalDisks/Disk | //Disk")
$psus   = $x.SelectNodes("//PowerSupplies/PowerSupply | //PSU")
$fans   = $x.SelectNodes("//Fans/Fan | //Cooling/Fan")
$idrac  = $x.SelectSingleNode("//iDRAC | //ManagementController")

# ---------- BUILD VISIO ----------
$visio = New-VisioApp
$global:visio = $visio

# Page 1: Topology ------------------------------------------------
$pageTopo = $visio.Doc.Pages.Item(1)
$pageTopo.Name = "Topology"

# Server block
$server = DropBox $pageTopo "$label`nModel: $($sys.Model)`nST: $($sys.ServiceTag)" 4.5 7.5 3 1.2

# iDRAC mgmt (if present)
if ($idrac) {
  $ip   = ($idrac.SelectSingleNode("./IPAddress")?.InnerText)   -as [string]
  $fw   = ($idrac.SelectSingleNode("./Firmware")?.InnerText)   -as [string]
  $idr  = DropBox $pageTopo "iDRAC`n$ip`n$fw" 1.5 7.5 2 1
  Connector $pageTopo $idr $server "Mgmt"
}

# NICs → Switch nodes
# We’ll group NICs by speed where possible and draw individual switch boxes (generic) to the right.
$nicY = 6.5
$swX  = 8.5
$nics | ForEach-Object {
  $name  = ($_.SelectSingleNode("./Name")?.InnerText) -as [string]
  if(-not $name){ $name = ($_.SelectSingleNode("./ProductName")?.InnerText) }
  $mac   = ($_.SelectSingleNode("./MACAddress")?.InnerText) -as [string]
  $speed = ($_.SelectSingleNode("./LinkSpeed")?.InnerText) -as [string]
  if(-not $speed){ $speed = ($_.SelectSingleNode("./CurrentSpeed")?.InnerText) }
  $port  = ($_.SelectSingleNode("./Port")?.InnerText) -as [string]
  $slot  = ($_.SelectSingleNode("./Slot")?.InnerText) -as [string]

  $nicBox = DropBox $pageTopo "NIC: $name`n$mac`n$($speed ?? '')" 4.5 $nicY 3 0.9
  $swBox  = DropBox $pageTopo "Switch`n($($speed ?? 'link'))"      $swX $nicY 2 0.9
  Connector $pageTopo $server $nicBox "host bus"
  Connector $pageTopo $nicBox $swBox  "uplink$([string]::IsNullOrEmpty($port) ? '' : " p$port")"
  $nicY -= 1.1
}

# Storage: controller(s) and disk shelf
$storY = 2.0
if ($ctls -and $ctls.Count -gt 0) {
  $ctlBox = DropBox $pageTopo "Storage Controller(s)" 4.5 $storY 3 0.9
  Connector $pageTopo $server $ctlBox "PCIe"
  # Aggregate disks to a logical shelf on right
  $diskCount = ($disks | Measure-Object).Count
  if ($diskCount -gt 0){
    $shelf = DropBox $pageTopo "Disk Shelf`n$diskCount drives" $swX $storY 2 0.9
    Connector $pageTopo $ctlBox $shelf "SAS"
  }
}

# Page 2: Components ----------------------------------------------
$pageComp = $visio.Doc.Pages.Add()
$pageComp.Name = "Components"

# Chassis
$chassis = DropBox $pageComp "$label" 4.5 6.5 6.5 4.5

# Inside layout grid helpers
function PlaceInside($parent, [double]$xPct, [double]$yPct, [double]$wPct, [double]$hPct, [string]$text){
  # Convert percentages of parent size into inches
  $px = $parent.CellsU("PinX").Result("in"); $py = $parent.CellsU("PinY").Result("in")
  $pw = $parent.CellsU("Width").Result("in"); $ph = $parent.CellsU("Height").Result("in")
  $x = $px - $pw/2 + $pw*$xPct + ($pw*$wPct)/2
  $y = $py + $ph/2 - $ph*$yPct - ($ph*$hPct)/2
  return DropBox $pageComp $text $x $y ($pw*$wPct) ($ph*$hPct)
}

# CPUs
if($cpus -and $cpus.Count -gt 0){
  $i=0
  foreach($cpu in $cpus){
    $model = ($cpu.SelectSingleNode("./Model")?.InnerText) -as [string]
    $cores = ($cpu.SelectSingleNode("./Cores")?.InnerText) -as [string]
    $speed = ($cpu.SelectSingleNode("./Speed")?.InnerText) -as [string]
    $txt = "CPU$($i+1)`n$model`n$cores cores`n$speed"
    PlaceInside $chassis (0.03 + 0.24*$i) 0.05 0.22 0.28 $txt | Out-Null
    $i++
  }
}

# Memory (group into banks by slot prefix when possible)
if($dimms -and $dimms.Count -gt 0){
  $count = $dimms.Count
  $totalGB = 0
  $memLines = @()
  foreach($d in $dimms){
    $sizeTxt = ($d.SelectSingleNode("./SizeMB")?.InnerText)
    if($sizeTxt -match '^\d+$'){ $totalGB += [int]$sizeTxt/1024 }
    $slot = ($d.SelectSingleNode("./Slot")?.InnerText) -as [string]
    $spd  = ($d.SelectSingleNode("./SpeedMHz")?.InnerText) -as [string]
    $memLines += ("{0} - {1}MB @{2}MHz" -f ($slot ?? "DIMM"), ($sizeTxt ?? "?"), ($spd ?? "?"))
  }
  $memTxt = "Memory ($count DIMMs ~{0:N0} GB)`n{1}" -f $totalGB, ($memLines -join "`n")
  PlaceInside $chassis 0.28 0.05 0.44 0.5 $memTxt | Out-Null
}

# NICs block (summarized)
if($nics -and $nics.Count -gt 0){
  $nicLines = @()
  $idx=1
  foreach($n in $nics){
    $name  = ($n.SelectSingleNode("./Name")?.InnerText) -as [string]
    if(-not $name){ $name = ($n.SelectSingleNode("./ProductName")?.InnerText) }
    $mac   = ($n.SelectSingleNode("./MACAddress")?.InnerText) -as [string]
    $speed = ($n.SelectSingleNode("./LinkSpeed")?.InnerText) -as [string]
    $port  = ($n.SelectSingleNode("./Port")?.InnerText) -as [string]
    $slot  = ($n.SelectSingleNode("./Slot")?.InnerText) -as [string]
    $nicLines += ("NIC{0}: {1} {2} {3} {4}" -f $idx, ($name ?? ""), ($mac ?? ""), ($speed ?? ""), ($(if($slot){"(slot $slot)"})))
    $idx++
  }
  PlaceInside $chassis 0.74 0.05 0.23 0.5 ("Network`n" + ($nicLines -join "`n")) | Out-Null
}

# Storage (controllers + disks)
if($ctls -and $ctls.Count -gt 0 -or $disks.Count -gt 0){
  $ctlLines = @()
  foreach($c in $ctls){
    $cname = ($c.SelectSingleNode("./Name")?.InnerText) -as [string]
    $ctype = ($c.SelectSingleNode("./Type")?.InnerText) -as [string]
    $ctlLines += ("{0} {1}" -f ($cname ?? "Controller"), ($ctype ?? ""))
  }
  $dLines = @()
  foreach($d in $disks){
    $slot  = ($d.SelectSingleNode("./Slot")?.InnerText) -as [string]
    $cap   = ($d.SelectSingleNode("./CapacityGB")?.InnerText) -as [string]
    if(-not $cap){ $cap = ($d.SelectSingleNode("./Capacity")?.InnerText) }
    $type  = ($d.SelectSingleNode("./MediaType")?.InnerText) -as [string]
    $dLines += ("Disk{0}: {1} {2}" -f ($slot ?? ""), ($cap ?? ""), ($type ?? ""))
  }
  $storTxt = "Storage`n" + (($ctlLines + $dLines) -join "`n")
  PlaceInside $chassis 0.03 0.38 0.94 0.25 $storTxt | Out-Null
}

# Power & Cooling
if($psus -and $psus.Count -gt 0){
  $psTxt = "Power Supplies`n" + (($psus | ForEach-Object { ($_.SelectSingleNode("./Name")?.InnerText) ?? "PSU" }) -join "`n")
  PlaceInside $chassis 0.03 0.66 0.47 0.18 $psTxt | Out-Null
}
if($fans -and $fans.Count -gt 0){
  $fanTxt = "Fans`n" + (($fans | ForEach-Object { ($_.SelectSingleNode("./Name")?.InnerText) ?? "Fan" }) -join "`n")
  PlaceInside $chassis 0.53 0.66 0.44 0.18 $fanTxt | Out-Null
}

# Save
$visio.Doc.SaveAs($OutVsdx)
Write-Host "Diagrams saved to: $OutVsdx"
