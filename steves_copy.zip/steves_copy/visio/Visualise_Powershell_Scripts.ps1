﻿<# 
.SYNOPSIS
    This script analyzes a PowerShell script's logic and generates a structured table suitable for import into Microsoft Visio to create a flowchart. 
    It identifies key programming constructs, such as loops, conditionals, and processes, including nested and decision-based logic.

.DESCRIPTION
    - Reads a PowerShell script to extract its logical flow.
    - Recognizes constructs like loops (e.g., foreach, while), error handling (e.g., try-catch), conditionals (e.g., if-else), and specific cmdlets (e.g., New-Item, Export-Csv).
    - Tracks nested constructs and reconnects flow after branching (e.g., reconnects after if-else).
    - Dynamically maps custom patterns or tagged comments (e.g., # TASK:).
    - Generates a structured table with:
        - Step ID: Unique identifier for each step.
        - Step Name: Descriptive name of the action or decision.
        - Description: Explanation of what the step does.
        - Shape: Flowchart shape (e.g., Process, Decision, Terminator).
        - Next Step: Logical connection to the next step in the flow.

.INPUTS
    - Path to the target PowerShell script.

.OUTPUTS
    - CSV file containing the flowchart data, which can be imported into Visio.

.EXAMPLE
    Run the script as follows:
        .\GenerateLogicTable.ps1

.NOTES
    This script simplifies documenting and communicating complex scripts to non-technical audiences by converting code logic into intuitive flowcharts.
    It is designed to be modular and extensible to accommodate larger, more complex PowerShell scripts.
#>

# User-defined variables
# Update these variables as needed before running the script
$InputScript = "C:\temp\scripts\QCAD\qcad_Main_COnfig_Install_5000lines.ps1" # Path to the input PowerShell script
$OutputCsv = "C:\temp\scripts\visio\diagrams\qcad_Main_COnfig_Install_5000lines.csv" # Path to save the output CSV

# Initialize arrays and variables for tracking
$flowchartSteps = @()
$decisionStack = @()
$currentDecisionId = $null
$stepId = 1

# Read the input script
$scriptContent = Get-Content -Path $InputScript

# Parse script for key logic blocks
foreach ($line in $scriptContent) {
    $line = $line.Trim()

    if ($line -match "if\s*\(") {
        # Push to the decision stack
        $decisionStack += $stepId
        $currentDecisionId = $stepId

        # Add 'If Condition' step
        $flowchartSteps += [PSCustomObject]@{
            StepID      = $stepId++
            StepName    = "Evaluate If Condition"
            Description = "Evaluates: $line"
            Shape       = "Decision"
            NextStep    = $stepId
        }
    } elseif ($line -match "else") {
        # Add 'Else Branch' step, linking to the current decision
        $flowchartSteps += [PSCustomObject]@{
            StepID      = $stepId++
            StepName    = "Else Block"
            Description = "Executes alternative logic"
            Shape       = "Process"
            NextStep    = $stepId
        }
    } elseif ($line -match "foreach") {
        # Add 'Loop' step
        $flowchartSteps += [PSCustomObject]@{
            StepID      = $stepId++
            StepName    = "Loop through $($line -replace 'foreach','')"
            Description = "Iterates through a list: $line"
            Shape       = "Process"
            NextStep    = $stepId
        }
    } elseif ($line -match "}") {
        # Pop decision stack if closing a block
        if ($decisionStack.Count -gt 0) {
            $currentDecisionId = $decisionStack[-1]
            $decisionStack = $decisionStack[0..($decisionStack.Count - 2)]
        }
    } elseif ($line -match "Write-Host") {
        # Add a regular step
        $flowchartSteps += [PSCustomObject]@{
            StepID      = $stepId++
            StepName    = "Display Message"
            Description = "Outputs a message to the console"
            Shape       = "Process"
            NextStep    = $stepId
        }
    }
}

# Add a final 'End' step
$flowchartSteps += [PSCustomObject]@{
    StepID      = $stepId++
    StepName    = "End"
    Description = "Script execution completes"
    Shape       = "Terminator"
    NextStep    = $null
}

# Export the flowchart steps to a CSV
$flowchartSteps | Export-Csv -Path $OutputCsv -NoTypeInformation -Force

Write-Host "Flowchart logic saved to $OutputCsv"
