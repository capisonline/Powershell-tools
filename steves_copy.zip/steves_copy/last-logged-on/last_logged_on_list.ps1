﻿<# 
.SYNOPSIS
    Script to track down missing Win10 laptops by retrieving information about the last logged-on user, last IP address, and other details.
    
.DESCRIPTION
    This script takes a list of laptop hostnames or IP addresses from an input file and retrieves the last logged-on user, last IP address, 
    active sessions, and operating system details. The output is saved to a CSV file with the hostname in the first column.

.PARAMETER InputFile
    Path to the text file containing a list of laptop hostnames or IP addresses (one per line).

.PARAMETER OutputFile
    Path to the CSV file where the output information will be saved.

.EXAMPLE
    .\TrackLaptops.ps1 -InputFile "C:\path\to\input.txt" -OutputFile "C:\path\to\output.csv"


OR just update the variables and run it from Powershell ISE.
Originally written for BHP and I haven't updated it but it still works! :D

Rogers.Steven(CC) <Rogers.Steven2@police.qld.gov.au>
#>

param (
    [string]$InputFile = "C:\temp\scripts\last-logged-on\laptop_list.txt",
    [string]$OutputFile = "C:\temp\scripts\last-logged-on\output.csv"
)

# Read the list of laptop hostnames or IP addresses from the input file
$laptops = Get-Content -Path $InputFile

# Initialize an array to hold the output objects
$output = @()

foreach ($laptop in $laptops) {
    Write-Host "Checking laptop: $laptop"

    try {
        # Get the active sessions (if any)
        $activeSessions = query user /server:$laptop

        # Get the last logged-on user
        $lastUser = Get-WmiObject -Class Win32_NetworkLoginProfile -ComputerName $laptop |
                    Sort-Object -Property LastLogon -Descending |
                    Select-Object -First 1

        # Get the last IP address
        $lastIP = Get-WmiObject -Class Win32_NetworkAdapterConfiguration -ComputerName $laptop |
                  Where-Object { $_.IPAddress -ne $null } |
                  Select-Object -ExpandProperty IPAddress |
                  Select-Object -First 1

        # Get the operating system details
        $osDetails = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $laptop |
                     Select-Object -Property CSName, Caption, OSArchitecture, Version

        # Create a custom object with the gathered information
        $outputObject = [PSCustomObject]@{
            ComputerName      = $laptop
            ActiveSessions    = ($activeSessions -join ", ")
            LastLoggedOnUser  = $lastUser.Name
            LastLogonTime     = [Management.ManagementDateTimeConverter]::ToDateTime($lastUser.LastLogon)
            LastIPAddress     = ($lastIP -join ", ")
            OSName            = $osDetails.Caption
            OSArchitecture    = $osDetails.OSArchitecture
            OSVersion         = $osDetails.Version
        }

        # Add the custom object to the output array
        $output += $outputObject
    }
    catch {
        Write-Host "Could not retrieve information from $laptop" -ForegroundColor Red
    }
}

# Export the output array to a CSV file
$output | Export-Csv -Path $OutputFile -NoTypeInformation

Write-Host "Information successfully exported to $OutputFile"

