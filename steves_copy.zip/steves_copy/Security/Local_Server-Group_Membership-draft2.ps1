﻿# Define the path to the text file containing server names 
$serverListPath = "C:\temp\QCAD\PA\PA_Old_Servers.txt"
# Define the path for the output CSV file
$outputCsvPath = "C:\temp\QCAD\PA\Security\Local_Groups\Local_Groups_Output1.csv"



# Prepare the CSV file by creating the header
"ServerName,GroupName,Member" | Out-File $outputCsvPath

# Read each server name from the text file
$serverNames = Get-Content $serverListPath

foreach ($server in $serverNames) {
    try {
        # Invoke net localgroup on each server to list all groups and their members
        $scriptBlock = {
            $output = @()
            $groups = net localgroup | Where-Object { $_ -match "^\*" } | ForEach-Object { $_.Substring(1).Trim() }
            foreach ($group in $groups) {
                $membersOutput = net localgroup $group.Trim()
                $membersList = $membersOutput | Where-Object { $_ -and $_ -notmatch "command completed successfully" -and $_ -notmatch "The command completed successfully." -and $_ -notmatch "-" }
                $membersList = $membersList[1..($membersList.Length - 2)]  # Remove the header and footer from the member list output
                foreach ($member in $membersList) {
                    $output += [PSCustomObject]@{
                        Group   = $group
                        Member  = $member.Trim()
                    }
                }
            }
            return $output
        }
        $results = Invoke-Command -ComputerName $server -ScriptBlock $scriptBlock -ErrorAction Stop
        
        foreach ($result in $results) {
            # Write the server, group, and member to the CSV file
            "$server,$($result.Group),$($result.Member)" | Out-File $outputCsvPath -Append
        }
    } catch {
        Write-Warning "Failed to connect or retrieve data from server $server. Error: $_"
    }
}
