﻿
$servers = Get-Content "C:\temp\QCAD\VT\VT_OLD_Servers.txt" 

# Define the directory to save the security settings files locally
$outputDirectory = "C:\temp\QCAD\VT\Security\Sec_Edit\OLD_Servers"
# Ensure the output directory exists
if (-not (Test-Path -Path $outputDirectory)) {
    New-Item -ItemType Directory -Path $outputDirectory
}

# Loop through each server to export security settings and retrieve the files
foreach ($server in $servers) {
    try {
        # Define the path for the output file on the server
        $remoteFilePath = "\\$server\C$\Temp\$server-SecuritySettings.csv"
        # Define the path for the output file locally
        $localFilePath = Join-Path -Path $outputDirectory -ChildPath ("$server-SecuritySettings.csv")

        # Run secedit on the remote server to export the security settings
        Invoke-Command -ComputerName $server -ScriptBlock {
            secedit /export /areas USER_RIGHTS /cfg $using:remoteFilePath
        }

        # Copy the file from the server to the local directory
        Copy-Item -Path $remoteFilePath -Destination $localFilePath -Force

        # Optionally, clean up by removing the remote file if no longer needed
        Invoke-Command -ComputerName $server -ScriptBlock {
            Remove-Item -Path $using:remoteFilePath -Force
        }

        # Output the completion status for the current server
        Write-Host "Security settings from $server have been exported to $localFilePath"
    } catch {
        Write-Error "Failed to export or retrieve security settings from $server. Error: $_"
    }
}

# Display a final message once all servers have been processed
Write-Host "All servers have been processed. Security settings details are saved in $outputDirectory"

