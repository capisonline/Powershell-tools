﻿<# 
.SYNOPSIS
    Checks local Administrators group membership and user rights on a list of servers.

.DESCRIPTION
    This script connects to a list of servers, retrieves Administrators group membership (resolved to names),
    and checks user rights:
    - "Log on as a batch job"
    - "Log on as a service"
    - "Debug programs"
    - "IIS Impersonate"

    Results are exported to a CSV file, with each account appearing on a separate line.
    Resolve SIDs to User accounts via AD script. Just perform a vlookup against the SID user list
    Update $userRights as much as you like, look up the settings in the excel file

.NOTES
    - Requires administrative privileges.
    - Ensure PowerShell remoting is enabled.
    - Run the script in an elevated session.
#>

# Input and output paths
$serverListPath = "C:\temp\QCAD\BA\BA_New_Servers.txt"
$outputCsvPath = "C:\temp\QCAD\BA\server_check_results39.csv"

# Define user rights to check - update from Secedit_Specs.xlsx if more rights need checking
# You can add as many as you like here and the output will be updated accordingly
$userRights = @(
    @{ Name = "Log on as a batch job"; Right = "SeBatchLogonRight" },
    @{ Name = "Log on as a service"; Right = "SeServiceLogonRight" },
    @{ Name = "Debug programs"; Right = "SeDebugPrivilege" },
    @{ Name = "IIS Impersonate"; Right = "SeImpersonatePrivilege" } # For IIS apps this allows connections between VWS, VCS etc
)

# Initialize results array
$results = @()

# Read the list of servers
$servers = Get-Content -Path $serverListPath

# Loop through servers
foreach ($server in $servers) {
    try {
        Write-Host "Processing server: $server"

        # Check Administrators group membership
        $adminGroupMembers = Invoke-Command -ComputerName $server -ScriptBlock {
            Get-LocalGroupMember -Group "Administrators" | ForEach-Object {
                $_.Name
            }
        }

        # Add Admin Group Members to results
        foreach ($member in $adminGroupMembers) {
            $results += [PSCustomObject]@{
                Server   = $server
                Setting  = "Administrators Group"
                Account  = $member
            }
        }

        # Export user rights to a temp file
        $seceditExportPath = "C:\Temp\secedit.inf"
        Invoke-Command -ComputerName $server -ScriptBlock {
            secedit /export /cfg $using:seceditExportPath /areas USER_RIGHTS /quiet
        }

        # Parse user rights
        foreach ($right in $userRights) {
            $rightName = $right.Name
            $rightKey = $right.Right

            # Retrieve the right assignments from the exported file
            $sids = Invoke-Command -ComputerName $server -ScriptBlock {
                if (Test-Path $using:seceditExportPath) {
                    $line = (Select-String -Path $using:seceditExportPath -Pattern $using:rightKey).Line
                    if ($line) {
                        $line.Split('=')[-1].Trim() -split ","
                    } else {
                        @()
                    }
                } else {
                    @()
                }
            }

            # Add User Rights to results
            foreach ($sid in $sids) {
                $results += [PSCustomObject]@{
                    Server   = $server
                    Setting  = $rightName
                    Account  = $sid
                }
            }
        }

        # Cleanup temporary files - this deletes the secedit output for security purposes (clear text files shouldn't be left anywhere)
        Invoke-Command -ComputerName $server -ScriptBlock {
            Remove-Item -Path "C:\Temp\secedit.inf" -ErrorAction SilentlyContinue
        }

    } catch {
        Write-Warning "Error processing server ${server}: $_"
        $results += [PSCustomObject]@{
            Server   = $server
            Setting  = "Error"
            Account  = $_.Exception.Message
        }
    }
}

# Export results to CSV
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation -Encoding UTF8

Write-Host "Check completed. Results saved to $outputCsvPath."

