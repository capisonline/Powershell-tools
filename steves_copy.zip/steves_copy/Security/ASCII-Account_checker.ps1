﻿# Replace 'YourGroupName' with the name of the group you want to check 
$groupName = "PRDS\ISS-P-CAD-Administrators-DatabaseServers"

# Convert the group name to an array of characters
$charArray = $groupName.ToCharArray()

# Check each character to see if it is an ASCII character
$isAscii = $true
foreach ($char in $charArray) {
    if ([int][char]::ConvertToUtf32($char, 0) -gt 127) {
        $isAscii = $false
        break
    }
}

if ($isAscii) {
    Write-Host "The group name '$groupName' contains only ASCII characters."
} else {
    Write-Host "The group name '$groupName' contains non-ASCII characters."
}
