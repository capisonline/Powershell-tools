﻿# Define the path to the text file containing the server names 
$serverListPath = "C:\temp\QCAD\TP\Security\ServerList.txt"

# Define the output CSV file path
$outputCsvPath = "C:\temp\QCAD\TP\Security\GroupMemberships.csv"

# Read server names from the text file
$servers = Get-Content $serverListPath

# Initialize an array to store results
$results = @()

# Loop through each server in the list
foreach ($server in $servers) {
    # Get the list of groups on the server
    $groups = Get-ADGroup -Server $server -Filter * -Properties Members

    # Loop through each group to collect membership details
    foreach ($group in $groups) {
        # Retrieve members of the group
        $members = $group.Members | Get-ADObject -Server $server -Properties SamAccountName

        # Loop through each member to create output objects
        foreach ($member in $members) {
            $results += [PSCustomObject]@{
                ServerName   = $server
                GroupName    = $group.Name
                MemberName   = $member.SamAccountName
            }
        }
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

Write-Host "Group memberships have been exported to $outputCsvPath"
