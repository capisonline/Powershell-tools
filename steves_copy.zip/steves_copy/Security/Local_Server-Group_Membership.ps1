﻿# Define the path to the text file containing the server names 
$serverListPath = "C:\temp\QCAD\TP\Security\ServerList.txt"

# Define the output CSV file path
$outputCsvPath = "C:\temp\QCAD\TP\Security\Local_GroupMemberships.csv"

# Read server names from the text file
$servers = Get-Content $serverListPath

# Initialize an array to store results
$results = @()

# Loop through each server in the list
foreach ($server in $servers) {
    # Use Invoke-Command for remote execution
    $groupData = Invoke-Command -ComputerName $server -ScriptBlock {
        # Retrieve all local groups using net command
        $groups = net localgroup
        $groups | Where-Object { $_ -match "^\*" } | ForEach-Object {
            $groupName = $_ -replace "\*", "" # Remove asterisk and trim whitespace
            $groupName = $groupName.Trim()
            # Retrieve members of each group
            $members = net localgroup $groupName | Where-Object { $_ -and $_ -notmatch "command completed successfully" -and $_ -notmatch "----" -and $_ -notmatch "There are no entries in the list" }
            # Return data for each group member
            foreach ($member in $members) {
                [PSCustomObject]@{
                    ServerName = $env:COMPUTERNAME
                    GroupName  = $groupName
                    MemberName = $member.Trim()
                }
            }
        }
    }

    # Add the result from each server to the results array
    $results += $groupData
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

Write-Host "Local group memberships have been exported to $outputCsvPath"
