﻿<# Define the path to the text file containing server names 
$serverListPath = "C:\temp\QCAD\PA\PA_Old_Servers_Testing.txt"
# Define the path for the output CSV file
$outputCsvPath = "C:\temp\QCAD\PA\Security\Local_Groups_Output4.csv"
#>

# Define the path to the text file containing server names 
$serverListPath = "C:\temp\QCAD\TP\TP_OLD_Servers.txt"
# Define the path for the output CSV file
$outputCsvPath = "C:\temp\QCAD\TP\Error_Logs\failed-cutover\perms\TP-OLDServers_Local_Groups_Output1.csv"

$servers = Get-Content $serverListPath

$script = {
    $groups = Get-CimInstance win32_group -filter "domain='$($env:computername)'"
    foreach ($group in $groups) {
        $groupUsers = Get-CimInstance win32_groupuser -filter "GroupComponent=""Win32_Group.Domain='$($env:computername)',Name='$($group.Name)'"""
        foreach ($groupUser in $groupUsers) {
            $member = [CimInstance]$groupUser.PartComponent
            [PSCustomObject]@{
                Server = $env:COMPUTERNAME
                Group = $group.Name
                Member = $member.Name
            }
        }
    }
}

$output = Invoke-Command -ComputerName $servers -ScriptBlock $script

$output | Export-Csv $outputCsvPath -NoTypeInformation
