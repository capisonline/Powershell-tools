﻿# Load the ImportExcel module 
Import-Module ImportExcel

# Paths to the Excel files
$oldFilePath = "C:\temp\QCAD\TP\Security\Local_Groups_Output1.csv"
$newFilePath = "C:\temp\QCAD\TP\Security\Local_Groups_Output-New_Servers.csv"

# Reading the data from the Excel files
$oldData = Import-Excel -Path $oldFilePath -WorksheetName 'Sheet1'
$newData = Import-Excel -Path $newFilePath -WorksheetName 'Sheet1'

# Function to find and print differences
function Compare-Text($oldText, $newText) {
    if ($oldText -eq $newText) {
        "Texts are identical"
    }
    else {
        $oldWords = $oldText -split ' '
        $newWords = $newText -split ' '

        $missingInNew = $oldWords | Where-Object { $_ -notin $newWords }
        $addedInNew = $newWords | Where-Object { $_ -notin $oldWords }

        "Missing in New: $missingInNew`nAdded in New: $addedInNew"
    }
}

# Assuming you're comparing cell A1
$oldCell = $oldData[0].C1
$newCell = $newData[0].C1

# Output the differences
Compare-Text -oldText $oldCell -newText $newCell
