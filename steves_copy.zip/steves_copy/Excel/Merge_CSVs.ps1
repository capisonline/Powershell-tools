﻿
# Define the directory containing the CSV files 
$sourceDirectory = "C:\temp\QCAD\TP\Security\Sec_Edit\NEW_Servers"

# Define the path for the new merged CSV file
$mergedCSV = "C:\temp\QCAD\TP\Security\Sec_Edit\NEW_Servers\MergedFile-SecEdit.csv"

# Get all CSV files in the directory
$csvFiles = Get-ChildItem -Path $sourceDirectory -Filter "*.csv"

# Check if any CSV files found
if ($csvFiles.Count -eq 0) {
    Write-Host "No CSV files found in the directory."
    exit
}

# Create or clear the merged CSV file
if (Test-Path $mergedCSV) {
    Clear-Content $mergedCSV
} else {
    New-Item -Path $mergedCSV -ItemType File
}

# Loop through each CSV file
foreach ($file in $csvFiles) {
    # Get the content of the CSV file
    $content = Get-Content $file.FullName

    # If it's not the first file, skip the header (assumes header is the first line)
    if ($file -ne $csvFiles[0]) {
        $content = $content | Select-Object -Skip 1
    }

    # Append the content to the merged CSV file
    Add-Content -Path $mergedCSV -Value $content
}

Write-Host "CSV files have been merged into $mergedCSV"
