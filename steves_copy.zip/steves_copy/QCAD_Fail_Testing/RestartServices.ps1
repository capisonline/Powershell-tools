﻿<#
.SYNOPSIS
    This script stops and restarts critical services on a predefined list of servers.

.DESCRIPTION
    - Reads server-specific service restart details from an input CSV file.
    - Stops and restarts services listed for the current server.
    - Logs actions (Stop/Start, Success/Failure) to a specified local or central log location.
    - Designed to be executed via a Scheduled Task on each server.
    - Supports controlled batch execution by specifying batch groups.

.PARAMETER None
    No parameters required. The script reads from the CSV file automatically.

.INPUTS
    CSV file (`C:\Scripts\ServiceRestartConfig.csv`) with the following structure:
    - ServerName (Host name of the server)
    - ScheduledTime (Time for execution - for reference only)
    - BatchGroup (Batch number for controlled restarts)
    - ServicesToRestart (Comma-separated list of services to stop/start)
    - LogLocation (Local or central logging path)

            This file controls everything, and the script only executes based on its contents.

            ServerName	ScheduledTime	BatchGroup	ServicesToRestart	LogLocation
            BNEVAS01	02:00 AM	1	MSMQ, SQL Server	C:\Logs\
            BNECCM01	02:10 AM	1	IIS, MSMQ	C:\Logs\
            BNEPCAD01	02:30 AM	2	SQL Server	C:\Logs\
            BNEWEB01	02:50 AM	2	IIS	\CentralLogServer\Logs\



.OUTPUTS
    - Logs execution results in a log file named `ServiceRestart_<ServerName>.log`
    - Logs include timestamps, server name, service name, action, status, and error message.

.NOTES
    - Ensure this script is deployed to `C:\Scripts\` on each server.
    - The Scheduled Task should run under SYSTEM and execute this script at the configured time.
    - Services must exist on the server; missing services will be logged but not stop execution.
    - If a service fails to restart, it is logged, but no retries are attempted.

.EXAMPLE
    Running as a scheduled task:
    - Script will execute on `BNEVAS01` at its defined time.
    - Stops MSMQ and SQL Server.
    - Waits 5 seconds, then restarts both services.
    - Logs results to `C:\Logs\ServiceRestart_BNEVAS01.log`


.LAST UPDATED
    2025-02-27 - Initial implementation with dynamic CSV input and logging.
#>

# Define CSV location
$CsvFile = "C:\Scripts\ServiceRestartConfig.csv"

# Get the current server name
$ServerName = $env:COMPUTERNAME

# Import CSV data
$Servers = Import-Csv -Path $CsvFile

# Find the entry for this server
$ServerConfig = $Servers | Where-Object { $_.ServerName -eq $ServerName }

# Exit if no entry found for this server
if (-not $ServerConfig) {
    Write-Host "No configuration found for $ServerName. Exiting."
    exit 0
}

# Extract service list (convert from CSV text to array)
$ServicesToRestart = $ServerConfig.ServicesToRestart -split ",\s*"
$LogLocation = $ServerConfig.LogLocation

# Ensure the log directory exists
if (!(Test-Path $LogLocation)) {
    New-Item -ItemType Directory -Path $LogLocation -Force | Out-Null
}

# Define log file path
$LogFile = Join-Path -Path $LogLocation -ChildPath "ServiceRestart_$ServerName.log"

# Function to log actions
function Write-Log {
    param (
        [string]$ServiceName,
        [string]$Action,
        [string]$Status,
        [string]$ErrorMessage
    )

    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "$Timestamp,$ServerName,$ServiceName,$Action,$Status,$ErrorMessage"

    # Write to the log file
    Add-Content -Path $LogFile -Value $LogEntry
}

# Process each service
foreach ($Service in $ServicesToRestart) {
    try {
        # Stop the service
        Write-Host "Stopping service: $Service on $ServerName"
        Stop-Service -Name $Service -Force -ErrorAction Stop
        Write-Log -ServiceName $Service -Action "Stop" -Status "Success" -ErrorMessage ""

        # Wait before restarting (optional delay for staggered restarts)
        Start-Sleep -Seconds 5

        # Start the service
        Write-Host "Starting service: $Service on $ServerName"
        Start-Service -Name $Service -ErrorAction Stop
        Write-Log -ServiceName $Service -Action "Start" -Status "Success" -ErrorMessage ""

    } catch {
        # Capture and log any errors
        $ErrorMsg = $_.Exception.Message
        Write-Log -ServiceName $Service -Action "Start" -Status "Failed" -ErrorMessage $ErrorMsg
    }
}

Write-Host "Service restart process completed on $ServerName."
