﻿# Define ports to unblock (same as those blocked)
$ports = @(80, 443, 3389)  # HTTP, HTTPS, RDP

# Log file location
$logFile = "C:\Logs\FirewallTest.log"
$firewallRulePrefix = "TestBlock"

# Get the local server name
$localServer = $env:COMPUTERNAME

function Write-Log {
    param ($message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp - $message" | Out-File -Append -FilePath $logFile
    Write-EventLog -LogName "Application" -Source "FirewallTest" -EventID 1002 -EntryType Information -Message $message -ErrorAction SilentlyContinue
}

function Unblock-Traffic {
    foreach ($port in $ports) {
        $ruleName = "$firewallRulePrefix-$localServer-$port"
        Remove-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
        Write-Log "Unblocked port $port on $localServer (Rule: $ruleName)"
    }
}

# Unblock traffic
Unblock-Traffic
