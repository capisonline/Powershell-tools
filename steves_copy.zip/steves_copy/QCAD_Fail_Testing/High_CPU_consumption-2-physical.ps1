﻿<#
.SYNOPSIS
  High CPU Load Simulation Script (accurate targeting + ALWAYS stoppable in ISE).

.DESCRIPTION
  Generates controlled CPU load using background jobs.
  Accurate targeting: N full-core jobs (100%) + one partial-core job (e.g. 50%).
  Uses a STOP FILE so you can stop it even if PowerShell ISE aborts the main script.

.NOTES
  Author  : Rogers.Steven2@police.qld.gov.au
  Updated : 2026-01-02
#>

[CmdletBinding()]
param(
    [switch]$Stop
)

# =========================
# CONFIGURATION
# =========================
$TargetCpuPercent        = 75
$AutoScale               = $true
$HoldSeconds             = 18000
$RampDelayMS             = 100
$MeasureIntervalSeconds  = 5

# Duty-cycle window size (ms). 100 is a good balance.
$IntervalMs              = 100
$MinRemainderPercent     = 2

# Names/prefixes
$JobPrefix               = "QCAD_HighCPU"
$hostname                = $env:COMPUTERNAME

# Paths
$logDir                  = "D:\Failtesting\logs"
$stateDir                = "D:\Failtesting\state"
$timestamp               = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath                 = Join-Path $logDir "HighCPU_TestLog_${hostname}_$timestamp.txt"
$stopFile                = Join-Path $stateDir "${JobPrefix}_STOP_${hostname}.flag"

# =========================
# HELPERS
# =========================
function Ensure-Dir([string]$Path) {
    if (!(Test-Path $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function Stop-AllStressJobs {
    Get-Job -Name "$JobPrefix*" -ErrorAction SilentlyContinue | ForEach-Object {
        try { Stop-Job $_ -Force -ErrorAction SilentlyContinue } catch {}
        try { Remove-Job $_ -Force -ErrorAction SilentlyContinue } catch {}
    }
}

function Get-TotalCpuPercent {
    # Prefer Processor Information (more reliable on some systems), fallback to Processor.
    try {
        return [double](Get-Counter '\Processor Information(_Total)\% Processor Time').CounterSamples[0].CookedValue
    } catch {
        return [double](Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples[0].CookedValue
    }
}

# =========================
# STOP MODE (RUN FROM ANOTHER TAB/CONSOLE)
# =========================
if ($Stop) {
    Ensure-Dir $stateDir
    New-Item -ItemType File -Path $stopFile -Force | Out-Null
    Stop-AllStressJobs
    Write-Host "STOP issued: created $stopFile and stopped $JobPrefix* jobs." -ForegroundColor Green
    return
}

# =========================
# SETUP
# =========================
Ensure-Dir $logDir
Ensure-Dir $stateDir

# Clear any previous stop flag
if (Test-Path $stopFile) { Remove-Item $stopFile -Force -ErrorAction SilentlyContinue }

Add-Content $logPath "=== High CPU Test Started: $(Get-Date) ==="
Add-Content $logPath "Host: $hostname"
Add-Content $logPath "Requested Target CPU: $TargetCpuPercent%"
Add-Content $logPath "Auto-Scaling Enabled: $AutoScale"
Add-Content $logPath "IntervalMs: $IntervalMs | RampDelayMS: $RampDelayMS | MeasureIntervalSeconds: $MeasureIntervalSeconds"
Add-Content $logPath "STOP command: powershell -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Stop"
Add-Content $logPath "Stop-file: $stopFile"
Add-Content $logPath ""

# Prevent stacking from previous runs / scheduled task overlaps
Add-Content $logPath "Stopping any existing '$JobPrefix*' jobs to prevent stacking..."
Stop-AllStressJobs
Add-Content $logPath "Previous jobs (if any) stopped/removed."
Add-Content $logPath ""

# =========================
# CPU COUNT
# =========================
try {
    $cpuCount = (Get-CimInstance Win32_Processor | Measure-Object -Sum -Property NumberOfLogicalProcessors).Sum
    if (-not $cpuCount -or $cpuCount -lt 1) { $cpuCount = [Environment]::ProcessorCount }
} catch {
    $cpuCount = [Environment]::ProcessorCount
}

Add-Content $logPath "Detected $cpuCount logical CPU cores."

# Clamp target
if ($TargetCpuPercent -lt 0)   { $TargetCpuPercent = 0 }
if ($TargetCpuPercent -gt 100) { $TargetCpuPercent = 100 }

# =========================
# AUTOSCALE
# =========================
if ($AutoScale) {
    try {
        $currentLoad = Get-TotalCpuPercent
        $availableHeadroom = [math]::Max(0, 100 - $currentLoad)

        if ($TargetCpuPercent -gt $availableHeadroom) {
            Add-Content $logPath ("Auto-scaling: Current CPU {0:N2}%. Reducing target {1}% -> {2}%." -f $currentLoad, $TargetCpuPercent, [math]::Floor($availableHeadroom))
            $TargetCpuPercent = [math]::Floor($availableHeadroom)
        } else {
            Add-Content $logPath ("Sufficient headroom available: {0:N2}%." -f $availableHeadroom)
        }
    } catch {
        Add-Content $logPath "Auto-scaling failed: $_"
    }
}

Add-Content $logPath "Effective Target CPU: $TargetCpuPercent%"
Add-Content $logPath ""

# =========================
# BUILD DUTY PLAN (ACCURATE)
# =========================
$coreTarget = $cpuCount * ($TargetCpuPercent / 100.0)
$fullJobs   = [math]::Floor($coreTarget)
$remainder  = $coreTarget - $fullJobs
$remPct     = [int][math]::Round($remainder * 100)

$dutyPlan = @()
if ($fullJobs -gt 0) { $dutyPlan += @(100) * $fullJobs }
if ($remPct -ge $MinRemainderPercent) { $dutyPlan += $remPct }

if ($dutyPlan.Count -eq 0) {
    Add-Content $logPath "Target CPU is effectively 0%. No stress jobs will be started."
    Add-Content $logPath "=== High CPU Test Completed: $(Get-Date) ==="
    exit 0
}

Add-Content $logPath ("Core target = {0:N2}. Full jobs: {1}, remainder: {2:N2} (~{3}%)." -f $coreTarget, $fullJobs, $remainder, $remPct)
Add-Content $logPath "Duty plan per job (% of a core): $($dutyPlan -join ', ')"
Add-Content $logPath "Total stress jobs to launch: $($dutyPlan.Count)"
Add-Content $logPath ""

# =========================
# START STRESS JOBS
# =========================
$jobs = @()

for ($i = 0; $i -lt $dutyPlan.Count; $i++) {

    $duty   = [int]$dutyPlan[$i]
    $name   = ("{0}_{1:00}" -f $JobPrefix, ($i + 1))

    $jobs += Start-Job -Name $name -ScriptBlock {
        param([int]$Duty, [int]$Interval, [string]$StopFilePath)

        $busyMs = [int][math]::Round($Interval * ($Duty / 100.0))
        $idleMs = $Interval - $busyMs
        if ($idleMs -lt 0) { $idleMs = 0 }

        while (-not (Test-Path $StopFilePath)) {
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            while ($sw.ElapsedMilliseconds -lt $busyMs) {
                [System.Threading.Thread]::SpinWait(400) | Out-Null
            }
            if ($idleMs -gt 0) { Start-Sleep -Milliseconds $idleMs }
        }
    } -ArgumentList $duty, $IntervalMs, $stopFile

    Add-Content $logPath "Started job $name with duty $duty% at $(Get-Date)"
    Start-Sleep -Milliseconds $RampDelayMS
}

# =========================
# MONITOR JOB
# =========================
$monitorJob = Start-Job -Name "${JobPrefix}_Monitor" -ScriptBlock {
    param([string]$Log, [string]$StopFilePath, [int]$EverySec)

    function Get-TotalCpu {
        try {
            return [double](Get-Counter '\Processor Information(_Total)\% Processor Time').CounterSamples[0].CookedValue
        } catch {
            return [double](Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples[0].CookedValue
        }
    }

    while (-not (Test-Path $StopFilePath)) {
        try {
            $u = Get-TotalCpu
            Add-Content $Log ("Actual CPU Usage: {0:N2}% at {1}" -f $u, (Get-Date))
        } catch {
            Add-Content $Log ("Monitor failed at {0}: {1}" -f (Get-Date), $_)
        }
        Start-Sleep -Seconds $EverySec
    }
} -ArgumentList $logPath, $stopFile, $MeasureIntervalSeconds

Add-Content $logPath ""
Add-Content $logPath "All jobs launched. Holding for $HoldSeconds seconds (or until stop-file exists)..."
Add-Content $logPath ""

# =========================
# HOLD LOOP (STOPPABLE EVEN IF YOU ABORT ISE RUN)
# =========================
$end = (Get-Date).AddSeconds($HoldSeconds)
while ((Get-Date) -lt $end) {
    if (Test-Path $stopFile) { break }
    Start-Sleep -Seconds 1
}

# =========================
# CLEANUP
# =========================
Add-Content $logPath ""
Add-Content $logPath "Cleanup starting at $(Get-Date)..."

# Create stop-file (ensures all workers exit)
New-Item -ItemType File -Path $stopFile -Force | Out-Null

Start-Sleep -Seconds 1

Stop-AllStressJobs

# Remove stop-file for next run
Remove-Item $stopFile -Force -ErrorAction SilentlyContinue

Add-Content $logPath "Stopped and removed all jobs."
Add-Content $logPath "=== High CPU Test Completed: $(Get-Date) ==="
