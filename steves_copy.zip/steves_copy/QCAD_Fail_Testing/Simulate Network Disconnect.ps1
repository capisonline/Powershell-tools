﻿# PowerShell Script: Simulate Network Disconnect
$Server = "TargetServerName"
$NICName = "Ethernet"  # Change based on your actual adapter name
$DisableDuration = 10  # Time in seconds before re-enabling the NIC
$LogFile = "C:\Logs\NetworkDisconnectTest.log"

Write-Host "Disabling network interface on $Server ..." -ForegroundColor Yellow
Invoke-Command -ComputerName $Server -ScriptBlock {
    Disable-NetAdapter -Name $using:NICName -Confirm:$false
} -Credential (Get-Credential)

Write-Host "Waiting $DisableDuration seconds before re-enabling ..." -ForegroundColor Cyan
Start-Sleep -Seconds $DisableDuration

Invoke-Command -ComputerName $Server -ScriptBlock {
    Enable-NetAdapter -Name $using:NICName -Confirm:$false
} -Credential (Get-Credential)

Write-Host "Network re-enabled on $Server." -ForegroundColor Green
"[$(Get-Date)] Network re-enabled on $Server." | Out-File -Append $LogFile
