﻿<#
.SYNOPSIS
    High Memory Load Simulation Script for Stress and Monitoring Validation.

.DESCRIPTION
    This PowerShell script dynamically allocates memory to simulate high usage conditions
    on a Windows system. It is designed for use in system validation, monitoring alert 
    testing (e.g. SCOM, vCenter), and DR readiness checks by creating sustained memory 
    pressure near a configurable threshold (default: 90–95%).

    The script:
    - Calculates the system's total physical RAM.
    - Gradually allocates memory up to the target percentage of total RAM.
    - Touches each memory page to ensure it is committed by the OS.
    - Actively refreshes all memory pages during the hold phase to prevent trimming/compression.
    - Logs memory allocation progress and actual usage throughout the hold period.
    - Releases all memory and forces garbage collection on completion.

.NOTES
    Author   : Rogers.Steven2@police.qld.gov.au
    Tested On: Windows Server 2019, Windows 10
    Logs     : Stored in D:\Failtesting\logs\HighMem_TestLog_<hostname>_<timestamp>.txt

.WARNING
    This script is intended for use in test environments or under controlled conditions 
    only. It can cause paging, application slowdowns, or monitoring alerts. Do not use 
    in production without proper safeguards.

.EXAMPLE
    Run via Scheduled Task:
        ./HighMemStress.ps1
#>

# === CONFIGURATION ===
$logDir = "D:\Failtesting\logs"
$hostname = $env:COMPUTERNAME
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath = Join-Path $logDir "HighMem_TestLog_${hostname}_$timestamp.txt"

$targetUsagePercent = 95             # % of total RAM to allocate
$blockSizeBytes = 200MB              # Size of each memory block
$allocationDelayMS = 100             # Delay between allocations
$holdSeconds = 18000                 # Total hold duration in seconds (e.g., 5 hours)
$logIntervalSeconds = 300            # Refresh and log memory usage every N seconds (e.g., 5 minutes)

# === LOG SETUP ===
if (!(Test-Path $logDir)) {
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
}

Add-Content $logPath "=== High Memory Test Started: $(Get-Date) ==="
Add-Content $logPath "Host: $hostname"
Add-Content $logPath "Target Usage: $targetUsagePercent% of total physical RAM"

# === MEMORY ALLOCATION ===
$totalRAM = (Get-CimInstance -ClassName Win32_ComputerSystem).TotalPhysicalMemory
$targetBytes = [math]::Floor($totalRAM * $targetUsagePercent / 100)
Add-Content $logPath "Total RAM: $([math]::Round($totalRAM / 1GB, 2)) GB"
Add-Content $logPath "Target allocation: $([math]::Round($targetBytes / 1GB, 2)) GB"

$memBlocks = New-Object 'System.Collections.Generic.List[Object]'
$currentAllocated = 0
$blockCount = 0

try {
    while ($currentAllocated -lt $targetBytes) {
        $block = [byte[]]::new($blockSizeBytes)

        # Touch each page to force commit
        for ($j = 0; $j -lt $block.Length; $j += 4096) {
            $block[$j] = 1
        }

        $memBlocks.Add($block)
        $currentAllocated += $blockSizeBytes
        $blockCount++

        $usage = (Get-Counter '\Memory\% Committed Bytes In Use').CounterSamples[0].CookedValue
        Add-Content $logPath "[$blockCount] Allocated: $([math]::Round($currentAllocated / 1MB)) MB, Usage: $([math]::Round($usage, 2))%"

        Start-Sleep -Milliseconds $allocationDelayMS
    }

    Add-Content $logPath "Target reached: $([math]::Round($currentAllocated / 1GB, 2)) GB allocated."
    Add-Content $logPath "Holding memory for $holdSeconds seconds with refresh every $logIntervalSeconds seconds..."

    $totalLoops = [math]::Floor($holdSeconds / $logIntervalSeconds)

    for ($loop = 1; $loop -le $totalLoops; $loop++) {
        Add-Content $logPath "Holding memory... active refresh at $(Get-Date)"

        foreach ($block in $memBlocks) {
            for ($k = 0; $k -lt $block.Length; $k += 4096) {
                $block[$k] = ($block[$k] + 1) % 256
            }
        }

        $usage = (Get-Counter '\Memory\% Committed Bytes In Use').CounterSamples[0].CookedValue
        Add-Content $logPath "Live Usage during hold: $([math]::Round($usage, 2))%"

        Start-Sleep -Seconds $logIntervalSeconds
    }
}
catch {
    Add-Content $logPath "ERROR: $($_.Exception.GetType().FullName) - $($_.Exception.Message)"
}
finally {
    $memBlocks.Clear()
    $memBlocks = $null
    [System.GC]::Collect()
    Add-Content $logPath "Memory released and garbage collected at $(Get-Date)."
}

Add-Content $logPath "=== High Memory Test Completed: $(Get-Date) ==="
