﻿# Path to the text file containing the list of PCs 
$filePath = "C:\temp\QCAD\tp\TP_NEW_Server_list.txt"
# Get-Credential
# Check if the file exists
if (Test-Path $filePath) {
    # Read each line in the text file as computer names
    $computerNames = Get-Content $filePath

    # Loop through each computer name and initiate a restart
    foreach ($computer in $computerNames) {
        Write-Host "Attempting to restart $computer..."
        Restart-Computer -ComputerName $computer -Force -ErrorAction SilentlyContinue
        Write-Host "$computer restart command sent."
    }
} else {
    Write-Host "File not found: $filePath"
}
