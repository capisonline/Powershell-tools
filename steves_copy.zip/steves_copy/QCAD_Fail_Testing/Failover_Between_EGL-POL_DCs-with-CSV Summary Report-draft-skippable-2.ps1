﻿<#
QCAD Mini Failover Automation Script (EGL ↔ POL)
Structured for team readability, integration readiness, and future automation.
Includes: granular skip flags, DFS target switching, DFS validation, and full logging.
#>

##############################################
# 1. GLOBAL CONFIGURATION                    #
##############################################

param(
  [ValidateSet("EGL", "POL")] [string]$TargetDC,
  [switch]$TestMode,
  [switch]$SkipVAS,
  [switch]$SkipVWS,
  [switch]$SkipVCS,
  [switch]$SkipVIM,
  [switch]$SkipVMG,
  [switch]$SkipAAS
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmm"
$LogFile = "C:\QCADFailover\Failover_Log_$timestamp.txt"
$CsvLog = "C:\QCADFailover\Failover_Report_$timestamp.csv"
$CsvOutput = @()

# DFS Namespace changes with each environment IE: VT, PR etc.
$DFSNamespace = "\\PRDS.QLDPOL\\appdata\\VT\\QCAD"
$DFS_Shares = @(
  "OfficerDetails$",
  "VisionAudit$",
  "System_VisVT$",
  "New Version$"
)

$EGL = @{ 
    VAS = @("EGLVCADVASVT01", "EGLVCADVASVT02"); 
    VWS = @("EGLVCADVWSVT01", "EGLVCADVWSVT02", "EGLVCADVWSVT03", "EGLVCADVWSVT04"); 
    VCS = @("EGLVCADVCSVT01", "EGLVCADVCSVT02", "EGLVCADVCSVT03", "EGLVCADVCSVT04", "EGLVCADVCSVT05"); 
    VIM = @("EGLVCADVIMVT01", "EGLVCADVIMVT02"); 
    VMG = @("EGLVCADVMGVT01"); 
    APL = "EGLVCADAPLVT01" 
}
$POL = @{ 
    VAS = @("POLVCADVASVT03", "POLVCADVASVT04"); 
    VWS = @("POLVCADVWSVT01", "POLVCADVWSVT02", "POLVCADVWSVT03", "POLVCADVWSVT04"); 
    VCS = @("POLVCADVCSVT01", "POLVCADVCSVT02", "POLVCADVCSVT03", "POLVCADVCSVT04", "POLVCADVCSVT05"); 
    VIM = @("POLVCADVIMVT01", "POLVCADVIMVT02"); 
    VMG = @("POLVCADVMGVT01"); 
    APL = "POLVCADAPLVT01" 
}

$AAS = "EGLVCADAASVT01"
$ServicesToStop = @(
    "Fortek.Services.Arbitrator",    # Step 1: Arbitrator service disabled on VAS during failover
    "Fortek.FCS",                    # Step 3: FCS service disabled to prevent auto-start
    "VisPR_VDW",                     # Step 10: Restarted to recreate Oracle connections
    "RabbitMQ",                      # Step 16: Only on VAS05 - stop during failover
    "W3SVC",                         # Step 11: Restarted on VWS/VCS for Oracle reconnect
    "CCCM",                          # Step 19: Disable CCCM on old VCS
    "VisionService",                 # General Vision application services
    "ExternalClientGateway"          # Step 20: VMG - ECG service for QTasks
)
$ServicesToStart = @(
    "VisPR_VDW",                     # Step 10: Oracle reconnect after master switch
    "W3SVC",                         # Step 11: IIS restart on VWS/VCS
    "CCCM",                          # Only if CCCM needed on new VCS
    "VisionService",                 # Vision application services
    "ExternalClientGateway"          # VMG ECG connectivity
)

$Old = if ($TargetDC -eq 'EGL') { $POL } else { $EGL }
$New = if ($TargetDC -eq 'EGL') { $EGL } else { $POL }
$Master = $New.VAS[0]
$NewAPL = $New.APL

##############################################
# 2. FUNCTION DEFINITIONS                    #
##############################################

function Log-Action {
    param($Step, $Server, $Service, $Action, $IsTest)
    $line = "[$Step] $Action service '$Service' on $Server"
    if ($IsTest) { $line = "[TEST] $line" }
    Add-Content -Path $LogFile -Value $line
    $CsvOutput += [pscustomobject]@{
        Step     = $Step
        Server   = $Server
        Action   = $Action
        Service  = $Service
        TestMode = $IsTest
    }
}

function Control-Services {
    param($Action, $Servers, $Services, $Step, $TestMode)
    foreach ($Server in $Servers) {
        foreach ($Service in $Services) {
            Log-Action -Step $Step -Server $Server -Service $Service -Action $Action -IsTest:$TestMode
            if (-not $TestMode) {
                $cmd = if ($Action -eq 'Start') { "Start-Service" } else { "Stop-Service -Force" }
                Invoke-Command -ComputerName $Server -ScriptBlock { param($svc, $cmd) Invoke-Expression "$cmd -Name `$svc -ErrorAction SilentlyContinue" } -ArgumentList $Service, $cmd
            }
        }
    }
}

function Restart-IIS {
    param($Servers, $Step, $TestMode)
    foreach ($Server in $Servers) {
        Log-Action -Step $Step -Server $Server -Service "IIS" -Action "Restart" -IsTest:$TestMode
        if (-not $TestMode) {
            Invoke-Command -ComputerName $Server -ScriptBlock { iisreset }
        }
    }
}

function Copy-DFS-Shares {
    param($Source, $Targets, $Shares, $Step, $TestMode)
    foreach ($Share in $Shares) {
        foreach ($Target in $Targets) {
            Log-Action -Step $Step -Server $Target -Service $Share -Action "Copy" -IsTest:$TestMode
            if (-not $TestMode) {
                robocopy "\\$Source\$Share" "\\$Target\$Share" /MIR /R:1 /W:5 /NFL /NDL /NP /LOG+:$LogFile
            }
        }
    }
}

function Set-DfsnTargets {
    param($NamespacePath, $EGLTarget, $POLTarget, $EnablePOL, $TestMode)

    $Preferred = if ($EnablePOL) { $POLTarget } else { $EGLTarget }
    $Disabled = if ($EnablePOL) { $EGLTarget } else { $POLTarget }

    $beforePreferred = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred).State
    $beforeDisabled = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled).State

    Log-Action "Step 13" $Preferred "DFS Target Before: $beforePreferred" "Enable" $TestMode
    Log-Action "Step 13" $Disabled "DFS Target Before: $beforeDisabled" "Disable" $TestMode

    if (-not $TestMode) {
        Set-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred -State Online
        Set-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled -State Offline
    }

    $afterPreferred = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred).State
    $afterDisabled = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled).State

    Log-Action "Step 13" $Preferred "DFS Target After: $afterPreferred" "Enable" $TestMode
    Log-Action "Step 13" $Disabled "DFS Target After: $afterDisabled" "Disable" $TestMode
}

##############################################
# 3. MAIN EXECUTION

# Step 1 – Stop Arbitrator before promoting
if (-not $SkipVAS) {
  Control-Services Stop $Old.VAS @("Fortek.Services.Arbitrator") "Step 1" $TestMode
}

Add-Content -Path $LogFile -Value "--- SWITCHING TO $TargetDC ---"
Write-Host "🟡 STOP: You must now promote VAS Master to $Master manually."
if (-not $TestMode) {
    do {
        $confirmation = Read-Host "Type 'yes' to confirm VAS promotion has been completed"
    } while ($confirmation -ne 'yes')
} else {
    Write-Host "[TEST] Skipping confirmation."
}

if (-not $SkipVAS) {
  Control-Services Stop $Old.VAS $ServicesToStop "Step 1/15–20" $TestMode
  Control-Services Start $New.VAS $ServicesToStart "Step 10" $TestMode
  Copy-DFS-Shares $Master ($New.VAS | Where-Object { $_ -ne $Master }) $DFS_Shares "Step 13" $TestMode

  foreach ($share in $DFS_Shares) {
    $EGLTarget = "\\EGLVCADVASVT01\$share"
    $POLTarget = "\\POLVCADVASVT03\$share"
    Set-DfsnTargets -NamespacePath "$DFSNamespace\$share" -EGLTarget $EGLTarget -POLTarget $POLTarget -EnablePOL:($TargetDC -eq 'POL') -TestMode:$TestMode
  }
}
if (-not $SkipVWS) {
  Control-Services Stop $Old.VWS $ServicesToStop "Step 15–20" $TestMode
  Control-Services Start $New.VWS $ServicesToStart "Step 11" $TestMode
  Restart-IIS $New.VWS "Step 11" $TestMode
}
if (-not $SkipVCS) {
  Control-Services Stop $Old.VCS $ServicesToStop "Step 15–20" $TestMode
  Control-Services Start $New.VCS $ServicesToStart "Step 11" $TestMode
  Restart-IIS $New.VCS "Step 11" $TestMode
}
if (-not $SkipVIM) {
  Control-Services Stop $Old.VIM $ServicesToStop "Step 15–20" $TestMode
  Control-Services Start $New.VIM $ServicesToStart "Step 12" $TestMode
}
if (-not $SkipVMG) {
  Control-Services Stop $Old.VMG $ServicesToStop "Step 20" $TestMode
  Control-Services Start $New.VMG $ServicesToStart "Step 7" $TestMode
}
if (-not $SkipAAS) {
  if ($TestMode) {
    Log-Action "Step 14" $AAS "Web.config" "Update APL to $NewAPL" $true
  } else {
    Log-Action "Step 14" $AAS "Web.config" "Update APL to $NewAPL" $false
    Invoke-Command -ComputerName $AAS -ScriptBlock {
      param($apl)
      $path = "C:\InetPub\wwwroot\ARL\Qps.Ast.Arl.LocationForwardService\Web.config"
      (Get-Content $path) -replace "http://.*?/VisPR_MLSGateway/MlsGateway.asmx", "http://$apl/VisPR_MLSGateway/MlsGateway.asmx" | Set-Content $path
      iisreset
    } -ArgumentList $NewAPL
  }
}

$CsvOutput | Export-Csv -Path $CsvLog -NoTypeInformation
Write-Host "\n✅ Failover (or test) complete."
Write-Host "📄 Log saved to: $LogFile"
Write-Host "📊 CSV report saved to: $CsvLog"
