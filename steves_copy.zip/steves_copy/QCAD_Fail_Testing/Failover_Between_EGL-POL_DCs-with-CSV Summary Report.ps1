﻿<################################################################################################
 QCAD Mini Failover Automation Script (EGL ↔ POL)                                            #
################################################################################################

 Author: Generated for QCAD DR Planning by ChatGPT
 Purpose: Automates the application-layer failover process for QCAD (excluding Oracle)
 Aligns precisely with QCAD DR Plan 3.2.2.2 (Planned Removal and Reintroduction of CITEC)

  Covers Steps:
   - Step 1 / 15–20: Stop services
   - Step 2: Manual Master VAS promotion
   - Step 10–12: Start services & recreate connections
  - Step 13: Copy DFS shares to new site
   - Step 14: Update APL reference in AAS Web.config + restart IIS

 Excludes:
   - Step 9: Oracle RAC and cluster switch handled by DBAs

################################################################################################
# QUICK START                                                                                 #
################################################################################################

  Example LIVE Switch from EGL to POL:
     Switch-To -TargetDC POL

 Example TEST RUN (no changes made, log only):
     Switch-To -TargetDC POL -TestMode

 Output:
     - Plain text log:   C:\QCADFailover\Failover_Log_<timestamp>.txt
     - CSV summary:      C:\QCADFailover\Failover_Report_<timestamp>.csv

 Requirements:
     - Run from a machine with remote PowerShell access to all involved servers
     - Ensure QCAD admin accounts have rights to restart services and access file shares
     - Confirm manual VAS master promotion before proceeding

 DFS Shares Included:
    - System_VisVT\Manager
     - System_VisVT\New Version
     - OfficerDetails
     - VisionAudit
     (Easily extendable via `$DFS_Shares` variable)

 Services Managed:
     - Fortek.Services.Arbitrator
     - Fortek.FCS
     - VisVT_VDW
     - RabbitMQ
     - W3SVC (IIS)
     - CCCM
     - VisionService
     - ExternalClientGateway

 APL/AAS Handling:
     - AAS Web.config modified to point to correct APL (EGL or POL)
     - IIS restarted to apply changes

 DO NOT run this script unattended in production without first validating all DR dependencies.
 For TEST mode, all actions will be simulated, nothing is changed.

 You can comment out functions to exclude components from testing if needed


#>


$LogFile = "C:\QCADFailover\Failover_Log_$((Get-Date).ToString('yyyyMMdd_HHmm')).txt"
$CsvLog = "C:\QCADFailover\Failover_Report_$((Get-Date).ToString('yyyyMMdd_HHmm')).csv"

# Define server groups (Step 0: Prerequisite)
$EGL_VAS = @("EGLVCADVASVT01", "EGLVCADVASVT02")
$POL_VAS = @("POLVCADVASVT03", "POLVCADVASVT04")

$EGL_VWS = @("EGLVCADVWSVT01", "EGLVCADVWSVT02", "EGLVCADVWSVT03", "EGLVCADVWSVT04")
$POL_VWS = @("POLVCADVWSVT01", "POLVCADVWSVT02", "POLVCADVWSVT03", "POLVCADVWSVT04")

$EGL_VCS = @("EGLVCADVCSVT01", "EGLVCADVCSVT02", "EGLVCADVCSVT03", "EGLVCADVCSVT04", "EGLVCADVCSVT05")
$POL_VCS = @("POLVCADVCSVT01", "POLVCADVCSVT02", "POLVCADVCSVT03", "POLVCADVCSVT04", "POLVCADVCSVT05")

$EGL_VIM = @("EGLVCADVIMVT01", "EGLVCADVIMVT02")
$POL_VIM = @("POLVCADVIMVT01", "POLVCADVIMVT02")

$EGL_VMG = @("EGLVCADVMGVT01")
$POL_VMG = @("POLVCADVMGVT01")

$APL_PRIMARY = "EGLVCADAPLVT01"
$APL_SECONDARY = "POLVCADAPLVT01"
$AAS = "EGLVCADAASVT01"

# DFS Share Replication (Step 13)
$DFS_Shares = @(
  "D$\Vision\VisVT\System_VisVT\Manager",
  "D$\Vision\VisVT\System_VisVT\New Version",
  "D$\Vision\OfficerDetails",
  "D$\Vision\VisionAudit"
)

# Services (used in Steps 1, 3, 5, 6, 7, 15–20)
$ServicesToStop = @("Fortek.Services.Arbitrator", "Fortek.FCS", "VisVT_VDW", "RabbitMQ", "W3SVC", "CCCM", "VisionService", "ExternalClientGateway")
$ServicesToStart = @("VisVT_VDW", "W3SVC", "CCCM", "VisionService", "ExternalClientGateway")

$Global:CsvOutput = @()

function Log-Action {
    param($Server, $Service, $Action, $Step, $IsTest)
    $line = "[$Step] $Action service '$Service' on $Server"
    if ($IsTest) { $line = "[TEST] $line" }
    Add-Content -Path $LogFile -Value $line
    $Global:CsvOutput += [pscustomobject]@{
        Step     = $Step
        Server   = $Server
        Action   = $Action
        Service  = $Service
        TestMode = $IsTest
    }
}

function Stop-Services {
    param($servers, $TestMode)
    foreach ($server in $servers) {
        foreach ($svc in $ServicesToStop) {
            Log-Action -Server $server -Service $svc -Action "Stop" -Step "Step 1/15–20" -IsTest:$TestMode
            if (-not $TestMode) {
                Invoke-Command -ComputerName $server -ScriptBlock {
                    param($svc) Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue
                } -ArgumentList $svc
            }
        }
    }
}

function Start-Services {
    param($servers, $TestMode)
    foreach ($server in $servers) {
        foreach ($svc in $ServicesToStart) {
            Log-Action -Server $server -Service $svc -Action "Start" -Step "Step 10/11/12/7" -IsTest:$TestMode
            if (-not $TestMode) {
                Invoke-Command -ComputerName $server -ScriptBlock {
                    param($svc) Start-Service -Name $svc -ErrorAction SilentlyContinue
                } -ArgumentList $svc
            }
        }
    }
}

function Restart-IIS {
    param($servers, $TestMode)
    foreach ($server in $servers) {
        Log-Action -Server $server -Service "IIS" -Action "Restart" -Step "Step 11/12" -IsTest:$TestMode
        if (-not $TestMode) {
            Invoke-Command -ComputerName $server -ScriptBlock { iisreset }
        }
    }
}

function Copy-DFS-Shares {
    param($source, $targets, $TestMode)
    foreach ($share in $DFS_Shares) {
        foreach ($target in $targets) {
            $desc = "Copy DFS $share from $source to $target"
            Add-Content -Path $LogFile -Value "[Step 13] $desc"
            $Global:CsvOutput += [pscustomobject]@{
                Step     = "Step 13"
                Server   = $target
                Action   = "Copy"
                Service  = $share
                TestMode = $TestMode
            }
            if (-not $TestMode) {
                robocopy "\\$source\$share" "\\$target\$share" /MIR /R:1 /W:5 /NFL /NDL /NP /LOG+:$LogFile
            }
        }
    }
}

function Switch-To {
    param(
        [ValidateSet("EGL", "POL")][string]$TargetDC,
        [switch]$TestMode
    )
    if ($TargetDC -eq "EGL") {
        $Master = $EGL_VAS[0]
        $Secondary = $EGL_VAS[1]
        $OldDC_VAS = $POL_VAS; $NewDC_VAS = $EGL_VAS
        $OldDC_VWS = $POL_VWS; $NewDC_VWS = $EGL_VWS
        $OldDC_VCS = $POL_VCS; $NewDC_VCS = $EGL_VCS
        $OldDC_VIM = $POL_VIM; $NewDC_VIM = $EGL_VIM
        $OldDC_VMG = $POL_VMG; $NewDC_VMG = $EGL_VMG
        $NewAPL = $APL_PRIMARY
    } else {
        $Master = $POL_VAS[0]
        $Secondary = $POL_VAS[1]
        $OldDC_VAS = $EGL_VAS; $NewDC_VAS = $POL_VAS
        $OldDC_VWS = $EGL_VWS; $NewDC_VWS = $POL_VWS
        $OldDC_VCS = $EGL_VCS; $NewDC_VCS = $POL_VCS
        $OldDC_VIM = $EGL_VIM; $NewDC_VIM = $POL_VIM
        $OldDC_VMG = $EGL_VMG; $NewDC_VMG = $POL_VMG
        $NewAPL = $APL_SECONDARY
    }

    Write-Host "\n=== MINI FAILOVER: SWITCHING TO $TargetDC DC ==="
    Add-Content -Path $LogFile -Value "--- FAILOVER TO $TargetDC DC STARTED ---"

    Write-Host "❗ Please manually promote the VAS Master to $Master now."
    if (-not $TestMode) { Read-Host "Press ENTER after Master promotion is confirmed..." }
    else { Write-Host "[TEST] Skipping manual confirmation in TestMode." }

    Stop-Services -servers $OldDC_VAS -TestMode:$TestMode
    Stop-Services -servers $OldDC_VWS -TestMode:$TestMode
    Stop-Services -servers $OldDC_VCS -TestMode:$TestMode
    Stop-Services -servers $OldDC_VIM -TestMode:$TestMode
    Stop-Services -servers $OldDC_VMG -TestMode:$TestMode

    Start-Services -servers $NewDC_VAS -TestMode:$TestMode
    Start-Services -servers $NewDC_VWS -TestMode:$TestMode
    Start-Services -servers $NewDC_VCS -TestMode:$TestMode
    Start-Services -servers $NewDC_VIM -TestMode:$TestMode
    Start-Services -servers $NewDC_VMG -TestMode:$TestMode

    Restart-IIS -servers $NewDC_VWS -TestMode:$TestMode
    Restart-IIS -servers $NewDC_VCS -TestMode:$TestMode

    Copy-DFS-Shares -source $Master -targets ($NewDC_VAS | Where-Object { $_ -ne $Master }) -TestMode:$TestMode

    if ($TestMode) {
        Add-Content -Path $LogFile -Value "[TEST] Would update AAS Web.config to point to APL $NewAPL and restart IIS"
    } else {
        Write-Host "\nUpdating AAS Web.config to point to APL $NewAPL..."
        Invoke-Command -ComputerName $AAS -ScriptBlock {
            param($apl)
            $path = "D:\Octopus\Applications\Test\Qps.Ast.Arl.LocationForwardService\1.1.164_1\Web.config"
            (Get-Content $path) -replace "http://.*?/VisVT_MLSGateway/MlsGateway.asmx", "http://$apl/VisVT_MLSGateway/MlsGateway.asmx" | Set-Content $path
            iisreset
        } -ArgumentList $NewAPL
    }

    Write-Host "\n Failover to $TargetDC complete. Validate client access, QPages, narratives, PLK and UQP manually."
    Add-Content -Path $LogFile -Value "--- FAILOVER COMPLETE ---"

    $Global:CsvOutput | Export-Csv -Path $CsvLog -NoTypeInformation
    Write-Host "Log written to: $LogFile"
    Write-Host "CSV report written to: $CsvLog"
}

# Example usage:
# Switch-To -TargetDC POL           # Live run
# Switch-To -TargetDC POL -TestMode  # Dry-run with log/CSV
