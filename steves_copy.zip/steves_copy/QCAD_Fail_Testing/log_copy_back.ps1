﻿# === CONFIGURATION ===
$serverList = "C:\temp\QCAD\VT\Fail_Testing\VT_fail-testing_list.txt"  # Update this to your actual file
$remoteLogPath = "D$\Failtesting\logs"
$destinationRoot = "C:\temp\QCAD\VT\Fail_Testing\Performance_Logs"
$logSummary = "C:\temp\QCAD\VT\Fail_Testing\CopySummary_$(Get-Date -Format yyyyMMdd_HHmmss).txt"

# Create destination root if needed
if (!(Test-Path $destinationRoot)) {
    New-Item -Path $destinationRoot -ItemType Directory -Force | Out-Null
}

Add-Content $logSummary "=== Copy Summary - $(Get-Date) ==="

# === PROCESS EACH SERVER ===
Get-Content $serverList | ForEach-Object {
    $server = $_.Trim()
    if ($server -eq "") { return }

    $sourcePath = "\\$server\$remoteLogPath"
    $targetPath = Join-Path $destinationRoot $server

    try {
        # Create local folder for this server
        if (!(Test-Path $targetPath)) {
            New-Item -Path $targetPath -ItemType Directory -Force | Out-Null
        }

        # Copy files from remote server
        Copy-Item -Path "$sourcePath\*" -Destination $targetPath -Recurse -Force -ErrorAction Stop

        Add-Content $logSummary "SUCCESS: $server logs copied to $targetPath"
    }
    catch {
        Add-Content $logSummary "FAILED: $server - $_"
    }
}

Add-Content $logSummary "=== Copy Completed ==="
