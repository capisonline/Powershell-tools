﻿<#
.SYNOPSIS
    Injects a simulated ERROR log entry into ALL log files under the specified directory.

.DESCRIPTION
    - Recursively searches for *.log files in E:\Vision\VisPR\System_VisPR\Logs\
    - Appends an ERROR log entry to EVERY discovered log file.
    - The log entry follows log4net's format:
        YYYY-MM-DD HH:MM:SS,fff [9999] ERROR - Simulated SCOM Test Error.
    - Designed to be executed by a scheduled task every 5 minutes for 30 minutes.

.PARAMETER None
    This script does not require parameters.

.NOTES
    - Runs as SYSTEM via a scheduled task.
    - Intended for testing SCOM log monitoring.
    - Does not delete logs or interfere with log rotation.

.VERSION
    1.3 - Updated to inject into ALL log files
#>

# Define the log directory path
$logDirectory = "E:\Vision\VisPR\System_VisPR\Logs"

# Get all .log files recursively (including subdirectories)
$logFiles = Get-ChildItem -Path $logDirectory -Filter "*.log" -Recurse -File

# Proceed only if log files are found
if ($logFiles.Count -gt 0) {
    # Generate log entry with timestamp
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss,fff"
    $logEntry = "$timestamp [9999] ERROR - Simulated SCOM Test Error."

    # Append log entry to ALL discovered log files
    $logFiles | ForEach-Object {
        Add-Content -Path $_.FullName -Value $logEntry -Encoding UTF8
    }

    Write-Output "Injected log entry into $($logFiles.Count) log files."
} else {
    Write-Output "No log files found in $logDirectory."
}
