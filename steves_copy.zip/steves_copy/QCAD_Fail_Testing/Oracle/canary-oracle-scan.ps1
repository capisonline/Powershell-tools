. .\_qcad.common.ps1

<#
Purpose: Tiny read against Oracle service via SCAN every N seconds; log latency + endpoint.
If Oracle client not available, falls back to TCP connect test to SCAN:Port.
#>

param(
  [string]$ScanHost = "vt-scan.example.local",
  [int]$ScanPort = 1521,
  [string]$OracleTns = "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=vt-scan.example.local)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=VTDB)))",
  [string]$OracleUser = "canary_read",
  [string]$OraclePassword = "REDACTED",
  [int]$IntervalSeconds = $IdlePollSeconds,
  [int]$DurationSeconds = 300
)

$run   = New-RunFolder "canary"
$logCsv = Join-Path $run "canary.csv"
if(!(Test-Path $logCsv)){"Timestamp,Mode,Success,LatencyMs,Endpoint,Error" | Out-File -Encoding utf8 $logCsv}

function Test-Tcp {
  param([string]$Host,[int]$Port)
  $sw=[Diagnostics.Stopwatch]::StartNew()
  try{
    $client = New-Object System.Net.Sockets.TcpClient
    $async = $client.BeginConnect($Host,$Port,$null,$null)
    if(-not $async.AsyncWaitHandle.WaitOne(3000,$false)){ throw "TCP timeout" }
    $client.EndConnect($async); $client.Close(); $ok=$true
  } catch { $ok=$false; $err=$_.Exception.Message } finally { $sw.Stop() }
  [pscustomobject]@{Mode='TCP';Success=$ok;LatencyMs=[int]$sw.Elapsed.TotalMilliseconds;Endpoint="$Host:$Port";Error=$err}
}

# Try Oracle client (ODP.NET) first; fallback to TCP
$useOra = $false
try { Add-Type -AssemblyName Oracle.ManagedDataAccess -ErrorAction Stop; $useOra = $true } catch {}

$end = (Get-Date).AddSeconds($DurationSeconds)
while((Get-Date) -lt $end){
  if($useOra){
    $row = $null
    $sw=[Diagnostics.Stopwatch]::StartNew()
    try{
      $conn = New-Object Oracle.ManagedDataAccess.Client.OracleConnection("User Id=$OracleUser;Password=$OraclePassword;Data Source=$OracleTns")
      $conn.Open()
      $cmd = $conn.CreateCommand(); $cmd.CommandText = "select instance_name from v$instance"
      $inst = $cmd.ExecuteScalar()
      $conn.Close(); $ok=$true; $endpoint=$inst
    } catch { $ok=$false; $err=$_.Exception.Message } finally { $sw.Stop() }
    $row = [pscustomobject]@{Timestamp=(Get-Date).ToString($TimeFormat);Mode='ODP';Success=$ok;LatencyMs=[int]$sw.Elapsed.TotalMilliseconds;Endpoint=$endpoint;Error=$err}
  } else {
    $r = Test-Tcp -Host $ScanHost -Port $ScanPort
    $row = [pscustomobject]@{Timestamp=(Get-Date).ToString($TimeFormat);Mode=$r.Mode;Success=$r.Success;LatencyMs=$r.LatencyMs;Endpoint=$r.Endpoint;Error=$r.Error}
  }
  $row | Export-Csv -NoTypeInformation -Append -Path $logCsv
  Start-Sleep -Seconds $IntervalSeconds
}
