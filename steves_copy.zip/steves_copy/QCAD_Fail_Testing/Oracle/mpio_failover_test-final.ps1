﻿<#
.SYNOPSIS
    Validates Windows Native MPIO failover by disabling ONE storage initiator/port at a time and confirming storage I/O continues on remaining paths.

.DESCRIPTION
    This script validates Microsoft DSM / MSDSM MPIO failover by simulating partial path loss on Windows hosts.
    It disables a selected storage initiator device (PnP InstanceId) for a short duration, then re-enables it.

    Key intent:
      - Prove "MPIO failover works" (single port / single initiator loss).
      - NOT intended to test "all paths down / storage disappears".

    Evidence captured per run (timestamped folder under -OutputRoot):
      - fc_devices_discovery.csv (PnP discovery list)
      - mpclaim_before.txt / mpclaim_after.txt (full mpclaim -v)
      - mpclaim_summary_before.txt / mpclaim_summary_after.txt (mpclaim -s -d)
      - mpclaim_during_disable_disk<N>.txt (mid-test mpclaim for an MPIO disk)
      - mpio_setting_before/after.txt (Get-MPIOSetting)
      - event_*.csv (System event extracts for Disk/StorPort/MPIO/MSDSM)
      - mpio_actions.csv (disable/enable actions + exit codes + timestamps)

.SAFETY
    - Run in VT / non-production only.
    - Run as Administrator.
    - Provide ONLY storage initiator InstanceIds (e.g., QLogic FCoE/FC). Do NOT include RAID controllers (e.g., PERC).
    - Default guardrails prevent disabling all provided initiators unless -AllowAllPathsDown is set.

.PARAMETER ListFcDevices
    Discover candidate storage initiator devices (SCSIAdapter) and export to fc_devices_discovery.csv, then exit.

.PARAMETER HbaPortInstanceIds
    Array of PnP InstanceIds representing storage initiator devices to toggle.

.PARAMETER DoSinglePort
    Disable exactly one device selected by -SinglePortIndex, hold for -DisableSeconds_SinglePort, then re-enable.

.PARAMETER DoSingleHba
    Disable two devices selected by -SingleHbaPortIndexes, hold for -DisableSeconds_SingleHba, then re-enable.
    WARNING: If those two devices represent all storage initiators, this becomes an all-paths-down test.

.PARAMETER AllowAllPathsDown
    Overrides safety checks that prevent disabling all provided initiators.

.PARAMETER EvidenceMpioDiskNumber
    Disk number for mid-test mpclaim capture. Default -1 means auto-select the first MPIO disk found from "mpclaim -s -d".

.EXAMPLE
    # Discover candidates (exports to run folder)
    .\mpio_failover_test.ps1 -ListFcDevices -OutputRoot "D:\Steve"

.EXAMPLE
    # Single-port failover (disable one initiator for 30s, capture mid-test evidence automatically)
    .\mpio_failover_test.ps1 `
      -OutputRoot "D:\Steve" `
      -HbaPortInstanceIds @(
        "QEBDRV\FCOE2&PCI_80801077&SUBSYS_000F1077&REV_02\5&1035A1D6&0&5005C300",
        "QEBDRV\FCOE2&PCI_80801077&SUBSYS_000F1077&REV_02\5&12CC0087&0&5005C300"
      ) `
      -DoSinglePort -SinglePortIndex 0 `
      -DisableSeconds_SinglePort 30
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
  # ---- Discovery ----
  [switch]$ListFcDevices,

  # ---- Targets ----
  [string[]]$HbaPortInstanceIds = @(),

  # ---- Scenarios ----
  [switch]$DoSinglePort,
  [switch]$DoSingleHba,

  [int]$SinglePortIndex = 0,
  [int[]]$SingleHbaPortIndexes = @(0,1),

  # ---- Timing ----
  [int]$DisableSeconds_SinglePort = 30,
  [int]$DisableSeconds_SingleHba  = 60,
  [int]$SettleSeconds_AfterEnable = 30,

  # ---- Evidence (mid-test mpclaim) ----
  [int]$EvidenceMpioDiskNumber = -1,          # -1 = auto (first MPIO disk found)
  [int]$EvidenceDuringDelaySeconds = 10,      # delay after disable to capture mpclaim (during)

  # ---- Guardrails ----
  [switch]$AllowAllPathsDown,

  # ---- Method ----
  [ValidateSet("Auto","PnpDevice","PnPUtil")]
  [string]$ToggleMethod = "Auto",

  # ---- Output ----
  [string]$OutputRoot = "C:\temp\QCAD\VT\Oracle\Hardware_tests\mpio_tests"
)

# -----------------------------
# Helpers (standalone)
# -----------------------------
function Assert-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p  = New-Object Security.Principal.WindowsPrincipal($id)
  if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
    throw "Run this script in an elevated PowerShell session (Run as Administrator)."
  }
}

function New-RunFolder([string]$Name){
  $ts = Get-Date -Format "yyyyMMdd_HHmmss"
  $p  = Join-Path $OutputRoot "$Name\$ts"
  New-Item -ItemType Directory -Path $p -Force | Out-Null
  return $p
}

function Write-ActionsCsvHeader([string]$Path){
  "Timestamp,Action,InstanceId,ExitCode,Notes" | Out-File -Force $Path
}

function Write-ActionsCsvRow([string]$Path, [string]$Action, [string]$InstanceId, [int]$ExitCode, [string]$Notes = ""){
  $t = (Get-Date).ToString("o")
  $row = '"' + ($t,$Action,$InstanceId,$ExitCode,$Notes -join '","') + '"'
  Add-Content -Path $Path -Value $row
}

function Resolve-ToggleMethod {
  if($ToggleMethod -ne "Auto"){ return $ToggleMethod }
  if(Get-Command Disable-PnpDevice -ErrorAction SilentlyContinue){ return "PnpDevice" }
  return "PnPUtil"
}

function Disable-Dev([string]$Id, [string]$Method){
  if($PSCmdlet.ShouldProcess($Id,"Disable device")){
    if($Method -eq "PnpDevice"){
      try { Disable-PnpDevice -InstanceId $Id -Confirm:$false -ErrorAction Stop | Out-Null; return 0 }
      catch { return 1 }
    } else {
      $p = Start-Process -FilePath pnputil.exe -ArgumentList @('/disable-device',$Id) -Wait -PassThru -WindowStyle Hidden
      return [int]$p.ExitCode
    }
  }
  return 0
}

function Enable-Dev([string]$Id, [string]$Method){
  if($PSCmdlet.ShouldProcess($Id,"Enable device")){
    if($Method -eq "PnpDevice"){
      try { Enable-PnpDevice -InstanceId $Id -Confirm:$false -ErrorAction Stop | Out-Null; return 0 }
      catch { return 1 }
    } else {
      $p = Start-Process -FilePath pnputil.exe -ArgumentList @('/enable-device',$Id) -Wait -PassThru -WindowStyle Hidden
      return [int]$p.ExitCode
    }
  }
  return 0
}

function Get-FcPortDevices {
  # SCSIAdapter class: filter for common FC/FCoE vendor patterns; includes QLogic/Emulex/Broadcom/Marvell terms
  $candidates = Get-PnpDevice -Class SCSIAdapter -ErrorAction SilentlyContinue
  if(-not $candidates){ return @() }

  $fc = $candidates | Where-Object {
    $_.FriendlyName -match 'Fibre|Fiber|FCoE|FC|Emulex|QLogic|Marvell|Broadcom' -or
    $_.InstanceId   -match 'QEBDRV\\FCOE|FC'
  } | Select-Object Status,Class,FriendlyName,InstanceId

  return $fc
}

function Capture-MpclaimFull([string]$RunFolder, [string]$Suffix){
  try { & mpclaim.exe -v *> (Join-Path $RunFolder "mpclaim_${Suffix}.txt") } catch {}
}

function Capture-MpclaimSummary([string]$RunFolder, [string]$Suffix){
  try { & mpclaim.exe -s -d *> (Join-Path $RunFolder "mpclaim_summary_${Suffix}.txt") } catch {}
}

function Capture-MpioSettings([string]$RunFolder, [string]$Suffix){
  try { Get-MPIOSetting | Format-List * | Out-File (Join-Path $RunFolder "mpio_setting_${Suffix}.txt") } catch {}
  try { Get-WindowsFeature Multipath-IO | Format-List * | Out-File (Join-Path $RunFolder "feature_mpio_${Suffix}.txt") } catch {}
  try { Get-MSDSMGlobalDefaultLoadBalancePolicy | Format-List * | Out-File (Join-Path $RunFolder "msdsm_policy_${Suffix}.txt") } catch {}
  try { Get-MPIOPath | Format-Table -AutoSize | Out-File (Join-Path $RunFolder "mpio_paths_${Suffix}.txt") } catch {}
}

function Get-FirstMpioDiskNumber {
  # Parse "mpclaim -s -d" output for "MPIO Disk<N>"
  try {
    $out = & mpclaim.exe -s -d 2>$null
    if (-not $out) { return $null }

    $nums = foreach ($line in $out) {
      if ($line -match '^\s*MPIO Disk(\d+)\b') { [int]$Matches[1] }
    }
    if (-not $nums) { return $null }
    return ($nums | Sort-Object | Select-Object -First 1)
  } catch {
    return $null
  }
}

function Resolve-EvidenceDiskNumber {
  if ($EvidenceMpioDiskNumber -ge 0) { return $EvidenceMpioDiskNumber }
  return (Get-FirstMpioDiskNumber)
}

function Capture-MpclaimDisk([string]$RunFolder, [string]$Label, [int]$DiskNumber) {
  try {
    $p = Join-Path $RunFolder ("mpclaim_{0}_disk{1}.txt" -f $Label, $DiskNumber)
    & mpclaim.exe -s -d $DiskNumber *> $p
  } catch {}
}

function Capture-SystemEvents([string]$RunFolder, [string]$Suffix, [datetime]$StartTime){
  $providers = @(
    "Microsoft-Windows-MPIO",
    "Microsoft-Windows-StorPort",
    "Disk",
    "MPIO",
    "MSDSM"
  )

  foreach($prov in $providers){
    try {
      Get-WinEvent -FilterHashtable @{LogName="System"; ProviderName=$prov; StartTime=$StartTime} -ErrorAction Stop |
        Select-Object TimeCreated,Id,LevelDisplayName,ProviderName,Message |
        Export-Csv -NoTypeInformation -Path (Join-Path $RunFolder "event_${prov}_${Suffix}.csv")
    } catch {
      # Provider might not exist / no events in range; ignore.
    }
  }
}

# -----------------------------
# Main
# -----------------------------
Assert-Admin
$method   = Resolve-ToggleMethod
$testStart = (Get-Date).AddMinutes(-5)  # include a small buffer

$run = New-RunFolder "mpio"
$actionsCsv = Join-Path $run "mpio_actions.csv"
Write-ActionsCsvHeader $actionsCsv

# Always export discovery list for traceability
$fcList = Get-FcPortDevices
$fcList | Export-Csv -NoTypeInformation -Path (Join-Path $run "fc_devices_discovery.csv")

if($ListFcDevices){
  $fcList | Format-Table -AutoSize
  Write-Host ""
  Write-Host "Discovery exported to: $(Join-Path $run "fc_devices_discovery.csv")"
  Write-Host "Run folder: $run"
  return
}

if($HbaPortInstanceIds.Count -lt 1){
  throw "Provide -HbaPortInstanceIds. Tip: run with -ListFcDevices first."
}

# Guardrail: prevent a chosen test from disabling ALL provided initiators unless explicitly allowed.
if(-not $AllowAllPathsDown){
  if($DoSingleHba){
    $idx = $SingleHbaPortIndexes | Sort-Object -Unique
    if($idx.Count -ge $HbaPortInstanceIds.Count){
      throw "Refusing: Single-HBA selection would disable all provided initiators. Add more initiators OR set -AllowAllPathsDown (not recommended)."
    }
  }
}

# Resolve disk used for mid-test mpclaim evidence
$eDisk = Resolve-EvidenceDiskNumber
if ($null -ne $eDisk) {
  Set-Content -Path (Join-Path $run "evidence_mpio_disk.txt") -Value "Using MPIO Disk$eDisk for mid-test mpclaim evidence."
} else {
  Set-Content -Path (Join-Path $run "evidence_mpio_disk.txt") -Value "No MPIO disks detected via mpclaim -s -d. Mid-test mpclaim capture will be skipped."
}

# Baseline capture
Capture-MpclaimFull    -RunFolder $run -Suffix "before"
Capture-MpclaimSummary -RunFolder $run -Suffix "before"
Capture-MpioSettings   -RunFolder $run -Suffix "before"
Capture-SystemEvents   -RunFolder $run -Suffix "before" -StartTime $testStart

try {
  if($DoSinglePort){
    if($SinglePortIndex -lt 0 -or $SinglePortIndex -ge $HbaPortInstanceIds.Count){
      throw "SinglePortIndex $SinglePortIndex is out of range for HbaPortInstanceIds (count=$($HbaPortInstanceIds.Count))."
    }

    $id = $HbaPortInstanceIds[$SinglePortIndex]

    $ec = Disable-Dev $id $method
    Write-ActionsCsvRow $actionsCsv "DisableSinglePort" $id $ec "Method=$method; Hold=${DisableSeconds_SinglePort}s"

    # Mid-test evidence after disable takes effect
    if ($null -ne $eDisk -and $DisableSeconds_SinglePort -ge 6) {
      $delay = [Math]::Min($EvidenceDuringDelaySeconds, [Math]::Max(1, $DisableSeconds_SinglePort - 5))
      Start-Sleep -Seconds $delay
      Capture-MpclaimDisk -RunFolder $run -Label "during_disable" -DiskNumber $eDisk

      $remaining = $DisableSeconds_SinglePort - $delay
      if ($remaining -gt 0) { Start-Sleep -Seconds $remaining }
    } else {
      Start-Sleep -Seconds $DisableSeconds_SinglePort
    }

    $ec = Enable-Dev $id $method
    Write-ActionsCsvRow $actionsCsv "EnableSinglePort" $id $ec "Method=$method; Settle=${SettleSeconds_AfterEnable}s"
    Start-Sleep -Seconds $SettleSeconds_AfterEnable
  }

  if($DoSingleHba){
    $idx = $SingleHbaPortIndexes | Sort-Object -Unique
    if($idx.Count -ne 2){
      throw "SingleHbaPortIndexes must contain exactly two indexes (e.g., 0,1)."
    }
    foreach($i in $idx){
      if($i -lt 0 -or $i -ge $HbaPortInstanceIds.Count){
        throw "SingleHbaPortIndexes contains out-of-range index $i for HbaPortInstanceIds (count=$($HbaPortInstanceIds.Count))."
      }
    }

    $ids = @($HbaPortInstanceIds[$idx[0]], $HbaPortInstanceIds[$idx[1]])

    foreach($x in $ids){
      $ec = Disable-Dev $x $method
      Write-ActionsCsvRow $actionsCsv "DisableSingleHbaPort" $x $ec "Method=$method; Hold=${DisableSeconds_SingleHba}s"
    }

    # Mid-test evidence (optional)
    if ($null -ne $eDisk -and $DisableSeconds_SingleHba -ge 6) {
      $delay = [Math]::Min($EvidenceDuringDelaySeconds, [Math]::Max(1, $DisableSeconds_SingleHba - 5))
      Start-Sleep -Seconds $delay
      Capture-MpclaimDisk -RunFolder $run -Label "during_disable" -DiskNumber $eDisk

      $remaining = $DisableSeconds_SingleHba - $delay
      if ($remaining -gt 0) { Start-Sleep -Seconds $remaining }
    } else {
      Start-Sleep -Seconds $DisableSeconds_SingleHba
    }

    foreach($x in $ids){
      $ec = Enable-Dev $x $method
      Write-ActionsCsvRow $actionsCsv "EnableSingleHbaPort" $x $ec "Method=$method; Settle=${SettleSeconds_AfterEnable}s"
    }

    Start-Sleep -Seconds $SettleSeconds_AfterEnable
  }

  if(-not $DoSinglePort -and -not $DoSingleHba){
    Write-Host "No scenario switches specified. Use -DoSinglePort and/or -DoSingleHba." -ForegroundColor Yellow
  }
}
finally {
  # Always attempt to re-enable listed initiators (best effort) to avoid leaving a port down due to a script error.
  foreach($id in $HbaPortInstanceIds){
    try { Enable-Dev $id $method | Out-Null } catch {}
  }

  # Post capture
  Capture-MpclaimFull    -RunFolder $run -Suffix "after"
  Capture-MpclaimSummary -RunFolder $run -Suffix "after"
  Capture-MpioSettings   -RunFolder $run -Suffix "after"
  Capture-SystemEvents   -RunFolder $run -Suffix "after" -StartTime $testStart

  Write-Host ""
  Write-Host "Run folder:   $run"
  Write-Host "Actions CSV:  $actionsCsv"
  Write-Host "Discovery CSV:$(Join-Path $run "fc_devices_discovery.csv")"
}
