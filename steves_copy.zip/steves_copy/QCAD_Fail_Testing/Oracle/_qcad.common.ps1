param()

# ===== VARIABLES (common) =====
$LogRoot = "C:\QCAD-VT-Tests\logs"     # Hardcoded root for all evidence
$IdlePollSeconds = 10                   # iDRAC + canary idle cadence
$FaultPollSeconds = 2                   # iDRAC + canary during fault
$TimeFormat = "yyyy-MM-dd_HH-mm-ss.fff"

# ===== Helpers =====
function New-RunFolder([string]$TestName){
  $ts = (Get-Date).ToString('yyyyMMdd-HHmmss')
  $path = Join-Path $LogRoot "$($TestName)_$ts"
  New-Item -ItemType Directory -Force -Path $path | Out-Null
  return $path
}

function Write-Log([string]$Path,[string]$Level,[string]$Message){
  $line = [pscustomobject]@{
    Timestamp = (Get-Date).ToString($TimeFormat)
    Level     = $Level
    Message   = $Message
  }
  if(!(Test-Path $Path)){
    "Timestamp,Level,Message" | Out-File -Encoding utf8 $Path
  }
  $line | Export-Csv -NoTypeInformation -Append -Path $Path
  $line
}

function Invoke-Timeboxed([int]$Seconds,[scriptblock]$Body,[scriptblock]$Finally){
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  try   { & $Body } finally { & $Finally; $sw.Stop() }
  if($sw.Elapsed.TotalSeconds -gt $Seconds){ throw "Timebox exceeded: $($sw.Elapsed.TotalSeconds)s > ${Seconds}s" }
}
