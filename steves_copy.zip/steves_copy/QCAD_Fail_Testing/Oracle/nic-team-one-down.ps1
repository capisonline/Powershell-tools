. .\_qcad.common.ps1

<#
Purpose: Disable one LBFO team member for a strict window, then restore.
#>

param(
  [string]$TeamName = "PublicTeam",
  [string]$MemberName = "Ethernet2",
  [int]$DownSeconds = 60
)

$run = New-RunFolder "nic-team"
$log = Join-Path $run 'nic-team.csv'
if(!(Test-Path $log)){"Timestamp,Action,Team,Member,Result" | Out-File $log}

try{
  Write-Log $log 'INFO' "Disabling member $MemberName on team $TeamName"
  Set-NetLbfoTeamMember -Team $TeamName -Name $MemberName -AdministrativeMode Disabled -Confirm:$false
  Start-Sleep -Seconds $DownSeconds
}
finally{
  Set-NetLbfoTeamMember -Team $TeamName -Name $MemberName -AdministrativeMode Enabled -Confirm:$false
  Write-Log $log 'INFO' "Re-enabled member $MemberName"
}
