﻿<#
<#
.SYNOPSIS
    Validates Windows Native MPIO failover (PowerStore via QLogic FCoE CNA) by disabling ONE storage initiator/port at a time and confirming I/O continues on remaining paths.

.DESCRIPTION
    This script is designed to prove that Windows Native MPIO (Microsoft DSM / MSDSM) correctly fails over storage I/O when one
    storage initiator/adapter is lost, WITHOUT triggering a full storage outage.

    In this environment the storage paths are presented via QLogic FCoE CNA adapters. The script simulates a partial path-loss event
    by disabling a single CNA storage device (PnP InstanceId) for a short duration, then re-enabling it. This forces MPIO to route I/O
    over surviving paths.

    IMPORTANT: This is an "MPIO failover works" test, NOT an "all paths down / storage disappears" test. This can be done to test DR stratergies though so the option has been included. 
    - A single-port test should reduce the number of active paths per MPIO disk (e.g., 4 -> 2) while keeping disks ONLINE.
    - A single-HBA test (disabling both CNAs/ports) may become an all-paths-down event and is not recommended unless explicitly intended.

    Typical evidence of correct behavior:
    - mpclaim shows each MPIO disk has multiple paths (e.g., "MPIO Disk0: 04 Paths, RRWS").
    - During the disable window, paths via the disabled device drop/inactivate, but remaining paths stay Active/Optimized or Active.
    - No disks go offline, no persistent Disk/StorPort errors, no Oracle node eviction, no BSOD.
    - After re-enable, paths return and RRWS continues normally.

    Output is captured into a timestamped run folder containing:
    - mpclaim before/after
    - MPIO settings before/after
    - FC/FCoE device discovery list
    - Storage-related System event log extracts
    - Actions CSV (device disable/enable operations + exit codes)

.SAFETY / CHANGE RISK
    - Must be run in a controlled test window (VT / non-production).
    - Run as Administrator.
    - Disabling a device is a "hard" simulation (PnP-level). It is still valid for failover testing but can trigger driver resets.
    - DO NOT include non-storage devices (e.g., RAID controller) in InstanceIds.
    - Default guardrails should prevent accidental "disable all provided ports" unless explicitly overridden.
    - If you have only two storage CNAs/ports listed and disable both, you may recreate an all-paths-down event.

.HOW THIS TEST WORKS (SEQUENCE)
    1) Creates a timestamped run folder under -OutputRoot (e.g. D:\Steve\mpio\yyyyMMdd_HHmmss\)
    2) Captures baseline evidence (mpclaim, MPIO settings, discovery, relevant event logs)
    3) Disables ONE device selected by -SinglePortIndex from -HbaPortInstanceIds (partial path-loss trigger)
    4) Waits -DisableSeconds_SinglePort while MPIO should continue I/O via surviving paths
    5) Re-enables that same device (recovery)
    6) Waits a short settle period
    7) Captures after evidence (mpclaim, MPIO settings, relevant event logs)

.SUCCESS CRITERIA
    PASS:
      - Disks remain ONLINE throughout test
      - Path count decreases during disable window but I/O continues
      - Paths recover after re-enable (path count returns to baseline)
      - No Oracle node eviction, no BSOD
      - Event logs show expected MPIO/MSDSM/StorPort transitions without persistent errors

    FAIL:
      - Any disk goes offline or remains degraded after recovery
      - Persistent StorPort/Disk errors indicating I/O failure beyond transient path loss
      - Oracle node eviction/reboot/BSOD
      - Paths do not return after re-enable

.PARAMETER ListFcDevices
    Lists candidate FC/FCoE storage devices (PnP SCSIAdapter entries) and exports discovery output to the run folder.
    Use this to identify correct InstanceIds for -HbaPortInstanceIds.

.PARAMETER HbaPortInstanceIds
    Array of PnP InstanceIds representing the storage initiator devices to toggle (e.g., QLogic FCoE CNA storage devices).
    Provide ONLY storage path devices. Do NOT include RAID controllers (e.g., "PERC H755 MX").

.PARAMETER DoSinglePort
    Executes a single-port/initiator failover test by disabling exactly one device (selected via -SinglePortIndex), then re-enabling it.

.PARAMETER SinglePortIndex
    Index into -HbaPortInstanceIds indicating which single device to disable for the -DoSinglePort test.
    Example: 0 disables the first InstanceId; repeat with 1 to validate the other path source.

.PARAMETER DisableSeconds_SinglePort
    Duration (seconds) to keep the selected device disabled during the single-port test.

.PARAMETER DoSingleHba
    Executes a "single HBA" test by disabling two selected ports (indices in -SingleHbaPortIndexes), then re-enabling them.
    WARNING: If the selected ports represent all storage initiators, this becomes an all-paths-down scenario.

.PARAMETER SingleHbaPortIndexes
    Two indexes into -HbaPortInstanceIds representing the pair of ports associated with one HBA/CNA.

.PARAMETER AllowAllPathsDown
    Overrides safety checks preventing a scenario that disables all provided storage initiators.
    Not recommended for MPIO failover validation.

.PARAMETER ToggleMethod
    Device toggle method:
      - Auto      : Prefer Disable/Enable-PnpDevice if available, else pnputil
      - PnpDevice : Force Disable/Enable-PnpDevice
      - PnPUtil   : Force pnputil /disable-device /enable-device

.PARAMETER OutputRoot
    Root folder for all output. A timestamped run folder is created beneath this path.

.EXAMPLE
    # 1) Discover relevant storage devices (exports fc_devices_discovery.csv into a run folder)
    .\mpio_failover_test.ps1 -ListFcDevices -OutputRoot "D:\Steve"

.EXAMPLE
    # 2) Single-port failover test (disable one CNA/initiator for 30s, then re-enable)
    .\mpio_failover_test.ps1 `
      -OutputRoot "D:\Steve" `
      -HbaPortInstanceIds @(
        "QEBDRV\FCOE2&PCI_80801077&SUBSYS_000F1077&REV_02\5&1035A1D6&0&5005C300",
        "QEBDRV\FCOE2&PCI_80801077&SUBSYS_000F1077&REV_02\5&12CC0087&0&5005C300"
      ) `
      -DoSinglePort -SinglePortIndex 0 `
      -DisableSeconds_SinglePort 30

.EXAMPLE
    # 3) Repeat the single-port test for the other side
    .\mpio_failover_test.ps1 `
      -OutputRoot "D:\Steve" `
      -HbaPortInstanceIds @(
        "<InstanceId_A>",
        "<InstanceId_B>"
      ) `
      -DoSinglePort -SinglePortIndex 1 `
      -DisableSeconds_SinglePort 30

.NOTES
    - In PowerStore/ALUA environments, mpclaim may show Active/Optimized and Active/Unoptimized paths (TPG states).
      This is expected. The key is that at least one viable path remains active during the test window.
    - Recommended to run mpclaim validation beforehand, e.g.:
        mpclaim -s -d
        mpclaim -s -d 0
      to confirm multiple paths per disk before toggling any device.

#>

#>

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  # ---- Discovery / listing ----
  [switch]$ListFcDevices,

  # ---- Explicit targets (InstanceIds) ----
  [string[]]$HbaPortInstanceIds = @(),

  # ---- Scenarios ----
  [switch]$DoSinglePort,
  [switch]$DoSingleHba,

  # Indexes into HbaPortInstanceIds (so you can use discovery output)
  [int]$SinglePortIndex = 0,

  # For single-HBA test: specify 2 indices that represent the two ports on one HBA
  [int[]]$SingleHbaPortIndexes = @(0,1),

  # ---- Timing ----
  [int]$DisableSeconds_SinglePort = 30,
  [int]$DisableSeconds_SingleHba  = 60,
  [int]$SettleSeconds_AfterEnable = 30,

  # ---- Guardrails ----
  [switch]$AllowAllPathsDown,

  # ---- Method ----
  [ValidateSet("Auto","PnpDevice","PnPUtil")]
  [string]$ToggleMethod = "Auto",

  # ---- Output ----
  [string]$OutputRoot = "C:\temp\QCAD\VT\Oracle\Hardware_tests\mpio_tests"
)

# -----------------------------
# Minimal helpers (standalone)
# -----------------------------
function New-RunFolder([string]$Name){
  $ts = Get-Date -Format "yyyyMMdd_HHmmss"
  $p  = Join-Path $OutputRoot "$Name\$ts"
  New-Item -ItemType Directory -Path $p -Force | Out-Null
  return $p
}
function Write-LineCsv([string]$Path, [string]$Action, [string]$InstanceId, [int]$ExitCode, [string]$Notes=""){
  $t = (Get-Date).ToString("o")
  $row = '"' + ($t,$Action,$InstanceId,$ExitCode,$Notes -join '","') + '"'
  Add-Content -Path $Path -Value $row
}
function Assert-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p  = New-Object Security.Principal.WindowsPrincipal($id)
  if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
    throw "Run this script in an elevated PowerShell session (Run as Administrator)."
  }
}

# -----------------------------
# Discovery: find likely FC ports
# -----------------------------
function Get-FcPortDevices {
  # FC HBAs usually show up under SCSIAdapter in PnP; filter by common vendor/name patterns
  $candidates = Get-PnpDevice -Class SCSIAdapter -ErrorAction SilentlyContinue
  if(-not $candidates){ return @() }

  $fc = $candidates | Where-Object {
    $_.FriendlyName -match 'Fibre|Fiber|FC|Emulex|QLogic|Marvell|Broadcom' -or
    $_.InstanceId   -match 'PCI\\VEN_' # keep sane devices; still filtered by name above
  } | Select-Object Status,Class,FriendlyName,InstanceId

  return $fc
}

# -----------------------------
# Toggle implementation
# -----------------------------
function Resolve-ToggleMethod {
  if($ToggleMethod -ne "Auto"){ return $ToggleMethod }
  # Prefer PnpDevice cmdlets if available
  if(Get-Command Disable-PnpDevice -ErrorAction SilentlyContinue){ return "PnpDevice" }
  return "PnPUtil"
}

function Disable-Dev([string]$Id, [string]$Method){
  if($PSCmdlet.ShouldProcess($Id,"Disable device")){
    if($Method -eq "PnpDevice"){
      try {
        Disable-PnpDevice -InstanceId $Id -Confirm:$false -ErrorAction Stop | Out-Null
        return 0
      } catch {
        return 1
      }
    } else {
      $p = Start-Process -FilePath pnputil.exe -ArgumentList @('/disable-device',$Id) -Wait -PassThru -WindowStyle Hidden
      return [int]$p.ExitCode
    }
  }
  return 0
}

function Enable-Dev([string]$Id, [string]$Method){
  if($PSCmdlet.ShouldProcess($Id,"Enable device")){
    if($Method -eq "PnpDevice"){
      try {
        Enable-PnpDevice -InstanceId $Id -Confirm:$false -ErrorAction Stop | Out-Null
        return 0
      } catch {
        return 1
      }
    } else {
      $p = Start-Process -FilePath pnputil.exe -ArgumentList @('/enable-device',$Id) -Wait -PassThru -WindowStyle Hidden
      return [int]$p.ExitCode
    }
  }
  return 0
}

# -----------------------------
# Evidence capture
# -----------------------------
function Capture-Evidence([string]$RunFolder, [string]$Suffix){
  try { mpclaim.exe -v *> (Join-Path $RunFolder "mpclaim_${Suffix}.txt") } catch {}
  try { Get-MPIOSetting | Format-List * | Out-File (Join-Path $RunFolder "mpio_setting_${Suffix}.txt") } catch {}
  try { Get-WindowsFeature Multipath-IO | Format-List * | Out-File (Join-Path $RunFolder "feature_mpio_${Suffix}.txt") } catch {}

  # Useful (if present)
  try { Get-MPIOPath | Format-Table -AutoSize | Out-File (Join-Path $RunFolder "mpio_paths_${Suffix}.txt") } catch {}
  try { Get-MSDSMGlobalDefaultLoadBalancePolicy | Format-List * | Out-File (Join-Path $RunFolder "msdsm_policy_${Suffix}.txt") } catch {}

  # Pull relevant System log window (last 60 mins is usually enough for a short test)
  $start = (Get-Date).AddMinutes(-60)
  $providers = @(
    "Microsoft-Windows-MPIO",
    "Microsoft-Windows-StorPort",
    "Disk",
    "MPIO",
    "MSDSM"
  )

  foreach($prov in $providers){
    try {
      Get-WinEvent -FilterHashtable @{LogName="System"; ProviderName=$prov; StartTime=$start} -ErrorAction Stop |
        Select-Object TimeCreated,Id,LevelDisplayName,ProviderName,Message |
        Export-Csv -NoTypeInformation -Path (Join-Path $RunFolder "event_${prov}_${Suffix}.csv")
    } catch {
      # ignore if provider not present on this host
    }
  }
}

# -----------------------------
# Main
# -----------------------------
Assert-Admin
$method = Resolve-ToggleMethod

$run = New-RunFolder "mpio"
$csv = Join-Path $run "mpio_actions.csv"
"Timestamp,Action,InstanceId,ExitCode,Notes" | Out-File -Force $csv

# Always dump discovery list for traceability
$fcList = Get-FcPortDevices
$fcList | Export-Csv -NoTypeInformation -Path (Join-Path $run "fc_devices_discovery.csv")

if($ListFcDevices){
  $fcList | Format-Table -AutoSize
  Write-Host ""
  Write-Host "Discovery exported to: $(Join-Path $run "fc_devices_discovery.csv")"
  Write-Host "Run folder: $run"
  return
}

# Validate provided IDs exist
if($HbaPortInstanceIds.Count -lt 1){
  throw "Provide -HbaPortInstanceIds (use -ListFcDevices first to identify the correct InstanceId values)."
}

# Guardrail: by default, refuse to disable ALL provided ports in any scenario
if(-not $AllowAllPathsDown){
  # Single port is always fine (assuming you provided >1 total paths in the system)
  # Single HBA disables 2 ports; OK if you have other ports beyond those
  if($DoSingleHba){
    $idx = $SingleHbaPortIndexes | Sort-Object -Unique
    if($idx.Count -ge $HbaPortInstanceIds.Count){
      throw "Refusing: Single-HBA selection would disable all provided ports. Add more ports to -HbaPortInstanceIds OR set -AllowAllPathsDown (not recommended)."
    }
  }
}

Capture-Evidence -RunFolder $run -Suffix "before"

try {
  if($DoSinglePort){
    $id = $HbaPortInstanceIds[$SinglePortIndex]
    Write-LineCsv $csv "DisableSinglePort" $id (Disable-Dev $id $method) "Method=$method; Sleep=${DisableSeconds_SinglePort}s"
    Start-Sleep -Seconds $DisableSeconds_SinglePort
    Write-LineCsv $csv "EnableSinglePort"  $id (Enable-Dev  $id $method) "Method=$method; Settle=${SettleSeconds_AfterEnable}s"
    Start-Sleep -Seconds $SettleSeconds_AfterEnable
  }

  if($DoSingleHba){
    $ids = @()
    foreach($i in $SingleHbaPortIndexes){
      $ids += $HbaPortInstanceIds[$i]
    }

    foreach($id in $ids){
      Write-LineCsv $csv "DisableSingleHbaPort" $id (Disable-Dev $id $method) "Method=$method"
    }

    Start-Sleep -Seconds $DisableSeconds_SingleHba

    foreach($id in $ids){
      Write-LineCsv $csv "EnableSingleHbaPort" $id (Enable-Dev $id $method) "Method=$method"
    }

    Start-Sleep -Seconds $SettleSeconds_AfterEnable
  }
}
finally {
  # Always attempt to re-enable anything we were told about
  foreach($id in $HbaPortInstanceIds){
    try { Enable-Dev $id $method | Out-Null } catch {}
  }
  Capture-Evidence -RunFolder $run -Suffix "after"
  Write-Host "Run folder: $run"
  Write-Host "Actions CSV: $csv"
}
