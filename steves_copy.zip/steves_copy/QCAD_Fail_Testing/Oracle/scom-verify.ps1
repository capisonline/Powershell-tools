. .\_qcad.common.ps1

<#
Purpose: Snapshot SCOM alerts around test windows and verify required monitors are enabled.
Requires: OperationsManager PS module on a box with SCOM console or SDK access.
#>

param(
  [string]$ScomServer = "scom.mgmt.local",
  [string[]]$ExpectedRules = @(
    'MPIO path failed','Storport 129','NIC link down','Cluster eviction','RAC interconnect down'
  ),
  [int]$LookbackMinutes = 30
)

$run = New-RunFolder "scom"
$alertsCsv = Join-Path $run "scom-alerts.csv"
try { Import-Module OperationsManager -ErrorAction Stop; New-SCOMManagementGroupConnection -ComputerName $ScomServer -ErrorAction Stop } catch { Write-Warning $_ }

$since = (Get-Date).AddMinutes(-$LookbackMinutes)
if(!(Test-Path $alertsCsv)){"When,Severity,Name,Source,Path,Owner,ResolutionState" | Out-File $alertsCsv}
try{
  $alerts = Get-SCOMAlert -Criteria "TimeRaised >= '$($since.ToUniversalTime().ToString('o'))'"
  foreach($a in $alerts){
    "$($a.TimeRaised),$($a.Severity),$($a.Name),$($a.MonitoringObjectDisplayName),$($a.MonitoringObjectPath),$($a.Owner),$($a.ResolutionState)" | Add-Content $alertsCsv
  }
} catch { Write-Warning $_ }

$presence = foreach($rule in $ExpectedRules){
  [pscustomobject]@{ Rule=$rule; Seen= (Select-String -Path $alertsCsv -Pattern $rule -Quiet) }
}
$presence | Export-Csv -NoTypeInformation -Path (Join-Path $run 'expected-rule-presence.csv')
