. .\_qcad.common.ps1

<#
Purpose: Apply bounded CPU/RAM load for a fixed window; exit on timebox.
#>

param(
  [int]$TargetCpuPercent = 70,
  [int]$TargetRamPercent = 40,
  [int]$DurationSeconds = 300
)

$run   = New-RunFolder "host-stress"
$log   = Join-Path $run 'host-stress.csv'
if(!(Test-Path $log)){"Timestamp,CPUWorkers,RamMB,Note" | Out-File $log}

# CPU workers sized from logical cores
$cores = [Environment]::ProcessorCount
$workers = [math]::Max([math]::Floor($cores * ($TargetCpuPercent/100)),1)

# RAM target in MB
$phys = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1MB
$targetRamMB = [int]($phys * ($TargetRamPercent/100))

$ramBlocks = New-Object System.Collections.Generic.List[byte[]]

$jobs = for($i=1;$i -le $workers;$i++){
  Start-Job -ScriptBlock {
    while($true){
      $t=[Diagnostics.Stopwatch]::StartNew(); while($t.ElapsedMilliseconds -lt 80){}; Start-Sleep -Milliseconds 20
    }
  }
}

try{
  # Allocate RAM in 64MB blocks up to target
  $block = 64MB
  while(($ramBlocks | Measure-Object Length -Sum).Sum -lt $targetRamMB*1MB){ $ramBlocks.Add( New-Object byte[] ($block) ) | Out-Null }
  Write-Log $log 'INFO' "Started $workers CPU workers; Allocated $targetRamMB MB"
  Start-Sleep -Seconds $DurationSeconds
}
finally{
  $jobs | Remove-Job -Force
  $ramBlocks.Clear(); [GC]::Collect(); [GC]::WaitForPendingFinalizers()
  Write-Log $log 'INFO' 'Released load and memory'
}
