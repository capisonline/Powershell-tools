. .\_qcad.common.ps1

<#
Purpose: Toggle FC HBA ports using built-in pnputil to simulate path loss.
Scenarios: single-port loss; single-HBA loss; ALL paths down (VT only, ≤120s).
#>

param(
  [string[]]$HbaInstanceIds = @(
    # Populate with real Instance IDs from Get-PnpDevice
  ),
  [int]$AllPathsDownSeconds = 110,
  [switch]$DoSinglePort,
  [switch]$DoSingleHba,
  [switch]$DoAllPathsDown
)

$run = New-RunFolder "mpio"
$log = Join-Path $run 'mpio.csv'
if(!(Test-Path $log)){"Timestamp,Action,InstanceId,ExitCode" | Out-File $log}

function Disable-Dev([string]$Id){
  $p = Start-Process -FilePath pnputil.exe -ArgumentList @('/disable-device',$Id) -Wait -PassThru -WindowStyle Hidden
  Write-Log $log 'WARN' "Disabled $Id (exit $($p.ExitCode))" | Out-Null
}
function Enable-Dev([string]$Id){
  $p = Start-Process -FilePath pnputil.exe -ArgumentList @('/enable-device',$Id) -Wait -PassThru -WindowStyle Hidden
  Write-Log $log 'INFO' "Enabled $Id (exit $($p.ExitCode))" | Out-Null
}

# Baseline mpclaim
try{ mpclaim.exe -v > (Join-Path $run 'mpclaim_before.txt') } catch {}

if($DoSinglePort -and $HbaInstanceIds.Count -ge 1){
  Disable-Dev $HbaInstanceIds[0]; Start-Sleep 30; Enable-Dev $HbaInstanceIds[0]
}

if($DoSingleHba -and $HbaInstanceIds.Count -ge 2){
  # Assume pairs [0,1] belong to HBA-A; adjust mapping to your host
  Disable-Dev $HbaInstanceIds[0]; Disable-Dev $HbaInstanceIds[1]
  Start-Sleep 60
  Enable-Dev $HbaInstanceIds[0];  Enable-Dev $HbaInstanceIds[1]
}

if($DoAllPathsDown){
  if($HbaInstanceIds.Count -lt 2){ throw 'Need at least two FC ports to drop all paths' }
  Invoke-Timeboxed -Seconds $AllPathsDownSeconds -Body {
    foreach($id in $HbaInstanceIds){ Disable-Dev $id }
    Start-Sleep -Seconds ($AllPathsDownSeconds - 5)
  } -Finally {
    foreach($id in $HbaInstanceIds){ Enable-Dev $id }
  }
}

try{ mpclaim.exe -v > (Join-Path $run 'mpclaim_after.txt') } catch {}
