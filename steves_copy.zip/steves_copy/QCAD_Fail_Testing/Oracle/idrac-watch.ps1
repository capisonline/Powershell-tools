. .\_qcad.common.ps1

<#
Purpose: Poll iDRAC Redfish for health/thermals/power/storage/NIC + gather new Lifecycle/SEL events.
Screenshots: Prompts operator to capture web UI images at T0 / Fault / Recovery.
#>

param(
  [string]$IdracHost = "idrac-hostname-or-ip",
  [string]$IdracUser = "root",
  [string]$IdracPass = "REDACTED",
  [int]$IntervalSeconds = $IdlePollSeconds,
  [int]$DurationSeconds = 300,
  [switch]$DuringFault
)

$run = New-RunFolder "idrac-$IdracHost"
$healthCsv = Join-Path $run "idrac_health.csv"
if(!(Test-Path $healthCsv)){"Timestamp,Overall,PowerState,CPU,Memory,Storage,Network,PSURedundancy,AvgInletTempC" | Out-File $healthCsv}

$baseUri = "https://$IdracHost/redfish/v1"
$cred = New-Object System.Management.Automation.PSCredential($IdracUser,(ConvertTo-SecureString $IdracPass -AsPlainText -Force))

function Get-Redfish($path){
  Invoke-RestMethod -Uri "$baseUri$path" -Credential $cred -Authentication Basic -SkipCertificateCheck -Method Get -TimeoutSec 10
}

$phase = if($DuringFault){'FAULT'} else {'BASELINE'}
Write-Host "Please capture iDRAC web UI screenshots now ($phase). Press Enter to continue..." -ForegroundColor Yellow
[void][System.Console]::ReadLine()

$end=(Get-Date).AddSeconds($DurationSeconds)
while((Get-Date) -lt $end){
  try{
    $sys = Get-Redfish '/Systems/System.Embedded.1'
    $pwr = Get-Redfish '/Chassis/System.Embedded.1/Power'
    $thr = Get-Redfish '/Chassis/System.Embedded.1/Thermal'

    $overall = $sys.Status.Health
    $cpu     = $sys.Processors.Status.Health
    $mem     = $sys.Memory.Status.Health
    $net     = ($sys.EthernetInterfaces.'@odata.count')
    $stor    = (Get-Redfish '/Systems/System.Embedded.1/Storage').'Members@odata.count'
    $psuRed  = ($pwr.PowerSupplies | Select-Object -First 1).RedundancyStatus
    $avgInlet = ($thr.Temperatures | Where-Object Name -match 'Inlet' | Select-Object -ExpandProperty ReadingCelsius -ErrorAction SilentlyContinue | Measure-Object -Average).Average

    "$((Get-Date).ToString($TimeFormat)),$overall,$($sys.PowerState),$cpu,$mem,$stor,$net,$psuRed,$avgInlet" | Add-Content $healthCsv
  } catch { Write-Host "Redfish read failed: $($_.Exception.Message)" -ForegroundColor Red }
  Start-Sleep -Seconds $IntervalSeconds
}

Write-Host "Please capture iDRAC web UI screenshots now (RECOVERY). Press Enter to finish..." -ForegroundColor Yellow
[void][System.Console]::ReadLine()
