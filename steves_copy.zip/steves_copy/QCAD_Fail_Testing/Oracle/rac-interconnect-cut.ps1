. .\_qcad.common.ps1

<#
Purpose: Disable the RAC interconnect adapter on ONE node for a strict window; restore.
Use with care—expected eviction on this node.
#>

param(
  [string]$InterconnectAdapterName = "Ethernet-Interconnect",
  [int]$DownSeconds = 90
)

$run = New-RunFolder "rac-ic"
$log = Join-Path $run 'rac-ic.csv'
if(!(Test-Path $log)){"Timestamp,Action,Adapter,Result" | Out-File $log}

try{
  Write-Log $log 'WARN' "Disabling interconnect $InterconnectAdapterName"
  Disable-NetAdapter -Name $InterconnectAdapterName -Confirm:$false
  Start-Sleep -Seconds $DownSeconds
}
finally{
  Enable-NetAdapter -Name $InterconnectAdapterName -Confirm:$false
  Write-Log $log 'INFO' "Re-enabled interconnect $InterconnectAdapterName"
}
