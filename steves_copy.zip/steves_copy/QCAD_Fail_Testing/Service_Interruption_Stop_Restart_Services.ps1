﻿# PowerShell Script: Stop/Restart Critical Services Across Servers
$Servers = Get-Content "C:\temp\QCAD\VT\Fail_Testing\VT_fail-testing_list.txt" # List of target servers
$Services = @("MSMQ", "MSSQLSERVER", "W3SVC")  # List of critical services
$LogFile = "C:\temp\QCAD\VT\Fail_Testing\ServiceInterruptTest.log"

foreach ($Server in $Servers) {
    foreach ($Service in $Services) {
        Write-Host "Stopping $Service on $Server ..." -ForegroundColor Yellow
        Invoke-Command -ComputerName $Server -ScriptBlock {
            Stop-Service -Name $using:Service -Force
        } -Credential (Get-Credential)

        Start-Sleep -Seconds 50  # Wait before restarting

        Write-Host "Restarting $Service on $Server ..." -ForegroundColor Cyan
        Invoke-Command -ComputerName $Server -ScriptBlock {
            Start-Service -Name $using:Service
        } -Credential (Get-Credential)

        # Log results
        "[$(Get-Date)] $Service restarted successfully on $Server." | Out-File -Append $LogFile
    }
}
