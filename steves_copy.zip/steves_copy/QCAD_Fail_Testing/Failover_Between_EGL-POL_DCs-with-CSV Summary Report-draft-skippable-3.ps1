﻿<#
.SYNOPSIS
    Automates QCAD application-level disaster recovery failover between the EGL and POL datacentres,
    including promoting the VAS master, restarting dependent services, updating DFS shares and AAS config,
    and cleanly shutting down services in the source (old) datacentre.

.DESCRIPTION
    This script performs an orchestrated failover of the QCAD application tier from one datacentre (EGL or POL) 
    to the other, aligning with QCAD DR Plan section 3.2.2.2. It:

    - Stops the Arbitrator and key Vision services in the source DC
    - Prompts manual promotion of the new VAS master
    - Starts services in the target DC
    - Syncs and updates DFS shares
    - Updates AAS config to reference the new APL server
    - Shuts down all remaining services in the old DC
    - Disables Arbitrator and FCS to prevent split-brain scenarios
    - Provides manual reminder to offline servers in F5 load balancers

    Supports dry-run (test mode) for validation and change control sign-off.

    Detailed logs (TXT) and structured output (CSV) are generated for audit/compliance tracking.

.PARAMETER TargetDC
    The destination datacentre to switch QCAD to. Accepts only 'EGL' or 'POL'.

.PARAMETER TestMode
    Simulates all actions without making any changes. Use this to validate logic before live failover.

.PARAMETER SkipVAS
    Skips Vision Application Server (VAS) actions (stop/start, DFS sync, master promotion prompt).

.PARAMETER SkipVWS
    Skips Vision Web Server (VWS) actions (stop/start, IIS reset).

.PARAMETER SkipVCS
    Skips Vision Client Service (VCS) server actions (stop/start, IIS reset).

.PARAMETER SkipVIM
    Skips Vision Integration Module (VIM) server actions.

.PARAMETER SkipVMG
    Skips Vision Mobile Gateway (VMG) server actions.

.PARAMETER SkipAAS
    Skips updating the AAS server’s Web.config and IIS restart.

.EXAMPLE
    .\QCAD-Failover.ps1 -TargetDC POL

    Executes a full failover to the POL datacentre (live mode). 
    Restarts services, updates AAS and DFS, and shuts down old DC components.

.EXAMPLE
    .\QCAD-Failover.ps1 -TargetDC EGL -TestMode -SkipAAS -SkipVWS

    Simulates a failover to EGL without changing AAS or VWS servers. Outputs test logs only.

.NOTES
    Author: SteveR
    Last Updated: 2025-05-31
    DR Alignment: QCAD DR Plan Section 3.2.2.2 (Loss of Data Centre)
    Log Output:  C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_<timestamp>.txt
    CSV Report:  C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_<timestamp>.csv

    Manual Tasks:
        - Promote VAS Master when prompted
        - Confirm Oracle RAC switch (if applicable)
        - Force Offline old DC servers in F5 (optional: automate)
#>



##############################################
# 1. GLOBAL CONFIGURATION                    #
##############################################

param(
  [ValidateSet("EGL", "POL")] [string]$TargetDC,
  [switch]$TestMode,
  [switch]$SkipVAS,
  [switch]$SkipVWS,
  [switch]$SkipVCS,
  [switch]$SkipVIM,
  [switch]$SkipVMG,
  [switch]$SkipAAS
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmm"
$LogFile = "C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_POL-EGL\Failover_Log_$timestamp.txt"
$CsvLog = "C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_POL-EGL\Failover_Report_$timestamp.csv"
$CsvOutput = @()

# DFS Namespace changes with each environment IE: VT, PR etc.
$DFSNamespace = "\\PRDS.QLDPOL\\appdata\\VT\\QCAD"
$DFS_Shares = @(
  "OfficerDetails$",
  "VisionAudit$",
  "System_VisVT$",
  "New Version$"
)

$EGL = @{ 
    VAS = @("EGLVCADVASVT01", "EGLVCADVASVT02"); 
    VWS = @("EGLVCADVWSVT01", "EGLVCADVWSVT02", "EGLVCADVWSVT03", "EGLVCADVWSVT04"); 
    VCS = @("EGLVCADVCSVT01", "EGLVCADVCSVT02", "EGLVCADVCSVT03", "EGLVCADVCSVT04", "EGLVCADVCSVT05"); 
    VIM = @("EGLVCADVIMVT01", "EGLVCADVIMVT02"); 
    VMG = @("EGLVCADVMGVT01"); 
    APL = "EGLVCADAPLVT01" 
}

$POL = @{ 
    VAS = @("POLVCADVASVT03", "POLVCADVASVT04"); 
    VWS = @("POLVCADVWSVT05", "POLVCADVWSVT06", "POLVCADVWSVT07", "POLVCADVWSVT08"); 
    VCS = @("POLVCADVCSVT06", "POLVCADVCSVT07", "POLVCADVCSVT08", "POLVCADVCSVT09", "POLVCADVCSVT10"); 
    VIM = @("POLVCADVIMVT03", "POLVCADVIMVT04"); 
    VMG = @("POLVCADVMGVT02"); 
  

# AAS Servers
$AAS = @{ EGL = "EGLVCADAASVT01"; POL = "POLVCADAASVT02" }

# Services to manage
$ServicesToStop = @(
    "Fortek.Services.Arbitrator",    # Step 1: Arbitrator service disabled on VAS during failover
    "Fortek.FCS",                    # Step 3: FCS service disabled to prevent auto-start
    "VisVT_VDW",                     # Step 10: Restarted to recreate Oracle connections
    "RabbitMQ",                      # Step 16: Only on VAS05 - stop during failover
    "W3SVC",                         # Step 11: Restarted on VWS/VCS for Oracle reconnect
    #"CCCM",                          # Step 19: Disable CCCM on old VCS
    "VisionService",                 # General Vision application services
    "ExternalClientGateway"          # Step 20: VMG - ECG service for QTasks
)
$ServicesToStart = @(
    "VisVT_VDW",                     # Step 10: Oracle reconnect after master switch
    "W3SVC",                         # Step 11: IIS restart on VWS/VCS
    #"CCCM",                          # Only if CCCM needed on new VCS
    "VisionService",                 # Vision application services
    "ExternalClientGateway"          # VMG ECG connectivity
)

$Old = if ($TargetDC -eq 'EGL') { $POL } else { $EGL }
$New = if ($TargetDC -eq 'EGL') { $EGL } else { $POL }
$Master = $New.VAS[0]
$NewAPL = $New.APL
$CurrentAAS = $AAS[$TargetDC]

##############################################
# 2. FUNCTION DEFINITIONS                    #
##############################################

function Log-Action {
    param($Step, $Server, $Service, $Action, $IsTest)
    $line = "[$Step] $Action service '$Service' on $Server"
    if ($IsTest) { $line = "[TEST] $line" }
    Add-Content -Path $LogFile -Value $line
    $CsvOutput += [pscustomobject]@{
        Step     = $Step
        Server   = $Server
        Action   = $Action
        Service  = $Service
        TestMode = $IsTest
    }
}

function Control-Services {
    param(
        [ValidateSet("Start", "Stop")] [string]$Action,
        [string[]]$Servers,
        [string[]]$Services,
        [string]$Step,
        [bool]$TestMode
    )
    foreach ($Server in $Servers) {
        foreach ($Service in $Services) {
            if (![string]::IsNullOrWhiteSpace($Service)) {
                Log-Action -Step $Step -Server $Server -Service $Service -Action $Action -IsTest:$TestMode

                if (-not $TestMode) {
                    $result = Invoke-Command -ComputerName $Server -ScriptBlock {
                        param($svc, $cmd)
                        try {
                            $svcObj = Get-Service -Name $svc -ErrorAction Stop
                            if ($cmd -eq 'Start' -and $svcObj.Status -ne 'Running') {
                                Start-Service -Name $svc -ErrorAction Stop
                                return "STARTED: $svc"
                            } elseif ($cmd -eq 'Stop' -and $svcObj.Status -ne 'Stopped') {
                                Stop-Service -Name $svc -Force -ErrorAction Stop
                                return "STOPPED: $svc"
                            } else {
                                return "UNCHANGED: $svc is already $($svcObj.Status)"
                            }
                        } catch {
                            return "FAILED: $svc - $($_.Exception.Message)"
                        }
                    } -ArgumentList $Service, $Action

                    Write-Host "$Server :: $result"
                }
            }
        }
    }
}

function Restart-IIS {
    param($Servers, $Step, $TestMode)
    foreach ($Server in $Servers) {
        Log-Action -Step $Step -Server $Server -Service "IIS" -Action "Restart" -IsTest:$TestMode
        if (-not $TestMode) {
            Invoke-Command -ComputerName $Server -ScriptBlock { iisreset }
        }
    }
}

function Copy-DFS-Shares {
    param($Source, $Targets, $Shares, $Step, $TestMode)
    foreach ($Share in $Shares) {
        foreach ($Target in $Targets) {
            Log-Action -Step $Step -Server $Target -Service $Share -Action "Copy" -IsTest:$TestMode
            if (-not $TestMode) {
                robocopy "\\$Source\$Share" "\\$Target\$Share" /MIR /R:1 /W:5 /NFL /NDL /NP /LOG+:$LogFile
            }
        }
    }
}

function Set-DfsnTargets {
    param($NamespacePath, $EGLTarget, $POLTarget, $EnablePOL, $TestMode)

    $Preferred = if ($EnablePOL) { $POLTarget } else { $EGLTarget }
    $Disabled = if ($EnablePOL) { $EGLTarget } else { $POLTarget }

    $beforePreferred = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred).State
    $beforeDisabled = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled).State

    Log-Action "Step 13" $Preferred "DFS Target Before: $beforePreferred" "Enable" $TestMode
    Log-Action "Step 13" $Disabled "DFS Target Before: $beforeDisabled" "Disable" $TestMode

    if (-not $TestMode) {
        Set-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred -State Online
        Set-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled -State Offline
    }

    $afterPreferred = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred).State
    $afterDisabled = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled).State

    Log-Action "Step 13" $Preferred "DFS Target After: $afterPreferred" "Enable" $TestMode
    Log-Action "Step 13" $Disabled "DFS Target After: $afterDisabled" "Disable" $TestMode
}

##############################################
# 3. MAIN EXECUTION

# Step 1 – Stop Arbitrator before promoting
if (-not $SkipVAS) {
  Control-Services Stop $Old.VAS @("Fortek.Services.Arbitrator") "Step 1" $TestMode
}

Add-Content -Path $LogFile -Value "--- SWITCHING TO $TargetDC ---"
Write-Host "🟡 STOP: You must now promote VAS Master to $Master manually."
if (-not $TestMode) {
    do {
        $confirmation = Read-Host "Type 'yes' to confirm VAS promotion has been completed"
    } while ($confirmation -ne 'yes')
} else {
    Write-Host "[TEST] Skipping confirmation."
}

if (-not $SkipVAS) {
  Control-Services Stop $Old.VAS $ServicesToStop "Step 1/15–20" $TestMode
  Control-Services Start $New.VAS $ServicesToStart "Step 10" $TestMode
  Copy-DFS-Shares $Master ($New.VAS | Where-Object { $_ -ne $Master }) $DFS_Shares "Step 13" $TestMode

  foreach ($share in $DFS_Shares) {
    $EGLTarget = "\\EGLVCADVASVT01\$share"
    $POLTarget = "\\POLVCADVASVT03\$share"
    Set-DfsnTargets -NamespacePath "$DFSNamespace\$share" -EGLTarget $EGLTarget -POLTarget $POLTarget -EnablePOL:($TargetDC -eq 'POL') -TestMode:$TestMode
  }
}
if (-not $SkipVWS) {
  Control-Services Stop $Old.VWS $ServicesToStop "Step 15–20" $TestMode
  Control-Services Start $New.VWS $ServicesToStart "Step 11" $TestMode
  Restart-IIS $New.VWS "Step 11" $TestMode
}
if (-not $SkipVCS) {
  Control-Services Stop $Old.VCS $ServicesToStop "Step 15–20" $TestMode
  Control-Services Start $New.VCS $ServicesToStart "Step 11" $TestMode
  Restart-IIS $New.VCS "Step 11" $TestMode
}
if (-not $SkipVIM) {
  Control-Services Stop $Old.VIM $ServicesToStop "Step 15–20" $TestMode
  Control-Services Start $New.VIM $ServicesToStart "Step 12" $TestMode
}
if (-not $SkipVMG) {
  Control-Services Stop $Old.VMG $ServicesToStop "Step 20" $TestMode
  Control-Services Start $New.VMG $ServicesToStart "Step 7" $TestMode
}
if (-not $SkipAAS) {
  if ($TestMode) {
    Log-Action "Step 14" $CurrentAAS "Web.config" "Update APL to $NewAPL" $true
  } else {
    Log-Action "Step 14" $CurrentAAS "Web.config" "Update APL to $NewAPL" $false
    Invoke-Command -ComputerName $CurrentAAS -ScriptBlock {
      param($apl)
      $path = "C:\InetPub\wwwroot\ARL\Qps.Ast.Arl.LocationForwardService\Web.config"
      (Get-Content $path) -replace "http://.*?/VisVT_MLSGateway/MlsGateway.asmx", "http://$apl/VisVT_MLSGateway/MlsGateway.asmx" | Set-Content $path
      iisreset
    } -ArgumentList $NewAPL
  }
}


##############################################
# 4. SHUTDOWN LOGIC FOR OLD DATACENTER       #
##############################################

Write-Host "Initiating shutdown of services on old Data Centre ($($Old.VAS[0].Substring(0,3)))..."

# Step A: Stop all services on all old servers (if not already stopped)
if (-not $SkipVAS) {
    Control-Services Stop $Old.VAS $ServicesToStop "Shutdown VAS" $TestMode
}
if (-not $SkipVWS) {
    Control-Services Stop $Old.VWS $ServicesToStop "Shutdown VWS" $TestMode
}
if (-not $SkipVCS) {
    Control-Services Stop $Old.VCS $ServicesToStop "Shutdown VCS" $TestMode
}
if (-not $SkipVIM) {
    Control-Services Stop $Old.VIM $ServicesToStop "Shutdown VIM" $TestMode
}
if (-not $SkipVMG) {
    Control-Services Stop $Old.VMG $ServicesToStop "Shutdown VMG" $TestMode
}

# Step B: Disable Arbitrator and FCS on old VAS
foreach ($Server in $Old.VAS) {
    foreach ($svc in @("Fortek.Services.Arbitrator", "Fortek.FCS")) {
        Log-Action -Step "Shutdown VAS Config" -Server $Server -Service $svc -Action "Disable" -IsTest:$TestMode
        if (-not $TestMode) {
            Invoke-Command -ComputerName $Server -ScriptBlock {
                param($svcName)
                Set-Service -Name $svcName -StartupType Disabled -ErrorAction SilentlyContinue
            } -ArgumentList $svc
        }
    }
}

# Step C: Optional — Force Offline old servers in F5 (manual or scripted via API if available)
Write-Host "Please ensure old servers are forced offline in F5 manually or via automation."


$CsvOutput | Export-Csv -Path $CsvLog -NoTypeInformation
Write-Host "\nFailover (or test) complete."
Write-Host "Log saved to: $LogFile"
Write-Host "CSV report saved to: $CsvLog"
