﻿# PowerShell Script: Inject Key Phrases into Logs for Failover Testing
# Maintains detailed script execution logging
# Author: [Your Name]
# Environment: Windows Server 2019

# Variables
$LogFiles = @("C:\Logs\AppLog1.log", "C:\Logs\AppLog2.log")  # Paths to target log files
$KeyPhrases = @(
    "[ERROR] Critical failure detected at $(Get-Date)",
    "[WARNING] Service disruption observed at $(Get-Date)",
    "[DEBUG] Performance degradation noted at $(Get-Date)"
)  # Add key phrases dynamically
$ScriptLogFile = "C:\Logs\LogInjectionScript.log"  # Path for script execution logging
$DebugRetention = 50  # Retains last 50 lines of existing logs before injecting new entries

# Function: Write to Script Log
function Write-ScriptLog {
    param (
        [string]$Message,
        [string]$Level = "INFO"
    )
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] [$Level] $Message"
    Add-Content -Path $ScriptLogFile -Value $LogEntry
    Write-Host $LogEntry -ForegroundColor Cyan
}

# Function: Inject Key Phrases into Logs
function Inject-LogEntries {
    param (
        [string]$LogFile
    )
    
    if (Test-Path $LogFile) {
        Write-ScriptLog "Processing log file: $LogFile"

        # Read existing log content, keeping the last X lines
        $ExistingContent = Get-Content -Path $LogFile
        if ($ExistingContent.Count -gt $DebugRetention) {
            $ExistingContent = $ExistingContent | Select-Object -Last $DebugRetention
        }

        # Inject new key phrases
        foreach ($Phrase in $KeyPhrases) {
            $ExistingContent += $Phrase
            Write-ScriptLog "Injected key phrase into $LogFile: '$Phrase'"
        }

        # Overwrite the log file with modified content
        $ExistingContent | Set-Content -Path $LogFile -Force
        Write-ScriptLog "Injection complete for $LogFile"
    } else {
        Write-ScriptLog "ERROR: Log file $LogFile not found!" "ERROR"
    }
}

# Start of Script Execution
Write-ScriptLog "Starting Key Phrase Log Injection Script"

# Inject key phrases into each log file
foreach ($LogFile in $LogFiles) {
    Inject-LogEntries -LogFile $LogFile
}

Write-ScriptLog "Log injection script completed successfully."
