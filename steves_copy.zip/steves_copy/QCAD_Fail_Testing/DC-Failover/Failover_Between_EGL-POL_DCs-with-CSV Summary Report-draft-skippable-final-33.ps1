﻿<#
.SYNOPSIS
    Automates QCAD application-level disaster recovery failover between the EGL and POL datacentres,
    including promoting the VAS master, restarting dependent services, updating DFS shares and AAS config,
    and cleanly shutting down services in the source (old) datacentre.

.DESCRIPTION
    This script performs an orchestrated failover of the QCAD application tier from one datacentre (EGL or POL) 
    to the other, aligning with QCAD DR Plan section 3.2.2.2. It:

    - Stops the Arbitrator and key Vision services in the source DC
    - Prompts manual promotion of the new VAS master
    - Starts services in the target DC in dependency order
    - Syncs and updates DFS shares
    - Updates AAS config to reference the new APL server
    - Optionally shuts down all remaining services in the old DC (in reverse order)
    - Disables Arbitrator and FCS to prevent split-brain scenarios
    - Provides manual reminder to offline servers in F5 load balancers

    Supports dry-run (test mode) for validation and change control sign-off.

    Detailed logs (TXT) and structured output (CSV) are generated for audit/compliance tracking.

.PARAMETER TargetDC
    The destination datacentre to switch QCAD to. Accepts only 'EGL' or 'POL'.

.PARAMETER TestMode
    Simulates all actions without making any changes. Use this to validate logic before live failover.

.PARAMETER SkipVAS
    Skips Vision Application Server (VAS) actions (stop/start, DFS sync, master promotion prompt).

.PARAMETER SkipVWS
    Skips Vision Web Server (VWS) actions (stop/start, IIS reset).

.PARAMETER SkipVCS
    Skips Vision Client Service (VCS) server actions (stop/start, IIS reset).

.PARAMETER SkipVIM
    Skips Vision Integration Module (VIM) server actions.

.PARAMETER SkipVMG
    Skips Vision Mobile Gateway (VMG) server actions.

.PARAMETER SkipAAS
    Skips updating the AAS server’s Web.config and IIS restart.

.PARAMETER SkipShutdown
    Skips the full shutdown of services in the old datacentre after failover.

.EXAMPLE
    .\QCAD-Failover.ps1 -TargetDC POL

    Executes a full failover to the POL datacentre (live mode). 
    Restarts services, updates AAS and DFS, and shuts down old DC components.

.EXAMPLE
    .\QCAD-Failover.ps1 -TargetDC EGL -TestMode -SkipAAS -SkipVWS -SkipShutdown

    Simulates a failover to EGL without touching AAS/VWS or performing any shutdown in the old DC. Outputs test logs only.

.NOTES
    Author: SteveR
    Last Updated: 2025-05-31
    DR Alignment: QCAD DR Plan Section 3.2.2.2 (Loss of Data Centre)
    Log Output:  C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_<timestamp>.txt
    CSV Report:  C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_<timestamp>.csv

    Manual Tasks:
        - Promote VAS Master when prompted
        - Confirm Oracle RAC switch (if applicable)
        - Force Offline old DC servers in F5 (optional: automate)
#>


param(
  [ValidateSet("EGL", "POL")] [string]$TargetDC,
  [switch]$TestMode,
  [switch]$SkipVAS,
  [switch]$SkipVWS,
  [switch]$SkipVCS,
  [switch]$SkipVIM,
  [switch]$SkipVMG,
  [switch]$SkipAAS,
  [switch]$SkipDFS,
  [switch]$SkipNamespaceUpdate,
  [switch]$SkipShutdown
)
# This $EnvironmentName is used because I copied the info from other scripts / csv's
$EnvironmentName = "VT"

$timestamp = Get-Date -Format "yyyyMMdd_HHmm"
$LogFile = "C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_${TargetDC}\Failover_Log_${timestamp}.txt"
$CsvLog = "C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_${TargetDC}\Failover_Report_${timestamp}.csv"
$CsvOutput = @()

$logDir = Split-Path $LogFile
if (-not (Test-Path $logDir)) {
    New-Item -Path $logDir -ItemType Directory -Force | Out-Null
}

$EnvironmentName = "VT"

$EGL = @{ 
    VAS = @("EGLVCADVASVT01", "EGLVCADVASVT02"); 
    VWS = @("EGLVCADVWSVT01", "EGLVCADVWSVT02", "EGLVCADVWSVT03", "EGLVCADVWSVT04"); 
    VCS = @("EGLVCADVCSVT01", "EGLVCADVCSVT02", "EGLVCADVCSVT03", "EGLVCADVCSVT04", "EGLVCADVCSVT05"); 
    VIM = @("EGLVCADVIMVT01", "EGLVCADVIMVT02"); 
    VMG = @("EGLVCADVMGVT01"); 
    APL = "EGLVCADAPLVT01" 
}

$POL = @{ 
    VAS = @("POLVCADVASVT03", "POLVCADVASVT04"); 
    VWS = @("POLVCADVWSVT05", "POLVCADVWSVT06", "POLVCADVWSVT07", "POLVCADVWSVT08"); 
    VCS = @("POLVCADVCSVT06", "POLVCADVCSVT07", "POLVCADVCSVT08", "POLVCADVCSVT09", "POLVCADVCSVT10"); 
    VIM = @("POLVCADVIMVT03", "POLVCADVIMVT04"); 
    VMG = @("POLVCADVMGVT02"); 
    APL = "POLVCADAPLVT01" 
}

$AAS = @{ EGL = "EGLVCADAASVT01"; POL = "POLVCADAASVT02" }

$MasterRoles = @{
    EGL = @("EGLVCADVASVT01")
    POL = @("POLVCADVASVT03")
}
$Old = if ($TargetDC -eq 'EGL') { $POL } else { $EGL }
$New = if ($TargetDC -eq 'EGL') { $EGL } else { $POL }
$Master = $New.VAS[0]
$NewAPL = $New.APL
$CurrentAAS = $AAS[$TargetDC]
$MasterServers = $MasterRoles[$TargetDC]

$ServiceStartupOrder = @{
    VAS = @("VisVT_VSCM", "VisVT_NumberCruncher", 
            "VisVT_DataService_Svr", "VisVT_FortekCoreService", 
            "VisVT_IntegrityChecker", "VisVT_CNI", 
            "VisVT_EventProcessor", "VisVT_ExternalClientGateway", 
            "VisVT_MessageBroker", "VisVT_VCS", 
            "VisVT_VDW")
    VAS_MasterOnly = @("VisVT_Arbitrator", "RabbitMQ", 
                       "VisVT_ICEMS_Messenger", "VisVT_ICEMS_Processor")
    VCS = @("VisVT_CCCM", "VisVT_VCS")
    VIM = @("VisVT_ARL", "VisVT_Audit", 
            "VisVT_Occurrence", "VisVT_OfficerDetail", 
            "VisVT_PoliceLinkVIM")
    VMG = @("VisVT_ExternalClientGateway")
}

$ServiceShutdownOrder = @{ VAS = [System.Collections.ArrayList]::new($ServiceStartupOrder.VAS); VCS = [System.Collections.ArrayList]::new($ServiceStartupOrder.VCS); VIM = [System.Collections.ArrayList]::new($ServiceStartupOrder.VIM); VMG = [System.Collections.ArrayList]::new($ServiceStartupOrder.VMG) }
$ServiceShutdownOrder.Values | ForEach-Object { $_.Reverse() }

$DFSNamespace = "\\PRDS.QLDPOL\\appdata\\VT\\QCAD"
$DFS_Shares = @("OfficerDetails$", "VisionAudit$", "System_VisVT$", "New Version$")

function Log-Action {
    param(
        [string]$Step,
        [string]$Server,
        [string]$Service,
        [string]$Action,
        [bool]$IsTest
    )
    $prefix = if ($IsTest) { "[TEST]" } else { "" }
    $line = "$prefix [$Step] $Action service '$Service' on $Server"
    Write-Host $line
    Add-Content -Path $LogFile -Value $line
    $CsvOutput += [pscustomobject]@{
        Step     = $Step
        Server   = $Server
        Action   = $Action
        Service  = $Service
        TestMode = $IsTest
    }
}

function Control-Services {
    param(
        [ValidateSet("Start", "Stop", "Restart")] [string]$Action,
        [string[]]$Servers,
        [string[]]$Services,
        [string]$Step,
        [bool]$TestMode
    )
    foreach ($Server in $Servers) {
        foreach ($Service in $Services) {
            if (![string]::IsNullOrWhiteSpace($Service)) {
                Log-Action -Step $Step -Server $Server -Service $Service -Action $Action -IsTest:$TestMode

                if (-not $TestMode) {
                    $result = Invoke-Command -ComputerName $Server -ScriptBlock {
                        param($svc, $cmd)
                        try {
                            $svcObj = Get-Service -Name $svc -ErrorAction Stop

                            switch ($cmd) {
                                'Start' {
                                    if ($svcObj.Status -ne 'Running') {
                                        Start-Service -Name $svc -ErrorAction Stop
                                        return "STARTED: $svc"
                                    } else {
                                        return "UNCHANGED: $svc already running"
                                    }
                                }
                                'Stop' {
                                    if ($svcObj.Status -ne 'Stopped') {
                                        Stop-Service -Name $svc -Force -ErrorAction Stop
                                        return "STOPPED: $svc"
                                    } else {
                                        return "UNCHANGED: $svc already stopped"
                                    }
                                }
                                'Restart' {
                                    Stop-Service -Name $svc -Force -ErrorAction Stop
                                    Start-Sleep -Seconds 2
                                    Start-Service -Name $svc -ErrorAction Stop
                                    return "RESTARTED: $svc"
                                }
                            }
                        } catch {
                            return "FAILED: $svc - $($_.Exception.Message)"
                        }
                    } -ArgumentList $Service, $Action

                    Write-Host "$Server :: $result"
                }
            }
        }
    }
}

function Restart-IIS {
    param($Servers, $Step, $TestMode)
    foreach ($Server in $Servers) {
        Log-Action -Step $Step -Server $Server -Service "IIS" -Action "Reset" -IsTest:$TestMode
        if (-not $TestMode) {
            Invoke-Command -ComputerName $Server -ScriptBlock { iisreset }
        }
    }
}

function Copy-DFS-Shares {
    param(
        [string]$Source,
        [string[]]$Targets,
        [string[]]$Shares,
        [string]$Step,
        [bool]$TestMode,
        [bool]$SkipDFS = $false
    )

    if ($SkipDFS) {
        Write-Host "[INFO] Skipping DFS share copy (Copy-DFS-Shares) due to SkipDFS flag."
        return
    }

    foreach ($Share in $Shares) {
        foreach ($Target in $Targets) {
            Log-Action -Step $Step -Server $Target -Service $Share -Action "Copy" -IsTest:$TestMode
            if (-not $TestMode) {
                robocopy "\\$Source\$Share" "\\$Target\$Share" /MIR /R:1 /W:5 /NFL /NDL /NP /LOG+:$LogFile
            }
        }
    }
}


function Set-DfsnTargets {
    param(
        [string]$NamespacePath,
        [string]$EGLTarget,
        [string]$POLTarget,
        [bool]$EnablePOL,
        [bool]$TestMode,
        [bool]$SkipNamespaceUpdate = $false
    )

    if ($SkipNamespaceUpdate) {
        Write-Host "[INFO] Skipping DFS namespace update (Set-DfsnTargets) due to SkipNamespaceUpdate flag."
        return
    }

    $Preferred = if ($EnablePOL) { $POLTarget } else { $EGLTarget }
    $Disabled = if ($EnablePOL) { $EGLTarget } else { $POLTarget }

    $beforePreferred = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred).State
    $beforeDisabled = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled).State

    Log-Action "Step 13" $Preferred "DFS Target Before: $beforePreferred" "Enable" $TestMode
    Log-Action "Step 13" $Disabled "DFS Target Before: $beforeDisabled" "Disable" $TestMode

    if (-not $TestMode) {
        Set-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred -State Online
        Set-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled -State Offline
    }

    $afterPreferred = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred).State
    $afterDisabled = (Get-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled).State

    Log-Action "Step 13" $Preferred "DFS Target After: $afterPreferred" "Enable" $TestMode
    Log-Action "Step 13" $Disabled "DFS Target After: $afterDisabled" "Disable" $TestMode
}


# === Failover Sequence ===
if (-not $SkipVAS) {
    Control-Services Stop $Old.VAS @("VisVT_Arbitrator") "Step 1" $TestMode
}

Write-Host "STOP: You must now promote VAS Master to $Master manually."
if (-not $TestMode) {
    do {
        $confirmation = Read-Host "Type 'yes' to confirm VAS promotion has been completed"
    } while ($confirmation -ne 'yes')
} else {
    Write-Host "[TEST] Skipping VAS promotion confirmation."
}

if (-not $SkipVAS) {
    Control-Services Stop $Old.VAS $ServiceShutdownOrder.VAS "Shutdown VAS" $TestMode
    Control-Services Restart $New.VAS $ServiceStartupOrder.VAS "Restart VAS" $TestMode
    Control-Services Restart $MasterServers $ServiceStartupOrder.VAS_MasterOnly "Restart VAS Master-Only" $TestMode
    Restart-IIS $New.VAS "Reset VAS IIS" $TestMode
}
if (-not $SkipVCS) {
    Control-Services Stop $Old.VCS $ServiceShutdownOrder.VCS "Shutdown VCS" $TestMode
    Control-Services Restart $New.VCS $ServiceStartupOrder.VCS "Restart VCS" $TestMode
    Restart-IIS $New.VCS "Reset VCS IIS" $TestMode
}
if (-not $SkipVIM) {
    Control-Services Stop $Old.VIM $ServiceShutdownOrder.VIM "Shutdown VIM" $TestMode
    Control-Services Restart $New.VIM $ServiceStartupOrder.VIM "Restart VIM" $TestMode
}
if (-not $SkipVMG) {
    Control-Services Stop $Old.VMG $ServiceShutdownOrder.VMG "Shutdown VMG" $TestMode
    Control-Services Restart $New.VMG $ServiceStartupOrder.VMG "Restart VMG" $TestMode
}


if (-not $SkipAAS) {
    if ($TestMode) {
        Log-Action "Step 14" $CurrentAAS "Web.config" "Update APL to $NewAPL" $true
    } else {
        Log-Action "Step 14" $CurrentAAS "Web.config" "Update APL to $NewAPL" $false
        Invoke-Command -ComputerName $CurrentAAS -ScriptBlock {
            param($apl)
            $path = "C:\InetPub\wwwroot\ARL\Qps.Ast.Arl.LocationForwardService\Web.config"
            (Get-Content $path) -replace "http://.*?/VisVT_MLSGateway/MlsGateway.asmx", "http://$apl/VisVT_MLSGateway/MlsGateway.asmx" | Set-Content $path
            iisreset
        } -ArgumentList $NewAPL
    }
}

if (-not $SkipShutdown) {
    Write-Host "Initiating shutdown of services on old Data Centre ($($Old.VAS[0].Substring(0,3)))..."

    if (-not $SkipVAS) {
        Control-Services Stop $Old.VAS $ServiceShutdownOrder.VAS "Shutdown VAS" $TestMode
    }
    if (-not $SkipVWS) {
        Control-Services Stop $Old.VWS $ServiceShutdownOrder.VAS "Shutdown VWS" $TestMode
    }
    if (-not $SkipVCS) {
        Control-Services Stop $Old.VCS $ServiceShutdownOrder.VCS "Shutdown VCS" $TestMode
    }
    if (-not $SkipVIM) {
        Control-Services Stop $Old.VIM $ServiceShutdownOrder.VIM "Shutdown VIM" $TestMode
    }
    if (-not $SkipVMG) {
        Control-Services Stop $Old.VMG $ServiceShutdownOrder.VMG "Shutdown VMG" $TestMode
    }

    foreach ($Server in $Old.VAS) {
        foreach ($svc in @("Fortek.Services.Arbitrator", "Fortek.FCS")) {
            Log-Action -Step "Shutdown VAS Config" -Server $Server -Service $svc -Action "Disable" -IsTest:$TestMode
            if (-not $TestMode) {
                Invoke-Command -ComputerName $Server -ScriptBlock {
                    param($svcName)
                    Set-Service -Name $svcName -StartupType Disabled -ErrorAction SilentlyContinue
                } -ArgumentList $svc
            }
        }
    }

    Write-Host "Please ensure old servers are forced offline in F5 manually or via automation."
} else {
    Write-Host "[INFO] Skipping shutdown of old datacentre services as per -SkipShutdown flag."
}

$CsvOutput | Export-Csv -Path $CsvLog -NoTypeInformation
Write-Host "`nFailover (or test) complete."
Write-Host "Log saved to: $LogFile"
Write-Host "CSV report saved to: $CsvLog"
