# ==========================
# Continuous Memory Monitor + Failover (looped)
# ==========================

# Ensure log/output folder exists
$workDir = "T:\Temp\MemLeak"
New-Item -ItemType Directory -Path $workDir -Force | Out-Null

# Log file path (constant)
$loggingPath = Join-Path $workDir "TriggerResult.txt"

# Simple logger
function Write-Log {
    param([string]$Message)
    $ts = Get-Date -Format "yyMMdd_HHmmss"
    "[{0}] {1}" -f $ts, $Message | Out-File -FilePath $loggingPath -Append -Encoding UTF8 -Force
}

while ($true) {
    try {
        # Get committed memory in bytes
        $committed = (Get-Counter '\Memory\Committed Bytes').CounterSamples[0].CookedValue

        # Get commit limit in bytes
        $commitLimit = (Get-Counter '\Memory\Commit Limit').CounterSamples[0].CookedValue

        # Convert to MB
        $committedMB = [math]::Round($committed / 1MB, 2)
        $commitLimitMB = [math]::Round($commitLimit / 1MB, 2)

        # Calculate Usage
        $usagePercentage = ($committedMB / $commitLimitMB) * 100

        # Round the result
        $usageRounded = [math]::Round($usagePercentage, 2)

        # Timestamp for this iteration (used in filenames/emails)
        $timestamp = Get-Date -Format "yyMMdd_HHmmss"

        # Format trigger result
        $triggerResult = "Committed Memory: $committedMB MB / $commitLimitMB MB , Approximately $usageRounded %"

        # Write Trigger check to file
        Write-Log $triggerResult

        If ($usagePercentage -gt 60) {

            # Define output path
            $wprResultPath = "T:\Temp\MemLeak\MemLeak_$timestamp.etl"

            # Define Email parameters
            $Recipients = "morris.matthewja@police.qld.gov.au,Rogers.Steven2@police.qld.gov.au"
            $smtpServer = "smtp.police.qld.gov.au"
            $from = "Release.Tracking@police.qld.gov.au"
            $to = $Recipients -split ','

            # Define SQL session
            $tsql = @"
IF EXISTS (SELECT * FROM sys.server_event_sessions WHERE name = 'MemoryMonitorSession')
    DROP EVENT SESSION MemoryMonitorSession ON SERVER;

CREATE EVENT SESSION MemoryMonitorSession ON SERVER
ADD EVENT sqlserver.memory_grant_updated_by_feedback,
ADD EVENT sqlserver.memory_grant_wait_begin
ADD TARGET package0.event_file (
    SET filename = N'T:\Temp\MemLeak\MemoryMonitorSession',
        max_file_size = 50, -- in MB
        max_rollover_files = 5
);

ALTER EVENT SESSION MemoryMonitorSession ON SERVER STATE = START;
"@

            # Start WPR in file mode with a basic profile
            $wprStart = Start-Process -FilePath "D:\Steve\Windows Performance Toolkit\wpr.exe" -ArgumentList "-start CPU Memory VirtualAlloc HeapUsage -filemode" -PassThru -WindowStyle Hidden

            # Start the SQL xEvents monitoring session
            Write-Log "Starting SQL Extended Events session 'MemoryMonitorSession'"
            Invoke-Sqlcmd -Query $tsql -ServerInstance "EGLVCADVASVT01\SQLEXPRESS"

            # Start a 13 minute sleep (allows for 2 qcad sync cycles)
            Write-Log "Sleeping 780s to capture context..."
            Start-Sleep -Seconds 780

            # Send alert of automated failover
            $subjectOF = "EGLVCADVASVT01 beginning automated failover due to memory leak"
            try {
                Send-MailMessage -From $from -To $to -Subject $subjectOF -Body "EGLVCADVASVT01 will not be accessible for ~30 minutes." -SmtpServer $smtpServer -Port 25
                Write-Log "Sent start-of-failover email."
            } catch {
                Write-Log "WARNING: Failed to send start email: $($_.Exception.Message)"
            }

            # Buffer to allow email to be sent
            Start-Sleep -Seconds 20

            # Disable NIC to isolate server
            Write-Log "Disabling NIC 'Core' to isolate server."
            Disable-NetAdapter -Name "Core" -Confirm:$false

            # Sleep to see if system stabilises after blocking external connections
            Write-Log "Sleeping 460s post NIC disable..."
            Start-Sleep -Seconds 460

            # Identify all vision services
            $visService = Get-Service | Where-Object { $_.Name -like "VisVT_*" }

            # Stop and disable all vision services
            foreach ($service in $visService) {
                try {
                    Write-Log "Stopping service: $($service.Name)"
                    Stop-Service -Name $service.Name -Force -ErrorAction SilentlyContinue
                    Write-Log "Disabling service: $($service.Name)"
                    Set-Service -Name $service.Name -StartupType Disabled
                } catch {
                    Write-Log "WARNING: Service action failed on $($service.Name): $($_.Exception.Message)"
                }
            }

            # Start a 17 minute sleep (allow for qcad failover to 2nd vas)
            Write-Log "Sleeping 460s to allow downstream failover..."
            Start-Sleep -Seconds 460

            # Stop the SQL xEvents monitoring session
            Write-Log "Stopping SQL Extended Events session 'MemoryMonitorSession'"
            Invoke-Sqlcmd -Query "ALTER EVENT SESSION [MemoryMonitorSession] ON SERVER STATE = STOP;" -ServerInstance "EGLVCADVASVT01\SQLEXPRESS"

            # Stop and save the trace
            Write-Log "Stopping WPR and saving to: $wprResultPath"
            $wprStop = Start-Process -FilePath "D:\Steve\Windows Performance Toolkit\wpr.exe" -ArgumentList ("-stop `"$wprResultPath`"") -PassThru -WindowStyle Hidden
            $wprStop | Wait-Process

            # Enable NIC to integrate server
            Write-Log "Re-enabling NIC 'Core'."
            Enable-NetAdapter -Name "Core" -Confirm:$false

            # Buffer
            Start-Sleep -Seconds 20

            # Send completion alert
            $subjectOL = "EGLVCADVASVT01 failover complete; capture saved"
            try {
                Send-MailMessage -From $from -To $to -Subject $subjectOL -Body "EGLVCADVASVT01 is back online and memory capture has been saved." -SmtpServer $smtpServer -Port 25
                Write-Log "Sent completion email."
            } catch {
                Write-Log "WARNING: Failed to send completion email: $($_.Exception.Message)"
            }
        }

    } catch {
        Write-Log "ERROR: $($_.Exception.Message)"
    }

    # Wait before next check
    Start-Sleep -Seconds 60
}
