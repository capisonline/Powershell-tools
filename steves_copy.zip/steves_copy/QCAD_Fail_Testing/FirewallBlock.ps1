﻿# this script creates a firewall "block" rule 
# Define ports to block (common for all servers)
$ports = @(80, 443, 3389)  # HTTP, HTTPS, RDP

# Log file location
$logFile = "C:\Logs\FirewallTest.log"
$firewallRulePrefix = "TestBlock"

# Get the local server name
$localServer = $env:COMPUTERNAME

# Ensure log directory exists
if (!(Test-Path (Split-Path $logFile))) { New-Item -ItemType Directory -Path (Split-Path $logFile) -Force }

function Write-Log {
    param ($message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp - $message" | Out-File -Append -FilePath $logFile
    Write-EventLog -LogName "Application" -Source "FirewallTest" -EventID 1001 -EntryType Information -Message $message -ErrorAction SilentlyContinue
}

function Block-Traffic {
    foreach ($port in $ports) {
        $ruleName = "$firewallRulePrefix-$localServer-$port"
        if (!(Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule -DisplayName $ruleName -Direction Outbound -Action Block -LocalPort $port -Protocol TCP
            Write-Log "Blocked port $port on $localServer (Rule: $ruleName)"
        } else {
            Write-Log "Rule already exists: $ruleName"
        }
    }
}

# Block traffic
Block-Traffic
