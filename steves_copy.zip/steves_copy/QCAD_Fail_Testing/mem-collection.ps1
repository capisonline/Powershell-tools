# Get committed memory in bytes
$committed = (Get-Counter '\Memory\Committed Bytes').CounterSamples[0].CookedValue

# Get commit limit in bytes
$commitLimit = (Get-Counter '\Memory\Commit Limit').CounterSamples[0].CookedValue

# Convert to MB
$committedMB = [math]::Round($committed / 1MB, 2)
$commitLimitMB = [math]::Round($commitLimit / 1MB, 2)

# Calculate Usage
$usagePercentage = ($committedMB / $commitLimitMB) * 100

# Round the result
$usageRounded = [math]::Round($usagePercentage, 2)

# Set Date format
$timestamp = Get-Date -Format "yyMMdd_HHmmss"

# Set logging path
$loggingPath = "T:\Temp\MemLeak\TriggerResult.txt"

# Format trigger result
$triggerResult = "[$timeStamp] - Committed Memory: $committedMB MB / $commitLimitMB MB , Approximately $usageRounded %"

# Write Trigger check to file
$triggerResult | Out-File -FilePath $loggingPath  -Append -Encoding UTF8 -Force

If ($usagePercentage -gt 60) {
    #Write-Warning "Memory usage is over 60%. Starting Windows Performance Recorder..."

    # Define output path
    $wprResultPath = "T:\Temp\MemLeak\MemLeak_$timestamp.etl"

    # Define Email parameters
    $Recipients = "morris.matthewja@police.qld.gov.au,Rogers.Steven2@police.qld.gov.au"
    $smtpServer = "smtp.police.qld.gov.au"
    $from = "Release.Tracking@police.qld.gov.au"
    $to = $Recipients -split ','

    # Define SQL session (includin logging location into E drive
    $tsql = @"
    IF EXISTS (SELECT * FROM sys.server_event_sessions WHERE name = 'MemoryMonitorSession')
        DROP EVENT SESSION MemoryMonitorSession ON SERVER;
    
    CREATE EVENT SESSION MemoryMonitorSession ON SERVER
    ADD EVENT sqlserver.memory_grant_updated_by_feedback,
    ADD EVENT sqlserver.memory_grant_wait_begin
    ADD TARGET package0.event_file (
        SET filename = N'T:\Temp\MemLeak\MemoryMonitorSession',
            max_file_size = 50, -- in MB
            max_rollover_files = 5
    );

    ALTER EVENT SESSION MemoryMonitorSession ON SERVER STATE = START;
"@

    # Start WPR in file mode with a basic profile
    Start-Process -FilePath "D:\Steve\Windows Performance Toolkit\wpr.exe" -ArgumentList "-start CPU Memory VirtualAlloc HeapUsage -filemode"

    # Start the SQL xEvents monitoring session
    Invoke-Sqlcmd -Query $tsql -ServerInstance "EGLVCADVASVT01\SQLEXPRESS"

    # Start a 13 minute sleep (allows for 2 qcad sync cycles)
    Start-Sleep -Seconds 780 

    # Send alert of automated failover
    $subjectOF = "EGLVCADVASVT01 is begining automated failover due to memory leak"
    Send-MailMessage -From $from -To $to -Subject $subjectOF -Body "EGLVCADVASVT01 will not be accessable for ~ 30 minutes" -SmtpServer $smtpServer -Port 25

    # Buffer to allow email to be sent
    Start-Sleep -Seconds 20

    # Disable NIC to isolate server
    Disable-NetAdapter -Name "Core" -Confirm:$false

    # Sleep to see if system stabalises after blocking external connections
    Start-Sleep -Seconds 460

    # Identify all vision services
    $visService = Get-Service | where-object {$_.name -like "VisVT_*"}

    # Stop and disable all vision services
    foreach ($service in $visService) {
        Set-Service -Name $service -Status Stopped -StartupType Disabled
    }

    # Start a 17 minute sleep (allow for qcad failover to 2nd vas)
    Start-Sleep -Seconds 460

    # Stop the SQL xEvents monitoring session
    Invoke-Sqlcmd -Query "ALTER EVENT SESSION [MemoryMonitorSession] ON SERVER STATE = STOP;" -ServerInstance "EGLVCADVASVT01\SQLEXPRESS"

    # Stop and save the trace
    Start-Process -FilePath "D:\Steve\Windows Performance Toolkit\wpr.exe" -ArgumentList "-stop $wprResultPath"

    # Enable NIC to integrate server
    Enable-NetAdapter -Name "Core" -Confirm:$false

    # Buffer to allow email to be sent
    Start-Sleep -Seconds 20

    # Send alert of automated failover
    $subjectOL = "EGLVCADVASVT01 is begining automated failover due to memory leak"
    Send-MailMessage -From $from -To $to -Subject $subjectOL -Body "EGLVCADVASVT01 is now back online and memory capture has been made" -SmtpServer $smtpServer -Port 25

}