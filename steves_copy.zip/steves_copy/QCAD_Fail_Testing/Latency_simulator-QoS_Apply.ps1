﻿<# PowerShell Script: Apply QoS Policy and Schedule Cleanup
# Author: Steven Rogers
# Environment: Windows Server 2019
Deploy Both Scripts

Place QoS_Apply.ps1 and QoS_Remove.ps1 in E:\Fail_Testing on all target servers.
Run QoS_Apply.ps1

Applies QoS policies.
Schedules QoS_Remove.ps1 to run after $DurationMinutes.
Exits immediately.
After $DurationMinutes, QoS_Remove.ps1 Runs Automatically

Removes the applied QoS policies.
Deletes itself from the task scheduler.
Logging

Actions are recorded in E:\Fail_Testing\QoS_Log.txt.




#> 




# Define Variables
$PolicyPrefix = "LatencySim_"  # Prefix for policy names
$IPProtocol = "TCP"  # Options: TCP or UDP
$Ports = @("1433", "1521", "3306", "5432")  # Modify this list as needed
$ThrottleRate = 1000000  # Bandwidth limit in bits per second (1 Mbps)
$NetworkProfile = "All"  # Options: Domain, Private, Public, All
$DurationMinutes = 10  # Duration before removal
$LogFile = "E:\Fail_Testing\QoS_Log.txt"  # Log file path
$CleanupScript = "E:\Fail_Testing\QoS_Remove.ps1"  # Cleanup script path
$TaskName = "QoS_Policy_Removal"

# Ensure the script runs as Admin
if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "This script must be run as an Administrator!" -ForegroundColor Red
    exit
}

Write-Host "Applying QoS policies..." -ForegroundColor Yellow

# Apply QoS Policies
foreach ($Port in $Ports) {
    $PolicyName = "$PolicyPrefix$Port"

    if (Get-NetQosPolicy | Where-Object { $_.Name -eq $PolicyName }) {
        Write-Host "QoS Policy '$PolicyName' already exists. Skipping..." -ForegroundColor Cyan
    } else {
        New-NetQosPolicy -Name $PolicyName `
            -IPProtocol $IPProtocol `
            -DestinationPortRange $Port `
            -ThrottleRateActionBitsPerSecond $ThrottleRate `
            -NetworkProfile $NetworkProfile
        
        Write-Host "QoS Policy '$PolicyName' applied successfully." -ForegroundColor Green
        "[$(Get-Date)] QoS Policy '$PolicyName' applied for port $Port with throttle rate $ThrottleRate bps" | Out-File -Append -FilePath $LogFile
    }
}

# Schedule Cleanup Task
$RunTime = (Get-Date).AddMinutes($DurationMinutes).ToString("HH:mm")
schtasks.exe /Create /SC ONCE /TN $TaskName /TR "powershell.exe -ExecutionPolicy Bypass -File $CleanupScript" /ST $RunTime /F

Write-Host "`nQoS policies will be removed in $DurationMinutes minutes..." -ForegroundColor Cyan
Write-Host "Scheduled Task '$TaskName' set to run at $RunTime" -ForegroundColor Green
"[$(Get-Date)] Scheduled cleanup task '$TaskName' to run at $RunTime" | Out-File -Append -FilePath $LogFile
