﻿<#
.SYNOPSIS
    Deploys a PowerShell script and a scheduled task to a list of remote servers.

.DESCRIPTION
    - Reads a list of target servers from `ServerList.txt`.
    - Copies a specified PowerShell script and an optional CSV file to each server.
    - Creates a scheduled task on each server to execute the script at a predefined time.
    - Ensures the task runs under SYSTEM for proper permissions.
    - Skips unreachable servers and logs the results.

.PARAMETER None
    No parameters required. The script reads configuration values from predefined variables.

.INPUTS
    - `ServerList.txt` (List of server hostnames, one per line)
    - `RestartServices.ps1` (Script to be deployed)
    - `ServiceRestartConfig.csv` (Optional CSV defining script behavior per server)

.OUTPUTS
    - The script and CSV are copied to each server.
    - A scheduled task named `RestartCriticalServices` is created on each server.
    - Deployment progress is logged in the console.

.NOTES
    - Ensure this script is run from a machine with administrative access to all target servers.
    - Modify `$TaskName`, `$ScriptSource`, and `$TriggerTime` to customize the deployment.
    - The task execution time is currently set to 2:00 AM but can be adjusted.

.EXAMPLE
    To deploy the script and create the scheduled task:
    ```
    PowerShell.exe -ExecutionPolicy Bypass -File C:\Scripts\DeployRestartTask.ps1
    ```

.LAST UPDATED
    2025-02-27 - Initial implementation with CSV-based execution and logging.
#>

# Define the script and CSV paths
$TaskName = "RestartCriticalServices"  # Change this for other scheduled tasks
$ScriptSource = "C:\Scripts\RestartServices.ps1"  # Change for other scripts
$CSVSource = "C:\Scripts\ServiceRestartConfig.csv"  # Optional, change as needed
$ServerList = "C:\Scripts\ServerList.txt"

# Define remote paths (destination on each server)
$RemoteScriptPath = "C$\Scripts\RestartServices.ps1"
$RemoteCSVPath = "C$\Scripts\ServiceRestartConfig.csv"

# Define execution time for the scheduled task (adjust as needed)
$TriggerTime = "02:00AM"  # Change for different execution times

# Read server list
$Servers = Get-Content -Path $ServerList

# Loop through each server
foreach ($Server in $Servers) {
    Write-Host "Deploying to $Server..."

    # Test if the server is online
    if (Test-Connection -ComputerName $Server -Count 2 -Quiet) {
        
        # Ensure remote Scripts folder exists
        Invoke-Command -ComputerName $Server -ScriptBlock {
            if (!(Test-Path "C:\Scripts")) {
                New-Item -ItemType Directory -Path "C:\Scripts" -Force | Out-Null
            }
        }

        # Copy script & CSV to remote server
        Copy-Item -Path $ScriptSource -Destination "\\$Server\$RemoteScriptPath" -Force
        Copy-Item -Path $CSVSource -Destination "\\$Server\$RemoteCSVPath" -Force

        # Create Scheduled Task on remote server
        Invoke-Command -ComputerName $Server -ScriptBlock {
            param ($TaskName, $ScriptPath, $TriggerTime)

            # Define task action
            $Action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-File $ScriptPath"
            
            # Define task trigger
            $Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date -Hour 2 -Minute 0)  # Adjust time if needed
            
            # Define execution account (SYSTEM)
            $Principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

            # Register the scheduled task
            $Task = New-ScheduledTask -Action $Action -Trigger $Trigger -Principal $Principal
            Register-ScheduledTask -TaskName $TaskName -InputObject $Task -Force

            Write-Host "Scheduled Task '$TaskName' created on $env:COMPUTERNAME"
        } -ArgumentList $TaskName, "C:\Scripts\RestartServices.ps1", $TriggerTime

        Write-Host
