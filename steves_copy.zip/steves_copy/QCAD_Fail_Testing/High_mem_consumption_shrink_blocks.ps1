﻿<#
<#
.SYNOPSIS
    High Memory Load Simulation (commit-aware, adaptive, OOM-resilient).

.DESCRIPTION
    Generates sustained, controlled memory pressure against the Windows COMMIT budget
    (Committed Bytes vs Commit Limit ≈ RAM + pagefile), not just physical RAM.
    Uses adaptive, small allocations with hysteresis to hover near a target % of Commit Limit,
    avoids one-step overshoot, and recovers gracefully from OutOfMemoryException.

    The script:
    - Takes atomic PDH snapshots of: %Committed, Committed Bytes, Commit Limit.
    - Computes headroom to a target % of Commit Limit and allocates only a small slice per step.
    - Shrinks block size and increases pacing as it approaches the ceiling (anti-overshoot).
    - Applies hysteresis: stop allocating at an upper band; resume only below a lower band.
    - Touches each 4KiB page to ensure commit; refreshes during HOLD to prevent trimming.
    - Catches OutOfMemoryException locally, sheds recent blocks, shrinks step, and continues.
    - Logs every action with timestamps and after-allocation snapshots.

.PARAMETER targetPercent
    Target % of Commit Limit to maintain (e.g., 70).

.PARAMETER stopPercent
    Upper hysteresis band. Allocation pauses when %Committed >= this value.

.PARAMETER resumePercent
    Lower hysteresis band. Allocation may resume when %Committed <= this value.

.PARAMETER startBlockMB
    Initial allocation chunk size in MB (auto-shrinks near the ceiling).

.PARAMETER minBlockMB
    Minimum chunk size in MB (lower bound for adaptive shrinking).

.PARAMETER maxBlockMB
    Maximum chunk size in MB (upper bound if you expand earlier in the ramp).

.PARAMETER allocationDelayMS
    Base delay between allocations (auto-increases near the ceiling).

.PARAMETER holdSeconds
    Duration of the HOLD phase where pressure is maintained.

.PARAMETER logIntervalSeconds
    Interval for logging/refresh during HOLD.

.NOTES
    Author   : Rogers.Steven2@police.qld.gov.au
    Purpose  : Safe, repeatable pressure for monitoring validation (SCOM, vCenter) and DR drills.
    Behavior : Commit-aware; prevents runaway to 99–100% by design; OOM-resilient.
    Logs     : D:\Failtesting\logs\HighMem_TestLog_<hostname>_<timestamp>.txt
    Tested On: Windows Server 2012 R2, 2019; PowerShell 5.1 (64-bit recommended).
    Prereqs  : Prefer system-managed pagefile; run in non-prod; ensure adequate headroom.

.WARNING
    Use ONLY in DEV/TEST or under a controlled window. This script can induce paging and latency.
    For QCAD contexts, never run on production CAD nodes. Validate rollback/runbooks first.

.EXAMPLE
    # Hover around 70% of Commit Limit with conservative bands
    # (Stop at 72%, resume at 66%), 32MB start blocks, 10s HOLD logging
    .\HighMemStress.ps1 `
      -targetPercent 70 -stopPercent 72 -resumePercent 66 `
      -startBlockMB 32 -minBlockMB 4 -maxBlockMB 128 `
      -allocationDelayMS 100 -holdSeconds 18000 -logIntervalSeconds 10

.EXAMPLE
    # Tighter ceiling for fragile hosts (WS2012/16GB): smaller blocks & wider hysteresis
    .\HighMemStress.ps1 `
      -targetPercent 65 -stopPercent 67 -resumePercent 60 `
      -startBlockMB 16 -minBlockMB 4 -maxBlockMB 64 `
      -allocationDelayMS 150 -holdSeconds 3600 -logIntervalSeconds 5

.EXAMPLE
    # Quick 15-minute validation run with verbose logs (good for Grafana/SCOM proof)
    .\HighMemStress.ps1 `
      -targetPercent 70 -stopPercent 72 -resumePercent 66 `
      -startBlockMB 32 -minBlockMB 8 -maxBlockMB 64 `
      -allocationDelayMS 100 -holdSeconds 900 -logIntervalSeconds 2
#>

#>

# === CONFIGURATION ===
$logDir             = "D:\Failtesting\logs"
$hostname           = $env:COMPUTERNAME
$timestamp          = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath            = Join-Path $logDir "HighMem_TestLog_${hostname}_$timestamp.txt"

# Target behavior (relative to Commit Limit)
$targetPercent      = 70           # Aim to hover around 70% of COMMIT LIMIT
$stopPercent        = 72           # Stop allocating when >= this (upper band)
$resumePercent      = 66           # Resume allocating only when <= this (lower band)  -> hysteresis

# Allocation behavior
$startBlockMB       = 32           # starting chunk size
$minBlockMB         = 4            # never go smaller than this
$maxBlockMB         = 128          # never go larger than this
$allocationDelayMS  = 100          # base delay between allocations
$holdSeconds        = 18000        # hold duration
$logIntervalSeconds = 10           # log/refresh interval during hold
$marginFractionStep = 0.10         # allocate at most 10% of remaining headroom per step

# OOM backoff
$oomReleaseBlocks   = 4            # shed this many blocks on OOM
$oomSleepMS         = 500          # brief pause after OOM before retry

# === LOG SETUP ===
if (!(Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
Add-Content $logPath "=== High Memory Test Started: $(Get-Date) ==="
Add-Content $logPath "Host: $hostname"
Add-Content $logPath "Target=$targetPercent%  Stop>=$stopPercent%  Resume<=$resumePercent% (of Commit Limit)"

# === HELPERS ===
function Get-MemorySnapshot {
    # single PDH snapshot for all three measurements (atomic for our purposes)
    $c = Get-Counter '\Memory\% Committed Bytes In Use','\Memory\Committed Bytes','\Memory\Commit Limit'
    $samples = $c.CounterSamples
    $pct  = ($samples | Where-Object Path -like '*% Committed Bytes In Use').CookedValue
    $comm = ($samples | Where-Object Path -like '*Committed Bytes').CookedValue
    $lim  = ($samples | Where-Object Path -like '*Commit Limit').CookedValue
    [pscustomobject]@{
        Timestamp       = $c.Timestamp
        Percent         = [double]$pct
        CommittedBytes  = [double]$comm
        CommitLimit     = [double]$lim
    }
}

function Touch-Block([byte[]]$block) {
    # Touch each 4KiB page so memory is actually committed and stays hot
    for ($j = 0; $j -lt $block.Length; $j += 4096) { $block[$j] = $block[$j] + 1 }
}

function Free-LastBlocks([System.Collections.Generic.List[object]]$list, [int]$count) {
    $released = 0L
    for ($i = 0; $i -lt $count; $i++) {
        if ($list.Count -gt 0) {
            $last = $list[$list.Count - 1]
            $released += $last.Length
            $list.RemoveAt($list.Count - 1)
        }
    }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    $released
}

# === RUNTIME STATE ===
$memBlocks        = New-Object 'System.Collections.Generic.List[object]'
$currentAllocated = 0L
$blockMB          = [int64]$startBlockMB

# === PRE-FLIGHT ===
if ([IntPtr]::Size -ne 8) {
    Add-Content $logPath "WARNING: 32-bit PowerShell detected; address space is limited. Prefer 64-bit host."
}

# === ALLOCATION PHASE (commit-aware & adaptive) ===
$allocating = $true

while ($allocating) {
    $snap = Get-MemorySnapshot
    $pct  = [math]::Round($snap.Percent,2)

    # Hysteresis control
    if ($pct -ge $stopPercent) {
        Add-Content $logPath ("Pause alloc at {0:HH:mm:ss.fff}: %Committed={1:N2} (>= {2}%). Entering HOLD." -f $snap.Timestamp, $pct, $stopPercent)
        break
    }

    # Determine headroom vs target
    $targetBytes = ($targetPercent/100.0) * $snap.CommitLimit
    $headroom    = $targetBytes - $snap.CommittedBytes

    if ($headroom -le 0) {
        Add-Content $logPath ("No headroom at {0:HH:mm:ss.fff}: %Committed={1:N2}. Entering HOLD." -f $snap.Timestamp, $pct)
        break
    }

    # Choose a step size = min(blockMB, 10% of remaining headroom), bounded
    $stepBytes = [int64]([math]::Floor([math]::Max(1MB, [math]::Min(($blockMB*1MB), ($headroom * $marginFractionStep)))))
    # As we get close to the ceiling, shrink blocks (smooth approach)
    if     ($pct -ge ($targetPercent - 4)) { $blockMB = [int64][math]::Max($minBlockMB, 8) }
    elseif ($pct -ge ($targetPercent - 8)) { $blockMB = [int64][math]::Max($minBlockMB, 16) }
    else                                   { $blockMB = [int64][math]::Min($blockMB, $maxBlockMB) }

    try {
        # Allocate one chunk sized for *this* step
        $block = [byte[]]::new($stepBytes)
        Touch-Block $block
        $memBlocks.Add($block)
        $currentAllocated += $block.LongLength

        # Log after-alloc snapshot (so we see the effect)
        $snap2 = Get-MemorySnapshot
        Add-Content $logPath ("[+{0} MB] {1:HH:mm:ss.fff}  Allocated={2} MB  %Committed={3:N2}  HeadroomToTarget={4:N0} MB  Block={5} MB" -f `
            ([math]::Round($stepBytes/1MB)), $snap2.Timestamp, ([math]::Round($currentAllocated/1MB)), $snap2.Percent, `
            ([math]::Round((($targetPercent/100.0)*$snap2.CommitLimit - $snap2.CommittedBytes)/1MB)), $blockMB)

        # Small pacing delay (optionally grow as we near target)
        $delay = if ($snap2.Percent -ge ($targetPercent - 3)) { [int]([math]::Max($allocationDelayMS * 3, 250)) }
                 elseif ($snap2.Percent -ge ($targetPercent - 6)) { $allocationDelayMS * 2 }
                 else { $allocationDelayMS }
        Start-Sleep -Milliseconds $delay
    }
    catch [System.OutOfMemoryException] {
        Add-Content $logPath ("OOM at {0:HH:mm:ss.fff} while allocating ~{1} MB. Backing off..." -f (Get-Date), [math]::Round($stepBytes/1MB))
        $released = Free-LastBlocks -list $memBlocks -count $oomReleaseBlocks
        $currentAllocated = [math]::Max(0, $currentAllocated - $released)
        # shrink future step
        $blockMB = [int64][math]::Max($minBlockMB, [math]::Floor($blockMB/2))
        Add-Content $logPath ("Released {0} MB. New Allocated={1} MB. Next Block={2} MB." -f ([math]::Round($released/1MB)), ([math]::Round($currentAllocated/1MB)), $blockMB)
        Start-Sleep -Milliseconds $oomSleepMS
        continue
    }
}

# === HOLD PHASE (maintain pressure, shed if above stopPercent, resume if below resumePercent) ===
Add-Content $logPath "Entering HOLD for $holdSeconds seconds; logging every $logIntervalSeconds seconds."
$loops = [math]::Floor($holdSeconds / $logIntervalSeconds)

for ($i = 1; $i -le $loops; $i++) {
    # keep pages hot
    foreach ($blk in $memBlocks) { Touch-Block $blk }

    $snap = Get-MemorySnapshot
    $pct  = [math]::Round($snap.Percent,2)
    Add-Content $logPath ("HOLD[{0}] {1:HH:mm:ss.fff}  %Committed={2:N2}  Blocks={3}  Allocated={4} MB" -f `
        $i, $snap.Timestamp, $pct, $memBlocks.Count, ([math]::Round($currentAllocated/1MB)))

    # If we drifted above stopPercent, shed a small block to stay compliant
    if ($pct -ge $stopPercent - 0.2) {
        $released = Free-LastBlocks -list $memBlocks -count 1
        $currentAllocated = [math]::Max(0, $currentAllocated - $released)
        Add-Content $logPath ("HOLD guardrail: released {0} MB to stay under {1}%." -f ([math]::Round($released/1MB)), $stopPercent)
    }
    # If a lot was freed externally and we’re well below resume band, gently top back up
    elseif ($pct -le $resumePercent) {
        # small, careful top-up (one minimal block)
        try {
            $topUpBytes = [int64]([math]::Max(1MB, [math]::Min(($minBlockMB*1MB), ((($targetPercent/100.0)*$snap.CommitLimit - $snap.CommittedBytes) * 0.05))))
            if ($topUpBytes -gt 0) {
                $blk = [byte[]]::new($topUpBytes)
                Touch-Block $blk
                $memBlocks.Add($blk)
                $currentAllocated += $blk.LongLength
                Add-Content $logPath ("Top-up: +{0} MB  NewAlloc={1} MB  %Committed~{2:N2}" -f ([math]::Round($topUpBytes/1MB)), ([math]::Round($currentAllocated/1MB)), $pct)
            }
        } catch [System.OutOfMemoryException] {
            Add-Content $logPath "Top-up OOM; skipping this interval."
        }
    }

    Start-Sleep -Seconds $logIntervalSeconds
}

# === CLEANUP ===
$releasedTotal = Free-LastBlocks -list $memBlocks -count $memBlocks.Count
Add-Content $logPath ("Memory released ({0} MB) and garbage collected at {1}." -f ([math]::Round($releasedTotal/1MB)), (Get-Date))
Add-Content $logPath "=== High Memory Test Completed: $(Get-Date) ==="
