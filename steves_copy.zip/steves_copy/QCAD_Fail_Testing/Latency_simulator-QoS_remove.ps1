﻿<# PowerShell Script: Remove QoS Policies
# Author: Steven Rogers
# Environment: Windows Server 2019

Deploy Both Scripts

Place QoS_Apply.ps1 and QoS_Remove.ps1 in E:\Fail_Testing on all target servers.
Run QoS_Apply.ps1

Applies QoS policies.
Schedules QoS_Remove.ps1 to run after $DurationMinutes.
Exits immediately.
After $DurationMinutes, QoS_Remove.ps1 Runs Automatically

Removes the applied QoS policies.
Deletes itself from the task scheduler.
Logging

Actions are recorded in E:\Fail_Testing\QoS_Log.txt.


#>
# Define Variables
$PolicyPrefix = "LatencySim_"  # Prefix for policy names
$Ports = @("1433", "1521", "3306", "5432")  # Ensure this matches the apply script
$LogFile = "E:\Fail_Testing\QoS_Log.txt"  # Log file path
$TaskName = "QoS_Policy_Removal"

Write-Host "`nRemoving QoS policies..." -ForegroundColor Red

foreach ($Port in $Ports) {
    $PolicyName = "$PolicyPrefix$Port"
    if (Get-NetQosPolicy | Where-Object { $_.Name -eq $PolicyName }) {
        Remove-NetQosPolicy -Name $PolicyName -Confirm:$false
        Write-Host "QoS Policy '$PolicyName' removed." -ForegroundColor Green
        "[$(Get-Date)] QoS Policy '$PolicyName' removed" | Out-File -Append -FilePath $LogFile
    } else {
        Write-Host "QoS Policy '$PolicyName' not found. Skipping..." -ForegroundColor Yellow
    }
}

# Remove Scheduled Task
schtasks.exe /Delete /TN $TaskName /F
Write-Host "Scheduled Task '$TaskName' removed." -ForegroundColor Cyan
"[$(Get-Date)] Scheduled Task '$TaskName' deleted" | Out-File -Append -FilePath $LogFile
