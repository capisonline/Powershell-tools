﻿<# Server list (where the scheduled task will be deployed)
This script deploys the blocking script (FirewallBlock.ps1) and the unblocking script (FirewallUnblock.ps1) to each server in servers.txt. 
It then creates a scheduled task to run FirewallUnblock.ps1 after X minutes.
#>
$serverList = Get-Content "C:\Scripts\servers.txt"

# Paths to the firewall scripts (stored on a network share)
$blockScriptPath = "\\NetworkShare\FirewallBlock.ps1"
$unblockScriptPath = "\\NetworkShare\FirewallUnblock.ps1"

# Time until unblocking (in minutes)
$unblockDelay = 10

# Scheduled task name
$taskName = "FirewallUnblockTask"

foreach ($server in $serverList) {
    Write-Host "Deploying to $server..."

    # Copy scripts to remote server
    Copy-Item -Path $blockScriptPath -Destination "\\$server\C$\Scripts\" -Force
    Copy-Item -Path $unblockScriptPath -Destination "\\$server\C$\Scripts\" -Force

    # Run the block script immediately on the remote server
    Invoke-Command -ComputerName $server -ScriptBlock {
        Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File C:\Scripts\FirewallBlock.ps1" -NoNewWindow
    }

    # Schedule the unblock script to run after the specified delay
    Invoke-Command -ComputerName $server -ScriptBlock {
        param ($taskName, $unblockDelay)
        $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File C:\Scripts\FirewallUnblock.ps1"
        $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes($unblockDelay)
        $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount
        $task = New-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -Description "Automatically unblocks firewall rules after $unblockDelay minutes"

        Register-ScheduledTask -TaskName $taskName -InputObject $task -Force
    } -ArgumentList $taskName, $unblockDelay
}
