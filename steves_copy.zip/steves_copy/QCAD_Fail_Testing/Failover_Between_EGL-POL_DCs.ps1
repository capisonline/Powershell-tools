﻿# Mini Failover Script: EGL <-> POL VAS Switch (Excludes Oracle)
# Author: Generated for QCAD by ChatGPT
# Context: Automates DR plan steps (3.2.2.2) to switch VAS Master between EGL and POL DCs
# Includes support for VAS, VWS, VCS, VIM, VMG, APL, AAS components with optional TestMode

# Define server groups (Step 0: Prerequisite)
$EGL_VAS = @("EGLVCADVASVT01", "EGLVCADVASVT02")
$POL_VAS = @("POLVCADVASVT03", "POLVCADVASVT04")

$EGL_VWS = @("EGLVCADVWSVT01", "EGLVCADVWSVT02", "EGLVCADVWSVT03", "EGLVCADVWSVT04")
$POL_VWS = @("POLVCADVWSVT01", "POLVCADVWSVT02", "POLVCADVWSVT03", "POLVCADVWSVT04")

$EGL_VCS = @("EGLVCADVCSVT01", "EGLVCADVCSVT02", "EGLVCADVCSVT03", "EGLVCADVCSVT04", "EGLVCADVCSVT05")
$POL_VCS = @("POLVCADVCSVT01", "POLVCADVCSVT02", "POLVCADVCSVT03", "POLVCADVCSVT04", "POLVCADVCSVT05")

$EGL_VIM = @("EGLVCADVIMVT01", "EGLVCADVIMVT02")
$POL_VIM = @("POLVCADVIMVT01", "POLVCADVIMVT02")

$EGL_VMG = @("EGLVCADVMGVT01")
$POL_VMG = @("POLVCADVMGVT01")

$APL_PRIMARY = "EGLVCADAPLVT01"
$APL_SECONDARY = "POLVCADAPLVT01"
$AAS = "EGLVCADAASVT01"

# DFS Share Replication (Step 13)
$DFS_Shares = @(
  "D$\Vision\VisPR\System_VisPR\Manager",
  "D$\Vision\VisPR\System_VisPR\New Version",
  "D$\Vision\OfficerDetails",
  "D$\Vision\VisionAudit"
)

# Services (used in Steps 1, 3, 5, 6, 7, 15–20)
$ServicesToStop = @("Fortek.Services.Arbitrator", "Fortek.FCS", "VisPR_VDW", "RabbitMQ", "W3SVC", "CCCM", "VisionService", "ExternalClientGateway")
$ServicesToStart = @("VisPR_VDW", "W3SVC", "CCCM", "VisionService", "ExternalClientGateway")

function Stop-Services {
    param($servers, $TestMode)
    foreach ($server in $servers) {
        Write-Host "Stopping services on $server..."  # Steps 1, 15–20
        foreach ($svc in $ServicesToStop) {
            if ($TestMode) {
                Write-Host "[TEST] Would stop service '$svc' on $server"
            } else {
                Invoke-Command -ComputerName $server -ScriptBlock {
                    param($svc) Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue
                } -ArgumentList $svc
            }
        }
    }
}

function Start-Services {
    param($servers, $TestMode)
    foreach ($server in $servers) {
        Write-Host "Starting services on $server..."  # Steps 10, 11, 12, 7
        foreach ($svc in $ServicesToStart) {
            if ($TestMode) {
                Write-Host "[TEST] Would start service '$svc' on $server"
            } else {
                Invoke-Command -ComputerName $server -ScriptBlock {
                    param($svc) Start-Service -Name $svc -ErrorAction SilentlyContinue
                } -ArgumentList $svc
            }
        }
    }
}

function Restart-IIS {
    param($servers, $TestMode)  # Steps 11, 12
    foreach ($server in $servers) {
        if ($TestMode) {
            Write-Host "[TEST] Would restart IIS on $server"
        } else {
            Write-Host "Restarting IIS on $server..."
            Invoke-Command -ComputerName $server -ScriptBlock { iisreset }
        }
    }
}

function Copy-DFS-Shares {
    param($source, $targets, $TestMode)  # Step 13
    foreach ($share in $DFS_Shares) {
        foreach ($target in $targets) {
            if ($TestMode) {
                Write-Host "[TEST] Would copy $share from $source to $target"
            } else {
                Write-Host "Copying $share from $source to $target..."
                robocopy "\\$source\$share" "\\$target\$share" /MIR /R:1 /W:5 /NFL /NDL /NP /LOG+:C:\QCADFailover\robocopy_$((Get-Date).ToString("yyyyMMdd_HHmm")).log
            }
        }
    }
}

function Switch-To {
    param(
        [ValidateSet("EGL", "POL")][string]$TargetDC,
        [switch]$TestMode
    )
    if ($TargetDC -eq "EGL") {
        $Master = $EGL_VAS[0]
        $Secondary = $EGL_VAS[1]
        $OldDC_VAS = $POL_VAS; $NewDC_VAS = $EGL_VAS
        $OldDC_VWS = $POL_VWS; $NewDC_VWS = $EGL_VWS
        $OldDC_VCS = $POL_VCS; $NewDC_VCS = $EGL_VCS
        $OldDC_VIM = $POL_VIM; $NewDC_VIM = $EGL_VIM
        $OldDC_VMG = $POL_VMG; $NewDC_VMG = $EGL_VMG
        $NewAPL = $APL_PRIMARY
    } else {
        $Master = $POL_VAS[0]
        $Secondary = $POL_VAS[1]
        $OldDC_VAS = $EGL_VAS; $NewDC_VAS = $POL_VAS
        $OldDC_VWS = $EGL_VWS; $NewDC_VWS = $POL_VWS
        $OldDC_VCS = $EGL_VCS; $NewDC_VCS = $POL_VCS
        $OldDC_VIM = $EGL_VIM; $NewDC_VIM = $POL_VIM
        $OldDC_VMG = $EGL_VMG; $NewDC_VMG = $POL_VMG
        $NewAPL = $APL_SECONDARY
    }

    Write-Host "\n=== MINI FAILOVER: SWITCHING TO $TargetDC DC ==="

    # Step 2: Manual promotion of VAS Master must occur here
    Write-Host "❗ Please manually promote the VAS Master to $Master now."
    if (-not $TestMode) {
        Read-Host "Press ENTER after Master promotion is confirmed..."
    } else {
        Write-Host "[TEST] Skipping manual confirmation in TestMode."
    }

    # Steps 1, 15–20
    Stop-Services -servers $OldDC_VAS -TestMode:$TestMode
    Stop-Services -servers $OldDC_VWS -TestMode:$TestMode
    Stop-Services -servers $OldDC_VCS -TestMode:$TestMode
    Stop-Services -servers $OldDC_VIM -TestMode:$TestMode
    Stop-Services -servers $OldDC_VMG -TestMode:$TestMode

    Write-Host "\n[MANUAL STEP] Shut down old VAS servers if needed."

    # Steps 10, 11, 12, 7
    Start-Services -servers $NewDC_VAS -TestMode:$TestMode
    Start-Services -servers $NewDC_VWS -TestMode:$TestMode
    Start-Services -servers $NewDC_VCS -TestMode:$TestMode
    Start-Services -servers $NewDC_VIM -TestMode:$TestMode
    Start-Services -servers $NewDC_VMG -TestMode:$TestMode

    Restart-IIS -servers $NewDC_VWS -TestMode:$TestMode  # Step 11
    Restart-IIS -servers $NewDC_VCS -TestMode:$TestMode  # Step 11

    Copy-DFS-Shares -source $Master -targets ($NewDC_VAS | Where-Object { $_ -ne $Master }) -TestMode:$TestMode  # Step 13

    # Step 14 – APL/AAS Update
    if ($TestMode) {
        Write-Host "[TEST] Would update AAS Web.config to point to APL $NewAPL and restart IIS"
    } else {
        Write-Host "\nUpdating AAS Web.config to point to APL $NewAPL..."
        Invoke-Command -ComputerName $AAS -ScriptBlock {
            param($apl)
            $path = "C:\InetPub\wwwroot\ARL\Qps.Ast.Arl.LocationForwardService\Web.config"
            (Get-Content $path) -replace "http://.*?/VisPR_MLSGateway/MlsGateway.asmx", "http://$apl/VisPR_MLSGateway/MlsGateway.asmx" | Set-Content $path
            iisreset
        } -ArgumentList $NewAPL
    }

    Write-Host "\n Failover to $TargetDC complete. Validate client access, QPages, narratives, PLK and UQP manually."
}

# Example usage:
# Switch-To -TargetDC POL           # Live run
# Switch-To -TargetDC POL -TestMode  # Dry-run for validation
