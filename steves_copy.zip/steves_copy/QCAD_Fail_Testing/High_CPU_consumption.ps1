﻿<#
.SYNOPSIS
    High CPU Load Simulation Script for Stress Testing and Monitoring Validation.

.DESCRIPTION
    This script simulates high CPU usage on a Windows system by launching a number of 
    background jobs that consume CPU cycles in a controlled loop. It is designed to test 
    system behavior, trigger performance monitoring alerts (e.g., vCenter, SCOM), and verify 
    DR response in both physical and virtual environments.

    Features include:
    - Dynamic detection of logical CPU cores.
    - Optional auto-scaling based on current CPU usage (can be disabled to cause near total system failure).
    - Configurable total CPU load percentage.
    - Gradual ramp-up of load to prevent sudden spikes.
    - Periodic logging of actual CPU usage for validation.
    - Per-server logging with hostname and timestamp in filename.
    - Safe cleanup of stress jobs even under high load.

   NOTE:
    By default, each stress job is configured to use approximately **90% of a single core** 
    (i.e., 90ms busy + 10ms idle). As a result, the actual CPU usage may be slightly below 
    the configured `$TargetCpuPercent` unless `$dutyCycle` is set to 100 manually.
    To achieve near-100% CPU usage (system will probably crash), set `$dutyCycle = 100` and `$sleepCycle = 0`.

.NOTES
    Author   : Rogers.Steven2@police.qld.gov.au
    Created  : 2025-05-26
    Logs     : D:\Failtesting\logs\HighCPU_TestLog_<hostname>_<timestamp>.txt

.EXAMPLE
    Runs automatically via Scheduled Task.

    Variables configured internally:
        $TargetCpuPercent = 100
        $AutoScale = $false
        $HoldSeconds = 120
        $RampDelayMS = 100
        $MeasureIntervalSeconds = 5
#>


# === CONFIGURATION ===
$TargetCpuPercent = 100       # Desired % total CPU usage (can be over 100 to cause system crash - will loose logging)
$AutoScale = $true            # Auto-adjust if system is already under load
$HoldSeconds = 18000            # Duration to hold CPU load (in seconds)
$RampDelayMS = 100            # Delay between starting each job (in milliseconds)
$MeasureIntervalSeconds = 5   # How often to record actual CPU usage

# === LOGGING SETUP ===
$hostname = $env:COMPUTERNAME
$logDir = "D:\Failtesting\logs"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath = Join-Path $logDir "HighCPU_TestLog_${hostname}_$timestamp.txt"

if (!(Test-Path $logDir)) {
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
}

Add-Content $logPath "=== High CPU Test Started: $(Get-Date) ==="
Add-Content $logPath "Host: $hostname"
Add-Content $logPath "Initial Target CPU: $TargetCpuPercent%"
Add-Content $logPath "Auto-Scaling Enabled: $AutoScale"

# === SYSTEM INSPECTION ===
$cpuCount = [Environment]::ProcessorCount
Add-Content $logPath "Detected $cpuCount logical CPU cores."

if ($AutoScale) {
    $currentLoad = (Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples[0].CookedValue
    $availableHeadroom = [math]::Max(0, 100 - $currentLoad)

    if ($TargetCpuPercent -gt $availableHeadroom) {
        Add-Content $logPath "Auto-scaling: Current CPU load is $([math]::Round($currentLoad, 2))%. Reducing target from $TargetCpuPercent% to $([math]::Floor($availableHeadroom))%."
        $TargetCpuPercent = [math]::Floor($availableHeadroom)
    } else {
        Add-Content $logPath "Sufficient headroom available: $([math]::Round($availableHeadroom, 2))%."
    }
}

# === JOB PREPARATION ===
# By default, each stress job is configured to use approximately **90% of a single core** 
$jobCount = [math]::Ceiling($cpuCount * ($TargetCpuPercent / 100.0))
$dutyCycle = 90 # Can set this to 100 to cause system crash
$sleepCycle = 100 - $dutyCycle

Add-Content $logPath "Launching $jobCount job(s) to simulate ~$TargetCpuPercent% total CPU usage."
Add-Content $logPath "Each job configured for ~$dutyCycle% core usage."

# === SHARED EXIT FLAG ===
$script:StopFlag = $false
Register-EngineEvent PowerShell.Exiting -Action { $script:StopFlag = $true }

# === START STRESS JOBS ===
$jobs = @()
for ($i = 1; $i -le $jobCount; $i++) {
    $jobs += Start-Job -ScriptBlock {
        while (-not $script:StopFlag) {
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            while ($sw.ElapsedMilliseconds -lt $using:dutyCycle) {
                1 + 1 | Out-Null
            }
            Start-Sleep -Milliseconds $using:sleepCycle
        }
    }
    Add-Content $logPath "Started job #$i at $(Get-Date)"
    Start-Sleep -Milliseconds $RampDelayMS
}

# === MONITOR ACTUAL CPU USAGE IN BACKGROUND ===
$monitorJob = Start-Job -ScriptBlock {
    $log = $using:logPath
    while (-not $script:StopFlag) {
        $usage = (Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples[0].CookedValue
        Add-Content $log "Actual CPU Usage: $([math]::Round($usage, 2))% at $(Get-Date)"
        Start-Sleep -Seconds $using:MeasureIntervalSeconds
    }
}

Add-Content $logPath "All stress jobs launched. Holding for $HoldSeconds seconds..."
Start-Sleep -Seconds $HoldSeconds

# === CLEANUP ===
$script:StopFlag = $true
Start-Sleep -Seconds 2

# Clean up jobs
foreach ($job in $jobs) {
    try {
        Stop-Job $job -ErrorAction SilentlyContinue
        Remove-Job $job -Force -ErrorAction SilentlyContinue
    } catch {
        Add-Content $logPath "Failed to clean up job $($job.Id): $_"
    }
}

# Clean up monitor job
try {
    Stop-Job $monitorJob -ErrorAction SilentlyContinue
    Remove-Job $monitorJob -Force -ErrorAction SilentlyContinue
} catch {
    Add-Content $logPath "Failed to clean up monitor job: $_"
}

Add-Content $logPath "Stopped and removed all jobs."
Add-Content $logPath "=== High CPU Test Completed: $(Get-Date) ==="
