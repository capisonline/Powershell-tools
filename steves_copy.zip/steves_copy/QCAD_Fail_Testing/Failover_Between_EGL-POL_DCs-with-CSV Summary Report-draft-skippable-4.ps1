﻿
<#
.SYNOPSIS
    Automates application-layer DR failover between QCAD datacenters (EGL and POL) by switching VAS master,
    restarting key services, syncing DFS shares, and updating AAS configuration.

.DESCRIPTION
    This script supports test-mode dry runs and granular control using skip flags for different server types.
    It aligns with the QCAD DR Plan (Step 3.2.2.2) excluding Oracle components. 
    Outputs are logged to text and CSV for compliance and audit purposes.

.PARAMETER TargetDC
    The target datacenter to fail over to. Accepts 'EGL' or 'POL'.

.PARAMETER TestMode
    Simulates all actions without making changes. Outputs are logged for review.

.PARAMETER SkipVAS
    Skips all actions related to Vision Application Servers (VAS).

.PARAMETER SkipVWS
    Skips all actions related to Vision Web Servers (VWS).

.PARAMETER SkipVCS
    Skips all actions related to Vision Client Service servers (VCS).

.PARAMETER SkipVIM
    Skips all actions related to Vision Integration Module (VIM) servers.

.PARAMETER SkipVMG
    Skips all actions related to Vision Mobile Gateway (VMG) servers.

.PARAMETER SkipAAS
    Skips AAS Web.config update and IIS restart.

.EXAMPLE
    Switch-To -TargetDC POL

    Performs a live failover to POL datacenter and updates all relevant components.

.EXAMPLE
    Switch-To -TargetDC EGL -TestMode -SkipVWS -SkipAAS

    Performs a dry-run failover to EGL, skipping actions on Web Servers and AAS.

.NOTES
    Author: SteveR
    Last Updated: 2025-05-31
    Log Output:     C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_POL-EGLr\Failover_Log_<timestamp>.txt
    CSV Summary:    C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_POL-EGL\Failover_Report_<timestamp>.csv

    To run:
    .\QCAD-Failover.ps1 -TargetDC POL
    or
    .\QCAD-Failover.ps1 -TargetDC EGL -TestMode -SkipAAS -SkipVWS


#>

param(
  [ValidateSet("EGL", "POL")] [string]$TargetDC,
  [switch]$TestMode,
  [switch]$SkipVAS,
  [switch]$SkipVWS,
  [switch]$SkipVCS,
  [switch]$SkipVIM,
  [switch]$SkipVMG,
  [switch]$SkipAAS,
  [switch]$SkipShutdown
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmm"
$LogFile = "C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_POL-EGL\Failover_Log_$timestamp.txt"
$CsvLog = "C:\temp\QCAD\VT\Fail_Testing\Automated_Failover_POL-EGL\Failover_Report_$timestamp.csv"
$CsvOutput = @()

$DFSNamespace = "\\PRDS.QLDPOL\\appdata\\VT\\QCAD"
$DFS_Shares = @("OfficerDetails$", "VisionAudit$", "System_VisVT$", "New Version$")

$EGL = @{ 
    VAS = @("EGLVCADVASVT01", "EGLVCADVASVT02"); 
    VWS = @("EGLVCADVWSVT01", "EGLVCADVWSVT02", "EGLVCADVWSVT03", "EGLVCADVWSVT04"); 
    VCS = @("EGLVCADVCSVT01", "EGLVCADVCSVT02", "EGLVCADVCSVT03", "EGLVCADVCSVT04", "EGLVCADVCSVT05"); 
    VIM = @("EGLVCADVIMVT01", "EGLVCADVIMVT02"); 
    VMG = @("EGLVCADVMGVT01"); 
    APL = "EGLVCADAPLVT01" 
}
$POL = @{ 
    VAS = @("POLVCADVASVT03", "POLVCADVASVT04"); 
    VWS = @("POLVCADVWSVT01", "POLVCADVWSVT02", "POLVCADVWSVT03", "POLVCADVWSVT04"); 
    VCS = @("POLVCADVCSVT01", "POLVCADVCSVT02", "POLVCADVCSVT03", "POLVCADVCSVT04", "POLVCADVCSVT05"); 
    VIM = @("POLVCADVIMVT01", "POLVCADVIMVT02"); 
    VMG = @("POLVCADVMGVT01"); 
    APL = "POLVCADAPLVT01" 
}

$AAS = @{ EGL = "EGLVCADAASVT01"; POL = "POLVCADAASVT02" }

$ServicesToStop = @("Fortek.Services.Arbitrator", "Fortek.FCS", "VisVT_VDW", "RabbitMQ", "W3SVC", "VisionService", "ExternalClientGateway")
$ServicesToStart = @("VisVT_VDW", "W3SVC", "VisionService", "ExternalClientGateway")

$Old = if ($TargetDC -eq 'EGL') { $POL } else { $EGL }
$New = if ($TargetDC -eq 'EGL') { $EGL } else { $POL }
$Master = $New.VAS[0]
$NewAPL = $New.APL
$CurrentAAS = $AAS[$TargetDC]

function Log-Action {
    param($Step, $Server, $Service, $Action, $IsTest)
    $line = "[$Step] $Action service '$Service' on $Server"
    if ($IsTest) { $line = "[TEST] $line" }
    Add-Content -Path $LogFile -Value $line
    $CsvOutput += [pscustomobject]@{
        Step     = $Step
        Server   = $Server
        Action   = $Action
        Service  = $Service
        TestMode = $IsTest
    }
}

function Control-Services {
    param($Action, $Servers, $Services, $Step, $TestMode)
    foreach ($Server in $Servers) {
        foreach ($Service in $Services) {
            Log-Action -Step $Step -Server $Server -Service $Service -Action $Action -IsTest:$TestMode
            if (-not $TestMode) {
                $cmd = if ($Action -eq 'Start') { "Start-Service" } else { "Stop-Service -Force" }
                Invoke-Command -ComputerName $Server -ScriptBlock { param($svc, $cmd) Invoke-Expression "$cmd -Name `$svc -ErrorAction SilentlyContinue" } -ArgumentList $Service, $cmd
            }
        }
    }
}

function Restart-IIS {
    param($Servers, $Step, $TestMode)
    foreach ($Server in $Servers) {
        Log-Action -Step $Step -Server $Server -Service "IIS" -Action "Restart" -IsTest:$TestMode
        if (-not $TestMode) {
            Invoke-Command -ComputerName $Server -ScriptBlock { iisreset }
        }
    }
}

function Copy-DFS-Shares {
    param($Source, $Targets, $Shares, $Step, $TestMode)
    foreach ($Share in $Shares) {
        foreach ($Target in $Targets) {
            Log-Action -Step $Step -Server $Target -Service $Share -Action "Copy" -IsTest:$TestMode
            if (-not $TestMode) {
                robocopy "\\$Source\$Share" "\\$Target\$Share" /MIR /R:1 /W:5 /NFL /NDL /NP /LOG+:$LogFile
            }
        }
    }
}

function Set-DfsnTargets {
    param($NamespacePath, $EGLTarget, $POLTarget, $EnablePOL, $TestMode)

    $Preferred = if ($EnablePOL) { $POLTarget } else { $EGLTarget }
    $Disabled = if ($EnablePOL) { $EGLTarget } else { $POLTarget }

    if (-not $TestMode) {
        Set-DfsnFolderTarget -Path $NamespacePath -TargetPath $Preferred -State Online
        Set-DfsnFolderTarget -Path $NamespacePath -TargetPath $Disabled -State Offline
    }

    Log-Action "Step 13" $Preferred "DFS Target" "Enable" $TestMode
    Log-Action "Step 13" $Disabled "DFS Target" "Disable" $TestMode
}

function Shutdown-Servers {
    param($Servers, $Step, $TestMode)
    foreach ($Server in $Servers) {
        Log-Action -Step $Step -Server $Server -Service "System" -Action "Shutdown" -IsTest:$TestMode
        if (-not $TestMode) {
            try {
                Invoke-Command -ComputerName $Server -ScriptBlock { Stop-Computer -Force } -ErrorAction Stop
            } catch {
                Log-Action "$Step - ERROR" $Server "System" "Shutdown FAILED: $_" $TestMode
            }
        }
    }
}

if (-not $SkipVAS) {
    Control-Services Stop $Old.VAS @("Fortek.Services.Arbitrator") "Step 1" $TestMode
}

Add-Content -Path $LogFile -Value "--- SWITCHING TO $TargetDC ---"
Write-Host "🟡 STOP: You must now promote VAS Master to $Master manually."
if (-not $TestMode) {
    do {
        $confirmation = Read-Host "Type 'yes' to confirm VAS promotion has been completed"
    } while ($confirmation -ne 'yes')
} else {
    Write-Host "[TEST] Skipping confirmation."
}

if (-not $SkipVAS) {
    Control-Services Stop $Old.VAS $ServicesToStop "Step 2" $TestMode
    Control-Services Start $New.VAS $ServicesToStart "Step 3" $TestMode
    Copy-DFS-Shares $Master ($New.VAS | Where-Object { $_ -ne $Master }) $DFS_Shares "Step 4" $TestMode
    foreach ($share in $DFS_Shares) {
        $EGLTarget = "\\EGLVCADVASVT01\$share"
        $POLTarget = "\\POLVCADVASVT03\$share"
        Set-DfsnTargets "$DFSNamespace\$share" $EGLTarget $POLTarget ($TargetDC -eq 'POL') $TestMode
    }
    if (-not $SkipShutdown) { Shutdown-Servers $Old.VAS "Shutdown VAS" $TestMode }
}
if (-not $SkipVWS) {
    Control-Services Stop $Old.VWS $ServicesToStop "Step 5" $TestMode
    Control-Services Start $New.VWS $ServicesToStart "Step 6" $TestMode
    Restart-IIS $New.VWS "Step 6" $TestMode
    if (-not $SkipShutdown) { Shutdown-Servers $Old.VWS "Shutdown VWS" $TestMode }
}
if (-not $SkipVCS) {
    Control-Services Stop $Old.VCS $ServicesToStop "Step 7" $TestMode
    Control-Services Start $New.VCS $ServicesToStart "Step 8" $TestMode
    Restart-IIS $New.VCS "Step 8" $TestMode
    if (-not $SkipShutdown) { Shutdown-Servers $Old.VCS "Shutdown VCS" $TestMode }
}
if (-not $SkipVIM) {
    Control-Services Stop $Old.VIM $ServicesToStop "Step 9" $TestMode
    Control-Services Start $New.VIM $ServicesToStart "Step 10" $TestMode
    if (-not $SkipShutdown) { Shutdown-Servers $Old.VIM "Shutdown VIM" $TestMode }
}
if (-not $SkipVMG) {
    Control-Services Stop $Old.VMG $ServicesToStop "Step 11" $TestMode
    Control-Services Start $New.VMG $ServicesToStart "Step 12" $TestMode
    if (-not $SkipShutdown) { Shutdown-Servers $Old.VMG "Shutdown VMG" $TestMode }
}
if (-not $SkipAAS) {
    Log-Action "Step 13" $CurrentAAS "Web.config" "Update APL to $NewAPL" $TestMode
    if (-not $TestMode) {
        Invoke-Command -ComputerName $CurrentAAS -ScriptBlock {
            param($apl)
            $path = "C:\InetPub\wwwroot\ARL\Qps.Ast.Arl.LocationForwardService\Web.config"
            (Get-Content $path) -replace "http://.*?/VisVT_MLSGateway/MlsGateway.asmx", "http://$apl/VisVT_MLSGateway/MlsGateway.asmx" | Set-Content $path
            iisreset
        } -ArgumentList $NewAPL
    }
}

$CsvOutput | Export-Csv -Path $CsvLog -NoTypeInformation
Write-Host "`n✅ Failover (or test) complete."
Write-Host "Log saved to: $LogFile"
Write-Host "CSV report saved to: $CsvLog"
