﻿$category = "VisVT Vision Client Service"

if ([System.Diagnostics.PerformanceCounterCategory]::Exists($category)) {
    [System.Diagnostics.PerformanceCounterCategory]::Delete($category)
}

$counters = New-Object System.Diagnostics.CounterCreationDataCollection

$state = New-Object System.Diagnostics.CounterCreationData
$state.CounterName = "State"
$state.CounterHelp = "The current state of the Vision Client Service"
$state.CounterType = [System.Diagnostics.PerformanceCounterType]::NumberOfItems32
$counters.Add($state)

$ir = New-Object System.Diagnostics.CounterCreationData
$ir.CounterName = "Incident Resources Processing Rate"
$ir.CounterHelp = "The number of IR packets received per second"
$ir.CounterType = [System.Diagnostics.PerformanceCounterType]::RateOfCountsPerSecond32
$counters.Add($ir)

[System.Diagnostics.PerformanceCounterCategory]::Create(
    $category,
    "Counters for the Vision Client Service",
    [System.Diagnostics.PerformanceCounterCategoryType]::SingleInstance,
    $counters
)


## Get-Counter -Counter "\VisVT Vision Client Service\*"
# Get-Counter "\VisVT Vision Client Service\*" -SampleInterval 1 -MaxSamples 5

#