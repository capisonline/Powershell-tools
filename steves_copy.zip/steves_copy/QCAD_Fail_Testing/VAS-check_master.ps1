﻿# Get-Counter "\Vision Arbitrator(visvt)\*"
(Get-Counter "\Vision Arbitrator(visvt)\master eligibility").CounterSamples.CookedValue
