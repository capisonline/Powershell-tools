<#
This script checks the installed windows features against a list supplied in the variable: $featureFile
Once run, copy the results into an Excel workbook and filter the results as required.
#>

# Path to the text file containing feature names (one feature per row) 
$featureFile = "C:\temp\feature_list.txt"

# Output file for results
$outputFile = "C:\temp\feature_list_OutputResults.csv"

# Check if the feature file exists
if (Test-Path $featureFile) {
    # Read feature names from the file
    $featureList = Get-Content $featureFile

    # Create an array to store result objects
    $resultArray = @()

    # Loop through each feature
    foreach ($feature in $featureList) {
        # Trim leading and trailing whitespaces
        $feature = $feature.Trim()

        # Execute Get-WindowsFeature for the current feature
        $result = Get-WindowsFeature -Name $feature

        # Create a custom object with the result
        $resultObject = [PSCustomObject]@{
            Feature       = $feature
            Installed     = $result.Installed
            InstallState  = $result.InstallState
        }

        # Add the result object to the array
        $resultArray += $resultObject
    }

    # Export the result array to a CSV file
    $resultArray | Export-Csv -Path $outputFile -NoTypeInformation

    Write-Output "Results saved to: $outputFile"
} else {
    Write-Output "Error: File not found - $featureFile"
}
