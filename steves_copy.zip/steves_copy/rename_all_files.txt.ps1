﻿Get-ChildItem C:\temp\QCAD\BA\LogMan\tasks\cleaned\*.* | Rename-Item -NewName { $_.BaseName + ".txt" } #-WhatIf
