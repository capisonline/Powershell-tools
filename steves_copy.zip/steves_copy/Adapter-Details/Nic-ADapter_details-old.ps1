﻿
$Environment = Read-Host -Prompt "Enter environment eg. VT, PS, etc."
$ServerList = Get-Content -Path .\ServerList.txt
$Path = (Get-Location).Path
 
$ServerList
if ((Read-host -Prompt "Does this server list look correct? Y/N") -eq "N"){exit}
 
$DefaultXML = "$Path\Default_AdapterDetail.xml"
$XMLStore = "$Path\$Environment CollectedXMLs"
 
## Check folder exists and re-create it if so
if ((Test-Path $XMLStore) -eq $true) {Remove-Item -Path $XMLStore -Recurse}
[void](New-Item -ItemType Directory -Path $XMLStore)
 
## Collect DNS Records for PRDS.QLDPOL
Write-Host "Collecting DNS records for PRDS.QLDPOL..."
$DNSRecords = Get-DnsServerResourceRecord -ZoneName "prds.qldpol" -ComputerName "164.112.162.141" -ErrorAction Stop -RRType CName | Select-Object HostName,RecordData
 
foreach ($Server in $ServerList){
     
    ## Filter DNS records for the specific alias of the current machine
    $DNSAlias = ($DNSRecords | Where-Object {($_.RecordData.HostNameAlias -split '\.')[0] -eq $Server} | Select-Object HostName).HostName
 
    ## Make a copy of the default XML in preperation for data input
    Write-Host "Collecting network adapter configuration and routes from $Server..."
    $TempXML = ($Server + "_AdapterDetail.xml")
    xcopy .\Default_AdapterDetail.xml $XMLStore /Q |find /v "File(s) copied"
    Rename-Item -Path $XMLStore\Default_AdapterDetail.xml -NewName $TempXML
    $xml = [xml](Get-Content -Path "$XMLStore\$TempXML")
 
    ## Update Hostname & DNS
    $node = $xml.SelectSingleNode('//Machine')
    $node.SetAttribute("Name","$Server")
    $node.SetAttribute("FQDN","$Server.prds.qldpol")
    $node.SetAttribute("DnsAlias","$DNSAlias.prds.qldpol")
 
    ## Update Network adapter configuration
    $NWAConfig = Invoke-Command -ComputerName $Server -ScriptBlock {Get-NetIPConfiguration -Detailed}
    $SubnetMask = Get-CimInstance -ComputerName $Server -ClassName win32_networkadapterconfiguration -Filter IPENABLED=1 | Select-Object IPSubnet
 
    $node = $xml.SelectSingleNode('//NetworkAdapter')
    $node.SetAttribute("Description",$NWAConfig.InterfaceDescription)
    $node.SetAttribute("Id","NIC1")
    $node.SetAttribute("IpEnabled","-1")
    $node.SetAttribute("IpAddress",$NWAConfig.IPv4Address.IPAddress)
    $node.SetAttribute("SubnetMask",$SubnetMask.IPSubnet)
    $node.SetAttribute("Gateway",$NWAConfig.IPv4DefaultGateway.NextHop)
    $node.SetAttribute("Dhcp","0")
    $node.SetAttribute("DNSDomain","")
    $node.SetAttribute("DNSSuffix","prds.qldpol")
    $node.SetAttribute("DNS-WINS","0")
    $node.SetAttribute("DNSOrder",$NWAConfig.DNSServer.ServerAddresses)
 
 
    ## Update Routes
    $Routes = Get-WmiObject Win32_IP4RouteTable -ComputerName $Server | Select-Object Destination,Mask,NextHop,Metric1
     
    foreach ($Route in $Routes){
        $node = $xml.SelectSingleNode('//Routes')
        $NewRouteElement = $xml.CreateElement("Route")
        $NewRouteElementAdd = $node.AppendChild($NewRouteElement)
        $NewRouteAttribute = $NewRouteElementAdd.SetAttribute("Destination",$Route.Destination)
        $NewRouteAttribute = $NewRouteElementAdd.SetAttribute("Mask",$Route.Mask)
        $NewRouteAttribute = $NewRouteElementAdd.SetAttribute("NextHop",$Route.NextHop)
        $NewRouteAttribute = $NewRouteElementAdd.SetAttribute("Metric1",$Route.Metric1)
    }
 
    ## Save the newly updated XML
    $xml.Save("$XMLStore\$TempXML")
}
