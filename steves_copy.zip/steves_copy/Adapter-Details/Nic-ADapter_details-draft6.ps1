﻿<# 
.SYNOPSIS
    Generates XML configuration files for servers, setting Name, DnsAlias,
    and network configuration dynamically.

.DESCRIPTION
    - Reads a list of servers from 'ServerList.txt'.
    - Retrieves DNS aliases from DNS records and **uses them as-is**, ensuring
      that only the **fully qualified name (FQDN)** is selected.
    - Queries each server for:
        - The “Up” network adapter (ignoring disconnected NICs).
        - IP, subnet, gateway, and DNS configuration.
        - The system route table, filtered for the correct interface.
    - Updates 'Default_AdapterDetail.xml', saving as '<ServerName>_AdapterDetail.xml'.
    
.NOTES
    - Ensures `Name="ServerName"` and `DnsAlias="DNS ALIAS"` without modifications.
    - Uses **exactly what is retrieved** from DNS (only FQDN, never short aliases).
    - Assumes PowerShell remoting is enabled on target servers.

.EXAMPLE
    PS C:\Scripts> .\Generate-AdapterDetailXML.ps1
#>


#region Parameters / Variables

$Environment = Read-Host -Prompt "Enter environment (e.g., VT, PS, etc.)"
$ServerList  = Get-Content -Path .\ServerList.txt
$ScriptPath  = (Get-Location).Path

Write-Host "`nServers to process:"
$ServerList | ForEach-Object { Write-Host " - $_" }

if ((Read-Host -Prompt "Does this server list look correct? Y/N") -eq "N") {
    Write-Warning "Exiting script at user request."
    return
}

# Path to the default template
$DefaultXML = Join-Path $ScriptPath "Default_AdapterDetail.xml"

# Output folder, e.g. "VT CollectedXMLs"
$XMLStore = Join-Path $ScriptPath ("$Environment CollectedXMLs")

#endregion Parameters / Variables


#region Prepare Output Folder

if (Test-Path $XMLStore) {
    Write-Host "Removing existing folder: $XMLStore"
    Remove-Item -Path $XMLStore -Recurse -Force
}

Write-Host "Creating new folder: $XMLStore"
New-Item -ItemType Directory -Path $XMLStore | Out-Null

#endregion Prepare Output Folder


#region Retrieve DNS Records

Write-Host "`nCollecting DNS CName records for prds.qldpol from 164.112.162.141..."

try {
    $DNSRecords = Get-DnsServerResourceRecord -ZoneName "prds.qldpol" `
                   -ComputerName "164.112.162.141" `
                   -RRType CName `
                   -ErrorAction Stop |
                Select-Object HostName, RecordData
}
catch {
    Write-Warning "Failed to retrieve DNS records. $_"
    return
}

#endregion Retrieve DNS Records


#region Process Each Server

foreach ($Server in $ServerList) {
    Write-Host "`n---- Processing $Server ----"

    # Retrieve the fully qualified DNS alias from DNS records
    $DNSAlias = ($DNSRecords | Where-Object {
        $_.RecordData.HostNameAlias -match '\.prds\.qldpol$'  # Ensure it contains .prds.qldpol (FQDN)
    } | Select-Object -ExpandProperty HostName -ErrorAction SilentlyContinue)

    # If no fully qualified alias was found, fallback to the first available alias
    if (-not $DNSAlias) {
        $DNSAlias = ($DNSRecords | Select-Object -ExpandProperty HostName -First 1 -ErrorAction SilentlyContinue)
    }

    # Trim any trailing dots
    $DNSAlias = $DNSAlias -replace '\.+$',''

    Write-Host "Final DNSAlias: '$DNSAlias'"

    # Copy and rename the default XML template for this server
    Write-Host "Copying default XML template for $Server..."
    $TempXML = "$Server`_AdapterDetail.xml"
    xcopy $DefaultXML $XMLStore /Q | Out-Null
    Rename-Item -Path (Join-Path $XMLStore "Default_AdapterDetail.xml") -NewName $TempXML

    # Load the XML for editing
    $XMLPath = Join-Path $XMLStore $TempXML
    [xml]$xml = Get-Content -Path $XMLPath

    # -- Update <Machine> attributes --
    $machineNode = $xml.SelectSingleNode('//Machine')
    $machineNode.SetAttribute("Name", $Server)   # Hostname only
    $machineNode.SetAttribute("DnsAlias", $DNSAlias)  # Exact DNS alias (FQDN only)

    # Collect network adapter info from the remote server
    Write-Host "Collecting NIC configuration from $Server..."
    $NWAConfig = Invoke-Command -ComputerName $Server -ScriptBlock {
        Get-NetIPConfiguration -Detailed |
            Where-Object {
                $_.NetAdapter.Status -eq 'Up' -and
                $_.IPv4Address -and
                $_.IPv4Address.IPAddress -notmatch '169\.254\.'
            } |
            Select-Object -First 1
    }

    if (-not $NWAConfig) {
        Write-Warning "No 'Up' NIC with a valid IPv4 address found on $Server. Skipping..."
        continue
    }

    # Match the subnet mask using the same InterfaceIndex
    $SubnetMask = Invoke-Command -ComputerName $Server -ScriptBlock {
        param($Idx)
        Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE" |
            Where-Object { $_.InterfaceIndex -eq $Idx } |
            Select-Object -ExpandProperty IPSubnet
    } -ArgumentList $NWAConfig.InterfaceIndex

    # -- Update <NetworkAdapter> node --
    Write-Host "Updating NetworkAdapter in the XML for $Server..."
    $adapterNode = $xml.SelectSingleNode('//NetworkAdapter')

    $adapterNode.SetAttribute("Description", $NWAConfig.InterfaceDescription)
    $adapterNode.SetAttribute("Id", "NIC1")
    $adapterNode.SetAttribute("IpEnabled", "-1")
    $adapterNode.SetAttribute("IpAddress", $NWAConfig.IPv4Address.IPAddress)
    $adapterNode.SetAttribute("SubnetMask", ($SubnetMask -join ','))
    $adapterNode.SetAttribute("Gateway", $NWAConfig.IPv4DefaultGateway.NextHop)
    $adapterNode.SetAttribute("Dhcp", "0")
    $adapterNode.SetAttribute("DNSDomain", "")
    $adapterNode.SetAttribute("DNSSuffix", "prds.qldpol")
    $adapterNode.SetAttribute("DNS-WINS", "0")

    # DNS can have multiple addresses; join if needed
    $dnsAddresses = $NWAConfig.DNSServer.ServerAddresses
    if ($dnsAddresses -is [System.Array]) {
        $adapterNode.SetAttribute("DNSOrder", $dnsAddresses -join ",")
    }
    else {
        $adapterNode.SetAttribute("DNSOrder", $dnsAddresses)
    }

    # Gather routes for the same interface index
    Write-Host "Collecting route table from $Server..."
    $Routes = Invoke-Command -ComputerName $Server -ScriptBlock {
        param($Idx)
        Get-WmiObject Win32_IP4RouteTable |
            Where-Object { $_.InterfaceIndex -eq $Idx } |
            Select-Object Destination,Mask,NextHop,Metric1
    } -ArgumentList $NWAConfig.InterfaceIndex

    # Update <Routes> in the XML
    $routesNode = $xml.SelectSingleNode('//Routes')
    $routesNode.RemoveAll()  # remove any default placeholders

    foreach ($route in $Routes) {
        $newRoute = $xml.CreateElement("Route")
        $newRoute.SetAttribute("Destination", $route.Destination)
        $newRoute.SetAttribute("Mask",       $route.Mask)
        $newRoute.SetAttribute("NextHop",    $route.NextHop)
        $newRoute.SetAttribute("Metric1",    $route.Metric1)
        [void]$routesNode.AppendChild($newRoute)
    }

    # Save the updated XML
    Write-Host "Saving updated XML for $Server..."
    $xml.Save($XMLPath)

    Write-Host "Done processing $Server."
}

Write-Host "`nAll servers processed. The updated XML files are located in:"
Write-Host $XMLStore
