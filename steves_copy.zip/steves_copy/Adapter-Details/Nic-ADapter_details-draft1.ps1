﻿<# 
.SYNOPSIS
    Generates an XML configuration file for each server (physical or virtual)
    by pulling dynamic information such as hostname, FQDN, DNS alias, network
    configuration (IP, mask, gateway, DNS servers), and route table entries.

.DESCRIPTION
    This script is designed to create client-side XML files that describe
    how to connect to or manage a set of Windows servers. The XML files
    can be used by downstream tools or client software that rely on these
    configuration details.

    Key Features:
      1. Prompts for an environment (e.g., "VT", "PS") and reads a list of
         servers from 'ServerList.txt'.
      2. Retrieves DNS CName records for "prds.qldpol" from a specific DNS server
         (164.112.162.141), to populate the DNSAlias attribute.
      3. Filters network adapters so that only the active ("Up") NIC
         with a valid IPv4 address is used to populate IP, subnet, gateway,
         and DNS servers.
      4. Gathers the correct subnet mask and route table by matching the
         "InterfaceIndex" of that NIC, ensuring we only capture routes
         for the active interface.
      5. Inserts or updates `<Machine>` and `<NetworkAdapter>` attributes
         in the XML using a default template file, 'Default_AdapterDetail.xml'.
      6. Creates a `<Route>` element for each route on the active interface
         inside the `<Routes>` element, preserving the original XML structure.
      7. Saves each updated XML as '<ServerName>_AdapterDetail.xml' in a
         per-environment output folder, e.g., 'VT CollectedXMLs'.

.NOTES
    - Assumes you have PowerShell remoting (Invoke-Command) enabled on the servers
      so it can retrieve network configuration.
    - If any server is missing an active NIC or DNS alias, the script warns and
      continues to the next.
    - If you want all routes on the server, remove the interface-based filter.
    - Adjust the DNS server IP ("164.112.162.141") to suit your environment.

.EXAMPLE
    PS C:\Scripts> .\Generate-AdapterDetailXML.ps1
    Enter environment eg. VT, PS, etc.: VT
    Servers to process:
    [List of servers from ServerList.txt]
    Does this server list look correct? Y/N: Y
    Collecting DNS CName records for prds.qldpol...
    ...
    All servers processed. The updated XML files are located in: C:\Scripts\VT CollectedXMLs
#>


#region Parameters / Variables

$Environment = Read-Host -Prompt "Enter environment eg. VT, PS, etc."
$ServerList  = Get-Content -Path .\ServerList.txt
$ScriptPath  = (Get-Location).Path

Write-Host "`nServers to process:"
$ServerList | ForEach-Object { Write-Host " - $_" }

if ((Read-Host -Prompt "Does this server list look correct? Y/N") -eq "N") {
    Write-Warning "Exiting script at user request."
    return
}

# Default template path
$DefaultXML = Join-Path $ScriptPath "Default_AdapterDetail.xml"

# Output folder, e.g. "VT CollectedXMLs"
$XMLStore   = Join-Path $ScriptPath ("$Environment CollectedXMLs")

#endregion


#region Prepare Output Folder

if (Test-Path $XMLStore) {
    Write-Host "Removing existing folder: $XMLStore"
    Remove-Item -Path $XMLStore -Recurse -Force
}

Write-Host "Creating new folder: $XMLStore"
New-Item -ItemType Directory -Path $XMLStore | Out-Null

#endregion


#region Retrieve DNS Records for prds.qldpol

Write-Host "`nCollecting DNS CName records for prds.qldpol from 164.112.162.141..."

try {
    $DNSRecords = Get-DnsServerResourceRecord -ZoneName "prds.qldpol" `
                   -ComputerName "164.112.162.141" `
                   -RRType CName `
                   -ErrorAction Stop |
                Select-Object HostName, RecordData
}
catch {
    Write-Warning "Failed to retrieve DNS records. $_"
    return
}

#endregion


#region Process Each Server in the List

foreach ($Server in $ServerList) {
    Write-Host "`n---- Processing $Server ----"

    # Attempt to match $Server to the DNS alias from the retrieved records
    $DNSAlias = ($DNSRecords | Where-Object {
        ($_.RecordData.HostNameAlias -split '\.')[0] -eq $Server
    } | Select-Object -ExpandProperty HostName -ErrorAction SilentlyContinue)

    if (-not $DNSAlias) {
        Write-Warning "No matching DNS Alias found for $Server in prds.qldpol. Using server name."
        $DNSAlias = $Server
    }

    # If the DNSAlias is already fully qualified with ".prds.qldpol",
    # don't append it again.
    # trim trailing "." 
    $DNSAlias = $DNSAlias.TrimEnd('.')
    if ($DNSAlias -notmatch '\.prds\.qldpol$') {
        $DNSAlias = "$DNSAlias.prds.qldpol"
    }

    # Copy the default XML template and rename it for this server
    Write-Host "Copying default XML template for $Server..."
    $TempXML = "$Server`_AdapterDetail.xml"
    xcopy $DefaultXML $XMLStore /Q | Out-Null
    Rename-Item -Path (Join-Path $XMLStore "Default_AdapterDetail.xml") -NewName $TempXML

    # Load the XML for editing
    $XMLPath = Join-Path $XMLStore $TempXML
    [xml]$xml = Get-Content -Path $XMLPath

    # -- Update <Machine> attributes --
    $machineNode = $xml.SelectSingleNode('//Machine')
    $machineNode.SetAttribute("Name", $Server)
    # Example: If you want FQDN to be server.prds.qldpol
    $machineNode.SetAttribute("FQDN", "$Server.prds.qldpol")
    $machineNode.SetAttribute("DnsAlias", $DNSAlias)

    # Gather network adapter info from the remote server
    Write-Host "Collecting NIC configuration from $Server..."
    $NWAConfig = Invoke-Command -ComputerName $Server -ScriptBlock {
        Get-NetIPConfiguration -Detailed |
            Where-Object {
                $_.NetAdapter.Status -eq 'Up' -and              # NIC must be Up
                $_.IPv4Address -and                             # Must have an IPv4 address
                $_.IPv4Address.IPAddress -notmatch '169\.254\.' # Exclude APIPA
            } |
            Select-Object -First 1
    }

    if (-not $NWAConfig) {
        Write-Warning "No 'Up' NIC with a valid IPv4 address found on $Server. Skipping..."
        continue
    }

    # Get the subnet mask by matching the same interface index
    $SubnetMask = Invoke-Command -ComputerName $Server -ScriptBlock {
        param($Idx)
        Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE" |
            Where-Object { $_.InterfaceIndex -eq $Idx } |
            Select-Object -ExpandProperty IPSubnet
    } -ArgumentList $NWAConfig.InterfaceIndex

    # -- Update <NetworkAdapter> node --
    Write-Host "Updating NetworkAdapter in the XML for $Server..."
    $adapterNode = $xml.SelectSingleNode('//NetworkAdapter')

    $adapterNode.SetAttribute("Description", $NWAConfig.InterfaceDescription)
    $adapterNode.SetAttribute("Id", "NIC1")        # Or some static ID
    $adapterNode.SetAttribute("IpEnabled", "-1")
    $adapterNode.SetAttribute("IpAddress", $NWAConfig.IPv4Address.IPAddress)
    $adapterNode.SetAttribute("SubnetMask", ($SubnetMask -join ',')) # If multiple masks, join them
    $adapterNode.SetAttribute("Gateway", $NWAConfig.IPv4DefaultGateway.NextHop)
    $adapterNode.SetAttribute("Dhcp", "0")
    $adapterNode.SetAttribute("DNSDomain", "")
    $adapterNode.SetAttribute("DNSSuffix", "prds.qldpol")
    $adapterNode.SetAttribute("DNS-WINS", "0")

    # DNSOrder can be multiple addresses; join them if it's an array
    $dnsAddresses = $NWAConfig.DNSServer.ServerAddresses
    if ($dnsAddresses -is [System.Array]) {
        $adapterNode.SetAttribute("DNSOrder", $dnsAddresses -join ",")
    }
    else {
        $adapterNode.SetAttribute("DNSOrder", $dnsAddresses)
    }

    # Gather routes for the same interface index
    Write-Host "Collecting route table from $Server..."
    $Routes = Invoke-Command -ComputerName $Server -ScriptBlock {
        param($Idx)
        Get-WmiObject Win32_IP4RouteTable |
            Where-Object { $_.InterfaceIndex -eq $Idx } |
            Select-Object Destination,Mask,NextHop,Metric1
    } -ArgumentList $NWAConfig.InterfaceIndex

    # Update <Routes> in the XML
    $routesNode = $xml.SelectSingleNode('//Routes')
    # Clear out any existing placeholder routes in the template
    $routesNode.RemoveAll()

    foreach ($route in $Routes) {
        $newRoute = $xml.CreateElement("Route")
        $newRoute.SetAttribute("Destination", $route.Destination)
        $newRoute.SetAttribute("Mask",       $route.Mask)
        $newRoute.SetAttribute("NextHop",    $route.NextHop)
        $newRoute.SetAttribute("Metric1",    $route.Metric1)
        [void] $routesNode.AppendChild($newRoute)
    }

    # Save the updated XML
    Write-Host "Saving updated XML for $Server..."
    $xml.Save($XMLPath)

    Write-Host "Done processing $Server."
}

Write-Host "`nAll servers processed. The updated XML files are located in:"
Write-Host $XMLStore
