﻿<# 
    .SYNOPSIS
    Dynamically updates a default XML template with:
      - Hostname
      - FQDN
      - DNS Alias
      - Network adapter config (Description, IP, Subnet, Gateway, DNS)
      - Routes

    Includes logic to handle Windows Server 2019 NIC Teaming by filtering
    only the NIC that's "Up" and ignoring disconnected interfaces.
#>

#region Script Configuration

$Environment = Read-Host -Prompt "Enter environment eg. VT, PS, etc."
$ServerList  = Get-Content -Path .\ServerList.txt
$Path        = (Get-Location).Path

Write-Host "Servers to process:"
$ServerList
if ((Read-Host -Prompt "Does this server list look correct? Y/N") -eq "N") {
    Write-Warning "Exiting script at user request."
    return
}

# Paths
$DefaultXML = Join-Path $Path "Default_AdapterDetail.xml"
$XMLStore   = Join-Path $Path ("$Environment CollectedXMLs")

#endregion Script Configuration


#region Prepare Folder

# If the target folder already exists, remove it to ensure a clean run
if (Test-Path $XMLStore) {
    Remove-Item -Path $XMLStore -Recurse -Force
}
New-Item -ItemType Directory -Path $XMLStore | Out-Null

#endregion Prepare Folder


#region DNS Record Retrieval

Write-Host "Collecting DNS CName records for prds.qldpol..."
try {
    $DNSRecords = Get-DnsServerResourceRecord -ZoneName "prds.qldpol" `
                   -ComputerName "164.112.162.141" `
                   -RRType CName `
                   -ErrorAction Stop |
                Select-Object HostName, RecordData
}
catch {
    Write-Warning "Failed to retrieve DNS records. $_"
    return
}

#endregion DNS Record Retrieval


#region Process Each Server

foreach ($Server in $ServerList) {

    Write-Host "`n---- Processing $Server ----"

    # Match the server's "alias" in the DNS records
    #   Splitting the HostNameAlias to strip off the domain portion
    $DNSAlias = ($DNSRecords | Where-Object {
        ($_.RecordData.HostNameAlias -split '\.')[0] -eq $Server
    } | Select-Object -ExpandProperty HostName -ErrorAction SilentlyContinue)

    # If no DNSAlias was found, default to the server name
    if (-not $DNSAlias) {
        Write-Warning "No matching DNS Alias found for $Server in prds.qldpol, using server name."
        $DNSAlias = $Server
    }

    # Copy the default XML template and rename it for this server
    Write-Host "Copying default XML template..."
    $TempXML = "$Server`_AdapterDetail.xml"
    xcopy $DefaultXML $XMLStore /Q | Out-Null
    Rename-Item -Path (Join-Path $XMLStore "Default_AdapterDetail.xml") -NewName $TempXML

    # Load the XML for editing
    $XMLPath = Join-Path $XMLStore $TempXML
    [xml]$xml = Get-Content -Path $XMLPath

    # -- Update <Machine> attributes --
    #    Keep "Id", "Template", "Sysprep", "Enabled" from template.
    $machineNode = $xml.SelectSingleNode('//Machine')
    $machineNode.SetAttribute("Name", $Server)
    $machineNode.SetAttribute("FQDN", "$Server.prds.qldpol")   # or "" if you prefer it blank
    $machineNode.SetAttribute("DnsAlias", "$DNSAlias.prds.qldpol")

    # -- Retrieve NIC info from the remote server --
    Write-Host "Collecting NIC configuration from $Server..."
    $NWAConfig = Invoke-Command -ComputerName $Server -ScriptBlock {
        Get-NetIPConfiguration -Detailed |
            Where-Object {
                $_.NetAdapter.Status -eq 'Up' -and              # NIC must be Up
                $_.IPv4Address -and                             # Must have an IPv4 address
                $_.IPv4Address.IPAddress -notmatch '169\.254\.' # Exclude APIPA
            } |
            Select-Object -First 1
    }

    if (-not $NWAConfig) {
        Write-Warning "No 'Up' NIC with valid IPv4 found on $Server. Skipping..."
        continue
    }

    # -- Retrieve the subnet mask matching the same InterfaceIndex --
    $SubnetMask = Invoke-Command -ComputerName $Server -ScriptBlock {
        param($Idx)
        $config = Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE" |
                  Where-Object { $_.InterfaceIndex -eq $Idx }
        $config.IPSubnet
    } -ArgumentList $NWAConfig.InterfaceIndex

    # -- Update <NetworkAdapter> node --
    Write-Host "Updating NetworkAdapter in the XML for $Server..."
    $adapterNode = $xml.SelectSingleNode('//NetworkAdapter')

    # Use the existing attributes from the template, or override as needed
    $adapterNode.SetAttribute("Description", $NWAConfig.InterfaceDescription)
    $adapterNode.SetAttribute("Id", "NIC1")  # or "6", depending on your needs
    $adapterNode.SetAttribute("IpEnabled", "-1")
    $adapterNode.SetAttribute("IpAddress", $NWAConfig.IPv4Address.IPAddress)
    $adapterNode.SetAttribute("SubnetMask", $SubnetMask -join ',') # if multiple, join them
    $adapterNode.SetAttribute("Gateway", $NWAConfig.IPv4DefaultGateway.NextHop)
    $adapterNode.SetAttribute("Dhcp", "0")
    $adapterNode.SetAttribute("DNSDomain", "")
    $adapterNode.SetAttribute("DNSSuffix", "prds.qldpol")
    $adapterNode.SetAttribute("DNS-WINS", "0")

    # DNSOrder can contain multiple addresses, so join them if needed
    $dnsAddresses = $NWAConfig.DNSServer.ServerAddresses
    if ($dnsAddresses -is [System.Array]) {
        $adapterNode.SetAttribute("DNSOrder", $dnsAddresses -join ",")
    }
    else {
        $adapterNode.SetAttribute("DNSOrder", $dnsAddresses)
    }

    # -- Retrieve routes for the same InterfaceIndex --
    Write-Host "Collecting route table from $Server..."
    $Routes = Invoke-Command -ComputerName $Server -ScriptBlock {
        param($Idx)
        Get-WmiObject Win32_IP4RouteTable |
            Where-Object { $_.InterfaceIndex -eq $Idx } |
            Select-Object Destination,Mask,NextHop,Metric1
    } -ArgumentList $NWAConfig.InterfaceIndex

    # -- Update <Routes> in the XML --
    $routesNode = $xml.SelectSingleNode('//Routes')
    # Clear out old routes if the default template has placeholders
    $routesNode.RemoveAll()

    foreach ($route in $Routes) {
        $newRoute = $xml.CreateElement("Route")
        $newRoute.SetAttribute("Destination", $route.Destination)
        $newRoute.SetAttribute("Mask",       $route.Mask)
        $newRoute.SetAttribute("NextHop",    $route.NextHop)
        $newRoute.SetAttribute("Metric1",    $route.Metric1)
        [void] $routesNode.AppendChild($newRoute)
    }

    # -- Save changes --
    Write-Host "Saving updated XML for $Server..."
    $xml.Save($XMLPath)

    Write-Host "Done processing $Server."
}

#endregion Process Each Server

Write-Host "`nAll servers processed. The updated XML files are located in:"
Write-Host $XMLStore
