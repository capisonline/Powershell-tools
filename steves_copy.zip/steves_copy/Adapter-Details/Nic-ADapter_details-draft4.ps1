﻿<# 
.SYNOPSIS
    Dynamically creates XML configuration files for servers (physical or virtual),
    populating attributes for hostnames, FQDN, DNS alias, IP settings, and routes.

.DESCRIPTION
    This script is intended to generate client-side XML files (e.g., for
    provisioning or configuration management tools) based on each server’s
    network configuration. It reads server names from 'ServerList.txt',
    retrieves DNS CNAME records for the 'prds.qldpol' domain, and queries
    each server for:
      - The “Up” network adapter (skipping disconnected or APIPA addresses)
      - Subnet mask and route table for that adapter’s InterfaceIndex

    These dynamic values are inserted into an XML template, 'Default_AdapterDetail.xml',
    resulting in a file named '<ServerName>_AdapterDetail.xml' for each server. The
    script handles potential trailing dots in DNS data (e.g. 'server.prds.qldpol.')
    to avoid duplicating the domain suffix.

.NOTES
    - Requires PowerShell remoting to be enabled on target servers.
    - Adjust the DNS server IP (164.112.162.141) if needed.
    - If you want to capture all routes (not just those tied to the “Up” NIC),
      remove or modify the InterfaceIndex filter.
    - If your DNS domain is not 'prds.qldpol', change the domain references.

.EXAMPLE
    PS C:\Scripts> .\Generate-AdapterDetailXML.ps1
    Enter environment eg. VT, PS, etc.: VT
    Servers to process:
     - Server1
     - Server2
    Does this server list look correct? Y/N: Y
    
    Collecting DNS CName records for prds.qldpol from 164.112.162.141...
    ---- Processing Server1 ----
    Raw DNSAlias: 'server1.prds.qldpol.'
    Normalized DNSAlias: 'server1.prds.qldpol'
    Final DNSAlias: 'server1.prds.qldpol'
    Copying default XML template for Server1...
    Collecting NIC configuration from Server1...
    ...
    Done processing Server1.
    ---- Processing Server2 ----
    ...
    All servers processed. The updated XML files are located in:
    C:\Scripts\VT CollectedXMLs

#>


#region Parameters / Variables

$Environment = Read-Host -Prompt "Enter environment eg. VT, PS, etc."
$ServerList  = Get-Content -Path .\ServerList.txt
$ScriptPath  = (Get-Location).Path

Write-Host "`nServers to process:"
$ServerList | ForEach-Object { Write-Host " - $_" }

if ((Read-Host -Prompt "Does this server list look correct? Y/N") -eq "N") {
    Write-Warning "Exiting script at user request."
    return
}

# Default template path
$DefaultXML = Join-Path $ScriptPath "Default_AdapterDetail.xml"

# Output folder, e.g. "VT CollectedXMLs"
$XMLStore = Join-Path $ScriptPath ("$Environment CollectedXMLs")

#endregion Parameters / Variables


#region Prepare Output Folder

if (Test-Path $XMLStore) {
    Write-Host "Removing existing folder: $XMLStore"
    Remove-Item -Path $XMLStore -Recurse -Force
}

Write-Host "Creating new folder: $XMLStore"
New-Item -ItemType Directory -Path $XMLStore | Out-Null

#endregion Prepare Output Folder


#region Retrieve DNS Records for prds.qldpol

Write-Host "`nCollecting DNS CName records for prds.qldpol from 164.112.162.141..."

try {
    $DNSRecords = Get-DnsServerResourceRecord -ZoneName "prds.qldpol" `
                   -ComputerName "164.112.162.141" `
                   -RRType CName `
                   -ErrorAction Stop |
                Select-Object HostName, RecordData
}
catch {
    Write-Warning "Failed to retrieve DNS records. $_"
    return
}

#endregion Retrieve DNS Records


#region Process Each Server

foreach ($Server in $ServerList) {
    Write-Host "`n---- Processing $Server ----"

    # Attempt to find this server's DNS alias (CNAME) in the records
    # Compare the entire HostNameAlias (minus trailing '.') to "<Server>.prds.qldpol"
    $aliasRecord = $DNSRecords |
        Where-Object {
            # Make sure RecordData and HostNameAlias are present before calling TrimEnd().
            $_.RecordData -and $_.RecordData.HostNameAlias -and
            $_.RecordData.HostNameAlias.TrimEnd('.') -eq "$Server.prds.qldpol"
        } |
        Select-Object -First 1

    # If we found a record, use its HostNameAlias. Otherwise, fallback to the server name.
    if ($aliasRecord) {
        $DNSAlias = $aliasRecord.RecordData.HostNameAlias
    }
    else {
        Write-Warning "No matching DNS Alias found for $Server in prds.qldpol. Using server name."
        $DNSAlias = $Server
    }

    Write-Host "Raw DNSAlias: '$DNSAlias'"

    # Normalize case & remove trailing dot(s)
    $DNSAlias = $DNSAlias.ToLower().TrimEnd('.')
    Write-Host "Normalized DNSAlias: '$DNSAlias'"

    # Append .prds.qldpol if not already present
    if ($DNSAlias -notmatch '\.prds\.qldpol$') {
        $DNSAlias = "$DNSAlias.prds.qldpol"
    }
    Write-Host "Final DNSAlias: '$DNSAlias'"

    # Copy the default XML template and rename it for this server
    Write-Host "Copying default XML template for $Server..."
    $TempXML = "$Server`_AdapterDetail.xml"
    xcopy $DefaultXML $XMLStore /Q | Out-Null
    Rename-Item -Path (Join-Path $XMLStore "Default_AdapterDetail.xml") -NewName $TempXML

    # Load the XML for editing
    $XMLPath = Join-Path $XMLStore $TempXML
    [xml]$xml = Get-Content -Path $XMLPath

    # --- Update <Machine> attributes ---
    $machineNode = $xml.SelectSingleNode('//Machine')
    $machineNode.SetAttribute("Name", $Server)
    $machineNode.SetAttribute("FQDN", "$Server.prds.qldpol")
    $machineNode.SetAttribute("DnsAlias", $DNSAlias)

    # Collect network adapter info from the remote server
    Write-Host "Collecting NIC configuration from $Server..."
    $NWAConfig = Invoke-Command -ComputerName $Server -ScriptBlock {
        Get-NetIPConfiguration -Detailed |
            Where-Object {
                $_.NetAdapter.Status -eq 'Up' -and
                $_.IPv4Address -and
                $_.IPv4Address.IPAddress -notmatch '169\.254\.'
            } |
            Select-Object -First 1
    }

    if (-not $NWAConfig) {
        Write-Warning "No 'Up' NIC with a valid IPv4 address found on $Server. Skipping..."
        continue
    }

    # Get the subnet mask by matching the same interface index
    $SubnetMask = Invoke-Command -ComputerName $Server -ScriptBlock {
        param($Idx)
        Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE" |
            Where-Object { $_.InterfaceIndex -eq $Idx } |
            Select-Object -ExpandProperty IPSubnet
    } -ArgumentList $NWAConfig.InterfaceIndex

    # --- Update <NetworkAdapter> node ---
    Write-Host "Updating NetworkAdapter in the XML for $Server..."
    $adapterNode = $xml.SelectSingleNode('//NetworkAdapter')

    $adapterNode.SetAttribute("Description", $NWAConfig.InterfaceDescription)
    $adapterNode.SetAttribute("Id", "NIC1")
    $adapterNode.SetAttribute("IpEnabled", "-1")
    $adapterNode.SetAttribute("IpAddress", $NWAConfig.IPv4Address.IPAddress)
    $adapterNode.SetAttribute("SubnetMask", ($SubnetMask -join ','))
    $adapterNode.SetAttribute("Gateway", $NWAConfig.IPv4DefaultGateway.NextHop)
    $adapterNode.SetAttribute("Dhcp", "0")
    $adapterNode.SetAttribute("DNSDomain", "")
    $adapterNode.SetAttribute("DNSSuffix", "prds.qldpol")
    $adapterNode.SetAttribute("DNS-WINS", "0")

    # DNS can have multiple servers; join if needed
    $dnsAddresses = $NWAConfig.DNSServer.ServerAddresses
    if ($dnsAddresses -is [System.Array]) {
        $adapterNode.SetAttribute("DNSOrder", $dnsAddresses -join ",")
    }
    else {
        $adapterNode.SetAttribute("DNSOrder", $dnsAddresses)
    }

    # Gather routes for the same interface index
    Write-Host "Collecting route table from $Server..."
    $Routes = Invoke-Command -ComputerName $Server -ScriptBlock {
        param($Idx)
        Get-WmiObject Win32_IP4RouteTable |
            Where-Object { $_.InterfaceIndex -eq $Idx } |
            Select-Object Destination,Mask,NextHop,Metric1
    } -ArgumentList $NWAConfig.InterfaceIndex

    # Update <Routes> in the XML
    $routesNode = $xml.SelectSingleNode('//Routes')
    # Remove any placeholder routes in the template
    $routesNode.RemoveAll()

    foreach ($route in $Routes) {
        $newRoute = $xml.CreateElement("Route")
        $newRoute.SetAttribute("Destination", $route.Destination)
        $newRoute.SetAttribute("Mask",       $route.Mask)
        $newRoute.SetAttribute("NextHop",    $route.NextHop)
        $newRoute.SetAttribute("Metric1",    $route.Metric1)
        [void] $routesNode.AppendChild($newRoute)
    }

    # Save the updated XML
    Write-Host "Saving updated XML for $Server..."
    $xml.Save($XMLPath)

    Write-Host "Done processing $Server."
}

Write-Host "`nAll servers processed. The updated XML files are located in:"
Write-Host $XMLStore

#endregion Process Each Server

