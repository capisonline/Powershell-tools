﻿# ----- Configuration -----
$TelegrafSource = "C:\temp\QCAD\Dashboards\monitoring\telegraf-1.34.3_windows_amd64\telegraf-1.34.3"
$RemotePath = "C$\Program Files\Telegraf"
$Servers = @(
    "QCAD-SRV01",
    "QCAD-SRV02"
    # Add more as needed
)
$LogPath = "C:\temp\telegraf_deploy_log.txt"
# --------------------------

# Create log file
"Telegraf Deployment Log - $(Get-Date)" | Out-File $LogPath

foreach ($server in $Servers) {
    Write-Host "Deploying to $server..." -ForegroundColor Cyan
    Add-Content $LogPath "`n--- [$server] ---"

    try {
        # Create remote directory
        Invoke-Command -ComputerName $server -ScriptBlock {
            New-Item -ItemType Directory -Path "C:\Program Files\Telegraf" -Force
        }

        # Copy files to remote server
        $UNCPath = "\\$server\$RemotePath"
        Copy-Item -Path "$TelegrafSource\*" -Destination $UNCPath -Recurse -Force

        # Install Telegraf service remotely
        Invoke-Command -ComputerName $server -ScriptBlock {
            Set-Location "C:\Program Files\Telegraf"
            .\telegraf.exe --service install
        }

        # Start the service
        Invoke-Command -ComputerName $server -ScriptBlock {
            Start-Service telegraf
        }

        # Check status
        $status = Invoke-Command -ComputerName $server -ScriptBlock {
            (Get-Service telegraf).Status
        }

        Add-Content $LogPath "$server: SUCCESS. Telegraf service status: $status"
        Write-Host "$server: Telegraf installed and $status" -ForegroundColor Green
    }
    catch {
        Add-Content $LogPath "$server: ERROR - $_"
        Write-Host "$server: FAILED - $_" -ForegroundColor Red
    }
}
