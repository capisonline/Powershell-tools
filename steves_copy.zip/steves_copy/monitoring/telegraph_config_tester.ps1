﻿# Settings
$TelegrafPath = "C:\Program Files\Telegraf\telegraf.exe"
$ConfigPath = "C:\Program Files\Telegraf\telegraf.conf"
$OutputCSV = "C:\temp\telegraf_test_output.csv"

# Run Telegraf test
$lines = & $TelegrafPath --config $ConfigPath --test 2>&1

# Prepare results
$results = @()

foreach ($line in $lines) {
    # Skip non-metric lines
    if (-not $line.StartsWith("> ")) { continue }

    # Clean and trim the line
    $metricLine = $line.Substring(2).Trim()

    # Match: measurement,[tags] [fields] [timestamp]
    if ($metricLine -match '^([^ ]+)\s([^"]+?)\s(\d+)$') {
        $tagPart = $matches[1]
        $fieldPart = $matches[2]
        $timestamp = $matches[3]

        $measurement = ($tagPart -split ",")[0]
        $tags = ($tagPart -split "," | Select-Object -Skip 1) -join ","

        $host = if ($tags -match "host=([^,]+)") { $matches[1] } else { "unknown" }

        $results += [PSCustomObject]@{
            Measurement = $measurement
            Host        = $host
            Tags        = $tags
            Fields      = $fieldPart
            Timestamp   = $timestamp
        }
    } else {
        Write-Host "Could not parse metric line:`n$line"
    }
}

# Save to CSV
if ($results.Count -gt 0) {
    $results | Export-Csv -NoTypeInformation -Path $OutputCSV
    Write-Host "`nMetrics saved to: $OutputCSV"
} else {
    Write-Warning "No metrics parsed. Output file not created."
}
