﻿# https://techdocs.broadcom.com/us/en/vmware-cis/aria/aria-operations/8-14/vmware-aria-operations-configuration-guide-8-14/connect-to-data-sources/monitoring-applications-and-os-using-open-source-telegraf/monitoring-applications-using-open-source-telegraf/install-and-configure-open-source-telegraf.html
# https://www.influxdata.com/time-series-platform/telegraf/
wget https://dl.influxdata.com/telegraf/releases/telegraf-1.34.3_windows_amd64.zip -UseBasicParsing -OutFile "C:\temp\QCAD\Dashboards\monitoring\telegraf-1.34.3_windows_amd64.zip"
