﻿# QCAD Telegraf Multi-Server Deployment Script
# --------------------------------------------
# Deploys Telegraf to a list of servers by:
# 1. Reading the appropriate [global_tags] block for each hostname
# 2. Merging the matching tag block with the base config
# 3. Copying the Telegraf binary and merged config to the remote server
# 4. Validating the configuration
# 5. Installing and starting the Telegraf service
# 6. Logging any deployment errors

$ServerList = Get-Content "C:\temp\QCAD\VT\monitoring\VT_NEW_Server_list.txt"
$ErrorActionPreference = 'Stop'

# --- Paths ---
$TagFile         = "C:\temp\QCAD\Dashboards\monitoring\telegraf-1.34.3_windows_amd64\telegraf-1.34.3\qcad_telegraf_tags.conf"
$BaseConfig      = "C:\temp\QCAD\Dashboards\monitoring\telegraf-1.34.3_windows_amd64\telegraf-1.34.3\telegraf.conf"
$TelegrafSource  = "C:\temp\QCAD\Dashboards\monitoring\telegraf-1.34.3_windows_amd64\telegraf-1.34.3"
$RemoteInstall   = "C$\Program Files\Telegraf"
$LogFile         = "C:\temp\telegraf_deploy_errors.txt"

# Ensure log path exists
if (-not (Test-Path $LogFile)) {
    New-Item -Path $LogFile -ItemType File -Force | Out-Null
}

foreach ($Server in $ServerList) {
    Write-Host "`n--- Deploying to $Server ---" -ForegroundColor Cyan

    try {
        # Step 0: Validate local paths
        if (-not (Test-Path $TagFile))        { throw "Missing TagFile: $TagFile" }
        if (-not (Test-Path $BaseConfig))     { throw "Missing BaseConfig: $BaseConfig" }
        if (-not (Test-Path $TelegrafSource)) { throw "Missing Telegraf source: $TelegrafSource" }

        # Step 1: Extract matching tag block
        $TagBlocks = [regex]::Matches((Get-Content $TagFile -Raw), '(?s)\[global_tags\](.+?)(?=\[global_tags\]|\Z)')
        $TagBlock = $null
        foreach ($block in $TagBlocks) {
            if ($block.Value -match "host\s*=\s*`"$Server`"") {
                $TagBlock = "[global_tags]$($block.Groups[1].Value)"
                break
            }
        }

        if (-not $TagBlock) {
            Write-Warning "${Server}: No tag block found — skipping"
            continue
        }

        $BaseContent = Get-Content $BaseConfig -Raw
        $FinalConf = $BaseContent -replace '(?m)^# PLACEHOLDER: global_tags will be injected here.*$', $TagBlock

        # Step 2: Save merged config to local temp
        $TempConf = "C:\temp\telegraf_$Server.conf"
        $FinalConf | Out-File -FilePath $TempConf -Encoding utf8 -Force

        # Step 3: Create remote target folder
        Invoke-Command -ComputerName $Server -ScriptBlock {
            New-Item -Path "C:\Program Files\Telegraf" -ItemType Directory -Force | Out-Null
        }

        # Step 4: Copy files and config
        $UNCPath = "\\$Server\$RemoteInstall"
        if (-not (Test-Path "$TelegrafSource\telegraf.exe")) {
            throw "Telegraf source missing expected file: telegraf.exe"
        }

        Copy-Item "$TelegrafSource\*" "$UNCPath" -Recurse -Force
        Copy-Item $TempConf "$UNCPath\telegraf.conf" -Force
        Remove-Item $TempConf -Force

        # Step 5: Validate config + install/start service
        Invoke-Command -ComputerName $Server -ScriptBlock {
            $exe = "C:\Program Files\Telegraf\telegraf.exe"
            $conf = "C:\Program Files\Telegraf\telegraf.conf"

            if (-not (Test-Path $exe))  { throw "Missing Telegraf executable on remote server" }
            if (-not (Test-Path $conf)) { throw "Missing Telegraf config on remote server" }

            & $exe --config $conf --test | Out-Null

            if (-not (Get-Service -Name telegraf -ErrorAction SilentlyContinue)) {
                & $exe --service install
            }

            Restart-Service telegraf -ErrorAction Stop
        }

        Write-Host "${Server}: Telegraf deployed and started" -ForegroundColor Green
    }
    catch {
        $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        $errMsg = "${Server}: Deployment failed — $($_.Exception.Message)"
        Write-Host $errMsg -ForegroundColor Red
        Add-Content -Path $LogFile -Value "$timestamp - $errMsg"
    }
}
