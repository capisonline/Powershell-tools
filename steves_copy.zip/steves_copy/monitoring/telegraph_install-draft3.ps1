# QCAD Telegraf Multi-Server Deployment Script
# --------------------------------------------
# Deploys Telegraf to a list of servers by:
# 1. Reading the appropriate [global_tags] block for each hostname
# 2. Replacing the placeholder in base config with that tag block
# 3. Copying the Telegraf binary and merged config to the remote server
# 4. Validating the configuration
# 5. Installing and starting the Telegraf service
# 6. Confirming that the service is running
# 7. Logging deployment events and any failures

$ServerList      = Get-Content "C:\temp\QCAD\VT\monitoring\VT_NEW_Server_list.txt"
$ErrorActionPreference = 'Stop'

# --- Paths ---
$TagFile         = "C:\temp\QCAD\Dashboards\monitoring\telegraf-1.34.3_windows_amd64\telegraf-1.34.3\qcad_telegraf_tags.conf"
$BaseConfig      = "C:\temp\QCAD\Dashboards\monitoring\telegraf-1.34.3_windows_amd64\telegraf-1.34.3\telegraf.conf"
$TelegrafSource  = "C:\temp\QCAD\Dashboards\monitoring\telegraf-1.34.3_windows_amd64\telegraf-1.34.3"
$RemoteInstall   = "C$\Program Files\Telegraf"
$LogFile         = "C:\temp\telegraf_deploy_errors.txt"

# Ensure log path exists
if (-not (Test-Path $LogFile)) {
    New-Item -Path $LogFile -ItemType File -Force | Out-Null
}

foreach ($Server in $ServerList) {
    Write-Host "`n--- Deploying to $Server ---" -ForegroundColor Cyan

    try {
        # Step 0: Validate local paths
        if (-not (Test-Path $TagFile))        { throw "Missing TagFile: $TagFile" }
        if (-not (Test-Path $BaseConfig))     { throw "Missing BaseConfig: $BaseConfig" }
        if (-not (Test-Path $TelegrafSource)) { throw "Missing Telegraf source: $TelegrafSource" }

        # Step 1: Extract matching tag block
        Write-Host "Looking for matching tag block for $Server..." -ForegroundColor DarkGray
        $TagBlocks = [regex]::Matches((Get-Content $TagFile -Raw), '(?s)\[global_tags\](.+?)(?=\[global_tags\]|\Z)')
        $TagBlock = $null
        foreach ($block in $TagBlocks) {
            $pattern = "host\s*=\s*`"" + [regex]::Escape($Server) + "`""
            if ($block.Value -match $pattern) {
                $TagBlock = "[global_tags]`n$($block.Groups[1].Value.Trim())"
                break
            }
        }

        if (-not $TagBlock) {
            $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            $warningMsg = "${Server}: No tag block found, skipping"
            Write-Warning $warningMsg
            Add-Content -Path $LogFile -Value "$timestamp - $warningMsg"
            continue
        }

        # Step 2: Inject into base config at placeholder
        Write-Host "Injecting tag block into base config..." -ForegroundColor DarkGray
        $BaseContent = Get-Content $BaseConfig -Raw
        $FinalConf = $BaseContent -replace '(?m)^# PLACEHOLDER: global_tags will be injected here.*$', $TagBlock

        $TempConf = "C:\temp\telegraf_$Server.conf"
        $FinalConf | Out-File -FilePath $TempConf -Encoding utf8 -Force

        # Step 3: Create remote folder
        Write-Host "Creating remote target folder on $Server..." -ForegroundColor DarkGray
        Invoke-Command -ComputerName $Server -ScriptBlock {
            New-Item -Path "C:\Program Files\Telegraf" -ItemType Directory -Force | Out-Null
        }

        # Step 4: Copy files to remote server
        Write-Host "Copying Telegraf files and config to $Server..." -ForegroundColor DarkGray
        $UNCPath = "\\$Server\$RemoteInstall"
        if (-not (Test-Path "$TelegrafSource\telegraf.exe")) {
            throw "Telegraf source missing expected file: telegraf.exe"
        }

        Copy-Item "$TelegrafSource\*" "$UNCPath" -Recurse -Force
        Copy-Item $TempConf "$UNCPath\telegraf.conf" -Force
        Remove-Item $TempConf -Force

        # Step 5: Validate config + install/start service
        Write-Host "Validating Telegraf config and ensuring service is installed..." -ForegroundColor DarkGray
        Invoke-Command -ComputerName $Server -ScriptBlock {
            $exe = "C:\Program Files\Telegraf\telegraf.exe"
            $conf = "C:\Program Files\Telegraf\telegraf.conf"

            if (-not (Test-Path $exe))  { throw "Missing Telegraf executable on remote server" }
            if (-not (Test-Path $conf)) { throw "Missing Telegraf config on remote server" }

            & $exe --config $conf --test *>$null

            if (-not (Get-Service -Name telegraf -ErrorAction SilentlyContinue)) {
                & $exe service install
                Start-Sleep -Seconds 3
            }

            Start-Service telegraf -ErrorAction Stop
            $svc = Get-Service -Name telegraf
            if ($svc.Status -ne 'Running') {
                throw "Telegraf service is installed but not running"
            }
        }

        Write-Host "${Server}: Telegraf deployed and running" -ForegroundColor Green
    }
    catch {
        $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        $errMsg = "${Server}: Deployment failed � $($_.Exception.Message)"
        Write-Host $errMsg -ForegroundColor Red
        Add-Content -Path $LogFile -Value "$timestamp - $errMsg"
    }
}
