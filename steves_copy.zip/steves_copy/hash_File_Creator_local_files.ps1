﻿$root = 'C:\temp\QCAD\VT\Issues\File_Hashes\Vision Sauce\ARCHIVE\4.13.45\4.13.45'
$out  = 'C:\temp\QCAD\VT\Issues\File_Hashes\Vision Sauce\ARCHIVE\4.13.45\4.13.45\file_inventory2.csv'

Get-ChildItem -Path $root -Recurse -File  |
  Select-Object FullName,
                Name,
                Extension,
                @{n='FileVersion';e={$_.VersionInfo.FileVersion}},
                @{n='ProductVersion';e={$_.VersionInfo.ProductVersion}},
                CreationTime,
                LastWriteTime,
                @{n='HashSHA256';e={(Get-FileHash -Algorithm SHA256 -Path $_.FullName).Hash}} |
  Export-Csv -Path $out -NoTypeInformation
