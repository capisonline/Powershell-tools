﻿Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

# Load counter list from text file
$counterFile = Join-Path $PSScriptRoot "counters.txt"
if (-not (Test-Path $counterFile)) {
    [System.Windows.MessageBox]::Show("Missing counters.txt", "Error", "OK", "Error")
    exit
}
$counters = Get-Content $counterFile | Where-Object { $_ -and $_ -notmatch '^#' }

# XAML for GUI layout
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="QCAD Live Perf Counters" Height="500" Width="850">
    <DockPanel>
        <Button Name="StopButton" Content="Stop Refresh" DockPanel.Dock="Bottom" Height="30" Margin="5"/>
        <DataGrid Name="CounterGrid" AutoGenerateColumns="True" IsReadOnly="True" Margin="5"/>
    </DockPanel>
</Window>
"@

# Load the GUI
$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

$grid = $window.FindName("CounterGrid")
$stopButton = $window.FindName("StopButton")

# Create the DispatcherTimer (WPF-safe)
$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromSeconds(2)

# Update action
$updateAction = {
    try {
        $results = Get-Counter -Counter $counters -SampleInterval 1 -MaxSamples 1
        $data = $results.CounterSamples | ForEach-Object {
            [PSCustomObject]@{
                Time     = $_.TimeStamp.ToString("HH:mm:ss")
                Counter  = $_.Path
                Value    = [math]::Round($_.CookedValue, 2)
            }
        }
        $grid.ItemsSource = $data
    } catch {
        Write-Warning "Error: $_"
    }
}

# Hook up the tick event and start
$timer.add_Tick($updateAction)
$timer.Start()

# Stop button logic
$stopButton.Add_Click({
    $timer.Stop()
    $stopButton.Content = "Stopped"
    $stopButton.IsEnabled = $false
})

# Show the window (modal)
$null = $window.ShowDialog()
