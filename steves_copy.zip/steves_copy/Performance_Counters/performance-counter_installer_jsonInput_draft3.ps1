﻿# QCAD Performance Counter Installer
# Author: QPS Engineering
# Date: 2025-06-19
# Purpose: Safely deploy performance counters based on historical JSON exports from older servers.
# Execution Context: Run from PowerShell ISE on a management workstation with access to target servers

# ----------------------------
# INPUT VARIABLES (set here)
# ----------------------------
$InputCsvPath     = "C:\temp\QCAD\VT\performance-counters\Discovery\installs\source_input-vas3.csv"      # CSV format: OLD_Server,NEW_Server
$CounterRootFolder = "C:\temp\QCAD\VT\performance-counters\Discovery\backups\OLD_VT"                # Folder containing subfolders named after OLD_Server with .json files inside
$LogOutputFolder   = "C:\temp\QCAD\VT\performance-counters\Discovery\installs\"                     # Folder where per-server logs will be stored

# ----------------------------
function Write-Log {
    param (
        [string]$Message,
        [string]$Server
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logLine = "$timestamp [$Server] $Message"
    Write-Output $logLine
    Add-Content -Path "$LogOutputFolder\$Server.log" -Value $logLine
}

function Load-JsonCounters {
    param (
        [string]$JsonPath
    )
    try {
        return Get-Content $JsonPath -Raw | ConvertFrom-Json
    } catch {
        return $null
    }
}

# ----------------------------
# MAIN SCRIPT
# ----------------------------
$serverPairs = Import-Csv -Path $InputCsvPath
foreach ($pair in $serverPairs) {
    $old = $pair.OLD_Server.Trim()
    $new = $pair.NEW_Server.Trim()
    $jsonFolder = Join-Path $CounterRootFolder $old
    $logPath = Join-Path $LogOutputFolder "$new.log"

    "" | Out-File $logPath  # Clear previous logs
    Write-Log "Starting performance counter audit and creation." $new

    $jsonFiles = Get-ChildItem -Path $jsonFolder -Filter *.json -ErrorAction SilentlyContinue
    if (!$jsonFiles) {
        Write-Log "No JSON files found in $jsonFolder. Skipping." $new
        continue
    }

    foreach ($jsonFile in $jsonFiles) {
        $jsonPath = $jsonFile.FullName
        $countersData = Load-JsonCounters -JsonPath $jsonPath
        if (!$countersData) {
            Write-Log "Failed to parse JSON: $jsonPath" $new
            continue
        }

        foreach ($category in $countersData) {
            $categoryName = $category.CategoryName
            $exists = Invoke-Command -ComputerName $new -ScriptBlock {
                param($categoryName)
                return [System.Diagnostics.PerformanceCounterCategory]::Exists($categoryName)
            } -ArgumentList $categoryName

            if ($exists) {
                Write-Log "Category already exists: $categoryName. Skipping creation." $new

                $existing = Invoke-Command -ComputerName $new -ScriptBlock {
                    param($categoryName)
                    $cat = New-Object System.Diagnostics.PerformanceCounterCategory($categoryName)
                    $cat.GetCounters() | ForEach-Object {
                        [PSCustomObject]@{
                            CounterName = $_.CounterName
                            CounterType = $_.CounterType
                        }
                    }
                } -ArgumentList $categoryName

                foreach ($item in $existing) {
                    Write-Log "    Found Counter: $($item.CounterName) ($($item.CounterType))" $new
                }
                continue
            }

            # Build counter definitions for remoting
            $counterDefinitions = @()
            foreach ($counter in $category.Counters) {
                $counterDefinitions += [PSCustomObject]@{
                    Name  = $counter.CounterName
                    Help  = $counter.CounterHelp
                    Type  = $counter.CounterType
                }
            }

            Invoke-Command -ComputerName $new -ScriptBlock {
                param($categoryName, $categoryHelp, $counterDefinitions)

                $collection = New-Object System.Diagnostics.CounterCreationDataCollection
                foreach ($def in $counterDefinitions) {
                    $ccd = New-Object System.Diagnostics.CounterCreationData
                    $ccd.CounterName = $def.Name
                    $ccd.CounterHelp = $def.Help
                    $ccd.CounterType = [System.Diagnostics.PerformanceCounterType]::$($def.Type)
                    $collection.Add($ccd)
                }

                [System.Diagnostics.PerformanceCounterCategory]::Create(
                    $categoryName,
                    $categoryHelp,
                    [System.Diagnostics.PerformanceCounterCategoryType]::SingleInstance,
                    $collection
                )
            } -ArgumentList $category.CategoryName, $category.CategoryHelp, $counterDefinitions

            Write-Log "Created new category: $($category.CategoryName) with $($category.Counters.Count) counters." $new

            foreach ($counter in $category.Counters) {
                Write-Log "    Created Counter: $($counter.CounterName) ($($counter.CounterType))" $new
            }
        }
    }
    Write-Log "Finished processing $new." $new
}
