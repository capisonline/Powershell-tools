﻿<#
.SYNOPSIS
    Extracts and backs up Performance Counter metadata from remote Windows servers and saves the data as JSON files locally with detailed logging.

.DESCRIPTION
    This script queries a list of Windows Performance Counter categories on a group of remote servers, exports metadata 
    for each category (including all counters and their properties), saves the data as JSON on the remote server, and then 
    copies those files back to a centralized local backup directory. A detailed log file is created for audit and troubleshooting.

    It should be run after the companion discovery script which exports all available categories to a CSV for review and cleansing.

    Input is provided via a CSV file with two required columns:
        
        Hostname            Category
        PHQ-CCM-VT-03       NSWPV413 Vision Server Engine
        PHQ-CCM-VT-03       NSWPV413 Vision Server Engine - Smart Polls
        PHQ-CCM-VT-03       QPS Vision Server Connection Manager
        PHQ-CCM-VT-03       QPSVisionServerConnectionManagerPolls
        PHQ-CCM-VT-03       Vision.DataIntegrity
        PHQ-CCM-VT-03       VisVT Vision Client Connection Manager

    For each server:
        1. A remote PowerShell session is initiated.
        2. Each specified category is validated and exported. Multi-instance counters are handled automatically.
        3. JSON output files are saved remotely under a sanitized filename.
        4. Files are copied back to a local machine under per-server folders.
        5. A log file is saved locally under LocalBackupRoot\logs\PerfCounterBackupLog_<timestamp>.log.

.PARAMETERS
    $InputCsv            Path to the CSV input file (required)
    $RemoteBackupPath    Path on each server to store the temporary JSON files (required)
    $LocalBackupRoot     Root directory on local machine to store backup and log files (required)

.NOTES
    - Requires WinRM (PowerShell remoting) access to target servers.
    - Handles both single-instance and multi-instance Performance Counters.
    - All activity is logged. Errors are caught and logged. Sessions are safely cleaned up.

.LINK
    Microsoft Docs - PerformanceCounterCategory class:
    https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.performancecountercategory

    Microsoft Docs - Performance Counters (Windows):
    https://learn.microsoft.com/en-us/windows/win32/perfctrs/performance-counters-portal
#>


# === Configurable Variables ===
$InputCsv = "C:\temp\QCAD\PR\perf-counters\PR__PerfCounterCategoryList.csv"
$RemoteBackupPath = "D:\Temp\perfcounterbackups-prod"
$LocalBackupRoot = "C:\temp\QCAD\PR\perf-counters\backups17"

# === Ensure local directories exist ===
if (-not (Test-Path $LocalBackupRoot)) {
    New-Item -Path $LocalBackupRoot -ItemType Directory | Out-Null
}

$LogDirectory = Join-Path $LocalBackupRoot "logs"
if (-not (Test-Path $LogDirectory)) {
    New-Item -Path $LogDirectory -ItemType Directory | Out-Null
}

# === Setup log file ===
$LogFile = Join-Path $LogDirectory ("PerfCounterBackupLog_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -Path $LogFile -ItemType File -Force | Out-Null

# === Logging Function ===
function Write-Log {
    param (
        [string]$Message,
        [ValidateSet("INFO", "WARNING", "ERROR")]
        [string]$Level = "INFO"
    )
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $Entry = "$Timestamp [$Level] $Message"
    Add-Content -Path $LogFile -Value $Entry
    Write-Host $Entry
}

Write-Log "Starting Performance Counter metadata backup."

# === Import CSV ===
try {
    $Entries = Import-Csv $InputCsv
    Write-Log "Imported CSV file successfully: $InputCsv"
} catch {
    Write-Log "Failed to import CSV file: $_" "ERROR"
    exit 1
}

# === Group by Hostname ===
$Grouped = $Entries | Group-Object Hostname

foreach ($ServerGroup in $Grouped) {
    $Hostname = $ServerGroup.Name
    $Categories = $ServerGroup.Group.Category

    Write-Log "Processing server: $Hostname"

    # Define the remote script
    $RemoteScript = {
        param($CategoryNames, $RemotePath)

        function Write-RemoteLog {
            param ($Msg)
            $time = Get-Date -Format "HH:mm:ss"
            Write-Output "[$time] $Msg"
        }

        if (-not (Test-Path $RemotePath)) {
            New-Item -Path $RemotePath -ItemType Directory | Out-Null
            Write-RemoteLog "Created remote backup directory: $RemotePath"
        }

        foreach ($Cat in $CategoryNames) {
            if ([System.Diagnostics.PerformanceCounterCategory]::Exists($Cat)) {
                try {
                    $Category = New-Object System.Diagnostics.PerformanceCounterCategory $Cat
                    $Export = [PSCustomObject]@{
                        CategoryName = $Category.CategoryName
                        CategoryHelp = $Category.CategoryHelp
                        CategoryType = $Category.CategoryType.ToString()
                        Counters     = @()
                    }

                    if ($Category.CategoryType -eq 'MultiInstance') {
                        $Instances = $Category.GetInstanceNames()
                        foreach ($Instance in $Instances) {
                            try {
                                $Counters = $Category.GetCounters($Instance)
                                foreach ($Counter in $Counters) {
                                    $Export.Counters += [PSCustomObject]@{
                                        InstanceName = $Instance
                                        CounterName  = $Counter.CounterName
                                        CounterHelp  = $Counter.CounterHelp
                                        CounterType  = $Counter.CounterType.ToString()
                                    }
                                }
                            } catch {
                                Write-RemoteLog "WARNING: Failed to get counters for instance '$Instance' in category '$Cat': $_"
                            }
                        }
                    } else {
                        $Counters = $Category.GetCounters()
                        foreach ($Counter in $Counters) {
                            $Export.Counters += [PSCustomObject]@{
                                CounterName = $Counter.CounterName
                                CounterHelp = $Counter.CounterHelp
                                CounterType = $Counter.CounterType.ToString()
                            }
                        }
                    }

                    $SafeName = ($Cat -replace '[^\w\d]', '_') + "_PerfCountersBackup.json"
                    $Path = Join-Path $RemotePath $SafeName
                    $Export | ConvertTo-Json -Depth 5 | Out-File -FilePath $Path -Encoding UTF8
                    Write-RemoteLog "Exported category '$Cat' to $Path"
                } catch {
                    Write-RemoteLog "WARNING: Failed to process category '$Cat': $_"
                }
            } else {
                Write-RemoteLog "WARNING: Category '$Cat' does not exist on $env:COMPUTERNAME"
            }
        }
    }

    try {
        # Execute remote export
        Invoke-Command -ComputerName $Hostname -ScriptBlock $RemoteScript -ArgumentList ($Categories, $RemoteBackupPath) -ErrorAction Stop
        Write-Log "Remote export complete on $Hostname"

        # Local folder for this host
        $LocalFolder = Join-Path $LocalBackupRoot $Hostname
        if (-not (Test-Path $LocalFolder)) {
            New-Item -Path $LocalFolder -ItemType Directory | Out-Null
            Write-Log "Created local folder: $LocalFolder"
        }

        # Copy JSON files back
        $Session = New-PSSession -ComputerName $Hostname
        Copy-Item -Path "$RemoteBackupPath\*" -Destination $LocalFolder -FromSession $Session -Recurse -Force
        Write-Log "Copied backup files from $Hostname to $LocalFolder"
        Remove-PSSession $Session
    } catch {
        Write-Log "ERROR processing server '$Hostname': $_" "ERROR"
        if ($Session) {
            Remove-PSSession $Session -ErrorAction SilentlyContinue
        }
    }
}

Write-Log "All servers processed. Backup complete."
