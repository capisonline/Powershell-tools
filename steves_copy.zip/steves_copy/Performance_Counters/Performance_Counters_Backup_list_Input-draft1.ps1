﻿<#
.SYNOPSIS
    Extracts and backs up Performance Counter metadata from remote Windows servers and saves the data as JSON files locally.

.DESCRIPTION
    This script is designed to query a list of Windows Performance Counter categories on a group of remote servers, export 
    the metadata for each category (including all counters and their properties), save the data to a defined backup path 
    on each remote server, and then copy all backup files to a centralized local directory.

    It is best ran after the discovery script which exports all categories to a csv for cleansing.

    Input is provided via a CSV file with two required columns: 
        
        Hostname	    Category
        PHQ-CCM-VT-03	NSWPV413 Vision Server Engine
        PHQ-CCM-VT-03	NSWPV413 Vision Server Engine - Smart Polls
        PHQ-CCM-VT-03	QPS Vision Server Connection Manager
        PHQ-CCM-VT-03	QPSVisionServerConnectionManagerPolls
        PHQ-CCM-VT-03	Vision.DataIntegrity
        PHQ-CCM-VT-03	VisVT Vision Client Connection Manager


    For each server:
        1. A remote PowerShell session is initiated.
        2. Each specified performance counter category is validated and then exported - **category** needs to be in the input file
        3. JSON output files are saved remotely under a sanitized filename.
        4. Files are copied back to the local machine for archival or analysis.

.PARAMETERS
        - Path to input CSV
        - Remote backup path on each server
        - Local backup root folder

.NOTES
    - Requires WinRM access to target servers.
    - Uses `System.Diagnostics.PerformanceCounterCategory` for category discovery.
    - Error handling is implemented to ensure sessions are removed cleanly.


.LINKs
    Microsoft Docs - PerformanceCounterCategory class:
    https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.performancecountercategory

    Microsoft Docs - Performance Counters (Windows):
    https://learn.microsoft.com/en-us/windows/win32/perfctrs/performance-counters-portal

#>


# vars
$InputCsv = "C:\temp\QCAD\PR\perf-counters\PR__PerfCounterCategoryList.csv"
$RemoteBackupPath = "D:\Temp\perfcounterbackups-test"
$LocalBackupRoot = "C:\temp\QCAD\PR\perf-counters\backups"

# Ensure local root folder exists
if (-not (Test-Path $LocalBackupRoot)) {
    New-Item -Path $LocalBackupRoot -ItemType Directory | Out-Null
}

# Read input
try {
    $entries = Import-Csv $InputCsv
} catch {
    Write-Error "Failed to import CSV file: $_"
    exit 1
}

# Group by server
$grouped = $entries | Group-Object Hostname

foreach ($serverGroup in $grouped) {
    $hostname = $serverGroup.Name
    $categories = $serverGroup.Group.Category

    Write-Host "Processing server: $hostname" -ForegroundColor Cyan

    $remoteScript = {
        param($categoryNames, $remotePath)

        if (-not (Test-Path $remotePath)) {
            New-Item -Path $remotePath -ItemType Directory | Out-Null
        }

        foreach ($cat in $categoryNames) {
            if ([System.Diagnostics.PerformanceCounterCategory]::Exists($cat)) {
                try {
                    $category = New-Object System.Diagnostics.PerformanceCounterCategory $cat
                    $counters = $category.GetCounters()

                    $export = [PSCustomObject]@{
                        CategoryName = $category.CategoryName
                        CategoryHelp = $category.CategoryHelp
                        CategoryType = $category.CategoryType.ToString()
                        Counters     = @()
                    }

                    foreach ($counter in $counters) {
                        $export.Counters += [PSCustomObject]@{
                            CounterName = $counter.CounterName
                            CounterHelp = $counter.CounterHelp
                            CounterType = $counter.CounterType.ToString()
                        }
                    }

                    $safeName = ($cat -replace '[^\w\d]', '_') + "_PerfCountersBackup.json"
                    $path = Join-Path $remotePath $safeName
                    $export | ConvertTo-Json -Depth 5 | Out-File -FilePath $path -Encoding UTF8
                } catch {
                    Write-Warning "Failed to process '$cat' on $env:COMPUTERNAME: $_"
                }
            } else {
                Write-Warning "Category '$cat' does not exist on $env:COMPUTERNAME"
            }
        }
    }

    try {
        # Run the backup remotely
        Invoke-Command -ComputerName $hostname -ScriptBlock $remoteScript -ArgumentList ($categories, $RemoteBackupPath) -ErrorAction Stop

        # Create local folder
        $localFolder = Join-Path $LocalBackupRoot $hostname
        if (-not (Test-Path $localFolder)) {
            New-Item -Path $localFolder -ItemType Directory | Out-Null
        }

        # Copy files back
        $session = New-PSSession -ComputerName $hostname
        Copy-Item -Path "$RemoteBackupPath\*" -Destination $localFolder -FromSession $session -Recurse -Force
        Remove-PSSession $session
    }
    catch {
        Write-Error "Error processing server '$hostname': $_"
        if ($session) {
            Remove-PSSession $session -ErrorAction SilentlyContinue
        }
    }
}
