﻿param (
    [string]$InputCsv = "C:\temp\QCAD\VT\performance-counters\Discovery\backups\OLD_VT\VT_PerfCounterCategoryList.csv",
    [string]$RemoteBackupPath = "D:\Temp\perfcounterbackups",
    [string]$LocalBackupRoot = "C:\temp\QCAD\VT\performance-counters\Discovery\backups\OLD_VT"
)

# Ensure local root folder exists
if (-not (Test-Path $LocalBackupRoot)) {
    New-Item -Path $LocalBackupRoot -ItemType Directory | Out-Null
}

# Read input
$entries = Import-Csv $InputCsv

# Group by server
$grouped = $entries | Group-Object Hostname

foreach ($serverGroup in $grouped) {
    $hostname = $serverGroup.Name
    $categories = $serverGroup.Group.Category

    $remoteScript = {
        param($categoryNames, $remotePath)

        if (-not (Test-Path $remotePath)) {
            New-Item -Path $remotePath -ItemType Directory | Out-Null
        }

        foreach ($cat in $categoryNames) {
            if ([System.Diagnostics.PerformanceCounterCategory]::Exists($cat)) {
                try {
                    $category = New-Object System.Diagnostics.PerformanceCounterCategory $cat
                    $counters = $category.GetCounters()

                    $export = [PSCustomObject]@{
                        CategoryName = $category.CategoryName
                        CategoryHelp = $category.CategoryHelp
                        CategoryType = $category.CategoryType.ToString()
                        Counters     = @()
                    }

                    foreach ($counter in $counters) {
                        $export.Counters += [PSCustomObject]@{
                            CounterName = $counter.CounterName
                            CounterHelp = $counter.CounterHelp
                            CounterType = $counter.CounterType.ToString()
                        }
                    }

                    $safeName = ($cat -replace '[^\w\d]', '_') + "_PerfCountersBackup.json"
                    $path = Join-Path $remotePath $safeName
                    $export | ConvertTo-Json -Depth 5 | Out-File -FilePath $path -Encoding UTF8
                } catch {
                    Write-Warning "Failed to process $cat on $env:COMPUTERNAME"
                }
            } else {
                Write-Warning "Category '$cat' does not exist on $env:COMPUTERNAME"
            }
        }
    }

    # Run the backup remotely
    Invoke-Command -ComputerName $hostname -ScriptBlock $remoteScript -ArgumentList ($categories, $RemoteBackupPath)

    # Pull files back to local
    $localFolder = Join-Path $LocalBackupRoot $hostname
    if (-not (Test-Path $localFolder)) {
        New-Item -Path $localFolder -ItemType Directory | Out-Null
    }

    $session = New-PSSession -ComputerName $hostname
    Copy-Item -Path "$RemoteBackupPath\*" -Destination $localFolder -FromSession $session -Recurse -Force
    Remove-PSSession $session
}
