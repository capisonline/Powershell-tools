﻿<# 
.SYNOPSIS
Reproduce (and optionally fix) a PerfLib-based memory leak similar to the vendor ProcessMonitor.dll.

.EXAMPLES
# 1) Leaky mode: re-create counters every 300s, align to 5-minute boundary (SCOM-style), no disposal
.\Repro-PerfCounterLeak.ps1 -Mode Leaky -VictimProcessName 'FortekCoreService' -IntervalSeconds 300 -AlignFiveMinute -DurationMinutes 60

# 2) Leaky mode using counters.txt (Category,Counter per line)
.\Repro-PerfCounterLeak.ps1 -Mode Leaky -VictimProcessName FortekCoreService -CountersFile "C:\temp\counters.txt" -DurationMinutes 30

# 3) Fixed mode: reuse + dispose counters to show flat commit line
.\Repro-PerfCounterLeak.ps1 -Mode Fixed -VictimProcessName 'FortekCoreService' -IntervalSeconds 300 -AlignFiveMinute -DurationMinutes 30
#>

[CmdletBinding()]
param(
  [ValidateSet('Leaky','Fixed')]
  [string]$Mode = 'Leaky',

  # Process instance name used for Process\* counters (e.g. sqlservr, FortekCoreService, etc.)
  [Parameter(Mandatory=$true)]
  [string]$VictimProcessName,

  # Optional counters file with lines: Category,Counter   (e.g. "Process,Private Bytes")
  [string]$CountersFile,

  [int]$IntervalSeconds = 300,
  [int]$DurationMinutes = 60,
  [switch]$AlignFiveMinute,

  # Output CSV of measurements
  [string]$OutCsv = "$(Join-Path $PWD ("PerfLeak_{0:yyyyMMdd_HHmmss}.csv" -f (Get-Date)))"
)

# --- Helpers ------------------------------------------------------------------

function Get-SystemCommit {
  # Returns [pscustomobject] with Commit bytes and percent
  $mem = Get-CimInstance -ClassName Win32_OperatingSystem
  $total = [int64]($mem.TotalVisibleMemorySize * 1KB)
  $free  = [int64]($mem.FreePhysicalMemory      * 1KB)
  $commit = (Get-Counter -Counter '\Memory\Committed Bytes').CounterSamples[0].CookedValue
  $commitPct = (Get-Counter -Counter '\Memory\% Committed Bytes In Use').CounterSamples[0].CookedValue
  [pscustomobject]@{
    CommittedBytes = [int64]$commit
    CommittedPct   = [double]$commitPct
    TotalPhysBytes = $total
    FreePhysBytes  = $free
  }
}

function Get-ProcMem ($name) {
  $p = Get-Process -Name $name -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $p) { return $null }
  [pscustomobject]@{
    Pid          = $p.Id
    PrivateBytes = [int64]$p.PrivateMemorySize64
    WorkingSet   = [int64]$p.WorkingSet64
    Handles      = [int]  $p.Handles
    Threads      = [int]  $p.Threads.Count
  }
}

function Get-DefaultCounters {
  @(
    # Category, Counter (Process counters require instance name)
    @{ Category='Process'; Name='Private Bytes'   }
    @{ Category='Process'; Name='Working Set'     }
    @{ Category='Process'; Name='Handle Count'    }
    @{ Category='Memory';  Name='Committed Bytes' }
    @{ Category='Memory';  Name='% Committed Bytes In Use' }
    @{ Category='System';  Name='Processes'       }
  )
}

function Read-CountersFromFile ($path) {
  if (-not (Test-Path $path)) { throw "Counters file not found: $path" }
  $list = @()
  Get-Content $path | ForEach-Object {
    $line = $_.Trim()
    if (-not $line -or $line.StartsWith('#')) { return }
    $parts = $line.Split(',').ForEach({ $_.Trim() })
    if ($parts.Count -eq 2) {
      $list += @{ Category=$parts[0]; Name=$parts[1] }
    }
  }
  if (-not $list) { throw "Counters file contained no usable entries." }
  $list
}

# Globals to keep references alive (to intentionally leak in Leaky mode)
$Global:LeakyCounters = New-Object System.Collections.Generic.List[System.Diagnostics.PerformanceCounter]
$Global:ReuseCounters = $null  # used in Fixed mode

function New-PerfCounter([hashtable]$ctr, [string]$instanceName) {
  try {
    switch ($ctr.Category) {
      'Process' { return [System.Diagnostics.PerformanceCounter]::new($ctr.Category, $ctr.Name, $instanceName) }
      'Memory'  { return [System.Diagnostics.PerformanceCounter]::new($ctr.Category, $ctr.Name) }
      'System'  { return [System.Diagnostics.PerformanceCounter]::new($ctr.Category, $ctr.Name) }
      default   { return $null }
    }
  } catch {
    Write-Verbose "Failed to create counter $($ctr.Category)\$($ctr.Name): $_"
    return $null
  }
}

function Read-CounterValue([System.Diagnostics.PerformanceCounter]$pc) {
  if (-not $pc) { return $null }
  try {
    # Mimic the vendor code’s pattern: prime + multiple NextValue() calls
    [void]$pc.NextValue()
    $help = $pc.CounterHelp
    if ($help -and $help -match 'in bytes') {
      return ($pc.NextValue() / 1024.0) # KB
    } elseif ($help -and $help -match 'in seconds') {
      return ($pc.NextValue() / 60.0)   # mins
    } else {
      return $pc.NextValue()
    }
  } catch {
    return $null
  }
}

function Ensure-InstanceName([string]$baseName) {
  # Try exact, then any indexed variants (e.g. sqlservr#1)
  $all = (Get-Counter '\Process(*)\ID Process').CounterSamples.InstanceName | Select-Object -Unique
  if ($all -contains $baseName) { return $baseName }
  $match = $all | Where-Object { $_ -like "$baseName*" } | Select-Object -First 1
  if ($match) { return $match }
  return $baseName
}

function Wait-ToAlignFiveMinute {
  $now = Get-Date
  $sec = $now.Minute % 5 * 60 + $now.Second
  $wait = (5*60) - $sec
  if ($wait -gt 0 -and $wait -lt 300) {
    Write-Host ("Aligning to next 5-min boundary, sleeping {0}s..." -f $wait)
    Start-Sleep -Seconds $wait
  }
}

# --- Build counter set --------------------------------------------------------

$counters = if ($CountersFile) { Read-CountersFromFile $CountersFile } else { Get-DefaultCounters }
$instance = Ensure-InstanceName $VictimProcessName

if ($Mode -eq 'Fixed') {
  # Build once, reuse, and dispose at the end
  $Global:ReuseCounters = foreach ($ctr in $counters) { New-PerfCounter $ctr $instance }
}

# --- Main loop ----------------------------------------------------------------

if ($AlignFiveMinute) { Wait-ToAlignFiveMinute }

$stopWatch = [System.Diagnostics.Stopwatch]::StartNew()
$deadline  = (Get-Date).AddMinutes($DurationMinutes)
$rows = New-Object System.Collections.Generic.List[psobject]

Write-Host "Mode: $Mode  | Process: $VictimProcessName (instance: $instance) | Interval: $IntervalSeconds s | Duration: $DurationMinutes min"
Write-Host "Writing telemetry to: $OutCsv"
Write-Host ""

while ((Get-Date) -lt $deadline) {

  $ts = Get-Date
  $sys = Get-SystemCommit
  $proc = Get-ProcMem $VictimProcessName

  $values = @{}

  if ($Mode -eq 'Leaky') {
    # Re-create counters every cycle and KEEP references alive (no Dispose) => leak
    $cycleCounters = foreach ($ctr in $counters) { New-PerfCounter $ctr $instance }
    foreach ($pc in $cycleCounters) {
      $name = if ($pc) { "$($pc.CategoryName)\$($pc.CounterName)" } else { "N/A" }
      $values[$name] = Read-CounterValue $pc
      # Intentionally leak by holding refs globally
      $Global:LeakyCounters.Add($pc)
    }
  } else {
    # Fixed: reuse the counters, read once
    foreach ($pc in $Global:ReuseCounters) {
      $name = if ($pc) { "$($pc.CategoryName)\$($pc.CounterName)" } else { "N/A" }
      $values[$name] = Read-CounterValue $pc
    }
  }

  $row = [pscustomobject]@{
    Timestamp            = $ts
    CommitBytes          = $sys.CommittedBytes
    CommitPct            = [math]::Round($sys.CommittedPct,2)
    TotalPhysBytes       = $sys.TotalPhysBytes
    FreePhysBytes        = $sys.FreePhysBytes
    ProcPid              = $proc.Pid
    ProcPrivateBytes     = $proc.PrivateBytes
    ProcWorkingSet       = $proc.WorkingSet
    ProcHandles          = $proc.Handles
    ProcThreads          = $proc.Threads
  }

  # Add each counter value as its own column (safe names)
  foreach ($k in $values.Keys) {
    $col = ($k -replace '[^a-zA-Z0-9_]', '_')
    Add-Member -InputObject $row -NotePropertyName $col -NotePropertyValue $values[$k]
  }

  $rows.Add($row) | Out-Null

  # Console summary
  $sum = "t={0:HH:mm:ss} Commit={1:N0} ({2}%) ProcPriv={3:N0} Handles={4} LeakedObjs={5}" -f $ts, $sys.CommittedBytes, $sys.CommittedPct, $proc.PrivateBytes, $proc.Handles, $Global:LeakyCounters.Count
  Write-Host $sum

  Start-Sleep -Seconds $IntervalSeconds
}

# --- Cleanup / persist --------------------------------------------------------

$rows | Export-Csv -Path $OutCsv -NoTypeInformation

if ($Mode -eq 'Fixed' -and $Global:ReuseCounters) {
  foreach ($pc in $Global:ReuseCounters) { try { $pc.Dispose() } catch {} }
  $Global:ReuseCounters = $null
}

Write-Host ""
Write-Host "Done. CSV saved to: $OutCsv"
if ($Mode -eq 'Leaky') {
  Write-Host "NOTE: Leaky mode intentionally kept $($Global:LeakyCounters.Count) PerformanceCounter objects alive (no Dispose)."
}
