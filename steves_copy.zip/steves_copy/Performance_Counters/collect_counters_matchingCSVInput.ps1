﻿$inputCsv = "C:\temp\QCAD\VT\VT_Server_Pairs.csv" 
$outputFolder = "C:\temp\QCAD\VT\performance-counters\Discovery\VT_OLD-NEW_Perf_CounterComparison.csv\individual"

if (-not (Test-Path $outputFolder)) {
    New-Item -ItemType Directory -Path $outputFolder | Out-Null
}

$serverList = Import-Csv -Path $inputCsv | ForEach-Object { $_.Old_Server; $_.New_Server } | Sort-Object -Unique

foreach ($server in $serverList) {
    if (-not $server) { continue }

    $outFile = Join-Path $outputFolder "$($server -replace '[^\w\d]', '_')_perf.csv"

    Write-Host "Collecting counters from $server..." -ForegroundColor Cyan
    try {
        $counters = Invoke-Command -ComputerName $server -ScriptBlock {
            Get-Counter -ListSet * | ForEach-Object {
                $cat = $_.CounterSetName
                $_.Counter | ForEach-Object {
                    [PSCustomObject]@{
                        Category = $cat
                        Counter  = $_
                    }
                }
            }
        }

        $counters | Export-Csv -Path $outFile -NoTypeInformation -Encoding UTF8
        Write-Host "Saved to $outFile" -ForegroundColor Green
    }
    catch {
        Write-Warning "Failed to get counters from ${server}: $_"
    }
}
