﻿# List of servers
$servers = Get-Content "C:\temp\QCAD\PR\Discovery\telemetry_capture\PR_Telemetry_ServerList.txt"

# Local output directory
$localOutputPath = "C:\temp\QCAD\PR\Discovery\performance-counters\counter-lists"
if (!(Test-Path $localOutputPath)) {
    New-Item -Path $localOutputPath -ItemType Directory | Out-Null
}

foreach ($server in $servers) {
    Write-Host "Connecting to $server..."

    try {
        $session = New-PSSession -ComputerName $server -ErrorAction Stop

        # Define remote filename and path
        $remoteFileName = "perf-counters_$server.csv"
        $remoteFilePath = "D:\Temp\$remoteFileName"

        # 1. Run Get-Counter on the remote server and save with hostname
        Invoke-Command -Session $session -ScriptBlock {
            param($filePath)
            Get-Counter -ListSet * |
                Select-Object CounterSetName, Counter, Description |
                Export-Csv -Path $filePath -NoTypeInformation -Force
        } -ArgumentList $remoteFilePath

        # 2. Copy it back to local
        $localFilePath = Join-Path $localOutputPath $remoteFileName
        Copy-Item -FromSession $session -Path $remoteFilePath -Destination $localFilePath -Force

        Write-Host "Copied $remoteFileName to $localFilePath"

        # 3. Clean up remote temp file
        Invoke-Command -Session $session -ScriptBlock {
            param($filePath)
            Remove-Item -Path $filePath -Force -ErrorAction SilentlyContinue
        } -ArgumentList $remoteFilePath

        Remove-PSSession -Session $session
    }
    catch {
        Write-Warning "Failed to retrieve from ${server}: $_"
    }
}
