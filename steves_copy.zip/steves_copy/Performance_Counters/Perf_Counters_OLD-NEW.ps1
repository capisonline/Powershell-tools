﻿# Input and output paths
$inputCsv = "C:\temp\QCAD\VT\VT_Server_Pairs.csv"        # Update this path
$outputCsv = "C:\temp\QCAD\VT\performance-counters\Discovery\VT_OLD-NEW_Perf_CounterComparison.csv" # Update this path

# Load server pairs from CSV
$serverPairs = Import-Csv -Path $inputCsv
$results = @()

foreach ($pair in $serverPairs) {
    $oldServer = $pair.Old_Server
    $newServer = $pair.New_Server

    Write-Host "Processing $oldServer vs $newServer..." -ForegroundColor Cyan

    # Initialize counters
    $oldCounters = @()
    $newCounters = @()

    # Get all counters from OLD server
    try {
        $oldCounters = Invoke-Command -ComputerName $oldServer -ScriptBlock {
            Get-Counter -ListSet * | ForEach-Object {
                $cat = $_.CounterSetName
                $_.Counter | ForEach-Object {
                    [PSCustomObject]@{
                        Category = $cat
                        Counter  = $_
                    }
                }
            }
        }
    } catch {
        Write-Warning "Could not retrieve counters from ${oldServer}: $_"
    }

    # Get all counters from NEW server
    try {
        $newCounters = Invoke-Command -ComputerName $newServer -ScriptBlock {
            Get-Counter -ListSet * | ForEach-Object {
                $cat = $_.CounterSetName
                $_.Counter | ForEach-Object {
                    [PSCustomObject]@{
                        Category = $cat
                        Counter  = $_
                    }
                }
            }
        }
    } catch {
        Write-Warning "Could not retrieve counters from ${newServer}: $_"
    }

    # Union of all counters from both servers
    $allCounters = ($oldCounters + $newCounters) | Sort-Object Category, Counter -Unique

    foreach ($item in $allCounters) {
        $existsOnOld = $oldCounters | Where-Object { $_.Category -eq $item.Category -and $_.Counter -eq $item.Counter }
        $existsOnNew = $newCounters | Where-Object { $_.Category -eq $item.Category -and $_.Counter -eq $item.Counter }

        $results += [PSCustomObject]@{
            OLD         = $oldServer
            NEW         = $newServer
            Category    = $item.Category
            Counter     = $item.Counter
            ExistsOnOld = [bool]$existsOnOld
            ExistsOnNew = [bool]$existsOnNew
        }
    }
}

# Output to CSV
$results | Export-Csv -Path $outputCsv -NoTypeInformation -Encoding UTF8
Write-Host "Done. Output saved to $outputCsv" 
