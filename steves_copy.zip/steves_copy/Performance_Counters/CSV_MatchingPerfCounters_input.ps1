﻿$inputCsv = "C:\temp\QCAD\VT\VT_Server_Pairs.csv" 
$dumpFolder = "C:\temp\QCAD\VT\performance-counters\Discovery\VT_OLD-NEW_Perf_CounterComparison.csv\individual"
$outputFolder = "C:\temp\QCAD\VT\performance-counters\Discovery\VT_OLD-NEW_Perf_CounterComparison.csv\individual\merged"

if (-not (Test-Path $outputFolder)) {
    New-Item -ItemType Directory -Path $outputFolder | Out-Null
}

$serverPairs = Import-Csv -Path $inputCsv

foreach ($pair in $serverPairs) {
    $old = $pair.Old_Server
    $new = $pair.New_Server

    $oldFile = Join-Path $dumpFolder "$($old -replace '[^\w\d]', '_')_perf.csv"
    $newFile = Join-Path $dumpFolder "$($new -replace '[^\w\d]', '_')_perf.csv"

    if (-not (Test-Path $oldFile) -or -not (Test-Path $newFile)) {
        Write-Warning "Missing dump file for $old or $new — skipping"
        continue
    }

    $oldCounters = Import-Csv $oldFile
    $newCounters = Import-Csv $newFile

    $allCounters = ($oldCounters + $newCounters) | Sort-Object Category, Counter -Unique
    $oldCats = $oldCounters | Select-Object -ExpandProperty Category -Unique
    $newCats = $newCounters | Select-Object -ExpandProperty Category -Unique

    $comparison = foreach ($item in $allCounters) {
        $existsOnOld = ($oldCats -contains $item.Category) -and ($oldCounters | Where-Object { $_.Category -eq $item.Category -and $_.Counter -eq $item.Counter })
        $existsOnNew = ($newCats -contains $item.Category) -and ($newCounters | Where-Object { $_.Category -eq $item.Category -and $_.Counter -eq $item.Counter })

        [PSCustomObject]@{
            Old_Server  = $old
            New_Server  = $new
            Category    = $item.Category
            Counter     = $item.Counter
            ExistsOnOld = [bool]$existsOnOld
            ExistsOnNew = [bool]$existsOnNew
        }
    }

    $outFile = Join-Path $outputFolder "$($old -replace '[^\w\d]', '_')_vs_$($new -replace '[^\w\d]', '_').csv"
    $comparison | Export-Csv -Path $outFile -NoTypeInformation -Encoding UTF8
    Write-Host "Compared $old to $new → $outFile" -ForegroundColor Green
}
