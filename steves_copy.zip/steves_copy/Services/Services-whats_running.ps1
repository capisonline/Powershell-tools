﻿<#
.SYNOPSIS
    QCAD - Vision Service Status Report (VisVT*/VisVit*) across multiple servers.

.DESCRIPTION
    Reads a list of server names from a text file (one per line) or CSV (column: Server),
    then queries Windows services remotely and reports any service whose *service name*
    starts with "VisVT" or "VisVit" (case-insensitive).

    Output:
      - Console table summary
      - CSV report (timestamped)
      - Text log (timestamped)

    Safety:
      - Read-only (no service changes)
      - Per-server timeout to avoid hanging on offline/unreachable hosts
      - Captures errors per server and continues

.PARAMETER InputPath
    Path to a .txt (one hostname per line) OR .csv (must contain column "Server").

.PARAMETER OutputDir
    Directory to write outputs (CSV + log). Created if missing.

.PARAMETER TimeoutSec
    Per-server timeout for the remote query.

.EXAMPLE
    # TXT input
    .\Get-VisVTServiceStatus.ps1 -InputPath C:\temp\servers.txt

.EXAMPLE
    # CSV input with a "Server" column
    .\Get-VisVTServiceStatus.ps1 -InputPath C:\temp\servers.csv -OutputDir C:\temp\reports -TimeoutSec 20
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path $_ })]
    [string]$InputPath,

    [string]$OutputDir = "C:\temp\VT\services\QCAD_ServiceReports",

    [ValidateRange(5, 300)]
    [int]$TimeoutSec = 15
)

# -------------------------
# Helpers
# -------------------------
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [$Level] $Message"
    Write-Host $line
    Add-Content -Path $script:LogPath -Value $line
}

function Get-ServersFromInput {
    param([string]$Path)

    $ext = [IO.Path]::GetExtension($Path).ToLowerInvariant()
    if ($ext -eq ".csv") {
        $rows = Import-Csv -Path $Path
        if (-not ($rows | Get-Member -Name "Server" -MemberType NoteProperty)) {
            throw "CSV must contain a column named 'Server'."
        }
        return $rows.Server | Where-Object { $_ -and $_.Trim() } | ForEach-Object { $_.Trim() } | Select-Object -Unique
    }
    else {
        # Treat as plain text
        return Get-Content -Path $Path |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ -and -not $_.StartsWith("#") } |
            Select-Object -Unique
    }
}

function Get-VisServicesFromServer {
    param(
        [string]$ComputerName,
        [int]$TimeoutSeconds
    )

    # Run the remote query in a background job so we can enforce a timeout.
    $job = Start-Job -ScriptBlock {
        param($cn)

        # Prefer CIM for richer fields; works well across modern Windows.
        # If CIM fails (firewall/DCOM/etc.), fall back to Get-Service.
        try {
            $svc = Get-CimInstance -ClassName Win32_Service -ComputerName $cn -ErrorAction Stop
            $svc | Where-Object {
                $_.Name -match '^(?i)VisVT' -or $_.Name -match '^(?i)VisVit'
            } | Select-Object @{
                    Name = 'Server'; Expression = { $cn }
                }, Name, DisplayName, State, StartMode, StartName, ProcessId
        }
        catch {
            # Fallback
            $svc2 = Get-Service -ComputerName $cn -ErrorAction Stop |
                Where-Object { $_.Name -match '^(?i)VisVT' -or $_.Name -match '^(?i)VisVit' } |
                Select-Object @{
                    Name = 'Server'; Expression = { $cn }
                }, Name, DisplayName, @{
                    Name='State'; Expression = { $_.Status.ToString() }
                }, @{
                    Name='StartMode'; Expression = { $null }
                }, @{
                    Name='StartName'; Expression = { $null }
                }, @{
                    Name='ProcessId'; Expression = { $null }
                }
            $svc2
        }
    } -ArgumentList $ComputerName

    if (Wait-Job -Job $job -Timeout $TimeoutSeconds) {
        $out = Receive-Job -Job $job -ErrorAction SilentlyContinue
        Remove-Job -Job $job -Force | Out-Null
        return $out
    }
    else {
        Stop-Job -Job $job -Force | Out-Null
        Remove-Job -Job $job -Force | Out-Null
        throw "Timeout after $TimeoutSeconds seconds."
    }
}

# -------------------------
# Main
# -------------------------
if (-not (Test-Path $OutputDir)) {
    New-Item -Path $OutputDir -ItemType Directory -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$csvPath = Join-Path $OutputDir "VisVT_ServiceStatus_$stamp.csv"
$script:LogPath = Join-Path $OutputDir "VisVT_ServiceStatus_$stamp.log"

Write-Log "Starting service status report."
Write-Log "InputPath: $InputPath"
Write-Log "OutputDir: $OutputDir"
Write-Log "TimeoutSec: $TimeoutSec"

$servers = Get-ServersFromInput -Path $InputPath
if (-not $servers -or $servers.Count -eq 0) {
    throw "No servers found in input."
}
Write-Log ("Targets: {0} server(s): {1}" -f $servers.Count, ($servers -join ", "))

$results = New-Object System.Collections.Generic.List[object]
$errors  = New-Object System.Collections.Generic.List[object]

foreach ($s in $servers) {
    Write-Log "Querying: $s"
    try {
        $svcs = Get-VisServicesFromServer -ComputerName $s -TimeoutSeconds $TimeoutSec

        if (-not $svcs) {
            Write-Log "No VisVT*/VisVit* services found." "WARN"
            $results.Add([pscustomobject]@{
                Server      = $s
                Name        = $null
                DisplayName = $null
                State       = "NOT_FOUND"
                StartMode   = $null
                StartName   = $null
                ProcessId   = $null
            }) | Out-Null
        }
        else {
            foreach ($row in $svcs) { $results.Add($row) | Out-Null }
            $runningCount = @($svcs | Where-Object { $_.State -eq "Running" }).Count
            $totalCount   = @($svcs).Count
            Write-Log "Found $totalCount service(s), $runningCount running."
        }
    }
    catch {
        $msg = $_.Exception.Message
        Write-Log "Failed querying $s - $msg" "ERROR"
        $errors.Add([pscustomobject]@{
            Server = $s
            Error  = $msg
        }) | Out-Null

        $results.Add([pscustomobject]@{
            Server      = $s
            Name        = $null
            DisplayName = $null
            State       = "ERROR"
            StartMode   = $null
            StartName   = $null
            ProcessId   = $null
        }) | Out-Null
    }
}

# Export CSV
$results | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
Write-Log "CSV written: $csvPath"

# Console summary
Write-Host ""
Write-Host "=== Summary (grouped by server) ==="
$results |
    Group-Object Server |
    Sort-Object Name |
    ForEach-Object {
        $serverName = $_.Name
        $rows = $_.Group

        $running = @($rows | Where-Object { $_.State -eq "Running" }).Count
        $stopped = @($rows | Where-Object { $_.State -eq "Stopped" }).Count
        $notfound = @($rows | Where-Object { $_.State -eq "NOT_FOUND" }).Count
        $err = @($rows | Where-Object { $_.State -eq "ERROR" }).Count

        [pscustomobject]@{
            Server   = $serverName
            Running  = $running
            Stopped  = $stopped
            NotFound = $notfound
            Error    = $err
        }
    } | Format-Table -AutoSize

Write-Host ""
Write-Host "=== Detailed results (first 200 rows) ==="
$results | Select-Object -First 200 | Format-Table -AutoSize

if ($errors.Count -gt 0) {
    Write-Host ""
    Write-Host "=== Errors ==="
    $errors | Format-Table -AutoSize
    Write-Log ("Completed with {0} error(s)." -f $errors.Count) "WARN"
} else {
    Write-Log "Completed successfully."
}

Write-Host ""
Write-Host "Report CSV: $csvPath"
Write-Host "Log file : $script:LogPath"