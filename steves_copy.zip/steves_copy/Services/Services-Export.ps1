﻿$servers = Get-Content "C:\temp\QCAD\PA\PA_OLD_Servers.txt" 

# Define the directory to save the CSV files
$outputDirectory = "C:\temp\QCAD\PA\Services"

# Ensure the output directory exists
if (-not (Test-Path -Path $outputDirectory)) {
    New-Item -ItemType Directory -Path $outputDirectory
}

# Loop through each server to gather and export service information
foreach ($server in $servers) {
    try {
        # Gather all service information from the current server
        $services = Get-WmiObject -Class Win32_Service -ComputerName $server |
                    Select-Object PSComputerName, Name, DisplayName, StartMode, State, StartName, PathName, 
                                  @{Name="ExecutableName"; Expression={
                                      if ($_.PathName -match '"(.+?\.exe)"') {
                                          $matches[1].Split('\')[-1]
                                      } else {
                                          $_.PathName.Split('\')[-1]
                                      }
                                  }}

        # Rename the properties to match your requirements
        $services = $services | Select-Object @{Name="MachineName"; Expression={$_.PSComputerName}},
                                                @{Name="ServiceName"; Expression={$_.Name}},
                                                @{Name="DisplayName"; Expression={$_.DisplayName}},
                                                @{Name="StartupType"; Expression={$_.StartMode}},
                                                @{Name="Status"; Expression={$_.State}},
                                                @{Name="LogonAs"; Expression={$_.StartName}},
                                                @{Name="Path"; Expression={$_.PathName}},
                                                @{Name="Executable"; Expression={$_.ExecutableName}}  # Added this line

        # Define the path for the CSV file specific to the server
        $csvFilePath = Join-Path -Path $outputDirectory -ChildPath ("$server-Services.csv")

        # Export the service data to a CSV file
        $services | Export-Csv -Path $csvFilePath -NoTypeInformation

        # Output the completion status for the current server
        Write-Host "Services from $server have been exported to $csvFilePath"
    } catch {
        Write-Error "Failed to retrieve services from $server. Error: $_"
    }
}

# Display a final message once all servers have been processed
Write-Host "All servers have been processed. Service details are saved in $outputDirectory"
