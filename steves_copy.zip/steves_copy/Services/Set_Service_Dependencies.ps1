﻿# Define paths
$serverListPath = "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"         # Path to the text file with server hostnames
$csvFilePath = "C:\temp\QCAD\VT\Services\new_servers\VT_Services_Start_Order.csv"    # Path to the CSV file

# Load CSV file
$csvData = Import-Csv -Path $csvFilePath

# Loop through each server
$servers = Get-Content -Path $serverListPath
foreach ($server in $servers) {
    Write-Output "Checking service status and setting dependencies on server $server..."

    # Extract server type from hostname (based on your format)
    $serverType = $server.Substring(7, 3)  # Adjusted based on your server name pattern
    $serviceRows = $csvData | Where-Object { $_.ServerType -eq $serverType }

    # Sort services by Start_Order and prepare a list of dependencies
    $orderedServices = $serviceRows | Sort-Object -Property Start_Order

    # Set dependencies for each service
    for ($i = 0; $i -lt $orderedServices.Count; $i++) {
        $serviceNameFormatted = $orderedServices[$i].ServiceName
        
        # Determine the dependent service if this is not the first service in the order
        $dependencyService = if ($i -gt 0) { $orderedServices[$i-1].ServiceName } else { $null }

        # Check service status remotely and set dependencies
        Invoke-Command -ComputerName $server -ScriptBlock {
            param ($serviceName, $dependencyService)

            try {
                # Check the service status
                $service = Get-Service -Name $serviceName -ErrorAction Stop
                $status = $service.Status
                if ($status -eq 'Running') {
                    Write-Output "$serviceName is running on $env:COMPUTERNAME"
                } else {
                    Write-Output "$serviceName is not running on $env:COMPUTERNAME"
                }

                # Set the dependency if there's a previous service in the order
                if ($dependencyService) {
                    # Run sc.exe to set the dependency
                    $result = sc.exe config $serviceName depend= $dependencyService
                    if ($result) {
                        Write-Output "Set dependency of $serviceName on $dependencyService on $env:COMPUTERNAME"
                    } else {
                        Write-Output "Failed to set dependency of $serviceName on $dependencyService on $env:COMPUTERNAME"
                    }
                }
            } catch {
                Write-Output "Error processing $serviceName on $env:COMPUTERNAME: $_"
            }
        } -ArgumentList $serviceNameFormatted, $dependencyService
    }
}
