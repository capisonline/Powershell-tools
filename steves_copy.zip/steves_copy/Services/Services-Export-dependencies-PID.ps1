﻿$servers = Get-Content "C:\temp\QCAD\VT\VT_NEW_Server_list.txt" 

# Define the directory to save the CSV files
$outputDirectory = "C:\temp\QCAD\VT\Services\new_servers\QA-02-07-25"

# Ensure the output directory exists
if (-not (Test-Path -Path $outputDirectory)) {
    New-Item -ItemType Directory -Path $outputDirectory
}

# Loop through each server to gather and export service information
foreach ($server in $servers) {
    try {
        # Gather all service information from the current server using Get-WmiObject
        $serviceData = Invoke-Command -ComputerName $server -ScriptBlock {
            $services = Get-WmiObject -Class Win32_Service
            $services | ForEach-Object {
                $service = $_

                # Fetch Dependent and Dependency services using WMI association queries
                $dependentServices = (Get-WmiObject -Query "Associators of {Win32_Service.Name='$($service.Name)'} Where AssocClass=Win32_DependentService Role=Antecedent" | Select-Object -ExpandProperty Name) -join ', '
                $servicesDependedOn = (Get-WmiObject -Query "Associators of {Win32_Service.Name='$($service.Name)'} Where AssocClass=Win32_DependentService Role=Dependent" | Select-Object -ExpandProperty Name) -join ', '

                # Extract the executable path and name
                $pathName = $service.PathName
                $executableName = if ($pathName -match '.*\\([^\\]+\.exe)') {
                    $matches[1]
                } else {
                    'Unknown'
                }

                # Creating a custom PSObject to collect all necessary information
                [PSCustomObject]@{
                    MachineName       = $env:COMPUTERNAME
                    ServiceName       = $service.Name
                    DisplayName       = $service.DisplayName
                    Description       = $service.Description
                    StartupType       = $service.StartMode
                    Status            = $service.State
                    PID               = $service.ProcessId  # Using ProcessId property
                    ExecutablePath    = $pathName
                    ExecutableName    = $executableName
                    LogonAs           = $service.StartName
                    DependentServices = $dependentServices
                    ServicesDependedOn= $servicesDependedOn
                }
            }
        } | Export-Csv -Path (Join-Path -Path $outputDirectory -ChildPath ("$server-Services.csv")) -NoTypeInformation

        # Output the completion status for the current server
        Write-Host "Services from $server have been exported to $(Join-Path -Path $outputDirectory -ChildPath ("$server-Services.csv"))"
    } catch {
        Write-Error "Failed to retrieve services from $server. Error: $_"
    }
}

# Display a final message once all servers have been processed
Write-Host "All servers have been processed. Service details are saved in $outputDirectory"
