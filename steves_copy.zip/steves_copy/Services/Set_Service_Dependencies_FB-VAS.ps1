﻿# Define services with their start order directly in the script 
$serviceData = @(
    [PSCustomObject]@{ Start_Order = 1; ServiceName = "visvt_VCCM" },
    [PSCustomObject]@{ Start_Order = 2; ServiceName = "visvt_VSCM" },
    [PSCustomObject]@{ Start_Order = 3; ServiceName = "visvt_NumberCruncher" }
    [PSCustomObject]@{ Start_Order = 4; ServiceName = "visvt_DataService_Svr" },
    [PSCustomObject]@{ Start_Order = 5; ServiceName = "visvt_IntegrityChecker" },
    [PSCustomObject]@{ Start_Order = 6; ServiceName = "visvt_FortekCoreService" }


)

Write-Output "Checking and setting service dependencies on this machine..."

# Sort services by Start_Order and set dependencies
$orderedServices = $serviceData | Sort-Object -Property Start_Order
for ($i = 0; $i -lt $orderedServices.Count; $i++) {
    $serviceName = $orderedServices[$i].ServiceName
    $dependencyService = if ($i -gt 0) { $orderedServices[$i-1].ServiceName } else { $null }

    Write-Output "Checking and setting dependency for $serviceName..."

    try {
        # Check the service status
        $service = Get-Service -Name $serviceName -ErrorAction Stop
        $status = $service.Status
        Write-Output "$serviceName status: $status"

        # Set dependency if applicable
        if ($dependencyService) {
            $result = sc.exe config $serviceName depend= $dependencyService
            if ($result) {
                Write-Output "Dependency set for $serviceName on $dependencyService."
            } else {
                Write-Output "Failed to set dependency for $serviceName on $dependencyService."
            }
        }
    } catch {
        Write-Output "Error processing ${serviceName}: $_"
    }
}
