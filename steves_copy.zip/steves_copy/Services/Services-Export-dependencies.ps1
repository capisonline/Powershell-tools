﻿$servers = Get-Content "C:\temp\QCAD\PA\PA_OLD_Servers.txt" 

# Define the directory to save the CSV files
$outputDirectory = "C:\temp\QCAD\TP\Services\Services-Dependencies"

# Ensure the output directory exists
if (-not (Test-Path -Path $outputDirectory)) {
    New-Item -ItemType Directory -Path $outputDirectory
}

# Loop through each server to gather and export service information
foreach ($server in $servers) {
    try {
        # Gather all service information from the current server using Get-Service and Get-WmiObject
        $serviceData = Invoke-Command -ComputerName $server -ScriptBlock {
            $services = Get-Service
            $services | ForEach-Object {
                $service = $_
                $wmiService = Get-WmiObject -Query ("SELECT * FROM Win32_Service WHERE Name = '" + $service.Name + "'")
                $dependentServices = ($service.DependentServices | Select-Object -ExpandProperty Name) -join ', '
                $servicesDependedOn = ($service.ServicesDependedOn | Select-Object -ExpandProperty Name) -join ', '

                # Extract the exe path and name
                $pathName = $wmiService.PathName
                # Split exe from path and save exe name
                $executableName = if ($pathName -match '.*\\([^\\]+\.exe)') {
                    $matches[1]
                } else {
                    'Unknown'
                }

                # Creating a custom PSObject to collect all necessary information
                [PSCustomObject]@{
                    MachineName       = $env:COMPUTERNAME
                    ServiceName       = $service.Name
                    DisplayName       = $service.DisplayName
                    StartupType       = $service.StartType
                    Status            = $service.Status
                    ExecutablePath    = $pathName
                    ExecutableName    = $executableName
                    LogonAs           = $wmiService.StartName
                    DependentServices = $dependentServices
                    ServicesDependedOn= $servicesDependedOn
                }
            }
        } | Export-Csv -Path (Join-Path -Path $outputDirectory -ChildPath ($server + "-Services.csv")) -NoTypeInformation

        # Output the completion status for the current server
        Write-Host "Services from $server have been exported to $(Join-Path -Path $outputDirectory -ChildPath ($server + '-Services.csv'))"
    } catch {
        Write-Error "Failed to retrieve services from $server. Error: $_"
    }
}

# Display a final message once all servers have been processed
Write-Host "All servers have been processed. Service details are saved in $outputDirectory"
