﻿<# 
.SYNOPSIS
    This script tests the accessibility of a list of URLs across multiple servers and logs the results to a CSV file.
    It dynamically replaces "http://localhost/" in the URLs with the hostname of the current server being tested.
    The results include the hostname, the updated URL, the status (Working/Failed), and any error messages.

.DESCRIPTION
    - Reads a list of server hostnames from a text file.
    - Reads a list of URLs from another text file.
    - Replaces "http://localhost/" in the URLs with the server hostname.
    - Tests the updated URLs using Invoke-WebRequest.
    - Logs the results to a CSV file, including details for troubleshooting.

.INPUTS
    - Server list file (e.g., VT_Web_Servers.txt)
    - URL list file (e.g., VT_urls.txt)

.OUTPUTS
    - CSV file containing the test results with the following columns:
        - Hostname
        - URL
        - Status (Working or Failed)
        - Error Details (or "No Errors" if successful)

.EXAMPLE
    Run the script as follows:
        .\CheckURLs.ps1

    Input files:
        C:\temp\QCAD\VT\QA\WEB_URLS\VT_Web_Servers.txt
        C:\temp\QCAD\VT\QA\WEB_URLS\VT_urls.txt

    Output file:
        C:\temp\QCAD\VT\QA\WEB_URLS\VT_URL_Test_Results.csv

.NOTES
    - Ensure the server list and URL list files are correctly formatted.
    - Requires appropriate permissions to run PowerShell on the servers being tested.
#>

# Define the list of servers and URLs
$serverList = Get-Content -Path "C:\temp\QCAD\VT\QA\WEB_URLS\OLD_VT_Web_Servers.txt" # Text file containing server hostnames
$urlList = Get-Content -Path "C:\temp\QCAD\VT\QA\WEB_URLS\VT_urls.txt"           # Text file containing URLs to test

# Define the output CSV file
$outputCsv = "C:\temp\QCAD\VT\QA\WEB_URLS\VT_URL_Test_Results_Post_Sentinel1_Fix3.csv"

# Initialize an empty array to hold results
$results = @()

# Loop through each server
foreach ($server in $serverList) {
    # Loop through each URL
    foreach ($url in $urlList) {
        # Replace 'localhost' with the current server name
        $updatedUrl = $url -replace "http://localhost/", "http://$server/"

        try {
            # Perform a test connection to the updated URL
            $response = Invoke-WebRequest -Uri $updatedUrl -UseBasicParsing -TimeoutSec 10

            # If successful, add the result to the array
            $results += [PSCustomObject]@{
                Hostname = $server
                URL      = $updatedUrl
                Status   = "Working"
                Error    = "No Errors"
            }
        } catch {
            # Capture the error and add it to the array
            $results += [PSCustomObject]@{
                Hostname = $server
                URL      = $updatedUrl
                Status   = "Failed"
                Error    = $_.Exception.Message
            }
        }
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsv -NoTypeInformation -Force

Write-Host "Test results saved to $outputCsv"
