﻿# Define base paths
$logFolder = "C:\Projects\eventlogs"
$outputFolder = "$logFolder\logmine_output"
$logminerExe = "C:\Path\To\logminer.exe"  # 🔁 CHANGE THIS TO YOUR ACTUAL LOGMINE PATH
$tempConfig = "$logFolder\temp_config.json"

# Ensure output directory exists
if (!(Test-Path $outputFolder)) {
    New-Item -ItemType Directory -Path $outputFolder | Out-Null
}

# Loop through each .log file
Get-ChildItem -Path $logFolder -Filter *.log | ForEach-Object {
    $logFile = $_.FullName
    $baseName = $_.BaseName
    $outputJson = "$outputFolder\patterns_output_$baseName.json"
    $errorLog = "$outputFolder\errors_output_$baseName.log"

    # Create config dynamically
    $config = @{
        input_type = "file"
        input_path = $logFile
        output_path = $outputJson
        output_mode = "chunked"
        chunk_lines = 100000
        max_clusters = 100000
        max_distance = 0.2
        distance_type = "logmine"
        k1 = 1.0
        k2 = 1.0
        regex_vars = @{
            date = "\d{4}-\d{2}-\d{2}"
            time = "\d{2}:\d{2}:\d{2}(,\d{3})?"
            ip   = "\b(?:\d{1,3}\.){3}\d{1,3}\b"
            num  = "\b\d+\b"
            uuid = "[a-fA-F0-9\-]{36}"
        }
        severity_rules = @{
            error = "ERROR"
            warn  = "WARN"
            info  = "INFO"
        }
        errorlog_path = $errorLog
    }

    # Convert config to JSON and write to temp file
    $config | ConvertTo-Json -Depth 10 | Set-Content -Path $tempConfig -Encoding UTF8

    # Run LogMine
    Write-Host "Running LogMine for: $($logFile)"
    & $logminerExe --config $tempConfig
}

# Cleanup
Remove-Item $tempConfig -Force
Write-Host "All logs processed."
