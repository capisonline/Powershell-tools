﻿# Define variables 
$serversList = "C:\path\to\servers.txt"  # Path to the text file containing the list of servers
$remoteFilePath = "C$\path\to\logman.xml"  # Path to the file on the remote servers
$localDestinationFolder = "C:\path\to\local\destination"  # Local folder to copy the files to

# Ensure the local destination folder exists
if (-not (Test-Path -Path $localDestinationFolder)) {
    New-Item -ItemType Directory -Path $localDestinationFolder
}

# Read the list of servers from the text file
$servers = Get-Content -Path $serversList

# Loop through each server and copy the file
foreach ($server in $servers) {
    $remoteFile = "\\$server\$remoteFilePath"
    $localFileName = "$server`_logman.xml"
    $localFile = Join-Path -Path $localDestinationFolder -ChildPath $localFileName
    
    try {
        # Copy the file from the remote server to the local destination
        Copy-Item -Path $remoteFile -Destination $localFile -ErrorAction Stop
        Write-Host "Successfully copied $remoteFile to $localFile"
    } catch {
        Write-Host "Failed to copy $remoteFile from $server. Error: $_"
    }
}
