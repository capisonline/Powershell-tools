﻿# This script scans a folder on a list of remote servers and copies the filtered
# files named by the filter line 31
# and copies them back to the local machine

# Define the path to the text file containing the list of server hostnames 
$serversFile = "C:\temp\QCAD\VT\VT_Old_Servers.txt"

# Read the server hostnames from the text file
$servers = Get-Content -Path $serversFile

# Define the source directory path on the remote servers
$sourceDirectory = "D$\vision"

# Define the folder destination base directory on the local machine
$destinationBaseDirectory = "C:\temp\QCAD\VT\Log4Net"

# Loop through each server and copy the directory
foreach ($server in $servers) {
    try {
        # Create a session to the remote server
        $session = New-PSSession -ComputerName $server

        # Define the destination directory with the server hostname
        $destinationDirectory = Join-Path -Path $destinationBaseDirectory -ChildPath $server

        # Ensure the destination directory exists
        if (-Not (Test-Path -Path $destinationDirectory)) {
            New-Item -ItemType Directory -Path $destinationDirectory | Out-Null
        }

        # Copy the directory from the remote server to the local machine
        Copy-Item -Path "\\$server\$sourceDirectory" -Destination $destinationDirectory -Recurse -Filter *.config

        # Close the session
        Remove-PSSession -Session $session

        Write-Output "Successfully copied directory from $server to $destinationDirectory"
    } catch {
        Write-Output "Failed to copy directory from ${server}: $_"
    }
}
