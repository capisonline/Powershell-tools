﻿# Path to the text file containing the list of server names 
$serversListPath = "C:\temp\QCAD\PA\PA_NEW_Server_list _logman_test.txt"

# Paths to the folders you want to copy
$sourceFolder1 = "C:\temp\QCAD\TP\LogMan\Final\7-ZipPortable"
$sourceFolder2 = "C:\temp\QCAD\PA\LogMan\final\tasks"

# Path to the scheduled task XML file
$scheduledTaskXmlPath = "C:\temp\QCAD\PA\LogMan\final\tasks\logman (QCAD logfile management).xml"

# Hardcoded credentials for the scheduled task
$taskUsername = "PRDS\QCAD-BatchJob-PA"
$taskPassword = 'J&m3d!iXT!j"4d'


# Read the list of server names
$servers = Get-Content -Path $serversListPath

# Function to copy folders and import the scheduled task
function Copy-FoldersAndImportTask {
    param (
        [string]$server,
        [string]$sourceFolder1,
        [string]$sourceFolder2,
        [string]$scheduledTaskXmlPath,
        [string]$taskUsername,
        [string]$taskPassword
    )
    
    # Paths to the destination folders
    $destinationFolder1 = "E$\7-ZipPortable"
    $destinationFolder2 = "E$\Tasks"

    # Copy the folders
    Copy-Item -Path $sourceFolder1 -Destination "\\$server\$destinationFolder1" -Recurse -Force
    Copy-Item -Path $sourceFolder2 -Destination "\\$server\$destinationFolder2" -Recurse -Force

    # Import the scheduled task
    $taskName = "logman (QCAD logfile management)"
    $taskXml = Get-Content -Path $scheduledTaskXmlPath -Raw
    $tempTaskXmlPath = "E:\$taskName.xml"
    
    # Save the XML to a temporary location on the remote server
    Invoke-Command -ComputerName $server -ScriptBlock {
        param ($taskXmlContent, $tempTaskXmlPath)
        Set-Content -Path $tempTaskXmlPath -Value $taskXmlContent -Force
    } -ArgumentList $taskXml, $tempTaskXmlPath

    # Register the task on the remote server
    Invoke-Command -ComputerName $server -ScriptBlock {
        param ($taskName, $tempTaskXmlPath, $taskUsername, $taskPassword)
        
        Register-ScheduledTask -Xml (Get-Content -Path $tempTaskXmlPath -Raw) -TaskName $taskName -User $taskUsername -Password $taskPassword
    } -ArgumentList $taskName, $tempTaskXmlPath, $taskUsername, $taskPassword
}

# Loop through each server and perform the actions
foreach ($server in $servers) {
    Copy-FoldersAndImportTask -server $server -sourceFolder1 $sourceFolder1 -sourceFolder2 $sourceFolder2 -scheduledTaskXmlPath $scheduledTaskXmlPath -taskUsername $taskUsername -taskPassword $taskPassword
}
