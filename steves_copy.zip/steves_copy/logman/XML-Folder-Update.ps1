﻿# Connects to a list of servers and reads the plmconf.xml file
# Uses the hostname & SiteCode sys variable to update the file and create all the folders required for QCAD logging
# Path to the text file containing the list of servers 
$serversFilePath = "C:\path\to\servers.txt"

# Path to save the CSV file with folder locations
$outputCsvPath = "C:\path\to\folder_locations.csv"

# Path to the XML configuration file on each server
$configPath = "E:\Tasks\plmconf.xml"

# Function to extract parts of the hostname based on the XML HostNameContext
function Get-HostnameComponents {
    param ($hostname, $hostNameContext)

    $components = @{}
    foreach ($context in $hostNameContext.ChildNodes) {
        if ($context.Name -eq "System" -or $context.Name -eq "ServerRole" -or $context.Name -eq "Environment" -or $context.Name -eq "Site") {
            $indices = $context.'#text' -split ","
            $start = [int]$indices[0]
            $length = [int]$indices[1]
            $components[$context.Name] = $hostname.Substring($start, $length)
        }
    }
    return $components
}

# Function to update XML with actual paths and create directories
function Update-XmlWithPaths {
    param ($xml, $components)

    $folderResults = @()

    foreach ($server in $xml.PLMConf.Server) {
        $pattern = $server.Pattern
        if ($components.ServerRole -eq $pattern) {
            foreach ($rule in $server.BackupRules.Rule) {
                $logDir = $rule.LogDir -replace "%SiteCode%", $components.Site
                $backupDir = $rule.BackupDir -replace "%SiteCode%", $components.Site
                $compressDir = $rule.CompressDir -replace "%SiteCode%", $components.Site

                # Create directories if they don't exist and log their status
                $folderResults += [PSCustomObject]@{Hostname=$components.Hostname; FolderPath=$logDir; Exists=(Test-Path -Path $logDir)}
                if (-not (Test-Path -Path $logDir)) {
                    New-Item -Path $logDir -ItemType Directory -Force
                }

                $folderResults += [PSCustomObject]@{Hostname=$components.Hostname; FolderPath=$backupDir; Exists=(Test-Path -Path $backupDir)}
                if (-not (Test-Path -Path $backupDir)) {
                    New-Item -Path $backupDir -ItemType Directory -Force
                }

                $folderResults += [PSCustomObject]@{Hostname=$components.Hostname; FolderPath=$compressDir; Exists=(Test-Path -Path $compressDir)}
                if (-not (Test-Path -Path $compressDir)) {
                    New-Item -Path $compressDir -ItemType Directory -Force
                }

                # Update XML paths
                $rule.LogDir = $logDir
                $rule.BackupDir = $backupDir
                $rule.CompressDir = $compressDir
            }
        }
    }

    return $xml, $folderResults
}

# Read the list of servers from the text file
if (Test-Path $serversFilePath) {
    $servers = Get-Content -Path $serversFilePath
    Write-Output "Server list loaded successfully."
} else {
    Write-Error "Server list file not found at path: $serversFilePath"
    exit 1
}

$folderLocations = @()

# Loop through each server and execute the operations
foreach ($server in $servers) {
    Write-Output "Processing server: $server"

    # Use Invoke-Command to run the script block on each remote server
    $scriptBlock = {
        param ($configPath)

        # Load the XML configuration
        $xml = [xml](Get-Content $configPath)

        # Get the hostname of the current machine
        $hostname = $env:COMPUTERNAME

        # Extract hostname components
        $hostNameContext = $xml.PLMConf.Server.HostNameContext[0]
        $components = Get-HostnameComponents -hostname $hostname -hostNameContext $hostNameContext
        $components.Hostname = $hostname

        # Update XML with actual paths and create directories
        $updatedXml, $folderResults = Update-XmlWithPaths -xml $xml -components $components

        # Save the updated XML file (optionally create a backup first)
        $backupPath = "$configPath.bak"
        Copy-Item -Path $configPath -Destination $backupPath -Force
        $updatedXml.Save($configPath)

        return $folderResults
    }

    # Execute the script block on the remote server
    $results = Invoke-Command -ComputerName $server -ScriptBlock $scriptBlock -ArgumentList $configPath

    # Collect results from each server
    $folderLocations += $results
}

# Save the folder locations and their existence status to a CSV file
$folderLocations | Export-Csv -Path $outputCsvPath -NoTypeInformation

Write-Output "Folder locations and their existence status saved to: $outputCsvPath"
