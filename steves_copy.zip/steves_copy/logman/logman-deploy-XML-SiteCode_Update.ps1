﻿# This script updates the SiteCode variable in the plmconf.xml file for the Logman Scheduled task. 
# It's not the prettiest - but it's fast as I didn't want to update the entire logman script. 
# Path to the text file containing the list of servers 
$serversFilePath = "C:\temp\QCAD\PA\PA_NEW_Server_list _logman_test.txt"

# Read the list of servers from the text file
$servers = Get-Content -Path $serversFilePath

# Path to the XML file on the target servers
$xmlPath = "E:\Tasks\plmconf.xml"

# Define the script block to be executed on each remote server
$scriptBlock = {
    param (
        $xmlPath,
        $siteCode
    )

    # Load the XML file
    if (Test-Path $xmlPath) {
        $xml = [xml](Get-Content $xmlPath)
    } else {
        Write-Error "XML file not found at path: $xmlPath"
        exit 1
    }

    # Function to replace placeholders in XML
    function Replace-Placeholders($node) {
        foreach ($child in $node.ChildNodes) {
            if ($child.NodeType -eq [System.Xml.XmlNodeType]::Element) {
                Replace-Placeholders $child
            } elseif ($child.NodeType -eq [System.Xml.XmlNodeType]::Text) {
                $child.Value = $child.Value -replace "%SiteCode%", $siteCode
            }
        }
    }

    # Replace placeholders in the entire XML document
    Replace-Placeholders $xml

    # Save the updated XML file (optionally create a backup first)
    $backupPath = "$xmlPath.bak"
    Copy-Item -Path $xmlPath -Destination $backupPath -Force
    $xml.Save($xmlPath)

    Write-Output "XML file updated successfully. Backup created at: $backupPath"

    # Optionally: Verify the changes (output the log directories for verification)
    $serverPattern = "APL" # Adjust based on your server role
    $serverConfig = $xml.PLMConf.Server | Where-Object { $_.Pattern -eq $serverPattern }

    foreach ($rule in $serverConfig.BackupRules.Rule) {
        $logDir = $rule.LogDir
        $backupDir = $rule.BackupDir
        $compressDir = $rule.CompressDir

        Write-Output "Log Directory: $logDir"
        Write-Output "Backup Directory: $backupDir"
        Write-Output "Compress Directory: $compressDir"
    }
}

# Loop through each server and execute the script block
foreach ($server in $servers) {
    Write-Output "Processing server: $server"

    # Retrieve the SiteCode environment variable from the local machine (assuming it's the same for all servers)
    $siteCode = $env:SiteCode

    if (-not [string]::IsNullOrEmpty($siteCode)) {
        Invoke-Command -ComputerName $server -ScriptBlock $scriptBlock -ArgumentList $xmlPath, $siteCode
    } else {
        Write-Error "SiteCode environment variable is not set."
        exit 1
    }
}
