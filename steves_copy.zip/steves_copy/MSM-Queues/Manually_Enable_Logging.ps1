﻿# Enable MSMQ Error Logging 
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters" -Name "EventLogging" -Value 7 -Force

# Enable MSMQ Message Tracking
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters" -Name "EnableReportMessages" -Value 7 -Force

# Set the Path for MSMQ Log Files
$logPath = "E:\Message_logging_Queues"
if (-Not (Test-Path $logPath)) {
    New-Item -Path $logPath -ItemType Directory
}
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters" -Name "LogPath" -Value $logPath -Force

# Restart MSMQ Service
Restart-Service -Name "MSMQ" -Force

Write-Output "MSMQ logging enabled and service restarted."
