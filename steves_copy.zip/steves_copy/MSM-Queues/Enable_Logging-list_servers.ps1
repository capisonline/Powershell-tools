﻿<# 
.SYNOPSIS
    This script enables detailed MSMQ logging across a list of servers specified in a text file.

.DESCRIPTION
    The script performs the following actions:
    1. Reads a list of server names from a specified text file.
    2. Enables MSMQ error logging and message tracking on each server by updating registry keys.
    3. Sets the path for MSMQ log files.
    4. Restarts the MSMQ service on each server to apply the changes.
    5. Logs the results to a CSV file.

.PARAMETER ServerListPath
    The path to the text file containing the list of server names.

.PARAMETER OutputCsvPath
    The path to the output CSV file where the results will be saved.

.EXAMPLE
    .\EnableMSMQLogging.ps1 -ServerListPath "C:\Path\To\ServerList.txt" -OutputCsvPath "C:\Path\To\Output.csv"
#>

param (
    [string]$ServerListPath,
    [string]$OutputCsvPath
)

# Import the list of servers
$servers = Get-Content -Path $ServerListPath

# Initialize an array to hold the results
$results = @()

# Function to enable MSMQ logging on a remote server
function Enable-MSMQLogging {
    param (
        [string]$serverName
    )

    try {
        Invoke-Command -ComputerName $serverName -ScriptBlock {
            # Enable MSMQ Error Logging
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters" -Name "EventLogging" -Value 7 -Force

            # Enable MSMQ Message Tracking
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters" -Name "EnableReportMessages" -Value 7 -Force

            # Set the Path for MSMQ Log Files
            $logPath = "E:\Message_logging_Queues"
            if (-Not (Test-Path $logPath)) {
                New-Item -Path $logPath -ItemType Directory
            }
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters" -Name "LogPath" -Value $logPath -Force

            # Restart MSMQ Service
            Restart-Service -Name "MSMQ" -Force

            Write-Output "MSMQ logging enabled and service restarted on $env:COMPUTERNAME."
        } -Credential (Get-Credential) -ErrorAction Stop

        # Log the result
        $results += [PSCustomObject]@{
            ServerName = $serverName
            Status     = "Success"
        }

    } catch {
        # Log the error
        $results += [PSCustomObject]@{
            ServerName = $serverName
            Status     = "Failed: $_"
        }
    }
}

# Iterate through each server and enable MSMQ logging
foreach ($server in $servers) {
    Enable-MSMQLogging -serverName $server
}

# Export the results to a CSV file
$results | Export-Csv -Path $OutputCsvPath -NoTypeInformation

Write-Output "Results exported to $OutputCsvPath"
