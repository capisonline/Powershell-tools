﻿
# Get the hostname of the current machine 
$hostname = $env:COMPUTERNAME

# Define the script name (you can manually set this or derive it dynamically)
$scriptName = "QCAD_CCM_Install.ps1"

# Define the log file path using the hostname and script name
$logFile = "C:\temp\$hostname`_$scriptName.txt"

# Define the error summary file path
$errorSummaryFile = "C:\temp\$hostname`_$scriptName`_error_summary.txt"

# Write a custom heading to the log file
$scriptSource = "Chocolatey Installation Script - Source: $scriptName http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD.ServerInstalls?path=%2FQCAD_CCM_Install.ps1&version=GBmaster"
$header = "==== $scriptSource ===="
$header | Out-File -FilePath $logFile -Encoding UTF8 -Append

# Start logging
Start-Transcript -Path $logFile -Append

# Capture start time for duration calculation
$start = Get-Date

# Main script block
try {
    # Your existing script content between the ===
    # ================================
    # 
$QcadSource = "http://dmproget.prds.qldpol/nuget/QCAD-2023-12B/"
$listId = 17
$apiKey = "c9b48a25f6373edbd923c457368aef9a"
$Start = Get-Date

# Set Environment Variables
$lifeCycle = (Get-ItemProperty "HKLM:\SOFTWARE\PSBA\BuildVariables").Lifecycle
[Environment]::SetEnvironmentVariable("EnvName", $lifeCycle, "Machine")
$EnvName = $lifeCycle
$Env:EnvName = $EnvName

# Update Chocolatey repository details
[xml]$XmlDocument = Get-Content -Path "C:\ProgramData\chocolatey\config\chocolatey.config"
$targetNode = $XmlDocument.SelectNodes("//sources")
$newNode = $XmlDocument.CreateElement("source")
$newNode.SetAttribute("id", "PSBAPreReqs")
$newNode.SetAttribute("value", "https://dmproget.prds.qldpol/nuget/Prerequisites/")
$newNode.SetAttribute("disabled", "false")
$newNode.SetAttribute("bypassProxy", "true")
$newNode.SetAttribute("selfService", "false")
$newNode.SetAttribute("adminOnly", "false")
$newNode.SetAttribute("priority", "0")
$targetNode.AppendChild($newNode)
$XmlDocument.Save("C:\ProgramData\chocolatey\config\chocolatey.config")

#choco install DotNet4.7.2 -y

choco install PowerShellGet.PSM --version 1.0.2 --source http://dmproget.prds.qldpol/nuget/Prerequisites/ -y
choco install QCAD.Fortek.Telephony.Service --version 2.1.0 --source http://dmproget.prds.qldpol/nuget/QCAD-2023-12B/ -y
choco install QCAD.Fortek.Voice.Recorder.Service --version 1.0.0 --source http://dmproget.prds.qldpol/nuget/QCAD-2023-12B/ -y

choco install QCAD.Utilities.Web.Config.Key.Generator  --source $QcadSource -y
choco install QCAD.Utilities.Fortek.Service.Monitor --version 4.13.42.47297 --source http://dmproget.prds.qldpol/nuget/QCAD-2023-12B/ -y
choco install QCAD.Utilities.Packet.Manager.Viewer --version 1.0.0 --source http://dmproget.prds.qldpol/nuget/QCAD-2023-12B/ -y
choco install QCAD.Utilities.VisionEncrypt --version 1.0.0 --source http://dmproget.prds.qldpol/nuget/QCAD-2023-12B/ -y
choco install QCAD.Utilities.VSCM.Monitor --version 4.13.42.47297 --source http://dmproget.prds.qldpol/nuget/QCAD-2023-12B/ -y

choco install Password.API.PSM -y
choco install TFS.API.PSM -y
choco install QCAD.Config.PSM -y
choco install QCAD.PreReq.PSM -y

Import-Module password_api_psm
Import-Module tfs_api_psm
Import-Module qcad_config_psm
Import-Module qcad_prereq_psm

Update-NetworkSettings

Update-DateAndTimeFormat

#Update-TnsNames

# Service Install

choco install QCAD.Vision.Client.Connection.Manager.Service --source $QcadSource -y

# Configs

Update-CcmService

# Total Time
$duration = New-TimeSpan -Start $Start
"Duration: " + $duration.Hours + ":" + $duration.Minutes + ":" + $duration.Seconds
  

    
    # ================================
}
catch {
    Write-Error "An error occurred: $_"
}
finally {
    # Stop logging and display results
    Stop-Transcript
}

# Check log for errors and save to a summary file
Select-String -Path $logFile -Pattern "Error" | Out-File $errorSummaryFile
