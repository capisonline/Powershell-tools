﻿
# Get the hostname of the current machine 
$hostname = $env:COMPUTERNAME

# Define the script name (you can manually set this or derive it dynamically)
$scriptName = "QCAD_FB_VAS_Install"

# Define the log file path using the hostname and script name
$logFile = "C:\temp\$hostname`_$scriptName.txt"

# Define the error summary file path
$errorSummaryFile = "C:\temp\$hostname`_$scriptName`_error_summary.txt"

# Write a custom heading to the log file
$scriptSource = "Chocolatey Installation Script - Source: $scriptName http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD.ServerInstalls?path=%2FQCAD_FB_VAS_Install.ps1"
$header = "==== $scriptSource ===="
$header | Out-File -FilePath $logFile -Encoding UTF8 -Append

# Start logging
Start-Transcript -Path $logFile -Append

# Capture start time for duration calculation
$start = Get-Date

# Main script block
try {
    # Your existing script content here
    # ================================
    
  $QcadSource = "http://dmproget.prds.qldpol/nuget/QCAD-2023-12B/"
$listId = 17
$apiKey = "c9b48a25f6373edbd923c457368aef9a"
$Start = Get-Date

# Set Environment Variables
$lifeCycle = (Get-ItemProperty "HKLM:\SOFTWARE\PSBA\BuildVariables").Lifecycle
[Environment]::SetEnvironmentVariable("EnvName", $lifeCycle, "Machine")
$EnvName = $lifeCycle
$Env:EnvName = $EnvName

# Update Chocolatey repository details
[xml]$XmlDocument = Get-Content -Path "C:\ProgramData\chocolatey\config\chocolatey.config"
$targetNode = $XmlDocument.SelectNodes("//sources")
$newNode = $XmlDocument.CreateElement("source")
$newNode.SetAttribute("id", "PSBAPreReqs")
$newNode.SetAttribute("value", "https://dmproget.prds.qldpol/nuget/Prerequisites/")
$newNode.SetAttribute("disabled", "false")
$newNode.SetAttribute("bypassProxy", "true")
$newNode.SetAttribute("selfService", "false")
$newNode.SetAttribute("adminOnly", "false")
$newNode.SetAttribute("priority", "0")
$targetNode.AppendChild($newNode)
$XmlDocument.Save("C:\ProgramData\chocolatey\config\chocolatey.config")


#choco install MSMQ --source windowsfeatures
#choco install MSMQ-Services --source windowsfeatures
#choco install MSMQ-Server --source windowsfeatures

# choco install Oracle.Client.19c.x64 -y
# choco install DotNet4.7.2 -y
# choco install sql-server-express 2019.20200409 -y
# choco install sql-server-management-studio -y

choco install QCAD.Utilities.Web.Config.Key.Generator  --source $QcadSource -y

choco install Password.API.PSM -y
choco install TFS.API.PSM -y
choco install QCAD.Config.PSM -y
choco install QCAD.PreReq.PSM -y
choco install SQLPS.PSM -y

Import-Module password_api_psm
Import-Module tfs_api_psm
Import-Module qcad_config_psm
Import-Module qcad_prereq_psm

Update-MessageQueues

Update-NetworkSettings

Update-DateAndTimeFormat

Update-SqlBrowserService

Update-SqlServerAlias

Update-SqlTcpProperties

Create-SQLDatabase

Create-SQLUsers

Create-VIMUsers

Create-LinkedServer

#Update-TnsNames

# FCS Service Install

choco install QCAD.Data.Service --source $QcadSource -y

choco install QCAD.Fortek.Core.Service --source $QcadSource -y

choco install QCAD.Integrity.Checker.Service --source $QcadSource -y

choco install QCAD.Number.Cruncher.Service --source $QcadSource -y

choco install QCAD.Vision.Server.Connection.Manager.Service --source $QcadSource -y

choco install Service.Manager --version 4.13.42.47297 --source $QcadSource -y

# MapBasic

choco install QCAD.Mapping.SDM.MapBasic --source $QcadSource -y

# MA Config

choco install QCAD.Config.MAConfig --source $QcadSource -y

# Utilities
choco install QCAD.Utilities.Fortek.ECG.Simulator.Command --source $QcadSource -y

choco install QCAD.Utilities.VSCM.Monitor --source $QcadSource -y

choco install QCAD.Utilities.Fortek.Service.Monitor --source $QcadSource -y

choco install QCAD.Utilities.CNI.Tester --source $QcadSource -y

choco install QCAD.Utilities.Fortek.Map.Info.Data.Converter --source $QcadSource -y

choco install QCAD.Utilities.Fortek.Map.Layer.Tester --source $QcadSource -y

choco install QCAD.Utilities.Fortek.ECG.Simulator.Command --source $QcadSource -y

choco install QCAD.Utilities.Fortek.Applications.External.Client.Simulator --source $QcadSource -y

choco install QCAD.Utilities.Fortek.Applications.External.Client.Gateway.Monitor --source $QcadSource -y

choco install QCAD.Utilities.Fortek.Port.Calculator --source $QcadSource -y

choco install QCAD.Utilities.Packet.Manager.Viewer --source $QcadSource -y

choco install QCAD.Utilities.VDW.Log.Viewer --source $QcadSource -y

choco install QCAD.Utilities.APL.Parser.Monitor --source $QcadSource -y

choco install QCAD.Utilities.Fortek.Simulators.CCCM --source $QcadSource -y

choco install QCAD.Utilities.Fortek.Simulators.CCCM.Viewer --source $QcadSource -y

choco install QCAD.Utilities.Service.Installer --source $QcadSource -y


# Configs

Update-VisionIni

Update-VisionSettings

Update-FortekCoreService

Update-VisionDataService

Update-IntegrityCheckerService

Update-NumberCruncherService

Update-VSCMService


# Utilities Config

Update-FortekServiceMonitor

Update-PacketManagerViewer

Update-VscmMonitor

Update-AplParserMonitor

Update-CccmViewer

Update-CccmSimulator

# Windows Services

Update-VisionServices -apiKey $apiKey -listId $listId -serviceExecutable VisionDataService -serviceFolder DataService -serviceName DataService_svr -serviceAccount VisionVDS

Update-VisionServices -apiKey $apiKey -listId $listId -serviceExecutable FortekCoreService -serviceFolder FortekCoreService -serviceName FortekCoreService -serviceAccount VisionFCS

Update-VisionServices -serviceExecutable IntegrityCheckerService -serviceFolder IntegrityChecker -serviceName IntegrityChecker

Update-VisionServices -serviceExecutable NumberCruncherService -serviceFolder NumberCruncher -serviceName NumberCruncher

Update-VisionServices -apiKey $apiKey -listId $listId -serviceExecutable VisionServerConnectionManager -serviceFolder VSCM -serviceName VSCM -serviceAccount VisionVSCM

# Total Time
$duration = New-TimeSpan -Start $Start
"Duration: " + $duration.Hours + ":" + $duration.Minutes + ":" + $duration.Seconds

    
    # ================================
}
catch {
    Write-Error "An error occurred: $_"
}
finally {
    # Stop logging and display results
    Stop-Transcript
}

# Check log for errors and save to a summary file
Select-String -Path $logFile -Pattern "Error" | Out-File $errorSummaryFile
