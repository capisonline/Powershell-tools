﻿# Deployment Script for QCAD Tech Refresh 2024

# Variables
$ServersList = Get-Content -Path "C:\temp\QCAD\PR\scripted-deploy\vcs\VCS-server-list.txt"
$ScriptPath = "C:\temp\QCAD\PR\scripted-deploy\VCS\QCAD-VCS-Install.ps1"
$LogPath = "C:\temp\QCAD\PR\scripted-deploy\VCS\QCAD_VCS_Deployment_Log2233.txt"
$RemoteScriptPath = "C:\Temp\QCAD-VCS-Install.ps1"
$RemoteLogPath = "C:\Temp\QCAD-VCS-Install.log"

# Function to Deploy the Script to Remote Servers
function Deploy-Script {
    param (
        [string]$Server
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] Deploying script to: $Server" -ForegroundColor Green
    "[$timestamp] Deploying script to: $Server" | Out-File -FilePath $LogPath -Append
    
    # Copy the script to the remote server
    try {
        Copy-Item -Path $ScriptPath -Destination "\\$Server\C$\Temp\QCAD-VCS-Install.ps1" -Force -ErrorAction Stop
        Write-Host "[$timestamp] Script copied to $Server" -ForegroundColor Cyan
        "[$timestamp] Script copied to $Server" | Out-File -FilePath $LogPath -Append
    } catch {
        Write-Host "[$timestamp] Failed to copy script to ${Server}: $_" -ForegroundColor Red
        "[$timestamp] Failed to copy script to ${Server}: $_" | Out-File -FilePath $LogPath -Append
        return
    }
    
    # Execute the script remotely and ensure logging is captured
    try {
        Invoke-Command -ComputerName $Server -ScriptBlock {
            $RemoteScriptPath = "C:\\Temp\\QCAD-VCS-Install.ps1"
            $RemoteLogPath = "C:\\Temp\\QCAD-VCS-Install.log"
            if (Test-Path -Path $RemoteScriptPath) {
                Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$RemoteScriptPath`" *>>`"$RemoteLogPath`" 2>&1" -NoNewWindow -Wait
            } else {
                throw "Script file not found on remote server."
            }
        } -ErrorAction Stop
        
        # Ensure the remote log file exists before retrieving it
        $logExists = Invoke-Command -ComputerName $Server -ScriptBlock {
            Test-Path "C:\\Temp\\QCAD-VCS-Install.log"
        }
        
        if ($logExists) {
            # Retrieve log file contents from the remote server
            $remoteOutput = Invoke-Command -ComputerName $Server -ScriptBlock {
                Get-Content -Path "C:\\Temp\\QCAD-VCS-Install.log"
            }
            Write-Host "[$timestamp] Execution output from ${Server}:`n$remoteOutput" -ForegroundColor Yellow
            "[$timestamp] Execution output from ${Server}:`n$remoteOutput" | Out-File -FilePath $LogPath -Append
        } else {
            Write-Host "[$timestamp] Warning: No log file found on remote server." -ForegroundColor Red
            "[$timestamp] Warning: No log file found on remote server." | Out-File -FilePath $LogPath -Append
        }
    } catch {
        Write-Host "[$timestamp] Error executing script on ${Server}: $_" -ForegroundColor Red
        "[$timestamp] Error executing script on ${Server}: $_" | Out-File -FilePath $LogPath -Append
    }
    
    Write-Host "[$timestamp] Deployment completed for $Server" -ForegroundColor Green
    "[$timestamp] Deployment completed for $Server" | Out-File -FilePath $LogPath -Append
}

# Deploy to each server one at a time
foreach ($Server in $ServersList) {
    Deploy-Script -Server $Server
    Start-Sleep -Seconds 2  # Pause briefly before moving to the next server
}

$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Write-Host "[$timestamp] Deployment script execution completed." -ForegroundColor Green
"[$timestamp] Deployment script execution completed." | Out-File -FilePath $LogPath -Append
