﻿<#
# Path to the input CSV file 

ServerName	    LocalPath
QPS-VAS-TP-03	d$\vision\visTP\System_VisTP\New Version

#### !!! Find and replace ':' with '$'
#>
$inputCsvPath = "C:\temp\QCAD\VT\Shared_Folders-NTFS_Perms\VT_NEW_server_shares_NTFS-Perms.csv"

# The CSV file path where the results will be saved
$outputCsvFilePath = "C:\temp\QCAD\VT\Shared_Folders-NTFS_Perms\VT_NEW_server_shares_NTFS-Perms-Output.csv"

# Read the server names and paths from the input CSV file
$serversAndPaths = Import-Csv -Path $inputCsvPath

# Initialize an empty array to hold the results
$results = @()

foreach ($item in $serversAndPaths) {
    $server = $item.ServerName
    $path = $item.LocalPath
    $acl = Get-Acl -Path "\\$server\$path"

    # Initialize an object to hold the permission strings
    $permissionStrings = @()

    foreach ($access in $acl.Access) {
        $identity = $access.IdentityReference.ToString()
        $permissions = $access.FileSystemRights.ToString()
        $permissionString = "$identity : $permissions"
        $permissionStrings += $permissionString
    }

    # Create a result object
    $result = [PSCustomObject]@{
        Server = $server
        Directory = $path
    }

    # Add permission strings to the result object dynamically
    for ($i = 0; $i -lt $permissionStrings.Count; $i++) {
        $result | Add-Member -NotePropertyName "Permission$($i+1)" -NotePropertyValue $permissionStrings[$i]
    }

    # Add the result object to the results array
    $results += $result
}

# Export the results array to a CSV file
$results | Export-Csv -Path $outputCsvFilePath -NoTypeInformation

Write-Host "Permissions report generated at $outputCsvFilePath"
