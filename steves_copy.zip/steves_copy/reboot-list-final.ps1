﻿# ============================
# Simple controlled reboot
# Environment token MUST appear in hostname
# ============================

$Environment = "VT"   # e.g. VT, PR, PA, BA ... (leave blank to be prompted)
$InputFile   = "C:\temp\QCAD\VT\Reboot_list.txt"
$LogFolder   = "C:\temp\QCAD\vt\RebootLogs"

# Prompt for environment if blank (ISE-friendly)
while ([string]::IsNullOrWhiteSpace($Environment)) {
    $Environment = Read-Host "Enter Environment token to enforce (e.g. VT, PR, PA, BA)"
}
$Environment = $Environment.Trim().ToUpper()

if ([string]::IsNullOrWhiteSpace($Environment)) {
    throw "Environment token cannot be blank."
}

# Read targets
if (-not (Test-Path $InputFile)) {
    throw "Input file not found: $InputFile"
}

$Computers = Get-Content $InputFile |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ -ne "" -and $_ -notmatch '^\s*#' } |
    Sort-Object -Unique

if ($Computers.Count -eq 0) {
    throw "No computer names found in $InputFile"
}

# Enforce token in hostname
$Bad = $Computers | Where-Object { $_.ToUpperInvariant() -notlike "*$Environment*" }

if ($Bad.Count -gt 0) {
    throw "Safety stop: these targets do NOT contain '$Environment' in the name: $($Bad -join ', ')"
}

# Timestamped log
if (-not (Test-Path $LogFolder)) { New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null }
$Stamp   = Get-Date -Format "yyyyMMdd_HHmmss"
$LogPath = Join-Path $LogFolder "Reboot_$Environment`_$Stamp.log"

"[$(Get-Date -Format s)] Environment token enforced: $Environment" | Out-File $LogPath
"[$(Get-Date -Format s)] Input file: $InputFile"                  | Out-File $LogPath -Append
"[$(Get-Date -Format s)] Target count: $($Computers.Count)"       | Out-File $LogPath -Append
"" | Out-File $LogPath -Append

# Optional single-line blast control (uncomment if you want it)
# if ((Read-Host "Type YES to reboot $($Computers.Count) servers") -ne "YES") { throw "Aborted." }

# Reboot loop
foreach ($Computer in $Computers) {
    Write-Host "Restarting $Computer..."
    try {
        Restart-Computer -ComputerName $Computer -Force -ErrorAction Stop
        $msg = "[$(Get-Date -Format s)] OK   $Computer"
        Write-Host "  OK"
    }
    catch {
        $msg = "[$(Get-Date -Format s)] FAIL $Computer | $($_.Exception.Message)"
        Write-Host "  FAIL: $($_.Exception.Message)"
    }
    $msg | Out-File $LogPath -Append
}

Write-Host ""
Write-Host "Done. Log: $LogPath"
