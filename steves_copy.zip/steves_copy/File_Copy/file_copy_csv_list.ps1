﻿# Inputfile to be:
# Servername, Filepath
# Path to the input CSV file 
$inputCsvPath = "C:\temp\QCAD\VT\Error_Logs\vision_logfiles_copy_input.csv"

# Local directory to save the copied log files
$localDirectory = "C:\temp\QCAD\VT\Error_Logs\Logs\full_copy"

# Create the local directory if it doesn't exist
if (-not (Test-Path -Path $localDirectory)) {
    New-Item -ItemType Directory -Path $localDirectory
}

# Read the CSV file
$logFileDetails = Import-Csv -Path $inputCsvPath

# Function to copy log files from a remote server to the local machine
function Copy-LogFiles {
    param (
        [string]$server,
        [string]$filePath
    )

    $fileName = Split-Path -Path $filePath -Leaf
    $localFilePath = Join-Path -Path $localDirectory -ChildPath ("$server`_$fileName")
    
    try {
        Copy-Item -Path "\\$server\$($filePath -replace ':', '$')" -Destination $localFilePath -ErrorAction Stop
        Write-Output "Successfully copied $filePath from $server to $localFilePath"
    } catch {
        Write-Output "Failed to copy $filePath from ${server}: $_"
    }
}

# Iterate through each log file detail and copy the files
foreach ($log in $logFileDetails) {
    Copy-LogFiles -server $log.ServerName -filePath $log.FilePath
}

Write-Output "Log file copying process is complete."
