﻿# List of server hostnames or IPs 
$servers = Get-Content "C:\temp\QCAD\"

# Your local directory where the files will be copied
$localDir = "C:\temp\QCAD\PR\Duress_Issue"

# Log file path
$logFile = "C:\temp\QCAD\PR\Duress_Issue\ScriptLog.txt"

# Ensure the local directory exists
if (-not (Test-Path -Path $localDir)) {
    New-Item -ItemType Directory -Path $localDir -ErrorAction SilentlyContinue
}

# Clear or create log file
Out-File -FilePath $logFile -Encoding UTF8 -Force -InputObject "Script started at $(Get-Date)"

# Loop through each server
foreach ($server in $servers) {
    try {
        # Log server processing start
        Add-Content -Path $logFile -Value "Processing server: $server"

        # Use Invoke-Command to perform actions on the remote server
        Invoke-Command -ComputerName $server -ScriptBlock {
            param ($sourceFilePath)
            # Define the source and target file paths
            $sourceFile = "E:\Vision\VisPR\System_VisPR\Log_Backup\Archive\2024-09-25.ZIP"
            $newFileName = "$env:COMPUTERNAME`_2024-09-25.ZIP"

            # Check if the source file exists
            if (Test-Path -Path $sourceFile) {
                # Rename the file (optional step)
                Rename-Item -Path $sourceFile -NewName $newFileName -ErrorAction SilentlyContinue
            }
        } -ArgumentList $sourceFile -ErrorAction SilentlyContinue

        Add-Content -Path $logFile -Value "Successfully processed server: $server"
    }
    catch {
        $errorMsg = "Failed to process server ${server}: $_"
        Add-Content -Path $logFile -Value $errorMsg
        Write-Output $errorMsg
        continue  # Ignore errors and move to the next server
    }

    # Define remote and local file paths
    $remoteFile = "\\$server\E$\Log_Backup\Archive\$server`_2024-09-25.ZIP"
    $destination = Join-Path -Path $localDir -ChildPath "$server`_2024-09-25.ZIP"

    # Copy the file from the remote server to your local machine
    try {
        Copy-Item -Path $remoteFile -Destination $destination -ErrorAction SilentlyContinue
        Add-Content -Path $logFile -Value "File copied from $server to $destination"
    }
    catch {
        $errorMsg = "Failed to copy file from server ${server}: $_"
        Add-Content -Path $logFile -Value $errorMsg
        Write-Output $errorMsg
    }
}

# Log script completion
Add-Content -Path $logFile -Value "Script completed at $(Get-Date)"
Write-Output "Script completed. Log saved to $logFile"
