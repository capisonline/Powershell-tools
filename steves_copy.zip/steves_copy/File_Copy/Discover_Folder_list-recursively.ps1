﻿# Define the path of the folder you want to scan 
$targetFolder = "E:\Log_Backup\Archive"  # Update this with the path of the folder you want to check

# Define the path to the input file containing the list of server names
$serverListPath = "C:\temp\QCAD\PR\PR_OLD_servers.txt"  # Update with the path to your server list file

# Define the output CSV file
$outputCsv = "C:\temp\QCAD\PR\Duress_Issue\PR_OLD_Log_FolderList-1.csv"  # Update with the desired output file path

# Initialize an array to store the results
$results = @()

# Read the list of servers
$servers = Get-Content -Path $serverListPath

# Loop through each server
foreach ($server in $servers) {
    try {
        # Get folder paths in the target folder on the remote server
        $folders = Invoke-Command -ComputerName $server -ScriptBlock {
            param ($targetFolder)
            Get-ChildItem -Path $targetFolder -Recurse -Directory | Select-Object -ExpandProperty FullName
        } -ArgumentList $targetFolder -ErrorAction Stop

        # Add each folder path as a new row with the hostname
        foreach ($folder in $folders) {
            $results += [PSCustomObject]@{
                Hostname    = $server
                FolderList  = $folder
            }
        }
    }
    catch {
        # Handle errors (e.g., if the server is unreachable)
        $results += [PSCustomObject]@{
            Hostname    = $server
            FolderList  = "Error: $_"
        }
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsv -NoTypeInformation -Encoding UTF8

Write-Output "Folder list saved to $outputCsv"
