﻿# Pull-FirewallLogs.ps1
# Copies firewall log files from multiple servers to your local machine

$servers = Get-Content "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"
$remoteBasePath = "E$\Logs\scripts\firewall"
$localOutputPath = "C:\temp\QCAD\VT\Networking\firewall-logs"

# Create local output folder if needed
if (-not (Test-Path $localOutputPath)) {
    New-Item -Path $localOutputPath -ItemType Directory | Out-Null
}

foreach ($server in $servers) {
    $remoteFile = "\\$server\$remoteBasePath\$server`_firewall.csv"
    $localFile = Join-Path $localOutputPath "$server`_firewall.csv"

    Write-Host "Copying from $server..."

    try {
        Copy-Item -Path $remoteFile -Destination $localFile -Force -ErrorAction Stop
        Write-Host "$server - Log copied successfully." -ForegroundColor Green
    } catch {
        Write-Warning "$server - Failed to copy log file: $_"
    }
}

Write-Host "`nAll available logs copied to: $localOutputPath"
