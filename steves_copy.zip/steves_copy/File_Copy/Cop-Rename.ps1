﻿# List of server hostnames or IPs 
$servers = get-content "C:\temp\QCAD\PR\PR_OLD_servers.txt"

# Your local directory where the files will be copied
$localDir = "C:\temp\QCAD\PR\Duress_Issue"

# Ensure the local directory exists
if (-not (Test-Path -Path $localDir)) {
    New-Item -ItemType Directory -Path $localDir
}

# Loop through each server
foreach ($server in $servers) {
    # Use Invoke-Command to perform actions on the remote server
    Invoke-Command -ComputerName $server -ScriptBlock {
        # Define the source and target file paths
        $sourceFile = "E:\Log_Backup\Archive\2024-09-25.ZIP"
        $newFileName = "$env:COMPUTERNAME`_2024-09-25.ZIP"
        
        
        # Check if the source file exists
        if (Test-Path -Path $sourceFile) {
            # Rename the file
            Rename-Item -Path $sourceFile -NewName $newFileName
        }
    } -ErrorAction Stop

    # Copy the renamed file to your local machine
    $remoteFile = "\\$server\E`$\Log_Backup\Archive\$server`_2024-09-25.ZIP"
    $destination = Join-Path -Path $localDir -ChildPath "$server`_2024-09-25.ZIP"

    # Copy the file
    Copy-Item -Path $remoteFile -Destination $destination -ErrorAction SilentlyContinue
}
