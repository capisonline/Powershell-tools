﻿# Copies files to servers based on the filename - files need to be named the hostname.

# Local directory containing the text files named after the remote server hostnames 
$localDirectory = "C:\temp\QCAD\PR\Roles_Features\Input_Txt_Files"

# Directory on remote servers where the files should be copied
$remoteDirectory = "C$\temp"

# Iterate through each text file in the local directory
Get-ChildItem -Path $localDirectory -Filter "*.txt" | ForEach-Object {
    $localFile = $_.FullName
    $remoteHostname = $_.BaseName  # File name without extension, assumed to be the hostname

    # Define the destination path on the remote server
    $remoteFilePath = "\\$remoteHostname\$remoteDirectory\$($_.Name)"

    # Copy the file to the remote server
    Try {
        Copy-Item -Path $localFile -Destination $remoteFilePath -Force
        Write-Host "File copied successfully to $remoteFilePath"
    } Catch {
        Write-Host "Failed to copy file to $remoteFilePath. Error: $_"
    }
}
