﻿# Path to the text file containing the server names 
$serverListPath = "C:\temp\scripts\server_list.txt"

# The CSV file path where the results will be saved
$outputCsvFilePath = "C:\temp\QCAD\TP\Shares\Old\outputPermissionsReport.csv"

# Read the server names and paths from the input CSV file
$serversAndPaths = Import-Csv -Path $inputCsvPath

# Initialize an empty array to hold the results
$results = @()

foreach ($item in $serversAndPaths) {
    $server = $item.ColumnA
    $path = $item.ColumnB

    # Check if the server is reachable
    $isReachable = Test-Connection -ComputerName $server -Count 1 -Quiet

    if ($isReachable) {
        $acl = Get-Acl -Path "\\$server\$path"

        # Initialize an object to hold the permission strings
        $permissionStrings = @()

        foreach ($access in $acl.Access) {
            $identity = $access.IdentityReference.ToString()
            $permissions = $access.FileSystemRights.ToString()
            $permissionString = "$identity : $permissions"
            $permissionStrings += $permissionString
        }

        # Create a result object
        $result = [PSCustomObject]@{
            Server = $server
            Directory = $path
        }

        # Add permission strings to the result object dynamically
        for ($i = 0; $i -lt $permissionStrings.Count; $i++) {
            $result | Add-Member -NotePropertyName "Permission$($i+1)" -NotePropertyValue $permissionStrings[$i]
        }

        # Add the result object to the results array
        $results += $result
    }
    else {
        Write-Host "Server $server is not reachable. Skipping..."
    }
}

# Export the results array to a CSV file
$results | Export-Csv -Path $outputCsvFilePath -NoTypeInformation
