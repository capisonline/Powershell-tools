﻿<#
.SYNOPSIS
    QCAD Production DFS Discovery - Netstat Logger with Rollover and Remote Archiving

.DESCRIPTION
    This script captures detailed network connection data using `netstat -bano` at regular intervals (every 240 seconds),
    flattens the output for readability, and appends it to a timestamped log file.

    The log file is automatically rolled over once it exceeds a defined size threshold (default: 20MB).
    Rolled files are renamed with a `.rolledlog` extension and include the hostname and timestamp to ensure traceability.

    Rolled files are then MOVED to a central collection server at:
        \\polvcadmgtdv01\D$\PR_Discovery\Netstat

    This allows safe collection of network-level activity from production servers without impacting running services,
    and ensures a rolling, time-stamped archive is retained for audit or DR validation purposes.

    - Uses netstat with process binding (`-bano`) to capture executable and PID info
    - Logs are flattened into a readable format for correlation across tools
    - Prevents in-progress log files from being moved
    - Designed to run continuously in the background, ideally via Scheduled Task as SYSTEM

.PARAMETERS
    None — all paths and thresholds are defined in script variables.

.NOTES
    Author: Rogers.Steven2@police.qld.gov.au

#>

$hostname = $env:COMPUTERNAME
$logDir = "D:\Failtesting\NetstatLogs"
$remotePath = "\\polvcadmgtdv01\D$\Failtesting\VT\Netstat"
$logFileBase = Join-Path $logDir "$hostname`_netstat.csv"


# For testing reduce to 1 & comment out sleeptime below 
$maxSizeMB = 20

# Ensure local directory exists
if (-not (Test-Path $logDir)) {
    New-Item -ItemType Directory -Path $logDir | Out-Null
}

while ($true) {
    try {
        # Check and roll if needed
        if (Test-Path $logFileBase) {
            $fileSizeMB = (Get-Item $logFileBase).Length / 1MB
            if ($fileSizeMB -ge $maxSizeMB) {
                $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
                $rolledFile = "$hostname`_netstat_$timestamp.rolledlog"
                $rolledPath = Join-Path $logDir $rolledFile
                Rename-Item -Path $logFileBase -NewName $rolledFile -Force
                move-Item -Path $rolledPath -Destination $remotePath -Force
            }
        }

        # Run netstat -bano and flatten output
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        "`n--- NETSTAT Snapshot: $timestamp ---`n" | Out-File -Append $logFileBase

        $FormattedNetstatOutput = (netstat -bano 2>&1 | Out-String) `
            -replace '(?m)^  (TCP|UDP)', '$1' `
            -replace '\r?\n\s+([^\[])', "`t`$1" `
            -replace '\r?\n\s+\[', "`t["

        $FormattedNetstatOutput | Out-File -Append -FilePath $logFileBase

    } catch {
        "Error: $_" | Out-File -Append "$logDir\error.log"
    }

    Start-Sleep -Seconds 240
}
