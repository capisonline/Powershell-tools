﻿
# Save below as *.ps1 and execute as a task so someone else can cancel it...
# Get the hostname of the computer 
$hostname = $env:COMPUTERNAME
$OutputFile = "C:\temp\" + $hostname + "_netstat.txt"

while ($true) {
    # Run netstat -bano command, format the output, and save it to a variable
    $FormattedNetstatOutput = (netstat -bano | Out-String) -replace '(?m)^  (TCP|UDP)', '$1' -replace '\r?\n\s+([^\[])', "`t`$1" -replace '\r?\n\s+\[', "`t["

    # Save the formatted output to a text file
    $FormattedNetstatOutput | Out-File -Append -FilePath $OutputFile

    # Wait for 240 seconds before running the command again
    Start-Sleep -Seconds 240
}

<#
# Once file is saved - clean up the file (sometimes they get really big)
$inputfile = "C:\temp\FormattedNetstatOutput.txt"
$outputfile = "C:\temp\C:\temp\FormattedNetstat-cleaned_outputfile.txt"
Get-Content $inputfile | sort | get-unique > $outputfile
#>


