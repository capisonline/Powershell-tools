﻿# Define the path to the folder containing the files 
$folderPath = "C:\temp\QCAD\TP\Networking\Netstat"

# Get all files in the folder that match the pattern
$files = Get-ChildItem -Path $folderPath -Filter "*_netstat.txt"

# Loop through each file
foreach ($file in $files) {
    # Define the input file path
    $inputFile = $file.FullName

    # Define the output file path by appending "-formatted" before the file extension
    $outputFile = $file.FullName -replace "\.txt$", "-formatted.txt"

    # Read the content of the file, sort it, get unique lines, and write them to the output file
    Get-Content $inputFile | Sort-Object | Get-Unique | Out-File $outputFile
}

# Print a message when the script completes processing all files
Write-Output "All files have been processed and saved with '-formatted.txt' suffix."
