﻿<#
 ---------------------------------------------
 QCAD Firewall Isolation Script (GPO Logging Friendly)
 ---------------------------------------------
 - Applies one inbound and one outbound block rule per IP
 - Logging settings are handled via GPO (this script doesn't modify them)
 - Designed for use in PowerShell ISE
 - review logs: %systemroot%\system32\logfiles\firewall\pfirewall.log
#>

# Input file paths
$serverListPath = "C:\temp\QCAD\vt\VT_Old_Servers.txt"
$blockListPath  = "C:\temp\QCAD\VT\Networking\VT_Prod_Oracle_Servers_firewall_list.txt"

# Read and sanitize input
$servers = Get-Content $serverListPath | Where-Object { $_ -and ($_ -notmatch "^#") }
$blockRanges = Get-Content $blockListPath | Where-Object { $_ -and ($_ -notmatch "^#") }

# Remote script block to run on each server
$RemoteScript = {
    # Unpack first argument as IP list
    $blockRanges = @($args[0])

    $VerbosePreference = "Continue"
    $hostname = $env:COMPUTERNAME

    Write-Verbose "[$hostname] Received $($blockRanges.Count) IPs to block"

    foreach ($ip in $blockRanges) {
        $ip = $ip.Trim()
        if ($ip) {
            $safeName = $ip.Replace("/", "_").Replace(".", "_")
            $ruleOut = "Block_OLD_PROD_Outbound_$safeName"
            $ruleIn  = "Block_OLD_PROD_Inbound_$safeName"

            try {
                Write-Verbose "[$hostname] Creating OUTBOUND block rule for $ip"
                New-NetFirewallRule -DisplayName $ruleOut -Direction Outbound `
                    -RemoteAddress $ip -Action Block -Enabled True -Profile Any -ErrorAction Stop

                Write-Verbose "[$hostname] Creating INBOUND block rule for $ip"
                New-NetFirewallRule -DisplayName $ruleIn -Direction Inbound `
                    -RemoteAddress $ip -Action Block -Enabled True -Profile Any -ErrorAction Stop
            }
            catch {
                Write-Warning "[$hostname] Failed to create rules for ${ip}: $_"
            }
        }
    }

    Write-Verbose "[$hostname] Completed firewall rule creation"
}

# Loop through each server and apply the rules
foreach ($server in $servers) {
    Write-Host "`n[$(Get-Date -Format 'HH:mm:ss')] Applying firewall rules to $server..." -ForegroundColor Cyan

    try {
        Invoke-Command `
            -ComputerName $server `
            -ScriptBlock $RemoteScript `
            -ArgumentList (,($blockRanges)) `
            -Verbose `
            -ErrorAction Stop
    }
    catch {
        Write-Warning "[$server] Could not connect or execute remote script: $_"
    }
}
