﻿<#
================================================================================
 QCAD Firewall Rule Verification Script - QA Audit for Old PROD Block Rules
================================================================================

Purpose:
--------
This script checks that all expected QCAD firewall rules (inbound and outbound)
exist on a list of servers. It verifies rules that were applied as part of the
"OLD PROD isolation" process — specifically those starting with the name:
  - Block_OLD_PROD_Outbound_<IP>
  - Block_OLD_PROD_Inbound_<IP>

How it works:
-------------
- Reads a list of target servers and IPs from input text files
- Connects to each server using PowerShell remoting
- Checks if the expected firewall rules exist for each IP
- Outputs the result in the console and saves a CSV report for QA records

Expected Inputs:
----------------
- A list of servers:        C:\temp\QCAD\VT\VT_NEW_Server_list.txt
- A list of IPs to block:   C:\temp\QCAD\VT\Networking\firewall_block_input.txt

Output:
-------
- A verification CSV:       C:\temp\QCAD\VT\firewall_rule_verification_report.csv

Use this script as part of the QA handover to demonstrate firewall rule compliance.

================================================================================
#>

# Input file paths
$serverListPath = "C:\temp\QCAD\PR\PR_New_Servers.txt"
$blockListPath  = "C:\temp\QCAD\PR\Networking\PR_old_firewall_list.txt"
$outputCsvPath  = "C:\temp\QCAD\PR\Networking\PR_firewall_rule_verification_report.csv"

# Read inputs
$servers = Get-Content $serverListPath | Where-Object { $_ -and ($_ -notmatch "^#") }
$blockRanges = Get-Content $blockListPath | Where-Object { $_ -and ($_ -notmatch "^#") }

# Prepare output array
$results = @()

foreach ($server in $servers) {
    Write-Host "`n[$(Get-Date -Format 'HH:mm:ss')] Checking firewall rules on $server..." -ForegroundColor Yellow

    try {
        $firewallRules = Invoke-Command -ComputerName $server -ScriptBlock {
            Get-NetFirewallRule | Where-Object { $_.DisplayName -like "Block_OLD_PROD_*" }
        } -ErrorAction Stop

        $existingNames = $firewallRules.DisplayName

        foreach ($ip in $blockRanges) {
            $safeName = $ip.Trim().Replace("/", "_").Replace(".", "_")
            $expectedOut = "Block_OLD_PROD_Outbound_$safeName"
            $expectedIn  = "Block_OLD_PROD_Inbound_$safeName"

            $outExists = $existingNames -contains $expectedOut
            $inExists  = $existingNames -contains $expectedIn

            $results += [pscustomobject]@{
                Server         = $server
                IPAddress      = $ip
                OutboundRule   = if ($outExists) { "Exists" } else { "Missing" }
                InboundRule    = if ($inExists)  { "Exists" } else { "Missing" }
            }
        }
    }
    catch {
        Write-Warning "[$server] Could not connect: $_"
        foreach ($ip in $blockRanges) {
            $results += [pscustomobject]@{
                Server         = $server
                IPAddress      = $ip
                OutboundRule   = "No Data"
                InboundRule    = "No Data"
            }
        }
    }
}

# Output to screen and file
$results | Format-Table -AutoSize
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation
Write-Host "`nReport saved to: $outputCsvPath" -ForegroundColor Green
