﻿# ExportFirewall.ps1
# Collects Windows Firewall log entries from the last 2 hours and exports them to E:\logs\scripts\firewall\<hostname>_firewall.csv

$logPath = "$env:SystemRoot\System32\LogFiles\Firewall\pfirewall.log"
$cutoffTime = (Get-Date).AddHours(-2)
$hostname = $env:COMPUTERNAME

$outputFolder = "E:\logs\scripts\firewall"
$outputPath = Join-Path $outputFolder "$hostname`_firewall.csv"

# Ensure output folder exists
if (-not (Test-Path $outputFolder)) {
    New-Item -Path $outputFolder -ItemType Directory -Force | Out-Null
}

# Define the firewall log headers (excluding Hostname for now)
$headerFields = @(
    "date","time","action","protocol","src-ip","dst-ip",
    "src-port","dst-port","size","tcpflags","tcpsyn","tcpack",
    "tcpwin","icmptype","icmpcode","info","path"
)

# Compose the final CSV headers
$csvHeaders = "Hostname" + "," + ($headerFields -join ",")

# Write headers only if the file does not exist yet
if (-not (Test-Path $outputPath)) {
    $csvHeaders | Out-File -FilePath $outputPath -Encoding UTF8
}

# Parse and filter log content
Get-Content $logPath | Where-Object { $_ -and ($_ -notlike '#*') } |
    ConvertFrom-Csv -Header $headerFields -Delimiter ' ' |
    Where-Object {
        $timestamp = "$($_.date) $($_.time)"
        try {
            $logTime = [datetime]::ParseExact($timestamp, 'yyyy-MM-dd HH:mm:ss', $null)
            $logTime -gt $cutoffTime
        } catch {
            $false
        }
    } |
    Select-Object @{Name='Hostname'; Expression = { $hostname } }, * |
    Export-Csv -Path $outputPath -Append -NoTypeInformation -Encoding UTF8
