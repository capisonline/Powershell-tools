﻿<# Pulls from a CSV - outputs results to a CSV
Structure Inpufile like this: 
Column A         Column B
Servername	     Port List
%hostname%  	 80
#>

# Inputfile
$serverData = Import-Csv -Path "C:\temp\QCAD\TP\Networking\TP_server_port_list.csv"

# Output file  
$outputFileName = "C:\temp\QCAD\TP\Networking\TP_port_check_results-final.csv"

# Create an empty array to store the results
$results = @()

# Loop through each server entry in the CSV
foreach ($server in $serverData) {
    $serverName = $server.Servername #< Column A name
    $ports = $server.'Port list'.Split(',') #< Column B name

    # Resolve the IP address of the server
    $ipAddress = [System.Net.Dns]::GetHostAddresses($serverName)[0].IPAddressToString

    # Check each port for the current server
    foreach ($port in $ports) {
        $port = $port.Trim()  # Trim spaces
        try {
            # Create TCP client to check the port
            $tcpClient = New-Object System.Net.Sockets.TcpClient
            $connect = $tcpClient.BeginConnect($serverName, $port, $null, $null)
            $success = $connect.AsyncWaitHandle.WaitOne(500, $false)
            $tcpClient.Close()

            # Determine port status based on connection attempt
            if ($success) {
                $status = "Open"
            } else {
                $status = "Closed"
            }
        } catch {
            # Handle any exceptions during the connection attempt
            $status = "Closed"
        }

        # Create an object to represent the result
        $resultObject = [PSCustomObject]@{
            Servername = $serverName
            IP = $ipAddress
            Port = $port
            Status = $status
        }

        # Add the result object to the array
        $results += $resultObject
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputFileName -NoTypeInformation

Write-Host "Port check results saved to $outputFileName"
