﻿# Read IPs from a text file 
$ips = Get-Content "C:\temp\QCAD\pa\PA_NEW_Server_list.txt"
#$output = "C:\temp\QCAD\PA\Networking\ping_list.csv"
# Prepare the results array
$results = @()

foreach ($ip in $ips) {
    # Start a background job for each ping to speed up the process
    $job = Start-Job -ScriptBlock {
        param($ip)
        try {
            # Perform the ping
            $ping = Test-Connection -ComputerName $ip -Count 1 -timeoutseconds 2 -ErrorAction Stop
            
            # Try to resolve hostname
            $hostName = [System.Net.Dns]::GetHostEntry($ip).HostName
        }
        catch {
            $ping = $null
            $hostName = "Hostname not found"
        }

        if ($ping) {
            $status = "Responded"
        } else {
            $status = "No response"
        }

        # Output the results to be collected later
        [PSCustomObject]@{
            IP       = $ip
            HostName = $hostName
            Status   = $status
        }
    } -ArgumentList $ip

    # Add the job to the results array
    $results += $job
}

# Wait for all jobs to complete
$results | Wait-Job

# Collect output from each job
$output = $results | Receive-Job

# Export the results to a CSV file
$output | Export-Csv "C:\temp\QCAD\PR\Networking\PR-ORA_ping-list.csv" -NoTypeInformation #-Append -Force

# Cleanup jobs
$results | Remove-Job
