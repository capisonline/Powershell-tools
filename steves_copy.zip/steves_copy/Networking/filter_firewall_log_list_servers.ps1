﻿<#
.SYNOPSIS
    Collects Windows Firewall log entries from a list of remote servers, filters entries from the last 2 hours,
    and consolidates them into a single CSV file with the format:
    Hostname, Timestamp, Action, Protocol, SrcIP, DstIP, SrcPort, DstPort, Flags, Sequence, Ack, Window, etc.

.DESCRIPTION
    This script uses PowerShell Remoting (WinRM) to:
    - Connect to each server listed in 'servers.txt'
    - Read the contents of %SystemRoot%\System32\LogFiles\Firewall\pfirewall.log
    - Filter lines with a timestamp within the last 2 hours
    - Parse and transform those lines into a structured format
    - Append all data into a single CSV file on the local machine

.NOTES
    - Make sure WinRM is enabled on all target servers
    - Requires admin access on the remote systems
    - Timestamps in logs must be in 'yyyy-MM-dd HH:mm:ss' format


#>

$serverList = Get-Content -Path "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"
$outputCsv = "C:\temp\QCAD\VT\Networking\firewall-logs\Consolidated_FirewallLogs.csv"
$cutoffTime = (Get-Date).AddHours(-2)

# Initialize CSV with headers
"Hostname,Timestamp,Action,Protocol,SrcIP,DstIP,SrcPort,DstPort,Other" | Out-File -FilePath $outputCsv -Encoding UTF8

foreach ($server in $serverList) {
    Write-Host "Connecting to $server ..." -ForegroundColor Cyan

    try {
        $session = New-PSSession -ComputerName $server -ErrorAction Stop

        $logContent = Invoke-Command -Session $session -ScriptBlock {
            $logPath = "$env:SystemRoot\System32\LogFiles\Firewall\pfirewall.log"
            if (Test-Path $logPath) {
                Get-Content -Path $logPath -ErrorAction Stop
            } else {
                Write-Output "NOLOGFOUND"
            }
        }

        Remove-PSSession -Session $session

        if ($logContent -eq "NOLOGFOUND") {
            Write-Warning "Firewall log not found on $server."
            continue
        }

        $entriesFound = 0

        foreach ($line in $logContent) {
            if ($line -match '^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}') {
                $timestamp = Get-Date ($line.Split(' ')[0..1] -join ' ') -ErrorAction SilentlyContinue
                if ($timestamp -and $timestamp -gt $cutoffTime) {
                    $fields = $line -split '\s+'
                    $hostname = $server
                    $time = "$($fields[0]) $($fields[1])"
                    $action = $fields[2]
                    $protocol = $fields[3]
                    $srcIP = $fields[4]
                    $dstIP = $fields[5]
                    $srcPort = $fields[6]
                    $dstPort = $fields[7]
                    $rest = ($fields[8..($fields.Length - 1)] -join " ")
                    "$hostname,$time,$action,$protocol,$srcIP,$dstIP,$srcPort,$dstPort,""$rest""" | Out-File -FilePath $outputCsv -Append -Encoding UTF8
                    $entriesFound++
                }
            }
        }

        if ($entriesFound -gt 0) {
            Write-Host "$server - $entriesFound entries saved." -ForegroundColor Green
        } else {
            Write-Host "$server - No entries found in last 2 hours." -ForegroundColor Yellow
        }
    } catch {
        Write-Warning "Failed to collect logs from ${server}: $_"
    }
}


Write-Host "Collection complete. Output saved to: $outputCsv"
