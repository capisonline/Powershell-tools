﻿# -----------------------------
# QCAD Firewall Rule Cleanup Script
# Removes all block rules created by the isolation script
# -----------------------------

# Input: same server list used previously
$serverListPath = "C:\firewall\server_list.txt"
$servers = Get-Content $serverListPath | Where-Object { $_ -and ($_ -notmatch "^#") }

# Script to remove rules from remote servers
$RemoteCleanupScript = {
    $VerbosePreference = "Continue"
    $rules = Get-NetFirewallRule | Where-Object { $_.DisplayName -like "Block_OLD_PROD_*" }

    foreach ($rule in $rules) {
        Write-Verbose "Removing rule: $($rule.DisplayName)"
        Remove-NetFirewallRule -DisplayName $rule.DisplayName -ErrorAction SilentlyContinue
    }

    Write-Verbose "Removed $($rules.Count) rules from $env:COMPUTERNAME"
}

# Loop through servers
foreach ($server in $servers) {
    Write-Host "`n[$(Get-Date -Format 'HH:mm:ss')] Cleaning up rules on $server..." -ForegroundColor Yellow
    Invoke-Command -ComputerName $server -ScriptBlock $RemoteCleanupScript -Verbose
}
