<#
.SYNOPSIS
    Run tracert from each in-scope host to its Stage 1 destination list and
    aggregate per-host path CSVs.

.DESCRIPTION
    Stage 2 of the discovery pipeline. Reads the consolidated targets CSV
    produced by Build-TracertTargets.ps1, fans out to in-scope hosts via
    Invoke-Command with -ThrottleLimit parallelism, runs tracert.exe per
    target on each host, parses the output into structured hop rows, and
    writes one <hostname>_paths.csv per host.

    Operator-aggregated (Option A): each host's script block runs tracert
    and returns rows back through the PSRemoting pipeline. The operator
    workstation writes the per-host CSVs directly — no second-hop
    credential problem, no scheduled task footprint on hosts.

    Compatibility:
      - tracert.exe (universal back to NT)
      - Win32_IP4RouteTable via Get-WmiObject for local default gateway
        discovery (works on Server 2008+; Get-NetRoute is Win8/2012+ and
        deliberately not used)
      - Operator workstation needs PowerShell 5.1, PSRemoting enabled

    Retries: failed hosts (no result returned, transient WinRM) are retried
    up to -RetryCount times. Hosts that returned a result but with internal
    failures (timeouts, unreachable destinations) are NOT retried — those
    are real network behaviours and the per-host CSV captures them.

.PARAMETER TargetsCsv
    Output of Build-TracertTargets.ps1. CSV with SourceHost, Destination
    columns. Mandatory.

.PARAMETER FleetCsv
    The fleet CSV (same shape as Deploy/Remove). Used to map SourceHost to
    a DNSHostName. Only hosts present in BOTH the targets CSV and the
    fleet CSV are invoked. Mandatory.

.PARAMETER OutputDir
    Where to write per-host <hostname>_paths.csv. Default ..\output\paths\.
    Copy to \\AUBNETS5\<share>\paths\ post-run.

.PARAMETER ReportDir
    Where to write the run transcript + per-host PASS/FAIL CSV report.
    Default ..\output\.

.PARAMETER ThrottleLimit
    Cross-host concurrency (Invoke-Command native). Default 32.

.PARAMETER MaxHops
    Passed to tracert -h. Default 30.

.PARAMETER PerHopTimeoutMs
    Passed to tracert -w. Default 2000. Worst-case per-trace time is
    MaxHops × PerHopTimeoutMs × 3 = 180 s with these defaults.

.PARAMETER PerHostCeilingSec
    Hard cap inside the script block on a host's whole trace run (sum of
    all traces). Default 600 s. Hosts hitting it return their partial
    result with a 'host ceiling reached' note.

.PARAMETER RetryCount
    Retries for hosts that didn't return a result (transient WinRM, etc).
    Default 2 → up to 3 total attempts per host. Linear backoff capped at 30s.

.EXAMPLE
    .\Invoke-FleetTracert.ps1 -TargetsCsv ..\output\tracert_targets_<utc>.csv `
                              -FleetCsv ..\inventory\pa_servers_deployed.csv `
                              -WhatIf
    Dry run: prints reachability + how many hosts would be invoked.

.EXAMPLE
    .\Invoke-FleetTracert.ps1 -TargetsCsv ..\output\tracert_targets_<utc>.csv `
                              -FleetCsv ..\inventory\pilot.csv `
                              -ThrottleLimit 8
    Pilot run with reduced concurrency.

.NOTES
    See ..\deployment\DEPLOYMENT_README.md § Stage 2 for the design.
#>

#Requires -Version 5.1

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)]
    [ValidateScript({ Test-Path $_ })]
    [string] $TargetsCsv,

    [Parameter(Mandatory)]
    [ValidateScript({ Test-Path $_ })]
    [string] $FleetCsv,

    [string] $OutputDir = (Join-Path $PSScriptRoot '..\output\paths'),
    [string] $ReportDir = (Join-Path $PSScriptRoot '..\output'),

    [ValidateRange(1, 128)] [int] $ThrottleLimit     = 32,
    [ValidateRange(1, 60)]  [int] $MaxHops           = 30,
    [ValidateRange(100, 10000)] [int] $PerHopTimeoutMs = 2000,
    [ValidateRange(60, 3600)]  [int] $PerHostCeilingSec = 600,
    [ValidateRange(0, 10)]  [int] $RetryCount        = 2
)

# ============================================================
# Setup
# ============================================================
foreach ($d in @($OutputDir, $ReportDir)) {
    if (-not (Test-Path -LiteralPath $d)) {
        New-Item -Path $d -ItemType Directory -Force | Out-Null
    }
}

$utc        = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
$transcript = Join-Path $ReportDir "tracert_$utc.log"
$reportCsv  = Join-Path $ReportDir "tracert_report_$utc.csv"

Start-Transcript -Path $transcript -Append | Out-Null

function Write-FleetLog {
    param(
        [Parameter(Mandatory)] [string] $Message,
        [ValidateSet('INFO','WARN','ERROR','PASS','FAIL','SKIP')] [string] $Level = 'INFO'
    )
    Write-Host "$(Get-Date -Format 'HH:mm:ss.fff') [$Level] $Message"
}

function Get-RowHostname {
    param([object] $Row)
    if ($Row.DNSHostName) { return $Row.DNSHostName }
    return $Row.Name
}

function Test-Target {
    param([string] $Hostname)
    try { $null = Test-WSMan -ComputerName $Hostname -ErrorAction Stop; return $true }
    catch { return $false }
}

# ============================================================
# Remote script block - runs on each host
# Filters $AllPairs to its own targets, runs tracert per target with a
# whole-host time ceiling, parses output, returns one PSCustomObject.
# ============================================================
$remoteScript = {
    param($AllPairs, $MaxHops, $PerHopTimeoutMs, $CeilingSec)

    function ConvertTo-RttMs {
        param([string] $Token)
        if ($Token -eq '*') { return $null }
        $t = $Token.Trim() -replace '<','' -replace '\s*ms\s*$',''
        try { return [int]$t } catch { return $null }
    }

    function Parse-TracertOutput {
        param([object[]] $Output, [string] $Destination)

        $hopRe = '^\s*(?<hop>\d+)\s+' +
                 '(?<r1>(?:<?\d+\s*ms|\*))\s+' +
                 '(?<r2>(?:<?\d+\s*ms|\*))\s+' +
                 '(?<r3>(?:<?\d+\s*ms|\*))\s+' +
                 '(?<addr>.+)$'

        $rows          = New-Object System.Collections.Generic.List[object]
        $reached       = $false
        $traceComplete = $false

        foreach ($line in $Output) {
            $s = "$line".Trim()
            if (-not $s) { continue }

            if ($s -match $hopRe) {
                $addr  = $matches['addr'].Trim()
                $notes = ''
                if ($addr -eq 'Request timed out.') {
                    $addr  = ''
                    $notes = 'all probes timed out'
                }
                $rows.Add([PSCustomObject]@{
                    HopNumber  = [int]$matches['hop']
                    HopAddress = $addr
                    RTT1ms     = (ConvertTo-RttMs $matches['r1'])
                    RTT2ms     = (ConvertTo-RttMs $matches['r2'])
                    RTT3ms     = (ConvertTo-RttMs $matches['r3'])
                    Notes      = $notes
                }) | Out-Null
            }
            elseif ($s -match '^Trace complete') {
                $traceComplete = $true
            }
        }

        if ($traceComplete) {
            $reached = $true
        }
        elseif ($rows.Count -gt 0 -and $rows[-1].HopAddress -eq $Destination) {
            $reached = $true
        }

        return [PSCustomObject]@{ Rows = $rows; Reached = $reached }
    }

    # --- Filter to this host's targets ---
    $hostname = $env:COMPUTERNAME
    $myTargets = @($AllPairs | Where-Object { $_.SourceHost -eq $hostname } |
                   Select-Object -ExpandProperty Destination)

    if ($myTargets.Count -eq 0) {
        return [PSCustomObject]@{
            Hostname         = $hostname
            LocalGateway     = ''
            TargetsAttempted = 0
            TracesReached    = 0
            TracesIncomplete = 0
            CeilingReached   = $false
            Rows             = @()
            Message          = 'no targets for this host'
        }
    }

    # --- Discover local default gateway (Server 2008+ via WMI) ---
    $localGateway = ''
    try {
        $default = Get-WmiObject -Class Win32_IP4RouteTable -ErrorAction Stop |
            Where-Object { $_.Destination -eq '0.0.0.0' -and $_.Mask -eq '0.0.0.0' } |
            Sort-Object Metric1 | Select-Object -First 1
        if ($default) { $localGateway = $default.NextHop }
    } catch {
        # Non-fatal; tracerts run regardless.
    }

    # --- Run traces with whole-host ceiling ---
    $runTs        = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $allRows      = New-Object System.Collections.Generic.List[object]
    $reachedCount = 0
    $incompleteCount = 0
    $ceilingReached  = $false
    $stopAt = (Get-Date).AddSeconds($CeilingSec)

    foreach ($dest in $myTargets) {
        if ((Get-Date) -gt $stopAt) {
            $ceilingReached = $true
            break
        }

        try {
            $out    = & tracert.exe '-d' '-h' "$MaxHops" '-w' "$PerHopTimeoutMs" $dest 2>&1
            $parsed = Parse-TracertOutput $out $dest
        } catch {
            $parsed = [PSCustomObject]@{ Rows = @(); Reached = $false }
        }

        if ($parsed.Reached) { $reachedCount++ } else { $incompleteCount++ }

        if ($parsed.Rows.Count -eq 0) {
            $allRows.Add([PSCustomObject]@{
                RunTimestamp = $runTs
                SourceHost   = $hostname
                Destination  = $dest
                HopNumber    = 0
                HopAddress   = ''
                RTT1ms       = $null; RTT2ms = $null; RTT3ms = $null
                Reached      = $false
                Notes        = 'no hops parsed'
            }) | Out-Null
        }
        else {
            foreach ($r in $parsed.Rows) {
                $allRows.Add([PSCustomObject]@{
                    RunTimestamp = $runTs
                    SourceHost   = $hostname
                    Destination  = $dest
                    HopNumber    = $r.HopNumber
                    HopAddress   = $r.HopAddress
                    RTT1ms       = $r.RTT1ms
                    RTT2ms       = $r.RTT2ms
                    RTT3ms       = $r.RTT3ms
                    Reached      = $parsed.Reached
                    Notes        = $r.Notes
                }) | Out-Null
            }
        }
    }

    $msg = ''
    if ($ceilingReached) {
        $remaining = $myTargets.Count - ($reachedCount + $incompleteCount)
        $msg = "host ceiling ${CeilingSec}s reached; $remaining target(s) not attempted"
    }

    return [PSCustomObject]@{
        Hostname         = $hostname
        LocalGateway     = $localGateway
        TargetsAttempted = ($reachedCount + $incompleteCount)
        TracesReached    = $reachedCount
        TracesIncomplete = $incompleteCount
        CeilingReached   = $ceilingReached
        Rows             = $allRows
        Message          = $msg
    }
}

# ============================================================
# Load inputs
# ============================================================
Write-FleetLog "TargetsCsv: $TargetsCsv"
$targets = Import-Csv -LiteralPath $TargetsCsv
if (-not $targets) { throw "TargetsCsv is empty: $TargetsCsv" }
$tCols = $targets[0].PSObject.Properties.Name
if ('SourceHost' -notin $tCols -or 'Destination' -notin $tCols) {
    throw "TargetsCsv must have SourceHost, Destination columns"
}

Write-FleetLog "FleetCsv:   $FleetCsv"
$fleet = Import-Csv -LiteralPath $FleetCsv
if (-not $fleet) { throw "FleetCsv is empty: $FleetCsv" }
if ('DNSHostName' -notin $fleet[0].PSObject.Properties.Name) {
    throw "FleetCsv must have a DNSHostName column"
}

$sourcesWithTargets = @($targets | Select-Object -ExpandProperty SourceHost -Unique)
$inScope = @($fleet | Where-Object {
    $hn = Get-RowHostname $_
    $hn -and ($sourcesWithTargets -contains $hn)
})

Write-FleetLog "Targets pairs:     $($targets.Count) across $($sourcesWithTargets.Count) source hosts"
Write-FleetLog "Fleet rows:        $($fleet.Count); in-scope (have targets): $($inScope.Count)"
Write-FleetLog "Tracert settings:  MaxHops=$MaxHops PerHopTimeout=${PerHopTimeoutMs}ms CeilingPerHost=${PerHostCeilingSec}s"
Write-FleetLog "Concurrency:       ThrottleLimit=$ThrottleLimit RetryCount=$RetryCount"

try {
    # ============================================================
    # Filter to WinRM-reachable hosts (serial probe up front)
    # ============================================================
    $reports   = New-Object System.Collections.Generic.List[object]
    $reachable = New-Object System.Collections.Generic.List[string]

    Write-FleetLog "Probing WinRM reachability across $($inScope.Count) hosts..."
    foreach ($row in $inScope) {
        $hn = Get-RowHostname $row
        if (Test-Target $hn) {
            [void]$reachable.Add($hn)
        }
        else {
            $reports.Add([PSCustomObject]@{
                Hostname         = $hn
                Result           = 'SKIP'
                Attempt          = 1
                TargetsAttempted = ($targets | Where-Object SourceHost -eq $hn).Count
                TracesReached    = 0
                TracesIncomplete = 0
                CeilingReached   = $false
                LocalGateway     = ''
                Message          = 'WinRM unreachable'
            }) | Out-Null
            Write-FleetLog "$hn - WinRM unreachable, skipping" 'SKIP'
        }
    }
    Write-FleetLog "Reachable: $($reachable.Count) of $($inScope.Count)"

    if ($reachable.Count -eq 0) {
        Write-FleetLog "No reachable hosts; nothing to trace." 'WARN'
        return
    }

    if (-not $PSCmdlet.ShouldProcess("$($reachable.Count) hosts", "Run tracert against $($targets.Count) targets")) {
        Write-FleetLog "WhatIf: would invoke tracert across $($reachable.Count) hosts" 'INFO'
        return
    }

    # ============================================================
    # Fan-out with retry: hosts that don't return a result get retried
    # ============================================================
    $pending      = @($reachable)
    $perHostAttempt = @{}
    foreach ($h in $reachable) { $perHostAttempt[$h] = 0 }

    for ($attempt = 1; $attempt -le ($RetryCount + 1); $attempt++) {
        if ($pending.Count -eq 0) { break }

        Write-FleetLog "Attempt $attempt - invoking tracert on $($pending.Count) host(s)..."

        $batch = Invoke-Command -ComputerName $pending -ThrottleLimit $ThrottleLimit `
            -ScriptBlock $remoteScript `
            -ArgumentList $targets, $MaxHops, $PerHopTimeoutMs, $PerHostCeilingSec `
            -ErrorAction SilentlyContinue

        $returnedFor = New-Object System.Collections.Generic.HashSet[string]
        foreach ($res in $batch) {
            $hn = $res.PSComputerName
            [void]$returnedFor.Add($hn)
            $perHostAttempt[$hn] = $attempt

            # Write per-host paths CSV
            $perHostCsv = Join-Path $OutputDir "${hn}_paths.csv"
            if ($res.Rows -and $res.Rows.Count -gt 0) {
                $res.Rows | Export-Csv -LiteralPath $perHostCsv -NoTypeInformation -Encoding UTF8
            }

            $reports.Add([PSCustomObject]@{
                Hostname         = $hn
                Result           = 'PASS'
                Attempt          = $attempt
                TargetsAttempted = $res.TargetsAttempted
                TracesReached    = $res.TracesReached
                TracesIncomplete = $res.TracesIncomplete
                CeilingReached   = $res.CeilingReached
                LocalGateway     = $res.LocalGateway
                Message          = $res.Message
            }) | Out-Null

            $reachSummary = "$($res.TracesReached)/$($res.TargetsAttempted) reached"
            if ($res.CeilingReached) { $reachSummary += " (ceiling hit)" }
            Write-FleetLog "$hn - $reachSummary" 'PASS'
        }

        # Pending = hosts that didn't return
        $pending = @($pending | Where-Object { -not $returnedFor.Contains($_) })

        if ($pending.Count -gt 0 -and $attempt -le $RetryCount) {
            $backoff = [math]::Min(30, 5 * $attempt)
            Write-FleetLog "$($pending.Count) host(s) didn't return; retrying in ${backoff}s..." 'WARN'
            Start-Sleep -Seconds $backoff
        }
    }

    # Anything still pending after retries = FAIL
    foreach ($hn in $pending) {
        $reports.Add([PSCustomObject]@{
            Hostname         = $hn
            Result           = 'FAIL'
            Attempt          = $perHostAttempt[$hn]
            TargetsAttempted = ($targets | Where-Object SourceHost -eq $hn).Count
            TracesReached    = 0
            TracesIncomplete = 0
            CeilingReached   = $false
            LocalGateway     = ''
            Message          = "no result after $($RetryCount + 1) attempts"
        }) | Out-Null
        Write-FleetLog "$hn - no result after $($RetryCount + 1) attempts" 'FAIL'
    }

    # ============================================================
    # Report
    # ============================================================
    $reports | Export-Csv -LiteralPath $reportCsv -NoTypeInformation -Encoding UTF8

    $pass = @($reports | Where-Object Result -eq 'PASS').Count
    $fail = @($reports | Where-Object Result -eq 'FAIL').Count
    $skip = @($reports | Where-Object Result -eq 'SKIP').Count
    Write-FleetLog "Summary: PASS=$pass FAIL=$fail SKIP=$skip (total $($inScope.Count))"
    Write-FleetLog "Per-host paths: $OutputDir"
    Write-FleetLog "Report:         $reportCsv"
    Write-FleetLog "Transcript:     $transcript"

} finally {
    try { Stop-Transcript | Out-Null } catch {}
}
