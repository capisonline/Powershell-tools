OFFICIAL



# === CONFIGURATION ===

$hostname = $env:COMPUTERNAME

$baseDir = "E:\PR_Discovery\Logs"

$remoteArchive = "\\POLVCADMGTDV01\captures"

$intervalSeconds = 240

$maxSizeMB = 10

# === FILE PATHS ===

$svcFile = Join-Path $baseDir "$hostname`_services.csv"

$procFile = Join-Path $baseDir "$hostname`_processes.csv"

$netstatFile = Join-Path $baseDir "$hostname`_netstat.txt"

$dfsLogFile = Join-Path $baseDir "$hostname`_dfs.csv"

$remoteLog = Join-Path $remoteArchive "$hostname`_logs.txt"

# === INIT ===

if (-not (Test-Path $baseDir)) { New-Item -Path $baseDir -ItemType Directory -Force | Out-Null }

if (-not (Test-Path $dfsLogFile)) {

    "Timestamp,ClientComputer,User,FilePath,SessionId,NumFilesOpen" | Out-File -FilePath $dfsLogFile -Encoding UTF8

}

function Write-Log {

    param([string]$message)

    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [$hostname] $message"

    Add-Content -Path $remoteLog -Value $line

    Write-Host $line

}

# === MAIN LOOP ===

while ($true) {

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    try {

        # ==== Telemetry Logging: Services ====

        $svcEntries = Get-WmiObject Win32_Service | Select-Object `

            @{Name='Timestamp';Expression={$timestamp}},

            Name, DisplayName, StartMode, State, StartName, PathName, ProcessId

        $svcEntries | Export-Csv -Path $svcFile -Append -NoTypeInformation -Encoding UTF8

        # ==== Telemetry Logging: Processes ====

        $pidMap = @{}

        $svcEntries | Where-Object { $_.ProcessId -ne 0 } | ForEach-Object {

            $pidMap[$_.ProcessId] = $pidMap[$_.ProcessId] + ",$($_.Name)"

        }

        $procEntries = Get-WmiObject Win32_Process | Where-Object { $_.ProcessId -gt 4 -and $_.ExecutablePath } | ForEach-Object {

            try {

                $owner = $_.GetOwner()

                $user = if ($owner.ReturnValue -eq 0) { "$($owner.Domain)\$($owner.User)" } else { "Unavailable" }

            } catch { $user = "Unavailable" }

            [PSCustomObject]@{

                Timestamp = $timestamp

                Name = $_.Name

                Id = $_.ProcessId

                ExecutablePath = $_.ExecutablePath

                CommandLine = $_.CommandLine

                UserName = $user

                HostedServices = $pidMap[$_.ProcessId]

            }

        }

        $procEntries | Export-Csv -Path $procFile -Append -NoTypeInformation -Encoding UTF8

        # ==== Telemetry Logging: Netstat ====

        $netstatData = (netstat -bano | Out-String) `

            -replace '(?m)^  (TCP|UDP)', '$1' `

            -replace '\r?\n\s+([^\[])', "`t`$1" `

            -replace '\r?\n\s+\[', "`t["

        Add-Content -Path $netstatFile -Value "`n# Snapshot: $timestamp`n$netstatData"

        # ==== DFS Namespace Monitoring ====

        $sessions = Get-SmbSession | Select-Object SessionId, ClientComputerName, ClientUserName, NumOpens

        $openFiles = Get-SmbOpenFile | Select-Object SessionId, ClientComputerName, ClientUserName, Path

        foreach ($file in $openFiles) {

            $session = $sessions | Where-Object { $_.SessionId -eq $file.SessionId }

            $entry = "$timestamp,$($file.ClientComputerName),$($file.ClientUserName),$($file.Path),$($file.SessionId),$($session.NumOpens)"

            Add-Content -Path $dfsLogFile -Value $entry

        }

        # ==== File Rollover ====

        foreach ($file in @($svcFile, $procFile, $netstatFile, $dfsLogFile)) {

            if ((Test-Path $file) -and ((Get-Item $file).Length / 1MB -ge $maxSizeMB)) {

                $rolled = "$file" -replace '\.csv|\.txt$', "_$(Get-Date -Format 'yyyyMMdd_HHmmss').rolledlog"

                Rename-Item -Path $file -NewName (Split-Path $rolled -Leaf) -Force

                Move-Item -Path $rolled -Destination $remoteArchive -Force

                Write-Log "Rolled and moved: $rolled"

            }

        }

        Write-Log "Snapshot captured successfully at $timestamp"

    } catch {

        Write-Log "ERROR: $_"

    }

    Start-Sleep -Seconds $intervalSeconds

}
