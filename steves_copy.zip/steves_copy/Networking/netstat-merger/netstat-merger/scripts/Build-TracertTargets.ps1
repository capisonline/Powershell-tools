<#
.SYNOPSIS
    Build the per-host tracert target list from Stage 1 compact CSVs.

.DESCRIPTION
    Reads the post-compaction CSVs produced by Compress-DailyCaptures.ps1
    (one or more files per source host under \\AUBNETS5\<share>\compact\),
    extracts unique RemoteAddress values per source host, filters out
    obvious noise (loopback, link-local, multicast, broadcast, wildcards),
    and emits a single consolidated CSV that Invoke-FleetTracert.ps1 will
    consume.

    No anchors. Targets come directly from what Stage 1 observed each host
    actually talking to — the goal of Stage 2 is to map the L3 paths to
    those known-real destinations. Any infrastructure of interest (DCs,
    AUBNETS5, vCenter) will already appear in the captures because the
    hosts were talking to them; gateways / routers / firewalls fall out
    naturally as hops along the way.

    Operator-side, read-only against AUBNETS5. No remote calls. The output
    CSV is the review point — spot-check it before triggering the fleet
    tracert run.

.PARAMETER CompactPath
    Where the Stage 1 compact CSVs live. Default '\\AUBNETS5\captures\compact'.

.PARAMETER OutputCsv
    Where to write the consolidated target list. Default
    ..\output\tracert_targets_<utc>.csv (the <utc> suffix is added
    automatically).

.EXAMPLE
    .\Build-TracertTargets.ps1
    Reads default compact path, writes default output CSV.

.EXAMPLE
    .\Build-TracertTargets.ps1 -CompactPath D:\local_compact_copy `
                                -OutputCsv D:\my_targets.csv
    Run against a local copy of the compact data (useful when AUBNETS5 read
    access from the operator workstation is restricted).

.NOTES
    Output column shape: SourceHost, Destination (one row per unique pair).
    See ..\deployment\DEPLOYMENT_README.md § Stage 2 for context.
#>

#Requires -Version 5.1

[CmdletBinding()]
param(
    [string] $CompactPath = '\\AUBNETS5\captures\compact',
    [string] $OutputCsv   = (Join-Path $PSScriptRoot '..\output\tracert_targets.csv')
)

# ============================================================
# Filter: is this address a sensible tracert destination?
# ============================================================
function Test-IsTracertTarget {
    param([string] $Addr)
    if (-not $Addr)                                       { return $false }
    if ($Addr -eq '*' -or $Addr -eq '*:*')                { return $false }
    if ($Addr -eq '0.0.0.0' -or $Addr -eq '255.255.255.255') { return $false }
    if ($Addr -eq '::' -or $Addr -eq '::1' -or $Addr -eq '[::]') { return $false }
    if ($Addr -like '127.*')                              { return $false }
    if ($Addr -like '169.254.*')                          { return $false }
    if ($Addr -like 'fe80*' -or $Addr -like 'fe80::*')    { return $false }
    if ($Addr -match '^(22[4-9]|23[0-9])\.\d+\.\d+\.\d+$') { return $false }  # IPv4 multicast
    return $true
}

# ============================================================
# Setup
# ============================================================
if (-not (Test-Path -LiteralPath $CompactPath)) {
    throw "CompactPath '$CompactPath' not found or inaccessible. Confirm operator has read access to the share."
}

$outputDir = Split-Path -Parent $OutputCsv
if ($outputDir -and -not (Test-Path -LiteralPath $outputDir)) {
    New-Item -Path $outputDir -ItemType Directory -Force | Out-Null
}

# Inject UTC stamp before the .csv extension
$utc = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
$OutputCsv = $OutputCsv -replace '\.csv$', "_$utc.csv"

Write-Host "$(Get-Date -Format 'HH:mm:ss') Reading compact CSVs from $CompactPath..."

# ============================================================
# Read every compact CSV, accumulate unique (Source, Dest) pairs
# ============================================================
$compactFiles = @(Get-ChildItem -LiteralPath $CompactPath -Filter '*_compact_*.csv' -File -ErrorAction SilentlyContinue)

if ($compactFiles.Count -eq 0) {
    throw "No *_compact_*.csv files found at '$CompactPath'. Did Compress-DailyCaptures.ps1 run?"
}

Write-Host "$(Get-Date -Format 'HH:mm:ss') Found $($compactFiles.Count) compact file(s); reading..."

# HostName -> HashSet[Destination], so deduplication is automatic
$targetsByHost     = @{}
$totalRowsRead     = 0
$totalRowsFiltered = 0
$readErrors        = 0

foreach ($file in $compactFiles) {
    try {
        $rows = Import-Csv -LiteralPath $file.FullName
    } catch {
        Write-Host "$(Get-Date -Format 'HH:mm:ss') WARN: Failed to read $($file.Name): $($_.Exception.Message)"
        $readErrors++
        continue
    }

    foreach ($row in $rows) {
        $totalRowsRead++
        $src = $row.Hostname
        $dst = $row.RemoteAddress

        if (-not $src) { continue }
        if (-not (Test-IsTracertTarget $dst)) {
            $totalRowsFiltered++
            continue
        }

        if (-not $targetsByHost.ContainsKey($src)) {
            $targetsByHost[$src] = New-Object System.Collections.Generic.HashSet[string]
        }
        [void]$targetsByHost[$src].Add($dst)
    }
}

# ============================================================
# Emit consolidated CSV, sorted for readability
# ============================================================
$consolidated = New-Object System.Collections.Generic.List[object]
foreach ($src in ($targetsByHost.Keys | Sort-Object)) {
    foreach ($dst in ($targetsByHost[$src] | Sort-Object)) {
        $consolidated.Add([PSCustomObject]@{
            SourceHost  = $src
            Destination = $dst
        }) | Out-Null
    }
}

$consolidated | Export-Csv -LiteralPath $OutputCsv -NoTypeInformation -Encoding UTF8

# ============================================================
# Summary
# ============================================================
$sourceCount  = $targetsByHost.Count
$totalTargets = if ($targetsByHost.Count -gt 0) {
    ($targetsByHost.Values | ForEach-Object { $_.Count } | Measure-Object -Sum).Sum
} else { 0 }
$distinctDest = @($consolidated | Select-Object -ExpandProperty Destination -Unique).Count

Write-Host ""
Write-Host "Done."
Write-Host "  Compact rows read:                   $totalRowsRead"
Write-Host "  Rows filtered (loopback/wildcard/etc): $totalRowsFiltered"
Write-Host "  File read errors:                    $readErrors"
Write-Host "  Source hosts with targets:           $sourceCount"
Write-Host "  Total (host, destination) pairs:     $totalTargets"
Write-Host "  Distinct destinations across fleet:  $distinctDest"
Write-Host "  Output: $OutputCsv"
Write-Host ""
Write-Host "Spot-check suggestions before running Invoke-FleetTracert.ps1:"
Write-Host "  Import-Csv '$OutputCsv' | Group-Object SourceHost | Sort-Object Count -Desc | Select -First 10"
Write-Host "  Import-Csv '$OutputCsv' | Group-Object Destination | Sort-Object Count -Desc | Select -First 20"
