<#
.SYNOPSIS
    Per-host telemetry capture for the PA domain handover.
    Designed to run as a Scheduled Task (SYSTEM) on each in-scope server.

.DESCRIPTION
    Every $IntervalSeconds seconds takes a connection-centric snapshot.

    Connection data is captured via `netstat -bano`, then joined with
    Win32_Service (services hosted per PID) and Win32_Process (executable
    path, command line, owner) into one row per connection or listener.
    Output goes to a single CSV: <hostname>_connections.csv.

    Columns:
      Timestamp, Hostname, Protocol, LocalAddress, LocalPort, RemoteAddress,
      RemotePort, State, ProcessId, ProcessName, ExecutablePath, UserName,
      Services, CommandLine

    DFS open-file monitoring (file servers only) writes to a separate CSV;
    skip with -NoDfsNamespace on non-file-servers OR on 2008/2008 R2 hosts
    where Get-SmbSession is unavailable.

    Error model — "netstat must always work, the rest is enrichment":
      - netstat -bano is the load-bearing capture
      - Win32_Service and Win32_Process are best-effort enrichment maps
        keyed by PID. If either WMI call fails (sick repo, hang, missing
        provider) the function logs a WARN and returns an empty map; the
        affected enrichment columns are written blank but netstat rows
        still go to the CSV
      - Each block has its own try/catch in the main loop; one failing
        block does not skip the others

    Output goes to $BaseDir. When the connections file exceeds $MaxFileSizeMB
    it is rolled, and the rolled file is shipped to $RemoteArchive. If the
    share is unreachable, rolled files stay local with a WARN in the local log.

    Production safety:
      - Per-section try/catch
      - Pre-flight: drive present, BaseDir creatable, share reachable (warn)
      - Local-first logging: Write-Log writes only to a local file. The data
        archive ships on rollover. A dead share never blocks the loop on SMB
        resolution.
      - $StopFile gives a graceful exit without unregistering the task
      - $MaxIterations gives an optional self-terminate

    Compatibility floor:
      - netstat -bano (Win2000+) is the connection capture mechanism. DO NOT
        swap to Get-NetTCPConnection — that is Win8 / Server 2012+ only and
        would silently exclude the Server 2008 / 2008 R2 hosts in the PA
        fleet. See feedback_netstat_over_nettcpconnection.md and
        feedback_dont_modernize_working_code.md in user memory.
      - Win32_Service / Win32_Process via Get-WmiObject — works on PS 2.0+.
        No per-op timeout, but battle-tested by prior production deployments.
      - Get-SmbSession / Get-SmbOpenFile (DFS block) are Win8/2012+ only.
        On 2008-era hosts the DFS function is a graceful no-op. Use
        -NoDfsNamespace to skip outright.

    See ..\deployment\DEPLOYMENT_README.md for context, scope, and approval state.

.PARAMETER BaseDir
    Local directory for working capture files. Default 'C:\PA_Telemetry\Logs'.
    Deploy-Telemetry.ps1 always passes this explicitly to keep it aligned with
    its own -RemotePath parameter; the default here is for ad-hoc manual runs.

.PARAMETER RemoteArchive
    UNC path to ship rolled archives to. Default '\\AUBNETS5\captures' (TBC).

.PARAMETER IntervalSeconds
    Sleep between captures. Default 240.

.PARAMETER MaxFileSizeMB
    Rollover threshold per file. Default 10.

.PARAMETER MaxIterations
    Stop after N captures. 0 = unbounded.

.PARAMETER StopFile
    Touch this file to gracefully stop the loop. Default 'C:\PA_Telemetry\STOP'.

.PARAMETER NoDfsNamespace
    Skip the DFS namespace block. Use on non-file-servers and on 2008/2008 R2
    hosts where Get-SmbSession is unavailable.

.PARAMETER IncludeStates
    Whitelist of TCP states to capture. Default 'LISTENING','ESTABLISHED','CLOSE_WAIT'.
    Netstat-native state names (NOT the Get-NetTCPConnection enum names). UDP
    is always included (it has no state). Override to also keep transient
    states on busy hosts:
        -IncludeStates 'LISTENING','ESTABLISHED','CLOSE_WAIT','TIME_WAIT'

.PARAMETER IncludeLoopback
    Capture connections on 127.x / ::1. Off by default — loopback chatter is
    rarely useful for handover and adds volume.

.NOTES
    Connection-centric joined-CSV output schema. Capture mechanism restored
    2026-05-11 to netstat -bano + Get-WmiObject after a prior "hardening"
    pass swapped them for Get-NetTCPConnection / Get-CimInstance and
    silently broke Server 2008 / 2008 R2 compatibility. The output shape
    (single _connections.csv with the schema above) is unchanged from the
    2026-05-08 version.

    Per-section try/catch, pre-flight, local-first logging, stop-file, and
    max-iterations are kept from the hardening pass — those are real safety
    improvements with no compat cost.
#>

#Requires -Version 3.0

[CmdletBinding()]
param(
    [string]   $BaseDir         = 'C:\PA_Telemetry\Logs',
    [string]   $RemoteArchive   = '\\AUBNETS5\captures',
    [int]      $IntervalSeconds = 240,
    [int]      $MaxFileSizeMB   = 10,
    [int]      $MaxIterations   = 0,
    [string]   $StopFile        = 'C:\PA_Telemetry\STOP',
    [switch]   $NoDfsNamespace,
    [string[]] $IncludeStates   = @('LISTENING','ESTABLISHED','CLOSE_WAIT'),
    [switch]   $IncludeLoopback
)

$ErrorActionPreference = 'Continue'

# ============================================================
# Derived paths
# ============================================================
$hostname        = $env:COMPUTERNAME
$connectionsFile = Join-Path $BaseDir "$hostname`_connections.csv"
$dfsLogFile      = Join-Path $BaseDir "$hostname`_dfs.csv"
$localLog        = Join-Path $BaseDir "$hostname`_telemetry.log"

$dfsHeader = 'Timestamp,ClientComputer,User,FilePath,SessionId,NumFilesOpen'

# ============================================================
# Local logging - never blocks on remote SMB
# ============================================================
function Write-Log {
    param(
        [Parameter(Mandatory)] [string] $Message,
        [ValidateSet('INFO','WARN','ERROR')] [string] $Level = 'INFO'
    )
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') [$hostname][$Level] $Message"
    try { Add-Content -LiteralPath $localLog -Value $line -ErrorAction Stop } catch {
        Write-Host "LOCAL LOG WRITE FAILED: $line"
    }
    Write-Host $line
}

# ============================================================
# Helpers
# ============================================================
function Split-Endpoint {
    # Splits 'addr:port' (IPv4) or '[addr]:port' (IPv6) or '*:*' into (addr,port).
    param([string] $Endpoint)
    if (-not $Endpoint -or $Endpoint -eq '*:*') { return @($Endpoint, '') }
    $clean = $Endpoint -replace '[\[\]]', ''
    $idx   = $clean.LastIndexOf(':')
    if ($idx -lt 0) { return @($clean, '') }
    return @($clean.Substring(0, $idx), $clean.Substring($idx + 1))
}

function Test-Loopback {
    # 127.x / ::1 only. 0.0.0.0 / :: are wildcard listeners, not loopback.
    param([string] $Address)
    if (-not $Address) { return $false }
    return ($Address -eq '127.0.0.1' -or $Address -eq '::1' -or $Address -like '127.*')
}

# ============================================================
# Pre-flight - fail fast on unrecoverable, continue on degraded
# ============================================================
function Test-PreFlight {
    $drive = Split-Path $BaseDir -Qualifier
    if (-not (Test-Path -LiteralPath "$drive\")) {
        throw "Drive $drive not present on $hostname. Aborting before any capture."
    }
    if (-not (Test-Path -LiteralPath $BaseDir)) {
        New-Item -Path $BaseDir -ItemType Directory -Force | Out-Null
    }
    if (-not $NoDfsNamespace -and -not (Test-Path -LiteralPath $dfsLogFile)) {
        $dfsHeader | Out-File -LiteralPath $dfsLogFile -Encoding UTF8
    }
    if (-not (Test-Path -LiteralPath $RemoteArchive -ErrorAction SilentlyContinue)) {
        Write-Log "Remote archive '$RemoteArchive' unreachable at startup. Capture will continue local-only; rollovers will stay on host until the share returns." 'WARN'
    }
}

# ============================================================
# Enrichment map: PID -> 'svc1,svc2,...' (services hosted in that process).
# Failure logs WARN and returns empty map. Best-effort.
# ============================================================
function Get-PidServiceMap {
    $map = @{}
    try {
        $services = Get-WmiObject -Class Win32_Service -ErrorAction Stop
        foreach ($svc in $services) {
            if ($svc.ProcessId -ne 0) {
                $key = [int]$svc.ProcessId
                $existing = $map[$key]
                if ($existing) { $map[$key] = "$existing,$($svc.Name)" }
                else           { $map[$key] = $svc.Name }
            }
        }
    } catch {
        Write-Log "Win32_Service enumeration failed (continuing with empty service map): $($_.Exception.Message)" 'WARN'
    }
    return $map
}

# ============================================================
# Enrichment map: PID -> { Name, ExecutablePath, CommandLine, UserName }
# Failure logs WARN and returns empty map. Best-effort.
# ============================================================
function Get-PidProcessMap {
    $map = @{}
    try {
        $procs = Get-WmiObject -Class Win32_Process -ErrorAction Stop |
            Where-Object { $_.ProcessId -gt 4 }
        foreach ($p in $procs) {
            $user = 'Unavailable'
            try {
                $owner = $p.GetOwner()
                if ($owner.ReturnValue -eq 0) { $user = "$($owner.Domain)\$($owner.User)" }
            } catch {}

            $map[[int]$p.ProcessId] = New-Object PSObject -Property @{
                Name           = $p.Name
                ExecutablePath = $p.ExecutablePath
                CommandLine    = $p.CommandLine
                UserName       = $user
            }
        }
    } catch {
        Write-Log "Win32_Process enumeration failed (continuing with empty process map): $($_.Exception.Message)" 'WARN'
    }
    return $map
}

# ============================================================
# netstat -bano capture, flattened and split into per-connection lines.
# Throws on netstat failure (caller's try/catch handles it).
#
# !! WIN2008 / 2008 R2 COMPATIBILITY !!
# This MUST stay as netstat -bano. Do NOT replace with Get-NetTCPConnection
# / Get-NetUDPEndpoint - those are Win8/Server 2012+ only and would silently
# drop 2008-era hosts. See feedback_netstat_over_nettcpconnection.md in
# user memory and the regression history in ..\deployment\DEPLOYMENT_README.md.
# ============================================================
function Get-NetstatLines {
    $raw = netstat -bano | Out-String
    if (-not $raw) { throw "netstat returned empty output" }

    $flattened = $raw `
        -replace '(?m)^  (TCP|UDP)', '$1' `
        -replace '\r?\n\s+([^\[])', "`t`$1" `
        -replace '\r?\n\s+\[', "`t["

    return @($flattened -split "`r?`n" | Where-Object { $_ -match '^(TCP|UDP)\s' })
}

# ============================================================
# Connection capture: parse netstat lines, join with WMI enrichment
# maps by PID, emit one row per connection or listener to the single
# combined CSV.
# ============================================================
function Capture-Connections {
    param(
        [string]    $Timestamp,
        [hashtable] $PidServiceMap = @{},
        [hashtable] $PidProcessMap = @{}
    )

    $lines = Get-NetstatLines  # throws on netstat failure

    $rows = New-Object System.Collections.Generic.List[object]

    foreach ($line in $lines) {
        $parts       = $line -split "`t"
        $netstatPart = $parts[0]
        $tags        = if ($parts.Length -gt 1) { $parts[1..($parts.Length - 1)] } else { @() }

        $tokens = @($netstatPart -split '\s+' | Where-Object { $_ })
        if ($tokens.Count -lt 4) { continue }

        $protocol = $tokens[0]
        $local    = $tokens[1]
        $remote   = $tokens[2]

        if ($protocol -eq 'TCP') {
            $state    = $tokens[3]
            $pidToken = if ($tokens.Count -ge 5) { $tokens[4] } else { '' }
        } else {
            $state    = 'LISTENING'
            $pidToken = $tokens[3]
        }

        # TCP state filter (UDP always included - no state to filter on)
        if ($protocol -eq 'TCP' -and $IncludeStates -and ($IncludeStates -notcontains $state)) { continue }

        $localParts  = Split-Endpoint $local
        $remoteParts = Split-Endpoint $remote
        $localAddr   = $localParts[0]
        $localPort   = $localParts[1]
        $remoteAddr  = $remoteParts[0]
        $remotePort  = $remoteParts[1]

        if (-not $IncludeLoopback -and (Test-Loopback $localAddr)) { continue }

        # PID -> int (netstat occasionally emits non-numeric for kernel rows)
        $pidInt = 0
        [void][int]::TryParse($pidToken, [ref]$pidInt)

        # Parse [exe.exe] and service-name tags. "Can not obtain ownership
        # information" is netstat's stand-in when -b can't resolve - leave
        # the enrichment columns blank for those rows.
        $tagServices = @()
        $exeName     = ''
        foreach ($tag in $tags) {
            $t = $tag.Trim()
            if (-not $t)                                  { continue }
            if ($t -match '^\[(.+)\]$')                   { $exeName = $matches[1]; continue }
            if ($t -match 'Can not obtain ownership')     { continue }
            $tagServices += $t
        }

        $procInfo  = $PidProcessMap[$pidInt]
        $svcFromMap = $PidServiceMap[$pidInt]

        $rows.Add([PSCustomObject]@{
            Timestamp      = $Timestamp
            Hostname       = $hostname
            Protocol       = $protocol
            LocalAddress   = $localAddr
            LocalPort      = $localPort
            RemoteAddress  = $remoteAddr
            RemotePort     = $remotePort
            State          = $state
            ProcessId      = $pidInt
            ProcessName    = if ($procInfo) { $procInfo.Name }           else { $exeName }
            ExecutablePath = if ($procInfo) { $procInfo.ExecutablePath } else { '' }
            UserName       = if ($procInfo) { $procInfo.UserName }       else { '' }
            Services       = if ($svcFromMap) { $svcFromMap }            else { ($tagServices -join ',') }
            CommandLine    = if ($procInfo) { $procInfo.CommandLine }    else { '' }
        }) | Out-Null
    }

    if ($rows.Count -gt 0) {
        $rows | Export-Csv -LiteralPath $connectionsFile -Append -NoTypeInformation -Encoding UTF8
    }

    return $rows.Count
}

# ============================================================
# DFS namespace capture (Win8 / Server 2012+ only)
# Get-SmbSession returns nothing on older hosts -> graceful no-op.
# Pass -NoDfsNamespace to skip outright on non-file-servers / 2008 hosts.
# ============================================================
function Capture-DfsNamespace {
    param([string] $Timestamp)

    $sessions = Get-SmbSession -ErrorAction SilentlyContinue
    if (-not $sessions) { return }

    $openFiles = Get-SmbOpenFile -ErrorAction SilentlyContinue
    foreach ($file in $openFiles) {
        $session = $sessions | Where-Object { $_.SessionId -eq $file.SessionId }
        $entry   = "$Timestamp,$($file.ClientComputerName),$($file.ClientUserName),$($file.Path),$($file.SessionId),$($session.NumOpens)"
        Add-Content -LiteralPath $dfsLogFile -Value $entry
    }
}

# ============================================================
# Rollover - per-file size check, rename, ship, re-header if needed.
# Each file rolled independently; one failure doesn't block the others.
# ============================================================
function Invoke-Rollover {
    $rolloverList = @(
        @{ File = $connectionsFile; Header = $null      },
        @{ File = $dfsLogFile;      Header = $dfsHeader }
    )

    foreach ($entry in $rolloverList) {
        $f = $entry.File
        if (-not (Test-Path -LiteralPath $f)) { continue }
        if ((Get-Item -LiteralPath $f).Length / 1MB -lt $MaxFileSizeMB) { continue }

        $stamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
        $rolled = $f -replace '(\.csv|\.txt)$', "_$stamp.rolledlog"

        try {
            Rename-Item -LiteralPath $f -NewName (Split-Path $rolled -Leaf) -Force
        } catch {
            Write-Log "Rollover rename failed for $(Split-Path $f -Leaf): $($_.Exception.Message)" 'ERROR'
            continue
        }

        try {
            Move-Item -LiteralPath $rolled -Destination $RemoteArchive -Force -ErrorAction Stop
            Write-Log "Rolled and shipped: $(Split-Path $rolled -Leaf)"
        } catch {
            Write-Log "Rolled file kept locally (remote unreachable): $(Split-Path $rolled -Leaf) - $($_.Exception.Message)" 'WARN'
        }

        if ($entry.Header) { $entry.Header | Out-File -LiteralPath $f -Encoding UTF8 }
    }
}

# ============================================================
# Main loop
# ============================================================
Test-PreFlight
Write-Log "Starting telemetry. BaseDir='$BaseDir' Remote='$RemoteArchive' Interval=${IntervalSeconds}s MaxIter=$MaxIterations DFS=$(-not $NoDfsNamespace.IsPresent) States=[$($IncludeStates -join ',')] Loopback=$($IncludeLoopback.IsPresent)"

$iter = 0

while ($true) {
    if (Test-Path -LiteralPath $StopFile) {
        Write-Log "Stop file detected at '$StopFile' - exiting cleanly after $iter iterations"
        break
    }
    if ($MaxIterations -gt 0 -and $iter -ge $MaxIterations) {
        Write-Log "MaxIterations ($MaxIterations) reached - exiting"
        break
    }

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $iter++

    # Enrichment maps - best-effort. Failures log WARN inside the function
    # and return empty hashtables. Connection capture proceeds with whatever
    # is available; enrichment columns are blank for PIDs not in the maps.
    $pidServiceMap = Get-PidServiceMap
    $pidProcessMap = Get-PidProcessMap

    # netstat is load-bearing - own try/catch, errors logged but loop continues
    $rowCount = 0
    try {
        $rowCount = Capture-Connections $timestamp $pidServiceMap $pidProcessMap
    } catch {
        Write-Log "Connection capture failed (continuing): $($_.Exception.Message)" 'ERROR'
    }

    if (-not $NoDfsNamespace) {
        try { Capture-DfsNamespace $timestamp }
        catch { Write-Log "DFS namespace capture failed (continuing): $($_.Exception.Message)" 'ERROR' }
    }

    try { Invoke-Rollover }
    catch { Write-Log "Rollover failed (continuing): $($_.Exception.Message)" 'ERROR' }

    Write-Log "Snapshot $iter captured at $timestamp ($rowCount connection rows)"

    Start-Sleep -Seconds $IntervalSeconds
}
