<#
.SYNOPSIS
    Build a single combined-fleet CSV from per-host compact files.
    Stage 1.6 - runs on AUBNETS5 after Compress-DailyCaptures.ps1.

.DESCRIPTION
    Reads every <host>_compact_<runstamp>.csv under -CompactPath, re-dedupes
    across runs (the same connection can appear in two compact files when
    rollovers span a compaction window), and writes one combined CSV that
    matches the column schema in scripts\netstat-example.xlsx so the receiver
    can open it directly in Excel.

    Output column order (matches netstat-example.xlsx exactly for the first
    13 columns; FirstSeen, LastSeen, SnapshotCount appended):

        Source_ServerName, Type, Protocol, Source IP, Source Port,
        Dest IP, Resolved Name, Remote Port, Local / Remote, State,
        PID, Executable, ExecutablePath,
        FirstSeen, LastSeen, SnapshotCount

    Three columns from the example schema are deliberately emitted blank
    in this build:
      - Type           : reader will tag per host in Excel
      - Resolved Name  : reverse-DNS not performed at rollup time
      - Local / Remote : no internal/external classifier configured

    Dedup key (same as Compress-DailyCaptures.ps1):
        Hostname, Protocol, LocalAddress, LocalPort,
        RemoteAddress, RemotePort, State

    FirstSeen / LastSeen / SnapshotCount aggregate across all compact files
    for the same host, so re-runs over the full compact\ folder still produce
    correct lifetime windows.

.PARAMETER CompactPath
    Where the per-host compact CSVs live. Default 'C:\captures\compact'.

.PARAMETER OutputPath
    Directory the combined CSV is written to. Default 'C:\captures\report'.
    Created if missing.

.PARAMETER OutputFile
    Override the auto-generated filename. Default is
    'fleet_connections_<runstamp>.csv' in -OutputPath.

.PARAMETER SinceDate
    Only include compact files whose runstamp is on or after this date.
    Default unset = include every compact file present.

.PARAMETER LogPath
    Local audit log. Default 'C:\PA-FleetMonitor\Logs\build-report.log'.

.EXAMPLE
    .\Build-CombinedReport.ps1 -WhatIf
    Dry run - shows what would be written.

.EXAMPLE
    .\Build-CombinedReport.ps1
    Pick up every compact file under C:\captures\compact and write
    C:\captures\report\fleet_connections_<runstamp>.csv.

.EXAMPLE
    .\Build-CombinedReport.ps1 -SinceDate (Get-Date).AddDays(-7)
    Only roll up compact files from the last seven days.

.NOTES
    Stage 1.6 of the PA domain handover pipeline. Runs on AUBNETS5.
        Stage 1   = telemetry.ps1 capturing on each in-scope server
        Stage 1.5 = Compress-DailyCaptures.ps1 (per-host dedup)
        Stage 1.6 = THIS (fleet-wide combined CSV in customer schema)
        Stage 2   = network paths (tracert from prod servers)

    See ..\deployment\DEPLOYMENT_README.md for context.
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]   $CompactPath = 'C:\captures\compact',
    [string]   $OutputPath  = 'C:\captures\report',
    [string]   $OutputFile  = '',
    [datetime] $SinceDate,
    [string]   $LogPath     = 'C:\PA-FleetMonitor\Logs\build-report.log'
)

# ============================================================
# Local audit logging (same shape as Compress-DailyCaptures.ps1)
# ============================================================
function Write-Log {
    param(
        [Parameter(Mandatory)] [string] $Message,
        [ValidateSet('INFO','WARN','ERROR')] [string] $Level = 'INFO'
    )
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') [$Level] $Message"
    if ($LogPath) {
        $dir = Split-Path $LogPath -Parent
        if (-not (Test-Path -LiteralPath $dir)) {
            New-Item -Path $dir -ItemType Directory -Force | Out-Null
        }
        try { Add-Content -LiteralPath $LogPath -Value $line -ErrorAction Stop } catch {}
    }
    Write-Host $line
}

# ============================================================
# Pick first non-blank value (matches Compress-DailyCaptures pattern).
# Enrichment columns can be blank on snapshots where WMI failed; this
# carries the best value forward when merging across compact files.
# ============================================================
function Select-BestValue {
    param(
        [Parameter(Mandatory)] [object[]] $Rows,
        [Parameter(Mandatory)] [string]   $Column
    )
    foreach ($r in $Rows) {
        $v = $r.$Column
        if ($v) { return $v }
    }
    return ''
}

# ============================================================
# Min/Max as strings (FirstSeen / LastSeen are 'yyyy-MM-dd HH:mm:ss'
# format - lexicographic sort matches chronological).
# ============================================================
function Get-MinString {
    param([object[]] $Rows, [string] $Column)
    $values = @($Rows | ForEach-Object { $_.$Column } | Where-Object { $_ })
    if ($values.Count -eq 0) { return '' }
    # Select-Object -First 1, not [0] - a 1-element pipeline unwraps to a
    # bare string, and [0] would then index into the string and return its
    # first character (e.g. '2' from '2026-...').
    return ($values | Sort-Object | Select-Object -First 1)
}

function Get-MaxString {
    param([object[]] $Rows, [string] $Column)
    $values = @($Rows | ForEach-Object { $_.$Column } | Where-Object { $_ })
    if ($values.Count -eq 0) { return '' }
    return ($values | Sort-Object -Descending | Select-Object -First 1)
}

# ============================================================
# Pre-flight
# ============================================================
if (-not (Test-Path -LiteralPath $CompactPath)) {
    Write-Log "CompactPath '$CompactPath' not found. Aborting." 'ERROR'
    return
}

if (-not (Test-Path -LiteralPath $OutputPath)) {
    if ($PSCmdlet.ShouldProcess($OutputPath, 'Create output directory')) {
        New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
        Write-Log "Created $OutputPath"
    }
}

$runStamp = Get-Date -Format 'yyyyMMddTHHmmss'
if (-not $OutputFile) {
    $OutputFile = Join-Path $OutputPath "fleet_connections_${runStamp}.csv"
}

# ============================================================
# Find compact files
# ============================================================
Write-Log "Run $runStamp - scanning '$CompactPath' for *_compact_*.csv files..."

$compactFiles = @(Get-ChildItem -LiteralPath $CompactPath -Filter '*_compact_*.csv' -File -ErrorAction SilentlyContinue)

if ($PSBoundParameters.ContainsKey('SinceDate')) {
    $compactFiles = @($compactFiles | Where-Object { $_.LastWriteTime -ge $SinceDate })
    Write-Log "After -SinceDate $SinceDate filter: $($compactFiles.Count) file(s)."
}

if ($compactFiles.Count -eq 0) {
    Write-Log "No compact files to combine. Nothing written."
    return
}

Write-Log "Found $($compactFiles.Count) compact file(s) to combine."

# ============================================================
# Read all rows
# ============================================================
$allRows = New-Object System.Collections.Generic.List[object]
foreach ($file in $compactFiles) {
    try {
        $rows = Import-Csv -LiteralPath $file.FullName
        foreach ($r in $rows) { [void]$allRows.Add($r) }
    } catch {
        Write-Log "Failed to read $($file.Name): $($_.Exception.Message)" 'ERROR'
    }
}

if ($allRows.Count -eq 0) {
    Write-Log "Compact files read but contained no rows. Nothing written."
    return
}

Write-Log "Read $($allRows.Count) row(s) from $($compactFiles.Count) file(s)."

# ============================================================
# Re-dedup across compact files using the netstat tuple key.
# A connection that lived across two compactor runs will appear in two
# compact CSVs; merging them here gives correct fleet-wide lifetime.
# ============================================================
$deduped = $allRows |
    Group-Object -Property Hostname, Protocol, LocalAddress, LocalPort, `
                           RemoteAddress, RemotePort, State |
    ForEach-Object {
        $g = $_.Group

        # SnapshotCount across compact files = sum of per-file counts
        $snapshotTotal = 0
        foreach ($r in $g) {
            $n = 0
            if ($r.PSObject.Properties['SnapshotCount'] -and [int]::TryParse([string]$r.SnapshotCount, [ref]$n)) {
                $snapshotTotal += $n
            }
        }

        # Source port / remote port / PID as int where possible so Excel
        # treats them as numbers (sorts and filters correctly).
        $srcPort = 0; [void][int]::TryParse([string]$g[0].LocalPort,  [ref]$srcPort)
        $dstPort = 0; [void][int]::TryParse([string]$g[0].RemotePort, [ref]$dstPort)
        $pidInt  = 0; [void][int]::TryParse([string](Select-BestValue -Rows $g -Column 'ProcessId'), [ref]$pidInt)

        # Schema matches netstat-example.xlsx column order; three blank
        # columns are intentional (see header).
        [PSCustomObject]@{
            'Source_ServerName' = $g[0].Hostname
            'Type'              = ''
            'Protocol'          = $g[0].Protocol
            'Source IP'         = $g[0].LocalAddress
            'Source Port'       = $srcPort
            'Dest IP'           = $g[0].RemoteAddress
            'Resolved Name'     = ''
            'Remote Port'       = $dstPort
            'Local / Remote'    = ''
            'State'             = $g[0].State
            'PID'               = $pidInt
            'Executable'        = Select-BestValue -Rows $g -Column 'ProcessName'
            'ExecutablePath'    = Select-BestValue -Rows $g -Column 'ExecutablePath'
            'FirstSeen'         = Get-MinString  -Rows $g -Column 'FirstSeen'
            'LastSeen'          = Get-MaxString  -Rows $g -Column 'LastSeen'
            'SnapshotCount'     = $snapshotTotal
        }
    } |
    Sort-Object 'Source_ServerName', 'Protocol', 'Source Port'

$rawCount     = $allRows.Count
$uniqueCount  = @($deduped).Count
$reduction    = if ($rawCount -gt 0) { [math]::Round((1 - ($uniqueCount / $rawCount)) * 100, 1) } else { 0 }
$hostCount    = @($deduped | Select-Object -ExpandProperty 'Source_ServerName' -Unique).Count

# ============================================================
# Write the combined CSV
# ============================================================
if ($PSCmdlet.ShouldProcess($OutputFile, "Write combined fleet CSV ($uniqueCount rows from $hostCount host(s), $reduction% cross-file reduction)")) {
    $deduped | Export-Csv -LiteralPath $OutputFile -NoTypeInformation -Encoding UTF8
    Write-Log "Wrote $uniqueCount row(s) from $hostCount host(s) -> $(Split-Path $OutputFile -Leaf) ($reduction% cross-file reduction)."
}

Write-Log "Run complete. Output: $OutputFile"
