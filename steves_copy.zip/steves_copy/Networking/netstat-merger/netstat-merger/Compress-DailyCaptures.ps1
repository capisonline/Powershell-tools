<#
.SYNOPSIS
    Daily compaction of PA telemetry captures shipped to AUBNETS5.
    Stage 1.5 — runs on AUBNETS5, not on production hosts.

.DESCRIPTION
    Walks the capture archive, picks up rolled connection CSV files older than
    -OlderThanHours, and compacts each host's data into a deduped form: one row
    per unique connection tuple with FirstSeen, LastSeen, and SnapshotCount
    columns added.

    Dedup key (netstat-tuple only — enrichment columns are NOT in the key):
        Hostname, Protocol, LocalAddress, LocalPort, RemoteAddress, RemotePort, State

    Enrichment columns (ProcessId, ProcessName, ExecutablePath, UserName,
    Services, CommandLine) are aggregated per group via "first non-blank wins"
    — each column independently. This isolates the compact output from
    intermittent WMI failures on the capturing host: a connection captured
    360 times where Get-PidProcessMap returned an empty map on snapshot 47
    still produces ONE compact row, with enrichment taken from any of the
    359 snapshots where WMI succeeded.

    A persistent ESTABLISHED connection captured every 240 seconds across a 24h
    window collapses from ~360 rows/day to 1 row. Typical reduction: 90-99%.

    Folder layout under -ArchivePath after a run:
        captures\
        ├── <host>_connections_<stamp>.rolledlog    raw arrivals from telemetry.ps1 (top level)
        ├── compact\
        │   └── <host>_compact_<runstamp>.csv       compacted output, one per host per run
        └── raw\
            └── <host>_connections_<stamp>.rolledlog moved here after compaction; pruned by retention

    Reruns are idempotent: files already moved to raw\ aren't picked up by the
    top-level scan.

    Designed to run as a Scheduled Task on AUBNETS5 once daily, e.g. 02:00.

.PARAMETER CapturesPath
    Where the raw rolled files land from telemetry.ps1. Default 'C:\captures'.

.PARAMETER ArchivePath
    Root for compacted + raw archive subfolders. Default same as -CapturesPath.

.PARAMETER OlderThanHours
    Only process rolled files older than this. Default 24 — yesterday's files.
    Set lower for more frequent runs (e.g. 4-hourly compaction during a busy
    capture window).

.PARAMETER RetentionDays
    Delete raw archive files older than this. Default 30. Set 0 to keep
    everything (raw archive grows unbounded — be careful).

.PARAMETER LogPath
    Local audit log. Default 'C:\PA-FleetMonitor\Logs\compact.log'.

.EXAMPLE
    .\Compress-DailyCaptures.ps1 -WhatIf
    Dry run — shows what would happen, no files moved or written.

.EXAMPLE
    .\Compress-DailyCaptures.ps1 -CapturesPath 'D:\captures' -OlderThanHours 4
    Compact every 4 hours during an active capture window, against a different drive.

.NOTES
    Stage 1.5 of the PA domain handover pipeline. Runs on AUBNETS5.
    Stage 1   = telemetry.ps1 capturing on each in-scope server
    Stage 1.5 = THIS + Send-FleetSummary.ps1 (heartbeat / stalled-host detection)
    Stage 2   = network paths (tracert from prod servers)

    See ..\deployment\DEPLOYMENT_README.md for context.
#>
<#
.SYNOPSIS
    Daily compaction of PA telemetry captures shipped to AUBNETS5.
    Stage 1.5 � runs on AUBNETS5, not on production hosts.
#>
<#
.SYNOPSIS
    Compacts QCAD / PA netstat telemetry captures.

.DESCRIPTION
    Recursively scans -CapturesPath for netstat capture files.

    Matching files:
        <server>_netstat_20250722_095533.rolledlog
        <server>_netstat.txt
        <server>_netstat.csv

    It groups files by server name, imports the CSV data, deduplicates by
    network tuple, writes one compact CSV per host, then moves processed
    raw files into the archive\raw folder.

    There is NO LastWriteTime / file-age filtering in this version.
#>

<#
.SYNOPSIS
    Compacts QCAD / PA netstat telemetry captures.

.DESCRIPTION
    Recursively scans -CapturesPath for netstat text capture files.

    Matches files containing "_netstat" with extensions:
        .rolledlog
        .txt
        .log

    Parses text like:
        # Snapshot: 2025-07-19 07:27:30
        TCP    0.0.0.0:80    0.0.0.0:0    LISTENING    4    Can not obtain ownership information
        TCP    0.0.0.0:135   0.0.0.0:0    LISTENING    652  RpcSs [svchost.exe]

    Outputs compact CSV files to:
        <ArchivePath>\compact

    Moves processed raw files to:
        <ArchivePath>\raw

    No LastWriteTime / age filtering is used.
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string] $CapturesPath  = 'C:\captures',
    [string] $ArchivePath   = '',
    [int]    $RetentionDays = 30,
    [string] $LogPath       = 'C:\PA-FleetMonitor\Logs\compact.log'
)

if (-not $ArchivePath) {
    $ArchivePath = $CapturesPath
}

function Write-Log {
    param(
        [Parameter(Mandatory)] [string] $Message,
        [ValidateSet('INFO','WARN','ERROR')] [string] $Level = 'INFO'
    )

    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') [$Level] $Message"

    if ($LogPath) {
        $dir = Split-Path $LogPath -Parent
        if (-not (Test-Path -LiteralPath $dir)) {
            New-Item -Path $dir -ItemType Directory -Force | Out-Null
        }

        try {
            Add-Content -LiteralPath $LogPath -Value $line -ErrorAction Stop
        }
        catch {
            Write-Host "WARNING: Failed to write to log file '$LogPath': $($_.Exception.Message)"
        }
    }

    Write-Host $line
}

function Select-BestValue {
    param(
        [Parameter(Mandatory)] [object[]] $Rows,
        [Parameter(Mandatory)] [string]   $Column
    )

    foreach ($r in $Rows) {
        $v = $r.$Column
        if ($v) {
            return $v
        }
    }

    return ''
}

function Split-NetstatEndpoint {
    param(
        [Parameter(Mandatory)] [string] $Endpoint
    )

    $Endpoint = $Endpoint.Trim()

    if ($Endpoint -match '^\[(.+)\]:(\d+)$') {
        return @{
            Address = $matches[1]
            Port    = $matches[2]
        }
    }

    if ($Endpoint -match '^(.+):(\d+)$') {
        return @{
            Address = $matches[1]
            Port    = $matches[2]
        }
    }

    return @{
        Address = $Endpoint
        Port    = ''
    }
}

function Get-HostNameFromFile {
    param(
        [Parameter(Mandatory)] [System.IO.FileInfo] $File
    )

    if ($File.BaseName -match '^(.+?)_netstat') {
        return $matches[1]
    }

    return $File.BaseName
}

function Parse-NetstatFile {
    param(
        [Parameter(Mandatory)] [System.IO.FileInfo] $File,
        [Parameter(Mandatory)] [string] $Hostname
    )

    $parsedRows = New-Object System.Collections.Generic.List[object]
    $snapshot = ''

    $lines = Get-Content -LiteralPath $File.FullName -ErrorAction Stop

    foreach ($line in $lines) {
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        if ($line -match '^#\s*Snapshot:\s*(.+)$') {
            $snapshot = $matches[1].Trim()
            continue
        }

        if ($line -match '^\s*Active Connections') {
            continue
        }

        if ($line -match '^\s*Proto\s+') {
            continue
        }

        $parts = $line -split '\s+'

        if ($parts.Count -lt 4) {
            continue
        }

        $protocol = $parts[0]

        if ($protocol -notin @('TCP','UDP')) {
            continue
        }

        $localEndpoint  = Split-NetstatEndpoint -Endpoint $parts[1]
        $remoteEndpoint = Split-NetstatEndpoint -Endpoint $parts[2]

        $state = ''
        $processId = ''
        $tailStartIndex = 0

        if ($protocol -eq 'TCP') {
            if ($parts.Count -lt 5) {
                continue
            }

            $state = $parts[3]
            $processId = $parts[4]
            $tailStartIndex = 5
        }
        else {
            $state = ''
            $processId = $parts[3]
            $tailStartIndex = 4
        }

        $tail = ''
        if ($parts.Count -gt $tailStartIndex) {
            $tail = ($parts[$tailStartIndex..($parts.Count - 1)] -join ' ').Trim()
        }

        $service = ''
        $processName = ''

        if ($tail -match '^(.+?)\s+\[(.+?)\]$') {
            $service = $matches[1].Trim()
            $processName = $matches[2].Trim()
        }
        elseif ($tail -match '^\[(.+?)\]$') {
            $processName = $matches[1].Trim()
        }
        elseif ($tail -match 'Can not obtain ownership information') {
            $processName = 'Can not obtain ownership information'
        }
        elseif ($tail) {
            $processName = $tail
        }

        [void]$parsedRows.Add([PSCustomObject]@{
            Timestamp      = $snapshot
            Hostname       = $Hostname
            Protocol       = $protocol
            LocalAddress   = $localEndpoint.Address
            LocalPort      = $localEndpoint.Port
            RemoteAddress  = $remoteEndpoint.Address
            RemotePort     = $remoteEndpoint.Port
            State          = $state
            ProcessId      = $processId
            ProcessName    = $processName
            ExecutablePath = ''
            UserName       = ''
            Services       = $service
            CommandLine    = ''
            SourceFile     = $File.Name
        })
    }

    return $parsedRows
}

if (-not (Test-Path -LiteralPath $CapturesPath)) {
    Write-Log "CapturesPath '$CapturesPath' not found. Aborting." 'ERROR'
    return
}

$rawArchive    = Join-Path $ArchivePath 'raw'
$compactOutput = Join-Path $ArchivePath 'compact'

foreach ($d in @($rawArchive, $compactOutput)) {
    if (-not (Test-Path -LiteralPath $d)) {
        if ($PSCmdlet.ShouldProcess($d, 'Create archive subfolder')) {
            New-Item -Path $d -ItemType Directory -Force | Out-Null
            Write-Log "Created archive subfolder: $d"
        }
    }
}

$runStamp = Get-Date -Format 'yyyyMMddTHHmmss'

Write-Log "Run $runStamp - recursively scanning '$CapturesPath' for *_netstat* text files."

$netstatFiles = @(
    Get-ChildItem -LiteralPath $CapturesPath -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -notlike "$rawArchive*" -and
        $_.FullName -notlike "$compactOutput*" -and
        $_.Name -match '_netstat' -and
        (
            $_.Extension -eq '.rolledlog' -or
            $_.Extension -eq '.txt' -or
            $_.Extension -eq '.log'
        )
    }
)

if ($netstatFiles.Count -eq 0) {
    Write-Log "No matching netstat files found under '$CapturesPath'." 'WARN'
    Write-Log "Expected names like: <server>_netstat_20250722_095533.rolledlog or <server>_netstat.txt" 'WARN'
    return
}

Write-Log "Found $($netstatFiles.Count) matching netstat file(s)."

$grouped = $netstatFiles | Group-Object {
    Get-HostNameFromFile -File $_
}

Write-Log "Grouped files into $($grouped.Count) host group(s)."

$totalRaw     = 0
$totalCompact = 0

foreach ($hostGroup in $grouped) {
    $hostname = $hostGroup.Name

    Write-Log "Processing host '$hostname' with $($hostGroup.Count) file(s)."

    $allRows = New-Object System.Collections.Generic.List[object]

    foreach ($file in $hostGroup.Group) {
        try {
            Write-Log "Parsing netstat file: $($file.FullName)"

            $rows = Parse-NetstatFile -File $file -Hostname $hostname

            foreach ($r in $rows) {
                [void]$allRows.Add($r)
            }

            Write-Log "Imported $($rows.Count) netstat row(s) from $($file.Name)."
        }
        catch {
            Write-Log "Failed to parse '$($file.FullName)': $($_.Exception.Message)" 'ERROR'
        }
    }

    if ($allRows.Count -eq 0) {
        Write-Log "No netstat rows imported for host '$hostname'; skipping." 'WARN'
        continue
    }

    $dedupProperties = @(
        'Hostname'
        'Protocol'
        'LocalAddress'
        'LocalPort'
        'RemoteAddress'
        'RemotePort'
        'State'
        'ProcessId'
    )

    $deduped = $allRows |
        Group-Object -Property $dedupProperties |
        ForEach-Object {
            $sorted = @($_.Group | Sort-Object Timestamp)

            $first = $sorted[0]
            $last  = $sorted[-1]

            [PSCustomObject]@{
                FirstSeen      = $first.Timestamp
                LastSeen       = $last.Timestamp
                SnapshotCount  = $_.Count

                Hostname       = $first.Hostname
                Protocol       = $first.Protocol
                LocalAddress   = $first.LocalAddress
                LocalPort      = $first.LocalPort
                RemoteAddress  = $first.RemoteAddress
                RemotePort     = $first.RemotePort
                State          = $first.State

                ProcessId      = $first.ProcessId
                ProcessName    = Select-BestValue -Rows $sorted -Column 'ProcessName'
                ExecutablePath = Select-BestValue -Rows $sorted -Column 'ExecutablePath'
                UserName       = Select-BestValue -Rows $sorted -Column 'UserName'
                Services       = Select-BestValue -Rows $sorted -Column 'Services'
                CommandLine    = Select-BestValue -Rows $sorted -Column 'CommandLine'
                SourceFile     = Select-BestValue -Rows $sorted -Column 'SourceFile'
            }
        }

    $rawCount     = $allRows.Count
    $compactCount = @($deduped).Count

    $reduction = if ($rawCount -gt 0) {
        [math]::Round((1 - ($compactCount / $rawCount)) * 100, 1)
    }
    else {
        0
    }

    $totalRaw     += $rawCount
    $totalCompact += $compactCount

    $outFile = Join-Path $compactOutput "${hostname}_compact_${runStamp}.csv"

    if ($PSCmdlet.ShouldProcess($outFile, "Write compacted CSV")) {
        $deduped |
            Sort-Object Protocol, LocalAddress, LocalPort, RemoteAddress, RemotePort, State, ProcessId |
            Export-Csv -LiteralPath $outFile -NoTypeInformation -Encoding UTF8

        Write-Log "Host '$hostname': $rawCount raw rows -> $compactCount compact rows ($reduction% reduction)."
        Write-Log "Output written: $outFile"
    }

    foreach ($file in $hostGroup.Group) {
        $dest = Join-Path $rawArchive $file.Name

        if ($PSCmdlet.ShouldProcess($file.FullName, "Move processed raw file to archive")) {
            try {
                Move-Item -LiteralPath $file.FullName -Destination $dest -Force -ErrorAction Stop
                Write-Log "Archived raw file: $($file.FullName) -> $dest"
            }
            catch {
                Write-Log "Failed to archive '$($file.FullName)': $($_.Exception.Message)" 'ERROR'
            }
        }
    }
}

if ($RetentionDays -gt 0) {
    $retentionCutoff = (Get-Date).AddDays(-$RetentionDays)

    $oldRaw = @(
        Get-ChildItem -LiteralPath $rawArchive -File -ErrorAction SilentlyContinue |
        Where-Object {
            $_.LastWriteTime -lt $retentionCutoff
        }
    )

    if ($oldRaw.Count -gt 0) {
        Write-Log "Pruning $($oldRaw.Count) archived raw file(s) older than $RetentionDays days."

        foreach ($file in $oldRaw) {
            if ($PSCmdlet.ShouldProcess($file.FullName, "Delete old archived raw file")) {
                try {
                    Remove-Item -LiteralPath $file.FullName -Force -ErrorAction Stop
                    Write-Log "Deleted old archived raw file: $($file.FullName)"
                }
                catch {
                    Write-Log "Failed to delete old archived raw file '$($file.FullName)': $($_.Exception.Message)" 'WARN'
                }
            }
        }
    }
}

$overallReduction = if ($totalRaw -gt 0) {
    [math]::Round((1 - ($totalCompact / $totalRaw)) * 100, 1)
}
else {
    0
}

Write-Log "Run complete. Hosts processed: $($grouped.Count). Raw rows: $totalRaw -> compact rows: $totalCompact ($overallReduction% reduction)."