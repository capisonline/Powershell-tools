﻿# Input / Output
$inputFile = "C:\temp\QCAD\VT\Networking\nslookup_all_VT.txt"
$outputCsv = "C:\temp\QCAD\VT\Networking\VT_nslookup-5.csv"

# Read input (skip blanks/comments)
$queries = Get-Content -LiteralPath $inputFile | ForEach-Object { $_.Trim() } | Where-Object {
    $_ -and -not $_.StartsWith('#')
}

# Prepare results
$results = New-Object System.Collections.Generic.List[object]

foreach ($q in $queries) {
    $dnsName   = $null
    $ipStrings = @()

    try {
        # Single call handles both forward & reverse lookups
        $entry = [System.Net.Dns]::GetHostEntry($q)

        # Canonical name (may be FQDN)
        $dnsName = $entry.HostName

        # Gather IPv4/IPv6 addresses (distinct; keep order stable)
        $ipStrings = $entry.AddressList |
                     Where-Object { $_ } |
                     Select-Object -ExpandProperty IPAddressToString -Unique
        if (-not $ipStrings -or $ipStrings.Count -eq 0) {
            $ipStrings = @("No IPs returned")
        }
    }
    catch {
        # Either the name/IP didn’t resolve or there was a DNS/socket error
        $dnsName   = "Resolution failed"
        $ipStrings = @("Resolution failed")
    }

    $results.Add([pscustomobject]@{
        Input        = $q
        DNS_Name     = $dnsName
        ResolvedIPs  = ($ipStrings -join ';')
    })
}

# Write CSV (fresh)
$null = New-Item -ItemType File -Path $outputCsv -Force
$results | Export-Csv -Path $outputCsv -NoTypeInformation -Encoding ASCII

Write-Host "DNS resolution complete. Results saved to $outputCsv"
