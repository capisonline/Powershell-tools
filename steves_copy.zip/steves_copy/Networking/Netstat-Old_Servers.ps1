﻿# Define the path to the input TXT file and the output CSV file 
$inputtxtPath = "C:\temp\QCAD\TP\Networking\TP_Old-Server-Netstat.txt"
$outputCsvPath = "C:\temp\QCAD\TP\Networking\TP_Old-Server-Netstat-results.csv"

# Read the input CSV file
$serverList = Get-Content -Path $inputtxtPath

# Result array
$results = @()

foreach ($server in $servers) {
    try {
        # Invoke netstat command remotely and parse output
        $output = Invoke-Command -ComputerName $server -ScriptBlock {
            netstat -an | Where-Object { $_ -match 'LISTENING|ESTABLISHED' } | ForEach-Object {
                $parts = $_ -split '\s+'
                if ($parts[1] -match '(.+):(\d+)$') {
                    $localAddress = $matches[1]
                    $localPort = $matches[2]
                } else {
                    $localAddress = $parts[1]
                    $localPort = $null
                }
                if ($parts[2] -match '(.+):(\d+)$') {
                    $remoteAddress = $matches[1]
                    $remotePort = $matches[2]
                } else {
                    $remoteAddress = $parts[2]
                    $remotePort = $null
                }
                [PSCustomObject]@{
                    Protocol = $parts[0]
                    LocalAddress = $localAddress
                    LocalPort = $localPort
                    RemoteAddress = $remoteAddress
                    RemotePort = $remotePort
                    State = $parts[3]
                }
            }
        }
        # Add server name to each result
        $output | ForEach-Object {
            $_ | Add-Member -NotePropertyName "Server" -NotePropertyValue $server
            $results += $_
        }
    } catch {
        Write-Warning "Failed to connect or retrieve data from $server"
    }
}

# Export results to CSV
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation
