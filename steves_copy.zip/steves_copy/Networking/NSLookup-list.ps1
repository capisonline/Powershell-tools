﻿# Path to the input file containing IP addresses 
$inputFile = "C:\temp\QCAD\VT\Networking\nslookup_all_VT.txt"

# Path to the output CSV file
$outputCsv = "C:\temp\QCAD\VT\Networking\VT_NEW-nslookup_all-2.csv"

# Read IP addresses from the input file
$ipAddresses = Get-Content $inputFile

# Create or clear the output CSV file
if (Test-Path $outputCsv) {
    Remove-Item $outputCsv
}

# Add CSV header
"IP_Address,DNS_Name" | Out-File $outputCsv -Encoding ASCII

foreach ($ip in $ipAddresses) {
    try {
        # Perform DNS lookup
        $hostEntry = [System.Net.Dns]::GetHostEntry($ip)
        $dnsName = $hostEntry.HostName
    } catch {
        # Handle IPs that do not resolve to a hostname
        $dnsName = "Resolution failed"
    }
    
    # Output IP and resolved DNS name to CSV file
    "$ip,$dnsName" | Out-File $outputCsv -Encoding ASCII -Append
}

# Output completion message
Write-Host "DNS resolution complete. Results saved to $outputCsv"
