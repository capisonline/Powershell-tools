﻿# Path to the text file containing the login names 
$loginNamesPath = "C:\temp\QCAD\SID\LoginNames.txt"

# The CSV file path where the results will be saved
$csvFilePath = "C:\temp\QCAD\SID\DisplayNameResults.csv"

# Read the login names from the file
$loginNames = Get-Content -Path $loginNamesPath

# Create an empty array to hold the results
$results = @()

foreach ($loginName in $loginNames) {
    try {
        # Attempt to find the user in Active Directory and get their display name
        $user = Get-ADUser -Identity $loginName -Properties DisplayName
        $displayName = $user.DisplayName

        # Check if a display name was found
        if (-not $displayName) {
            $displayName = "Display name not found"
        }
    } catch {
        # If there's an error (e.g., user not found), set a default message
        $displayName = "Could not resolve login name: $loginName"
    }

    # Create a result object for the CSV
    $result = [PSCustomObject]@{
        LoginName = $loginName
        DisplayName = $displayName
    }

    # Add the result object to the results array
    $results += $result
}

# Export the results array to a CSV file
$results | Export-Csv -Path $csvFilePath -NoTypeInformation
