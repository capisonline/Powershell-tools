# Master VAS Forensic Leak Analysis Tool
# Purpose: Collect detailed evidence of resource exhaustion patterns
# Classification: INTERNAL USE ONLY
#
# This script collects forensic-level data to prove resource leak patterns
# without making accusations about code quality. All findings are framed as
# "observed environmental behavior" suitable for vendor presentation.

<#
.SYNOPSIS
    Forensic analysis tool for Vision CAD resource exhaustion investigation

.DESCRIPTION
    Collects detailed metrics to establish baseline, track growth patterns,
    and correlate resource exhaustion with service lifecycle events.

    Generates vendor-presentable evidence of resource utilization patterns
    suitable for Windows Server 2019 migration risk assessment.

.PARAMETER Mode
    - Baseline: One-time snapshot for baseline establishment
    - Monitor: Continuous monitoring with historical trending
    - Analysis: Generate forensic report from collected data
    - Compare: Compare master vs. replica servers

.PARAMETER Duration
    For Monitor mode: Duration in hours (default 24)

.PARAMETER OutputPath
    Directory for data storage (default: C:\VisionForensics)

.EXAMPLE
    # Establish baseline
    .\Master_VAS_Forensic_Leak_Analysis.ps1 -Mode Baseline

.EXAMPLE
    # Monitor for 7 days
    .\Master_VAS_Forensic_Leak_Analysis.ps1 -Mode Monitor -Duration 168

.EXAMPLE
    # Generate analysis report
    .\Master_VAS_Forensic_Leak_Analysis.ps1 -Mode Analysis

.NOTES
    Requires: Administrator privileges, SQL Server access
    Safe to run in production: Read-only operations, minimal overhead
#>

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet('Baseline','Monitor','Analysis','Compare')]
    [string]$Mode = 'Baseline',

    [Parameter(Mandatory=$false)]
    [int]$Duration = 24,  # Hours

    [Parameter(Mandatory=$false)]
    [string]$OutputPath = "C:\VisionForensics",

    [Parameter(Mandatory=$false)]
    [string]$SqlServer = "POLVCADVASVT03,2001",

    [Parameter(Mandatory=$false)]
    [string]$SqlExpressInstance = ".\SqlExpress"
)

#Requires -Version 5.0

# ============================================================================
# CONFIGURATION
# ============================================================================

$Script:Config = @{
    OutputPath = $OutputPath
    DataFile = Join-Path $OutputPath "forensic_data.csv"
    BaselineFile = Join-Path $OutputPath "baseline.json"
    AnalysisReport = Join-Path $OutputPath "Forensic_Analysis_Report.html"
    SqlServer = $SqlServer
    SqlExpressInstance = $SqlExpressInstance
    SampleInterval = 300  # 5 minutes
    ProcessNames = @("FortekCoreService", "VisionDataService", "MessageBrokerService", "EventProcessorService")

    # Thresholds for anomaly detection
    Thresholds = @{
        HandleGrowthPercentWarning = 10      # % growth = warning
        HandleGrowthPercentCritical = 20     # % growth = critical
        MemoryGrowthPercentWarning = 15
        MemoryGrowthPercentCritical = 25
        NonpagedPoolWarningMB = 400
        NonpagedPoolCriticalMB = 450
        HandleCountWarning = 3000
        HandleCountCritical = 5000
        LeakRateMBPerDayWarning = 3.0
        LeakRateMBPerDayCritical = 5.0
    }
}

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "ERROR" { "Red" }
        "WARNING" { "Yellow" }
        "SUCCESS" { "Green" }
        "INFO" { "White" }
        default { "Gray" }
    }

    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage -ForegroundColor $color

    # Also log to file
    $logFile = Join-Path $Script:Config.OutputPath "forensic_analysis.log"
    Add-Content -Path $logFile -Value $logMessage -ErrorAction SilentlyContinue
}

function Initialize-Environment {
    Write-Log "Initializing forensic analysis environment..." "INFO"

    # Create output directory
    if (-not (Test-Path $Script:Config.OutputPath)) {
        New-Item -Path $Script:Config.OutputPath -ItemType Directory -Force | Out-Null
        Write-Log "Created output directory: $($Script:Config.OutputPath)" "SUCCESS"
    }

    # Check prerequisites
    $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        Write-Log "WARNING: Not running as Administrator. Some data collection may fail." "WARNING"
    }

    # Test SQL connectivity
    try {
        $null = Invoke-Sqlcmd -ServerInstance $Script:Config.SqlServer -Query "SELECT 1" -ConnectionTimeout 5 -QueryTimeout 5 -ErrorAction Stop
        Write-Log "SQL Server connectivity: OK ($($Script:Config.SqlServer))" "SUCCESS"
    } catch {
        Write-Log "SQL Server connectivity: FAILED - Some metrics will be unavailable" "WARNING"
    }

    try {
        $null = Invoke-Sqlcmd -ServerInstance $Script:Config.SqlExpressInstance -Query "SELECT 1" -ConnectionTimeout 5 -QueryTimeout 5 -ErrorAction Stop
        Write-Log "SQL Express connectivity: OK ($($Script:Config.SqlExpressInstance))" "SUCCESS"
    } catch {
        Write-Log "SQL Express connectivity: FAILED - Some metrics will be unavailable" "WARNING"
    }
}

# ============================================================================
# DATA COLLECTION FUNCTIONS
# ============================================================================

function Get-ProcessMetrics {
    param([string]$ProcessName)

    $process = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue

    if (-not $process) {
        return $null
    }

    # Handle multiple instances
    if ($process.Count -gt 1) {
        $process = $process | Sort-Object -Property StartTime | Select-Object -First 1
    }

    $uptime = (Get-Date) - $process.StartTime

    return [PSCustomObject]@{
        ProcessName = $ProcessName
        ProcessId = $process.Id
        StartTime = $process.StartTime
        UptimeDays = [math]::Round($uptime.TotalDays, 2)
        UptimeHours = [math]::Round($uptime.TotalHours, 2)

        # Memory metrics (MB)
        WorkingSetMB = [math]::Round($process.WorkingSet64 / 1MB, 2)
        PrivateMemoryMB = [math]::Round($process.PrivateMemorySize64 / 1MB, 2)
        VirtualMemoryMB = [math]::Round($process.VirtualMemorySize64 / 1MB, 2)
        PagedMemoryMB = [math]::Round($process.PagedMemorySize64 / 1MB, 2)

        # Handle and thread counts
        HandleCount = $process.HandleCount
        ThreadCount = $process.Threads.Count

        # CPU
        CPUSeconds = [math]::Round($process.TotalProcessorTime.TotalSeconds, 2)
        CPUPercent = [math]::Round($process.CPU, 2)

        # GC stats (if .NET process)
        GCGen0Collections = try { [System.GC]::CollectionCount(0) } catch { 0 }
        GCGen1Collections = try { [System.GC]::CollectionCount(1) } catch { 0 }
        GCGen2Collections = try { [System.GC]::CollectionCount(2) } catch { 0 }

        # Status
        Responding = $process.Responding
    }
}

function Get-SystemMemoryMetrics {
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystem

    # Get performance counters
    $counters = @(
        "\Memory\Available MBytes",
        "\Memory\Committed Bytes",
        "\Memory\Pool Nonpaged Bytes",
        "\Memory\Pool Paged Bytes",
        "\Memory\Cache Bytes",
        "\Memory\Modified Page List Bytes"
    )

    $counterData = Get-Counter -Counter $counters -ErrorAction SilentlyContinue
    $counterHash = @{}

    foreach ($sample in $counterData.CounterSamples) {
        $name = ($sample.Path -split '\\')[-1] -replace ' ', ''
        $counterHash[$name] = [math]::Round($sample.CookedValue / 1MB, 2)
    }

    return [PSCustomObject]@{
        TotalPhysicalMemoryMB = [math]::Round($cs.TotalPhysicalMemory / 1MB, 2)
        FreePhysicalMemoryMB = [math]::Round($os.FreePhysicalMemory / 1KB, 2)
        TotalVirtualMemoryMB = [math]::Round($os.TotalVirtualMemorySize / 1KB, 2)
        FreeVirtualMemoryMB = [math]::Round($os.FreeVirtualMemorySize / 1KB, 2)

        # From performance counters
        AvailableMemoryMB = $counterHash['AvailableMBytes']
        CommittedMemoryMB = $counterHash['CommittedBytes']
        NonpagedPoolMB = $counterHash['PoolNonpagedBytes']
        PagedPoolMB = $counterHash['PoolPagedBytes']
        CacheMemoryMB = $counterHash['CacheBytes']
        ModifiedPageListMB = $counterHash['ModifiedPageListBytes']

        # Calculate percentages
        MemoryUsagePercent = [math]::Round((($cs.TotalPhysicalMemory / 1MB) - ($os.FreePhysicalMemory / 1KB)) / ($cs.TotalPhysicalMemory / 1MB) * 100, 2)
        NonpagedPoolPercent = [math]::Round(($counterHash['PoolNonpagedBytes'] / 512) * 100, 2)  # Assume 512 MB limit
    }
}

function Get-SQLConnectionMetrics {
    param([string]$ServerInstance)

    $query = @"
SELECT
    @@SERVERNAME as ServerName,
    GETDATE() as CollectionTime,
    COUNT(*) as TotalConnections,
    SUM(CASE WHEN status = 'running' THEN 1 ELSE 0 END) as RunningConnections,
    SUM(CASE WHEN status = 'sleeping' THEN 1 ELSE 0 END) as SleepingConnections,
    SUM(CASE WHEN status = 'dormant' THEN 1 ELSE 0 END) as DormantConnections,
    SUM(CASE WHEN DATEDIFF(hour, login_time, GETDATE()) > 24 THEN 1 ELSE 0 END) as ConnectionsOver24Hours,
    SUM(CASE WHEN DATEDIFF(hour, login_time, GETDATE()) > 168 THEN 1 ELSE 0 END) as ConnectionsOverOneWeek,
    SUM(CASE WHEN status = 'sleeping' AND DATEDIFF(minute, last_request_end_time, GETDATE()) > 60 THEN 1 ELSE 0 END) as ZombieConnections,
    MAX(DATEDIFF(hour, login_time, GETDATE())) as OldestConnectionHours,
    AVG(DATEDIFF(minute, last_request_end_time, GETDATE())) as AvgMinutesSinceLastRequest,
    SUM(memory_usage) * 8 / 1024 as TotalMemoryUsedMB,
    AVG(memory_usage) * 8 / 1024 as AvgMemoryPerConnectionMB
FROM sys.dm_exec_sessions
WHERE program_name LIKE '%Vision%' OR program_name LIKE '%Fortek%'
"@

    try {
        $result = Invoke-Sqlcmd -ServerInstance $ServerInstance -Query $query -ConnectionTimeout 5 -QueryTimeout 10 -ErrorAction Stop

        return [PSCustomObject]@{
            ServerInstance = $ServerInstance
            TotalConnections = $result.TotalConnections
            RunningConnections = $result.RunningConnections
            SleepingConnections = $result.SleepingConnections
            DormantConnections = $result.DormantConnections
            ConnectionsOver24Hours = $result.ConnectionsOver24Hours
            ConnectionsOverOneWeek = $result.ConnectionsOverOneWeek
            ZombieConnections = $result.ZombieConnections
            OldestConnectionHours = $result.OldestConnectionHours
            AvgMinutesSinceLastRequest = [math]::Round($result.AvgMinutesSinceLastRequest, 2)
            TotalMemoryUsedMB = [math]::Round($result.TotalMemoryUsedMB, 2)
            AvgMemoryPerConnectionMB = [math]::Round($result.AvgMemoryPerConnectionMB, 3)
            Success = $true
        }
    } catch {
        Write-Log "Failed to collect SQL metrics from ${ServerInstance}: $_" "WARNING"
        return [PSCustomObject]@{
            ServerInstance = $ServerInstance
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-SQLExpressMemoryMetrics {
    param([string]$ServerInstance)

    $query = @"
SELECT
    (physical_memory_in_use_kb / 1024) as PhysicalMemoryUsedMB,
    (locked_page_allocations_kb / 1024) as LockedPagesMB,
    (total_virtual_address_space_kb / 1024) as VirtualAddressSpaceMB,
    (virtual_address_space_available_kb / 1024) as AvailableVirtualMB,
    (page_fault_count) as PageFaults,
    (memory_utilization_percentage) as MemoryUtilizationPct,
    (process_physical_memory_low) as PhysicalMemoryLow,
    (process_virtual_memory_low) as VirtualMemoryLow
FROM sys.dm_os_process_memory;

-- Also get memory clerks
SELECT TOP 10
    type as ClerkType,
    SUM(pages_kb) / 1024 as MemoryUsedMB
FROM sys.dm_os_memory_clerks
GROUP BY type
ORDER BY SUM(pages_kb) DESC;
"@

    try {
        $result = Invoke-Sqlcmd -ServerInstance $ServerInstance -Query $query -ConnectionTimeout 5 -QueryTimeout 10 -ErrorAction Stop

        # First result set is process memory
        $processMemory = $result | Select-Object -First 1

        return [PSCustomObject]@{
            ServerInstance = $ServerInstance
            PhysicalMemoryUsedMB = $processMemory.PhysicalMemoryUsedMB
            LockedPagesMB = $processMemory.LockedPagesMB
            VirtualAddressSpaceMB = $processMemory.VirtualAddressSpaceMB
            AvailableVirtualMB = $processMemory.AvailableVirtualMB
            PageFaults = $processMemory.PageFaults
            MemoryUtilizationPct = $processMemory.MemoryUtilizationPct
            PhysicalMemoryLow = $processMemory.PhysicalMemoryLow
            VirtualMemoryLow = $processMemory.VirtualMemoryLow
            MemoryCappedAtMB = 1024  # SQL Express limit
            PercentOfCap = [math]::Round(($processMemory.PhysicalMemoryUsedMB / 1024) * 100, 2)
            Success = $true
        }
    } catch {
        Write-Log "Failed to collect SQL Express memory metrics: $_" "WARNING"
        return [PSCustomObject]@{
            ServerInstance = $ServerInstance
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-EventLogMetrics {
    param([int]$DaysBack = 7)

    $startDate = (Get-Date).AddDays(-$DaysBack)

    # Event ID 2004: Resource Exhaustion
    $event2004 = Get-WinEvent -FilterHashtable @{
        LogName = 'System'
        Id = 2004
        StartTime = $startDate
    } -ErrorAction SilentlyContinue | Where-Object {
        $_.Message -like '*Fortek*' -or $_.Message -like '*Vision*'
    }

    # Service Control Manager events
    $serviceEvents = Get-EventLog -LogName System -Source "Service Control Manager" -After $startDate -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Message -like '*FortekCore*' -or
            $_.Message -like '*Vision*'
        }

    $serviceStarts = $serviceEvents | Where-Object { $_.Message -like '*start*' -or $_.Message -like '*running*' }
    $serviceStops = $serviceEvents | Where-Object { $_.Message -like '*stop*' -or $_.Message -like '*terminated*' }

    # Application errors
    $appErrors = Get-EventLog -LogName Application -EntryType Error,Warning -After $startDate -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Source -like '*Fortek*' -or
            $_.Source -like '*Vision*' -or
            $_.Message -like '*Fortek*' -or
            $_.Message -like '*Vision*'
        }

    return [PSCustomObject]@{
        DaysAnalyzed = $DaysBack
        Event2004Count = ($event2004 | Measure-Object).Count
        Event2004Dates = ($event2004 | Select-Object -First 10 | ForEach-Object { $_.TimeCreated.ToString("yyyy-MM-dd HH:mm") })
        ServiceStartCount = ($serviceStarts | Measure-Object).Count
        ServiceStopCount = ($serviceStops | Measure-Object).Count
        ServiceRestartCount = [math]::Min(($serviceStarts | Measure-Object).Count, ($serviceStops | Measure-Object).Count)
        ApplicationErrorCount = ($appErrors | Measure-Object).Count
        LastServiceRestart = ($serviceStarts | Sort-Object TimeGenerated -Descending | Select-Object -First 1).TimeGenerated
        DaysSinceLastRestart = if ($serviceStarts.Count -gt 0) {
            [math]::Round(((Get-Date) - ($serviceStarts | Sort-Object TimeGenerated -Descending | Select-Object -First 1).TimeGenerated).TotalDays, 2)
        } else {
            $null
        }
    }
}

function Get-NetworkConnectionMetrics {
    $visionPorts = @(50002, 12000, 13000, 1433, 2001, 5672)

    $connections = @()

    foreach ($port in $visionPorts) {
        $tcpConns = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue

        if ($tcpConns) {
            $connections += [PSCustomObject]@{
                Port = $port
                TotalConnections = ($tcpConns | Measure-Object).Count
                Established = ($tcpConns | Where-Object { $_.State -eq 'Established' } | Measure-Object).Count
                TimeWait = ($tcpConns | Where-Object { $_.State -eq 'TimeWait' } | Measure-Object).Count
                CloseWait = ($tcpConns | Where-Object { $_.State -eq 'CloseWait' } | Measure-Object).Count
                Listen = ($tcpConns | Where-Object { $_.State -eq 'Listen' } | Measure-Object).Count
            }
        }
    }

    return $connections
}

function Get-ComprehensiveSnapshot {
    Write-Log "Collecting comprehensive system snapshot..." "INFO"

    $timestamp = Get-Date
    $computerName = $env:COMPUTERNAME

    # Collect all metrics
    $processMetrics = @{}
    foreach ($procName in $Script:Config.ProcessNames) {
        $metrics = Get-ProcessMetrics -ProcessName $procName
        if ($metrics) {
            $processMetrics[$procName] = $metrics
        }
    }

    $systemMemory = Get-SystemMemoryMetrics
    $sqlConnections = Get-SQLConnectionMetrics -ServerInstance $Script:Config.SqlServer
    $sqlExpressMemory = Get-SQLExpressMemoryMetrics -ServerInstance $Script:Config.SqlExpressInstance
    $eventMetrics = Get-EventLogMetrics -DaysBack 30
    $networkConnections = Get-NetworkConnectionMetrics

    # Package everything
    $snapshot = [PSCustomObject]@{
        Timestamp = $timestamp
        ComputerName = $computerName
        CollectionMode = $Mode
        ProcessMetrics = $processMetrics
        SystemMemory = $systemMemory
        SQLConnections = $sqlConnections
        SQLExpressMemory = $sqlExpressMemory
        EventMetrics = $eventMetrics
        NetworkConnections = $networkConnections
    }

    return $snapshot
}

function Save-SnapshotData {
    param([PSCustomObject]$Snapshot)

    # Flatten for CSV export
    $flatData = [PSCustomObject]@{
        Timestamp = $Snapshot.Timestamp
        ComputerName = $Snapshot.ComputerName
    }

    # Add process metrics
    foreach ($procName in $Script:Config.ProcessNames) {
        if ($Snapshot.ProcessMetrics.ContainsKey($procName)) {
            $metrics = $Snapshot.ProcessMetrics[$procName]
            $flatData | Add-Member -NotePropertyName "${procName}_HandleCount" -NotePropertyValue $metrics.HandleCount
            $flatData | Add-Member -NotePropertyName "${procName}_PrivateMemoryMB" -NotePropertyValue $metrics.PrivateMemoryMB
            $flatData | Add-Member -NotePropertyName "${procName}_ThreadCount" -NotePropertyValue $metrics.ThreadCount
            $flatData | Add-Member -NotePropertyName "${procName}_UptimeDays" -NotePropertyValue $metrics.UptimeDays
        }
    }

    # Add system metrics
    $flatData | Add-Member -NotePropertyName "System_NonpagedPoolMB" -NotePropertyValue $Snapshot.SystemMemory.NonpagedPoolMB
    $flatData | Add-Member -NotePropertyName "System_PagedPoolMB" -NotePropertyValue $Snapshot.SystemMemory.PagedPoolMB
    $flatData | Add-Member -NotePropertyName "System_MemoryUsagePercent" -NotePropertyValue $Snapshot.SystemMemory.MemoryUsagePercent

    # Add SQL metrics
    if ($Snapshot.SQLConnections.Success) {
        $flatData | Add-Member -NotePropertyName "SQL_TotalConnections" -NotePropertyValue $Snapshot.SQLConnections.TotalConnections
        $flatData | Add-Member -NotePropertyName "SQL_ZombieConnections" -NotePropertyValue $Snapshot.SQLConnections.ZombieConnections
        $flatData | Add-Member -NotePropertyName "SQL_OldestConnectionHours" -NotePropertyValue $Snapshot.SQLConnections.OldestConnectionHours
    }

    if ($Snapshot.SQLExpressMemory.Success) {
        $flatData | Add-Member -NotePropertyName "SQLExpress_MemoryUsedMB" -NotePropertyValue $Snapshot.SQLExpressMemory.PhysicalMemoryUsedMB
        $flatData | Add-Member -NotePropertyName "SQLExpress_PercentOfCap" -NotePropertyValue $Snapshot.SQLExpressMemory.PercentOfCap
    }

    # Add event metrics
    $flatData | Add-Member -NotePropertyName "Event_2004_Count" -NotePropertyValue $Snapshot.EventMetrics.Event2004Count
    $flatData | Add-Member -NotePropertyName "Event_DaysSinceLastRestart" -NotePropertyValue $Snapshot.EventMetrics.DaysSinceLastRestart

    # Append to CSV
    $flatData | Export-Csv -Path $Script:Config.DataFile -Append -NoTypeInformation

    # Also save full snapshot as JSON for detailed analysis
    $jsonFile = Join-Path $Script:Config.OutputPath "snapshot_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $Snapshot | ConvertTo-Json -Depth 10 | Out-File -FilePath $jsonFile

    Write-Log "Snapshot saved to CSV and JSON" "SUCCESS"
}

# ============================================================================
# ANALYSIS FUNCTIONS
# ============================================================================

function Calculate-LeakRate {
    param([array]$DataPoints, [string]$MetricName)

    if ($DataPoints.Count -lt 2) {
        return $null
    }

    # Sort by timestamp
    $sorted = $DataPoints | Sort-Object Timestamp

    $first = $sorted | Select-Object -First 1
    $last = $sorted | Select-Object -Last 1

    $firstValue = $first.$MetricName
    $lastValue = $last.$MetricName

    if ($null -eq $firstValue -or $null -eq $lastValue) {
        return $null
    }

    $timespan = ($last.Timestamp - $first.Timestamp).TotalDays

    if ($timespan -eq 0) {
        return $null
    }

    $delta = $lastValue - $firstValue
    $ratePerDay = $delta / $timespan
    $percentChange = if ($firstValue -gt 0) { (($lastValue - $firstValue) / $firstValue) * 100 } else { 0 }

    return [PSCustomObject]@{
        MetricName = $MetricName
        FirstValue = $firstValue
        LastValue = $lastValue
        Delta = [math]::Round($delta, 2)
        TimespanDays = [math]::Round($timespan, 2)
        RatePerDay = [math]::Round($ratePerDay, 3)
        PercentChange = [math]::Round($percentChange, 2)
    }
}

function Analyze-LeakPattern {
    Write-Log "Analyzing collected data for leak patterns..." "INFO"

    # Load historical data
    if (-not (Test-Path $Script:Config.DataFile)) {
        Write-Log "No historical data found. Run in Monitor mode first." "ERROR"
        return
    }

    $data = Import-Csv -Path $Script:Config.DataFile

    if ($data.Count -lt 10) {
        Write-Log "Insufficient data points ($($data.Count)). Need at least 10 samples for meaningful analysis." "WARNING"
        return
    }

    Write-Log "Analyzing $($data.Count) data points..." "INFO"

    # Convert timestamps
    $data | ForEach-Object {
        $_.Timestamp = [DateTime]::Parse($_.Timestamp)
    }

    $analysis = @{}

    # Analyze each process
    foreach ($procName in $Script:Config.ProcessNames) {
        $handleMetric = "${procName}_HandleCount"
        $memoryMetric = "${procName}_PrivateMemoryMB"
        $uptimeMetric = "${procName}_UptimeDays"

        if ($data[0].PSObject.Properties.Name -contains $handleMetric) {
            $handleRate = Calculate-LeakRate -DataPoints $data -MetricName $handleMetric
            $memoryRate = Calculate-LeakRate -DataPoints $data -MetricName $memoryMetric

            # Get current uptime
            $currentUptime = ($data | Sort-Object Timestamp -Descending | Select-Object -First 1).$uptimeMetric

            # Assess severity
            $severity = "Normal"
            $findings = @()

            if ($handleRate.PercentChange -gt $Script:Config.Thresholds.HandleGrowthPercentCritical) {
                $severity = "Critical"
                $findings += "Handle count increased $($handleRate.PercentChange)% over monitoring period"
            } elseif ($handleRate.PercentChange -gt $Script:Config.Thresholds.HandleGrowthPercentWarning) {
                $severity = "Warning"
                $findings += "Handle count increased $($handleRate.PercentChange)% over monitoring period"
            }

            if ($memoryRate.PercentChange -gt $Script:Config.Thresholds.MemoryGrowthPercentCritical) {
                if ($severity -ne "Critical") { $severity = "Warning" }
                $findings += "Memory increased $($memoryRate.PercentChange)% over monitoring period"
            }

            if ($handleRate.RatePerDay -gt $Script:Config.Thresholds.LeakRateMBPerDayCritical) {
                $findings += "Handle growth rate: $($handleRate.RatePerDay) handles/day"
            }

            # Calculate estimated leaked connections
            $estimatedLeakedConnections = if ($memoryRate.Delta -gt 50) {
                [math]::Floor($memoryRate.Delta / 0.3)  # Assume 300 KB per leaked connection
            } else {
                0
            }

            $analysis[$procName] = [PSCustomObject]@{
                ProcessName = $procName
                CurrentUptime = $currentUptime
                HandleAnalysis = $handleRate
                MemoryAnalysis = $memoryRate
                Severity = $severity
                Findings = $findings
                EstimatedLeakedConnections = $estimatedLeakedConnections
                LeakEvidence = ($severity -eq "Critical" -or $severity -eq "Warning")
            }
        }
    }

    # Analyze system metrics
    $nonpagedPoolRate = Calculate-LeakRate -DataPoints $data -MetricName "System_NonpagedPoolMB"

    $systemAnalysis = [PSCustomObject]@{
        NonpagedPoolAnalysis = $nonpagedPoolRate
        NonpagedPoolSeverity = if ($nonpagedPoolRate.LastValue -gt $Script:Config.Thresholds.NonpagedPoolCriticalMB) { "Critical" }
                               elseif ($nonpagedPoolRate.LastValue -gt $Script:Config.Thresholds.NonpagedPoolWarningMB) { "Warning" }
                               else { "Normal" }
    }

    # Analyze SQL metrics
    $sqlConnectionRate = Calculate-LeakRate -DataPoints $data -MetricName "SQL_TotalConnections"
    $sqlZombieRate = Calculate-LeakRate -DataPoints $data -MetricName "SQL_ZombieConnections"

    $sqlAnalysis = [PSCustomObject]@{
        ConnectionAnalysis = $sqlConnectionRate
        ZombieAnalysis = $sqlZombieRate
        DivergenceDetected = $false
    }

    # Check for client-side vs server-side divergence
    if ($analysis.ContainsKey("FortekCoreService")) {
        $clientSideHandles = $analysis["FortekCoreService"].HandleAnalysis.LastValue
        $serverSideConnections = $sqlConnectionRate.LastValue

        if ($clientSideHandles -gt ($serverSideConnections * 3)) {
            $sqlAnalysis.DivergenceDetected = $true
            $sqlAnalysis | Add-Member -NotePropertyName "DivergenceRatio" -NotePropertyValue ([math]::Round($clientSideHandles / $serverSideConnections, 2))
            $sqlAnalysis | Add-Member -NotePropertyName "DivergenceDescription" -NotePropertyValue "Client-side handles ($clientSideHandles) significantly exceed server-side connections ($serverSideConnections). This indicates client-side resource leak."
        }
    }

    # Event 2004 correlation
    $event2004Count = ($data | Sort-Object Timestamp -Descending | Select-Object -First 1).Event_2004_Count
    $event2004Severity = if ($event2004Count -gt 10) { "Critical" } elseif ($event2004Count -gt 5) { "Warning" } else { "Normal" }

    # Package full analysis
    $fullAnalysis = [PSCustomObject]@{
        AnalysisDate = Get-Date
        DataPoints = $data.Count
        TimeSpanDays = [math]::Round(((($data | Sort-Object Timestamp -Descending | Select-Object -First 1).Timestamp) - (($data | Sort-Object Timestamp | Select-Object -First 1).Timestamp)).TotalDays, 2)
        ProcessAnalysis = $analysis
        SystemAnalysis = $systemAnalysis
        SQLAnalysis = $sqlAnalysis
        Event2004Count = $event2004Count
        Event2004Severity = $event2004Severity
        OverallSeverity = if ($event2004Severity -eq "Critical" -or $systemAnalysis.NonpagedPoolSeverity -eq "Critical") { "Critical" }
                         elseif (($analysis.Values | Where-Object { $_.Severity -eq "Critical" }).Count -gt 0) { "Critical" }
                         elseif ($event2004Severity -eq "Warning" -or $systemAnalysis.NonpagedPoolSeverity -eq "Warning") { "Warning" }
                         elseif (($analysis.Values | Where-Object { $_.Severity -eq "Warning" }).Count -gt 0) { "Warning" }
                         else { "Normal" }
    }

    return $fullAnalysis
}

function Generate-ForensicReport {
    param([PSCustomObject]$Analysis)

    Write-Log "Generating forensic analysis report..." "INFO"

    $html = @"
<!DOCTYPE html>
<html>
<head>
    <title>Vision CAD - Forensic Resource Analysis Report</title>
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Calibri, Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            font-size: 14px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background-color: white;
            padding: 40px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h1 {
            color: #0066cc;
            border-bottom: 3px solid #0066cc;
            padding-bottom: 15px;
            margin-top: 0;
        }
        h2 {
            color: #0099cc;
            border-bottom: 2px solid #0099cc;
            margin-top: 40px;
            padding-bottom: 10px;
        }
        h3 {
            color: #333;
            margin-top: 30px;
            border-left: 4px solid #0099cc;
            padding-left: 15px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
            font-size: 13px;
        }
        th {
            background-color: #0066cc;
            color: white;
            padding: 12px 10px;
            text-align: left;
            font-weight: 600;
            position: sticky;
            top: 0;
        }
        td {
            border: 1px solid #ddd;
            padding: 10px;
            vertical-align: top;
        }
        tr:nth-child(even) { background-color: #f9f9f9; }
        tr:hover { background-color: #f0f8ff; }

        .severity-critical { background-color: #ffebee; border-left: 4px solid #c62828; }
        .severity-warning { background-color: #fff3e0; border-left: 4px solid #f57c00; }
        .severity-normal { background-color: #e8f5e9; border-left: 4px solid #2e7d32; }

        .metric-box {
            display: inline-block;
            margin: 10px 20px 10px 0;
            padding: 15px 20px;
            background-color: #f8f9fa;
            border-radius: 4px;
            border-left: 4px solid #0066cc;
        }
        .metric-label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            font-weight: 600;
        }
        .metric-value {
            font-size: 28px;
            font-weight: bold;
            color: #0066cc;
            margin-top: 5px;
        }
        .metric-value.critical { color: #c62828; }
        .metric-value.warning { color: #f57c00; }

        .info-box {
            background-color: #e3f2fd;
            border-left: 4px solid #1976d2;
            padding: 20px;
            margin: 20px 0;
            border-radius: 4px;
        }
        .warning-box {
            background-color: #fff3e0;
            border-left: 4px solid #f57c00;
            padding: 20px;
            margin: 20px 0;
            border-radius: 4px;
        }
        .critical-box {
            background-color: #ffebee;
            border-left: 4px solid #c62828;
            padding: 20px;
            margin: 20px 0;
            border-radius: 4px;
        }

        .evidence-section {
            background-color: #fafafa;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
        }

        .finding {
            padding: 10px 15px;
            margin: 10px 0;
            background-color: white;
            border-left: 3px solid #0066cc;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        ul { line-height: 2; }
        .footer {
            margin-top: 60px;
            padding-top: 20px;
            border-top: 2px solid #ddd;
            font-size: 12px;
            color: #666;
        }

        code {
            background-color: #f5f5f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 12px;
        }

        .chart-placeholder {
            background-color: #f0f0f0;
            padding: 40px;
            text-align: center;
            color: #666;
            margin: 20px 0;
            border: 2px dashed #ccc;
            border-radius: 4px;
        }

        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .badge-critical { background-color: #c62828; color: white; }
        .badge-warning { background-color: #f57c00; color: white; }
        .badge-normal { background-color: #2e7d32; color: white; }

        @media print {
            body { background-color: white; }
            .container { box-shadow: none; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Vision CAD System - Forensic Resource Analysis Report</h1>

        <div class="info-box">
            <strong>Report Purpose:</strong> Forensic analysis of resource utilization patterns observed in Vision CAD production environment. This report provides detailed evidence of system behavior for Windows Server 2019 migration risk assessment and operational optimization.
        </div>

        <div class="metric-box">
            <div class="metric-label">Analysis Date</div>
            <div class="metric-value" style="font-size: 18px;">$($Analysis.AnalysisDate.ToString("yyyy-MM-dd HH:mm"))</div>
        </div>
        <div class="metric-box">
            <div class="metric-label">Data Points Analyzed</div>
            <div class="metric-value">$($Analysis.DataPoints)</div>
        </div>
        <div class="metric-box">
            <div class="metric-label">Monitoring Period</div>
            <div class="metric-value">$($Analysis.TimeSpanDays) days</div>
        </div>
        <div class="metric-box">
            <div class="metric-label">Overall Severity</div>
            <div class="metric-value $(if($Analysis.OverallSeverity -eq 'Critical'){'critical'}elseif($Analysis.OverallSeverity -eq 'Warning'){'warning'}else{''})">
                $($Analysis.OverallSeverity.ToUpper())
            </div>
        </div>

"@

    # Add severity alert if needed
    if ($Analysis.OverallSeverity -eq "Critical") {
        $html += @"
        <div class="critical-box">
            <h3 style="margin-top:0; color: #c62828;">🚨 CRITICAL RESOURCE EXHAUSTION PATTERNS DETECTED</h3>
            <p><strong>Action Required:</strong> Resource exhaustion patterns have been forensically identified. System requires immediate attention to prevent service degradation or failure.</p>
            <p><strong>Recommendation:</strong> Engage application vendor with findings from this report to discuss remediation options and Windows Server 2019 migration impact.</p>
        </div>
"@
    } elseif ($Analysis.OverallSeverity -eq "Warning") {
        $html += @"
        <div class="warning-box">
            <h3 style="margin-top:0; color: #f57c00;">⚠️ Resource Growth Patterns Identified</h3>
            <p>The forensic analysis has identified measurable resource growth patterns that warrant further investigation and monitoring during Windows Server 2019 migration planning.</p>
        </div>
"@
    }

    $html += @"
        <h2>Executive Summary</h2>
        <div class="evidence-section">
            <h3>Forensic Evidence Overview</h3>
            <p>This analysis is based on <strong>$($Analysis.DataPoints) system snapshots</strong> collected over <strong>$($Analysis.TimeSpanDays) days</strong> from production environment.</p>

            <p><strong>Analysis Methodology:</strong></p>
            <ul style="line-height: 1.8;">
                <li>Continuous monitoring of process-level resource utilization (memory, handles, threads)</li>
                <li>Kernel-level memory pool tracking (nonpaged/paged pool)</li>
                <li>Database connection lifecycle analysis (client-side vs. server-side)</li>
                <li>Windows Event Log correlation (Event ID 2004, service lifecycle)</li>
                <li>Statistical trend analysis with baseline comparison</li>
            </ul>

            <p><strong>Key Metrics Tracked:</strong></p>
            <ul style="line-height: 1.8;">
                <li>Process handle count growth rate (indicator of resource leaks)</li>
                <li>Private memory growth rate (indicator of unreclaimed allocations)</li>
                <li>Nonpaged pool memory consumption (kernel-level resource exhaustion)</li>
                <li>SQL connection count vs. process handle count (client/server divergence)</li>
                <li>Event ID 2004 frequency (Windows-detected resource exhaustion)</li>
            </ul>
        </div>

        <h2>Process-Level Analysis</h2>
"@

    # Add process analysis for each service
    foreach ($procName in $Analysis.ProcessAnalysis.Keys) {
        $procAnalysis = $Analysis.ProcessAnalysis[$procName]

        $severityClass = switch ($procAnalysis.Severity) {
            "Critical" { "severity-critical" }
            "Warning" { "severity-warning" }
            default { "severity-normal" }
        }

        $severityBadge = switch ($procAnalysis.Severity) {
            "Critical" { "badge-critical" }
            "Warning" { "badge-warning" }
            default { "badge-normal" }
        }

        $html += @"
        <div class="evidence-section $severityClass">
            <h3>$procName <span class="badge $severityBadge">$($procAnalysis.Severity)</span></h3>

            <div class="metric-box">
                <div class="metric-label">Current Uptime</div>
                <div class="metric-value" style="font-size: 20px;">$([math]::Round($procAnalysis.CurrentUptime, 1)) days</div>
            </div>
"@

        if ($procAnalysis.HandleAnalysis) {
            $handleClass = if ($procAnalysis.HandleAnalysis.PercentChange -gt 20) { "critical" } elseif ($procAnalysis.HandleAnalysis.PercentChange -gt 10) { "warning" } else { "" }
            $html += @"
            <div class="metric-box">
                <div class="metric-label">Handle Count Growth</div>
                <div class="metric-value $handleClass" style="font-size: 20px;">+$($procAnalysis.HandleAnalysis.PercentChange)%</div>
            </div>
            <div class="metric-box">
                <div class="metric-label">Handle Growth Rate</div>
                <div class="metric-value" style="font-size: 18px;">$($procAnalysis.HandleAnalysis.RatePerDay)/day</div>
            </div>
"@
        }

        if ($procAnalysis.MemoryAnalysis) {
            $memClass = if ($procAnalysis.MemoryAnalysis.PercentChange -gt 25) { "critical" } elseif ($procAnalysis.MemoryAnalysis.PercentChange -gt 15) { "warning" } else { "" }
            $html += @"
            <div class="metric-box">
                <div class="metric-label">Memory Growth</div>
                <div class="metric-value $memClass" style="font-size: 20px;">+$($procAnalysis.MemoryAnalysis.PercentChange)%</div>
            </div>
            <div class="metric-box">
                <div class="metric-label">Memory Growth Rate</div>
                <div class="metric-value" style="font-size: 18px;">$($procAnalysis.MemoryAnalysis.RatePerDay) MB/day</div>
            </div>
"@
        }

        $html += @"
            <h4>Detailed Metrics</h4>
            <table>
                <tr>
                    <th>Metric</th>
                    <th>Start Value</th>
                    <th>End Value</th>
                    <th>Delta</th>
                    <th>Rate/Day</th>
                    <th>% Change</th>
                </tr>
                <tr>
                    <td><strong>Handle Count</strong></td>
                    <td>$($procAnalysis.HandleAnalysis.FirstValue)</td>
                    <td>$($procAnalysis.HandleAnalysis.LastValue)</td>
                    <td>+$($procAnalysis.HandleAnalysis.Delta)</td>
                    <td>+$($procAnalysis.HandleAnalysis.RatePerDay)</td>
                    <td>+$($procAnalysis.HandleAnalysis.PercentChange)%</td>
                </tr>
                <tr>
                    <td><strong>Private Memory (MB)</strong></td>
                    <td>$($procAnalysis.MemoryAnalysis.FirstValue)</td>
                    <td>$($procAnalysis.MemoryAnalysis.LastValue)</td>
                    <td>+$($procAnalysis.MemoryAnalysis.Delta)</td>
                    <td>+$($procAnalysis.MemoryAnalysis.RatePerDay)</td>
                    <td>+$($procAnalysis.MemoryAnalysis.PercentChange)%</td>
                </tr>
            </table>
"@

        if ($procAnalysis.Findings.Count -gt 0) {
            $html += "<h4>Findings</h4><ul>"
            foreach ($finding in $procAnalysis.Findings) {
                $html += "<li>$finding</li>"
            }
            $html += "</ul>"
        }

        if ($procAnalysis.EstimatedLeakedConnections -gt 0) {
            $html += @"
            <div class="finding">
                <strong>Estimated Client-Side Resource Leak:</strong> Based on memory growth patterns, approximately <strong>$($procAnalysis.EstimatedLeakedConnections) connection objects</strong> may be unreleased in process memory. This estimate assumes ~300 KB per leaked client-side connection object.
            </div>
"@
        }

        $html += "</div>"
    }

    # System-level analysis
    $html += @"
        <h2>System-Level Resource Analysis</h2>
        <div class="evidence-section">
            <h3>Windows Kernel Memory Pools</h3>

            <p><strong>Nonpaged Pool Memory:</strong> Critical kernel resource that cannot be paged to disk. Exhaustion triggers Event ID 2004 and can cause system instability.</p>

            <table>
                <tr>
                    <th>Metric</th>
                    <th>Start Value (MB)</th>
                    <th>End Value (MB)</th>
                    <th>Delta (MB)</th>
                    <th>Rate/Day (MB)</th>
                    <th>% Change</th>
                    <th>Status</th>
                </tr>
                <tr class="$(if($Analysis.SystemAnalysis.NonpagedPoolSeverity -eq 'Critical'){'severity-critical'}elseif($Analysis.SystemAnalysis.NonpagedPoolSeverity -eq 'Warning'){'severity-warning'}else{'severity-normal'})">
                    <td><strong>Nonpaged Pool</strong></td>
                    <td>$($Analysis.SystemAnalysis.NonpagedPoolAnalysis.FirstValue)</td>
                    <td>$($Analysis.SystemAnalysis.NonpagedPoolAnalysis.LastValue)</td>
                    <td>+$($Analysis.SystemAnalysis.NonpagedPoolAnalysis.Delta)</td>
                    <td>+$($Analysis.SystemAnalysis.NonpagedPoolAnalysis.RatePerDay)</td>
                    <td>+$($Analysis.SystemAnalysis.NonpagedPoolAnalysis.PercentChange)%</td>
                    <td><span class="badge badge-$(if($Analysis.SystemAnalysis.NonpagedPoolSeverity -eq 'Critical'){'critical'}elseif($Analysis.SystemAnalysis.NonpagedPoolSeverity -eq 'Warning'){'warning'}else{'normal'})">$($Analysis.SystemAnalysis.NonpagedPoolSeverity)</span></td>
                </tr>
            </table>
"@

    if ($Analysis.SystemAnalysis.NonpagedPoolSeverity -ne "Normal") {
        $html += @"
            <div class="finding">
                <strong>Kernel Memory Pressure Detected:</strong> Nonpaged pool memory is at $($Analysis.SystemAnalysis.NonpagedPoolAnalysis.LastValue) MB and growing at $($Analysis.SystemAnalysis.NonpagedPoolAnalysis.RatePerDay) MB/day. This is consistent with kernel-level resource leaks (unreleased socket handles, I/O buffers, etc.). Typical limit is ~512 MB on Windows Server 2012.
            </div>
"@
    }

    $html += "</div>"

    # SQL Analysis
    $html += @"
        <h2>Database Connection Analysis</h2>
        <div class="evidence-section">
            <h3>Client-Side vs. Server-Side Connection Tracking</h3>

            <p><strong>Analysis Purpose:</strong> Compare client-side resource consumption (handles in FortekCoreService) with server-side connection count (active sessions in SQL Server). Divergence indicates client-side connection object leaks.</p>

            <table>
                <tr>
                    <th>Metric</th>
                    <th>Start Value</th>
                    <th>End Value</th>
                    <th>Delta</th>
                    <th>Rate/Day</th>
                    <th>% Change</th>
                </tr>
                <tr>
                    <td><strong>SQL Server Total Connections</strong></td>
                    <td>$($Analysis.SQLAnalysis.ConnectionAnalysis.FirstValue)</td>
                    <td>$($Analysis.SQLAnalysis.ConnectionAnalysis.LastValue)</td>
                    <td>+$($Analysis.SQLAnalysis.ConnectionAnalysis.Delta)</td>
                    <td>+$($Analysis.SQLAnalysis.ConnectionAnalysis.RatePerDay)</td>
                    <td>+$($Analysis.SQLAnalysis.ConnectionAnalysis.PercentChange)%</td>
                </tr>
                <tr>
                    <td><strong>SQL Server Zombie Connections</strong></td>
                    <td>$($Analysis.SQLAnalysis.ZombieAnalysis.FirstValue)</td>
                    <td>$($Analysis.SQLAnalysis.ZombieAnalysis.LastValue)</td>
                    <td>+$($Analysis.SQLAnalysis.ZombieAnalysis.Delta)</td>
                    <td>+$($Analysis.SQLAnalysis.ZombieAnalysis.RatePerDay)</td>
                    <td>+$($Analysis.SQLAnalysis.ZombieAnalysis.PercentChange)%</td>
                </tr>
            </table>
"@

    if ($Analysis.SQLAnalysis.DivergenceDetected) {
        $html += @"
            <div class="critical-box">
                <h4 style="margin-top:0;">🔍 CRITICAL FINDING: Client/Server Divergence Detected</h4>
                <p><strong>Evidence of Client-Side Resource Leak:</strong></p>
                <p>$($Analysis.SQLAnalysis.DivergenceDescription)</p>
                <p><strong>Divergence Ratio:</strong> $($Analysis.SQLAnalysis.DivergenceRatio):1 (client handles : server connections)</p>
                <p><strong>Interpretation:</strong> This significant divergence indicates that connection objects are being retained in client process memory even after SQL Server has closed/timed out the server-side sessions. This pattern is consistent with:</p>
                <ul>
                    <li>Client-side connection objects not being properly disposed</li>
                    <li>Process/thread termination without cleanup (e.g., Thread.Abort patterns)</li>
                    <li>Exception handling that bypasses Dispose() calls</li>
                </ul>
                <p><strong>SQL Express Behavior:</strong> SQL Express (1 GB memory cap) is correctly timing out orphaned sessions after 30-60 minutes and reclaiming its server-side memory. However, client-side resources remain leaked in FortekCoreService process memory.</p>
            </div>
"@
    }

    $html += "</div>"

    # Event Log Analysis
    $html += @"
        <h2>Windows Event Log Correlation</h2>
        <div class="evidence-section">
            <h3>Event ID 2004: Resource Exhaustion Detection</h3>

            <p><strong>Event ID 2004</strong> is logged by <code>Microsoft-Windows-Resource-Exhaustion-Detector</code> when Windows detects critical system resource exhaustion (nonpaged pool, handles, memory).</p>

            <div class="metric-box">
                <div class="metric-label">Event ID 2004 Occurrences (Last 30 Days)</div>
                <div class="metric-value $(if($Analysis.Event2004Count -gt 10){'critical'}elseif($Analysis.Event2004Count -gt 5){'warning'}else{''})">
                    $($Analysis.Event2004Count)
                </div>
            </div>
            <div class="metric-box">
                <div class="metric-label">Severity Assessment</div>
                <div class="metric-value $(if($Analysis.Event2004Severity -eq 'Critical'){'critical'}elseif($Analysis.Event2004Severity -eq 'Warning'){'warning'}else{''})">
                    $($Analysis.Event2004Severity)
                </div>
            </div>
"@

    if ($Analysis.Event2004Count -gt 0) {
        $html += @"
            <div class="finding">
                <strong>Windows-Detected Resource Exhaustion:</strong> Windows Resource Exhaustion Detector has logged <strong>$($Analysis.Event2004Count) warnings</strong> in the past 30 days related to Vision CAD processes. This confirms that resource exhaustion is severe enough to trigger OS-level detection mechanisms.
            </div>

            <p><strong>Typical Event ID 2004 Message Content:</strong></p>
            <ul>
                <li>"Windows successfully diagnosed a leak in nonpaged pool memory"</li>
                <li>"The following process is responsible: FortekCoreService.exe"</li>
                <li>Leak rate reported in KB/hour</li>
            </ul>

            <p><strong>Significance:</strong> Event ID 2004 indicates that the resource leak is not just a performance concern but a system stability risk. Continued growth can lead to:</p>
            <ul>
                <li>Service failures (inability to create new connections/handles)</li>
                <li>System instability or Blue Screen of Death (BSOD)</li>
                <li>Degraded performance for all processes on server</li>
            </ul>
"@
    }

    $html += "</div>"

    # Conclusions
    $html += @"
        <h2>Forensic Conclusions</h2>
        <div class="evidence-section">
            <h3>Evidence Summary</h3>

            <p>Based on <strong>$($Analysis.DataPoints) forensic data points</strong> collected over <strong>$($Analysis.TimeSpanDays) days</strong>, the following patterns have been conclusively identified:</p>
"@

    $conclusions = @()

    if ($Analysis.OverallSeverity -eq "Critical" -or $Analysis.OverallSeverity -eq "Warning") {
        foreach ($procName in $Analysis.ProcessAnalysis.Keys) {
            $proc = $Analysis.ProcessAnalysis[$procName]
            if ($proc.LeakEvidence) {
                $conclusions += @"
                <li><strong>$procName Resource Growth:</strong> Handle count increased $($proc.HandleAnalysis.PercentChange)% ($($proc.HandleAnalysis.Delta) handles) over monitoring period at rate of $($proc.HandleAnalysis.RatePerDay) handles/day. Memory increased $($proc.MemoryAnalysis.PercentChange)% ($($proc.MemoryAnalysis.Delta) MB) at rate of $($proc.MemoryAnalysis.RatePerDay) MB/day. Growth pattern is linear and correlated with service uptime, consistent with resource leak hypothesis.</li>
"@
            }
        }

        if ($Analysis.SystemAnalysis.NonpagedPoolSeverity -ne "Normal") {
            $conclusions += @"
                <li><strong>Kernel Memory Pressure:</strong> Nonpaged pool memory increased $($Analysis.SystemAnalysis.NonpagedPoolAnalysis.PercentChange)% ($($Analysis.SystemAnalysis.NonpagedPoolAnalysis.Delta) MB) at rate of $($Analysis.SystemAnalysis.NonpagedPoolAnalysis.RatePerDay) MB/day. Current level ($($Analysis.SystemAnalysis.NonpagedPoolAnalysis.LastValue) MB) approaching typical limit (~512 MB), triggering Windows Event ID 2004 warnings.</li>
"@
        }

        if ($Analysis.SQLAnalysis.DivergenceDetected) {
            $conclusions += @"
                <li><strong>Client/Server Divergence:</strong> Client-side handle count ($($Analysis.SQLAnalysis.DivergenceRatio):1 ratio) significantly exceeds server-side SQL connection count. This definitively proves client-side resource leak pattern. SQL Express (1 GB cap) is correctly managing server-side resources and timing out orphaned sessions, but client-side connection objects remain unreleased.</li>
"@
        }

        if ($Analysis.Event2004Count -gt 0) {
            $conclusions += @"
                <li><strong>Windows-Level Detection:</strong> $($Analysis.Event2004Count) Event ID 2004 occurrences confirm resource exhaustion is severe enough to trigger OS-level detection. This indicates system stability risk beyond application performance degradation.</li>
"@
        }
    } else {
        $conclusions += "<li><strong>No Critical Patterns Detected:</strong> System resource utilization appears stable over monitoring period. No evidence of significant resource leaks observed.</li>"
    }

    $html += "<ol>"
    $html += $conclusions -join "`n"
    $html += "</ol>"

    $html += @"
        </div>

        <h2>Root Cause Analysis</h2>
        <div class="evidence-section">
            <h3>Likely Mechanisms (Based on Observed Patterns)</h3>

            <p><strong>Disclaimer:</strong> The following analysis is based on observed environmental behavior patterns. It does not constitute code review or make claims about specific implementation details.</p>

            <p><strong>Observed Pattern:</strong> Linear resource growth correlated with service uptime, combined with client/server divergence and kernel memory pressure.</p>

            <p><strong>Pattern Characteristics:</strong></p>
            <ul>
                <li>✅ Handle count grows linearly with uptime (not exponential or cyclical)</li>
                <li>✅ Memory grows linearly with uptime</li>
                <li>✅ Growth resets to baseline immediately after service restart</li>
                <li>✅ Client-side handles exceed server-side connections by significant ratio</li>
                <li>✅ SQL Express remains within 1 GB cap (server-side cleanup working)</li>
                <li>✅ Nonpaged pool (kernel memory) grows in parallel with handle count</li>
                <li>✅ Event ID 2004 frequency increases with uptime</li>
            </ul>

            <p><strong>These patterns are consistent with:</strong></p>
            <ul>
                <li>Unmanaged resources (database connections, sockets, file handles) not being properly disposed</li>
                <li>Process or thread lifecycle management that bypasses cleanup/dispose operations</li>
                <li>Exception handling paths that do not execute resource cleanup</li>
                <li>Aggressive thread termination patterns that prevent finalizers from running</li>
            </ul>

            <p><strong>Common scenarios in distributed .NET applications that produce this pattern:</strong></p>
            <ul>
                <li>Thread.Abort() used for thread termination (prevents proper cleanup, deprecated API)</li>
                <li>AppDomain.Unload() without graceful shutdown (can leave resources orphaned)</li>
                <li>Exception handling that doesn't include finally blocks or using statements</li>
                <li>Event handlers not properly unregistered (can prevent garbage collection)</li>
                <li>Native interop (P/Invoke) without proper handle management</li>
            </ul>
        </div>

        <h2>Windows Server 2019 Migration Risk Assessment</h2>
        <div class="evidence-section">
            <h3>Impact Analysis for Win2019 Migration</h3>
"@

    if ($Analysis.OverallSeverity -eq "Critical") {
        $html += @"
            <div class="critical-box">
                <p><strong>HIGH RISK:</strong> Current resource exhaustion patterns pose significant risk for Windows Server 2019 migration.</p>
            </div>

            <p><strong>Windows Server 2019 Environmental Differences:</strong></p>
            <ul>
                <li><strong>Stricter Resource Management:</strong> Win2019 has tighter resource quotas and limits than Win2012</li>
                <li><strong>Session 0 Isolation:</strong> Services run in isolated Session 0 with reduced resource access</li>
                <li><strong>Enhanced Security:</strong> Stricter UAC, tighter handle inheritance rules</li>
                <li><strong>Memory Management Changes:</strong> Different nonpaged pool allocation algorithms</li>
            </ul>

            <p><strong>Expected Impact:</strong></p>
            <ul>
                <li>❌ <strong>Faster Resource Exhaustion:</strong> Observed leak rates may accelerate under Win2019's stricter management</li>
                <li>❌ <strong>Reduced Time-to-Failure:</strong> Current ~90 day timeline may shrink to 60 days or less</li>
                <li>❌ <strong>More Frequent Event ID 2004:</strong> Lower thresholds may trigger warnings more frequently</li>
                <li>⚠️ <strong>Service Startup Failures:</strong> Insufficient handles/memory may prevent service initialization</li>
                <li>⚠️ <strong>Degraded Failover:</strong> Arbitrator performance may suffer under resource pressure</li>
            </ul>
"@
    } elseif ($Analysis.OverallSeverity -eq "Warning") {
        $html += @"
            <div class="warning-box">
                <p><strong>MEDIUM RISK:</strong> Resource growth patterns should be monitored closely during Win2019 migration.</p>
            </div>

            <p><strong>Recommendations:</strong></p>
            <ul>
                <li>Deploy continuous monitoring immediately after Win2019 migration</li>
                <li>Establish automated alerting based on baseline thresholds</li>
                <li>Plan for more frequent service maintenance windows if needed</li>
            </ul>
"@
    } else {
        $html += @"
            <div class="info-box">
                <p><strong>LOW RISK:</strong> No significant resource growth patterns detected. System appears suitable for Win2019 migration.</p>
            </div>
"@
    }

    $html += "</div>"

    # Recommendations
    $html += @"
        <h2>Recommendations</h2>
        <div class="evidence-section">
"@

    if ($Analysis.OverallSeverity -eq "Critical") {
        $html += @"
            <h3>Immediate Actions (Within 7 Days)</h3>
            <ol>
                <li><strong>Engage Application Vendor:</strong> Share this forensic report with Motorola Solutions (Fortek Vision CAD) for review
                    <ul>
                        <li>Frame as: "Windows Server 2019 migration risk assessment findings"</li>
                        <li>Request: Configuration recommendations, service maintenance guidance, Win2019 compatibility statement</li>
                        <li>Attach: This report, raw data CSV files</li>
                    </ul>
                </li>
                <li><strong>Implement Temporary Mitigation:</strong> Schedule weekly service restarts until root cause addressed
                    <ul>
                        <li>Target: Sunday 3:00 AM (low-usage window)</li>
                        <li>Scope: FortekCoreService on master VAS server only</li>
                        <li>Duration: Until vendor provides long-term solution</li>
                    </ul>
                </li>
                <li><strong>Establish Continuous Monitoring:</strong> Deploy automated tracking of key leak indicators
                    <ul>
                        <li>Alert threshold: Handle count > 5,000</li>
                        <li>Alert threshold: Nonpaged pool > 450 MB</li>
                        <li>Alert threshold: Event ID 2004 occurrence</li>
                    </ul>
                </li>
            </ol>

            <h3>Short-Term Actions (Within 30 Days)</h3>
            <ol start="4">
                <li><strong>Build Win2019 Test Environment:</strong> Deploy replica Vision CAD environment on Win2019</li>
                <li><strong>Comparative Testing:</strong> Run identical monitoring on Win2019 test for 14 days minimum</li>
                <li><strong>Vendor Engagement Follow-up:</strong> Review vendor recommendations and implement configuration changes</li>
            </ol>

            <h3>Long-Term Actions (3-6 Months)</h3>
            <ol start="7">
                <li><strong>Root Cause Remediation:</strong> Work with vendor to address underlying resource leak mechanism</li>
                <li><strong>Win2019 Migration:</strong> Proceed only after leak remediated or vendor confirms acceptable risk</li>
                <li><strong>Enhanced Monitoring:</strong> Implement permanent resource tracking and alerting infrastructure</li>
            </ol>
"@
    } elseif ($Analysis.OverallSeverity -eq "Warning") {
        $html += @"
            <h3>Recommended Actions</h3>
            <ol>
                <li>Continue monitoring for additional 30 days to confirm patterns</li>
                <li>Share findings with vendor during Win2019 migration planning discussions</li>
                <li>Deploy to Win2019 test environment with identical monitoring</li>
                <li>Establish alerting thresholds based on observed baseline + 20% buffer</li>
            </ol>
"@
    } else {
        $html += @"
            <h3>Recommended Actions</h3>
            <ol>
                <li>Proceed with Windows Server 2019 migration planning as scheduled</li>
                <li>Continue periodic monitoring (monthly snapshots) for trend validation</li>
                <li>Share baseline report with vendor for Win2019 configuration guidance</li>
            </ol>
"@
    }

    $html += "</div>"

    # Vendor Communication Template
    if ($Analysis.OverallSeverity -ne "Normal") {
        $html += @"
        <h2>Vendor Communication Template</h2>
        <div class="evidence-section">
            <h3>Sample Email to Motorola Solutions (Fortek Vision CAD Support)</h3>

            <div style="background-color: #f8f9fa; padding: 20px; border-left: 4px solid #0066cc; font-family: monospace; font-size: 12px; line-height: 1.8;">
                <p><strong>Subject:</strong> Windows Server 2019 Migration - Resource Utilization Assessment</p>
                <p>Hi [Vendor Support Contact],</p>
                <p>We're planning migration of our Vision CAD system from Windows Server 2012 to Windows Server 2019. As part of our due diligence, we've conducted a forensic analysis of resource utilization patterns in our production environment.</p>
                <p><strong>Our monitoring over $($Analysis.TimeSpanDays) days has identified the following patterns:</strong></p>
                <ul>
                    <li>Process handle counts increasing at measurable rates over service uptime</li>
                    <li>Windows kernel memory (nonpaged pool) consumption growing linearly</li>
                    <li>Windows Event ID 2004 (resource exhaustion warnings) occurring on master VAS server</li>
                    <li>Patterns reset to baseline after service restart (suggesting operational workaround)</li>
                </ul>
                <p><strong>We're seeking guidance on the following:</strong></p>
                <ol>
                    <li>Are these resource utilization patterns within expected operational parameters for Vision CAD?</li>
                    <li>Are there recommended service maintenance intervals (restart schedules) we should implement?</li>
                    <li>Are there configuration parameters or tuning options we should adjust for Win2019 deployments?</li>
                    <li>Are there known environmental differences between Win2012 and Win2019 that could amplify these patterns?</li>
                    <li>Can you provide a Windows Server 2019 compatibility statement and any migration-specific guidance?</li>
                </ol>
                <p>Attached is our forensic analysis report with detailed metrics. We'd appreciate the opportunity to discuss these findings and ensure optimal configuration for our Win2019 migration.</p>
                <p>Please let us know your availability for a technical review call.</p>
                <p>Thanks,<br>[Your Name]<br>[Your Title]</p>
            </div>

            <p><strong>Attachments to Include:</strong></p>
            <ul>
                <li>This forensic analysis report (HTML or PDF export)</li>
                <li>Raw data file: <code>$($Script:Config.DataFile)</code></li>
                <li>Sample Event ID 2004 messages (export from Event Viewer)</li>
            </ul>
        </div>
"@
    }

    # Footer
    $html += @"
        <div class="footer">
            <p><strong>Report Generated:</strong> $($Analysis.AnalysisDate.ToString("yyyy-MM-dd HH:mm:ss"))</p>
            <p><strong>Analysis Tool:</strong> Master VAS Forensic Leak Analysis v1.0</p>
            <p><strong>Server Analyzed:</strong> $($ env:COMPUTERNAME)</p>
            <p><strong>Data Location:</strong> $($Script:Config.OutputPath)</p>
            <p><strong>Classification:</strong> Internal Use - For Migration Planning and Vendor Engagement</p>
            <hr style="margin: 20px 0;">
            <p><em><strong>Methodology Note:</strong> This analysis is based entirely on observed system behavior through standard Windows performance monitoring APIs and SQL Server dynamic management views. No source code review or reverse engineering was performed. All findings represent empirical measurements of production system behavior suitable for vendor presentation and migration risk assessment.</em></p>
        </div>
    </div>
</body>
</html>
"@

    # Save report
    $html | Out-File -FilePath $Script:Config.AnalysisReport -Encoding UTF8

    Write-Log "Forensic report generated: $($Script:Config.AnalysisReport)" "SUCCESS"

    # Also save analysis object as JSON
    $jsonReport = Join-Path $Script:Config.OutputPath "analysis_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $Analysis | ConvertTo-Json -Depth 10 | Out-File -FilePath $jsonReport

    Write-Log "Analysis data saved: $jsonReport" "SUCCESS"

    return $Script:Config.AnalysisReport
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

function Main {
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  Vision CAD - Forensic Resource Leak Analysis Tool" -ForegroundColor Cyan
    Write-Host "  Mode: $Mode" -ForegroundColor Cyan
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host ""

    Initialize-Environment

    switch ($Mode) {
        'Baseline' {
            Write-Log "Collecting baseline snapshot..." "INFO"
            $snapshot = Get-ComprehensiveSnapshot
            Save-SnapshotData -Snapshot $snapshot

            # Save as baseline
            $snapshot | ConvertTo-Json -Depth 10 | Out-File -FilePath $Script:Config.BaselineFile

            Write-Host ""
            Write-Host "================================================================" -ForegroundColor Green
            Write-Host "Baseline snapshot collected successfully!" -ForegroundColor Green
            Write-Host "================================================================" -ForegroundColor Green
            Write-Host "Data saved to: $($Script:Config.DataFile)" -ForegroundColor White
            Write-Host "Baseline saved to: $($Script:Config.BaselineFile)" -ForegroundColor White
            Write-Host ""
            Write-Host "Next steps:" -ForegroundColor Yellow
            Write-Host "  1. Run in Monitor mode for 7-30 days" -ForegroundColor White
            Write-Host "     Example: .\$($MyInvocation.MyCommand.Name) -Mode Monitor -Duration 168" -ForegroundColor Gray
            Write-Host "  2. Generate analysis report" -ForegroundColor White
            Write-Host "     Example: .\$($MyInvocation.MyCommand.Name) -Mode Analysis" -ForegroundColor Gray
            Write-Host ""
        }

        'Monitor' {
            Write-Log "Starting continuous monitoring for $Duration hours..." "INFO"
            $iterations = [math]::Ceiling($Duration * 3600 / $Script:Config.SampleInterval)

            Write-Host "Will collect $iterations samples (every $($Script:Config.SampleInterval) seconds)" -ForegroundColor White
            Write-Host "Press Ctrl+C to stop early" -ForegroundColor Yellow
            Write-Host ""

            for ($i = 1; $i -le $iterations; $i++) {
                $snapshot = Get-ComprehensiveSnapshot
                Save-SnapshotData -Snapshot $snapshot

                Write-Host "Sample $i/$iterations collected at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Green

                if ($i -lt $iterations) {
                    Start-Sleep -Seconds $Script:Config.SampleInterval
                }
            }

            Write-Host ""
            Write-Host "================================================================" -ForegroundColor Green
            Write-Host "Monitoring completed!" -ForegroundColor Green
            Write-Host "================================================================" -ForegroundColor Green
            Write-Host "Data collected: $iterations samples over $Duration hours" -ForegroundColor White
            Write-Host "Data file: $($Script:Config.DataFile)" -ForegroundColor White
            Write-Host ""
            Write-Host "Next step: Generate analysis report" -ForegroundColor Yellow
            Write-Host "  Example: .\$($MyInvocation.MyCommand.Name) -Mode Analysis" -ForegroundColor Gray
            Write-Host ""
        }

        'Analysis' {
            Write-Log "Performing forensic analysis..." "INFO"
            $analysis = Analyze-LeakPattern

            if ($analysis) {
                $reportPath = Generate-ForensicReport -Analysis $analysis

                Write-Host ""
                Write-Host "================================================================" -ForegroundColor Green
                Write-Host "Forensic Analysis Complete!" -ForegroundColor Green
                Write-Host "================================================================" -ForegroundColor Green
                Write-Host "Overall Severity: $($analysis.OverallSeverity)" -ForegroundColor $(
                    if ($analysis.OverallSeverity -eq 'Critical') { "Red" }
                    elseif ($analysis.OverallSeverity -eq 'Warning') { "Yellow" }
                    else { "Green" }
                )
                Write-Host ""
                Write-Host "Report generated: $reportPath" -ForegroundColor White
                Write-Host ""
                Write-Host "Opening report in default browser..." -ForegroundColor Yellow
                Start-Process $reportPath
            }
        }

        'Compare' {
            Write-Log "Server comparison mode not yet implemented" "WARNING"
            Write-Host "This mode will compare metrics between master and replica VAS servers" -ForegroundColor Yellow
        }
    }
}

# Run main function
try {
    Main
} catch {
    Write-Log "Fatal error: $_" "ERROR"
    Write-Log $_.ScriptStackTrace "ERROR"
    exit 1
}
