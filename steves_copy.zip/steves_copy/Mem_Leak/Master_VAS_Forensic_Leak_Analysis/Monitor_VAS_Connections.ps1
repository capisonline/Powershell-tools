<#
.SYNOPSIS
    Simple VAS connection leak monitoring - Master vs Replica comparison

.DESCRIPTION
    Monitors 3 key metrics in a loop:
    1. SQL server-side connections (DMV query)
    2. TCP client-side connections to SQL Express
    3. FortekCoreService.exe handle count

    Detects divergence between client and server metrics to prove leak.

.REQUIREMENTS
    - PowerShell SqlServer module (Install-Module -Name SqlServer)
    - Elevated/Administrator permissions (for netstat -b flag)
    - SQL Server access for account running script (if using SYSTEM account for scheduled task,
      ensure [NT AUTHORITY\SYSTEM] has VIEW SERVER STATE permission on SQL Express)

.PARAMETER Mode
    Monitor - Run monitoring loop
    Compare - Compare master vs replica results

.PARAMETER ServerRole
    Master or Replica (identifies which server this is running on)

.PARAMETER Duration
    How many hours to monitor (default: 24)

.PARAMETER Interval
    Sample interval in minutes (default: 5)

.EXAMPLE
    # Test SYSTEM account has SQL access (using PsExec)
    psexec -s powershell -File "C:\AI_Magd_Projects\QC2\Monitor_VAS_Connections.ps1" -Mode Monitor -ServerRole Master -Duration 1 -Interval 1
    # Watch first sample - if SQL_Connections = -1, SYSTEM needs VIEW SERVER STATE permission

.EXAMPLE
    # On Master VAS server (run manually or as scheduled task)
    .\Monitor_VAS_Connections.ps1 -Mode Monitor -ServerRole Master -Duration 168 -Interval 5

.EXAMPLE
    # On Replica VAS server (run manually or as scheduled task)
    .\Monitor_VAS_Connections.ps1 -Mode Monitor -ServerRole Replica -Duration 168 -Interval 5

.EXAMPLE
    # Compare results from both servers
    .\Monitor_VAS_Connections.ps1 -Mode Compare

.NOTES
    Running as Scheduled Task:
    1. Ensure SYSTEM account has SQL access:
       USE master;
       CREATE LOGIN [NT AUTHORITY\SYSTEM] FROM WINDOWS;
       GRANT VIEW SERVER STATE TO [NT AUTHORITY\SYSTEM];

    2. Test manually first:
       psexec -s powershell -File "script.ps1" -Mode Monitor -ServerRole Master -Duration 1 -Interval 1

    3. Create scheduled task:
       - Run whether user is logged on or not
       - Run with highest privileges
       - Account: SYSTEM
       - Action: powershell.exe -File "C:\AI_Magd_Projects\QC2\Monitor_VAS_Connections.ps1" -Mode Monitor -ServerRole Master -Duration 168 -Interval 5
#>

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Monitor','Compare')]
    [string]$Mode,

    [Parameter(Mandatory=$false)]
    [ValidateSet('Master','Replica')]
    [string]$ServerRole,

    [Parameter(Mandatory=$false)]
    [int]$Duration = 24,  # hours

    [Parameter(Mandatory=$false)]
    [int]$Interval = 5    # minutes
)

$OutputPath = "C:\AI_Magd_Projects\QC2\ConnectionMonitoring"

#region Helper Functions

function Get-SQLConnectionCount {
    <#
    .SYNOPSIS
        Query SQL Express for actual server-side connection count
    #>
    try {
        $query = "SELECT COUNT(*) as Total FROM sys.dm_exec_connections WHERE session_id > 50"

        $result = Invoke-Sqlcmd -Query $query -ServerInstance "localhost\SQLEXPRESS" -Database "master" -ErrorAction Stop

        return $result.Total
    }
    catch {
        Write-Warning "Failed to query SQL: $_"
        return -1
    }
}

function Get-TCPConnectionCount {
    <#
    .SYNOPSIS
        Count TCP connections from FortekCoreService.exe to SQL Express port 1433
    .NOTES
        Uses netstat -bano (requires admin permissions for -b flag)
    #>
    try {
        # Check if FortekCoreService.exe is running
        $process = Get-Process -Name "FortekCoreService" -ErrorAction SilentlyContinue
        if (-not $process) {
            Write-Warning "FortekCoreService.exe not running"
            return @{ Established = -1; CloseWait = -1; Total = -1 }
        }

        # Use netstat -bano with parsing to get process-to-connection mapping
        # -b shows executable name, -a shows all, -n numeric, -o shows PID
        $netstatOutput = netstat -bano 2>$null | Out-String

        # Parse netstat output: combine process name lines with connection lines
        $parsed = $netstatOutput -replace '(?m)^  (TCP|UDP)', '$1' -replace '\r?\n\s+([^\[])', "`t`$1" -replace '\r?\n\s+\[', "`t["

        # Filter for FortekCoreService connections to port 1433
        $connections = $parsed -split "`r?`n" | Where-Object {
            $_ -match "FortekCoreService" -and $_ -match ":1433"
        }

        # Count ESTABLISHED connections
        $established = ($connections | Where-Object { $_ -match "ESTABLISHED" }).Count

        # Count CLOSE_WAIT (indicator of improper closure)
        $closeWait = ($connections | Where-Object { $_ -match "CLOSE_WAIT" }).Count

        return @{
            Established = $established
            CloseWait = $closeWait
            Total = $established + $closeWait
        }
    }
    catch {
        Write-Warning "Failed to get TCP connections: $_"
        return @{ Established = -1; CloseWait = -1; Total = -1 }
    }
}

function Get-ProcessMetrics {
    <#
    .SYNOPSIS
        Get FortekCoreService.exe process metrics
    #>
    try {
        $process = Get-Process -Name "FortekCoreService" -ErrorAction Stop

        return @{
            HandleCount = $process.HandleCount
            ThreadCount = $process.Threads.Count
            PrivateMemoryMB = [math]::Round($process.PrivateMemorySize64 / 1MB, 2)
            WorkingSetMB = [math]::Round($process.WorkingSet64 / 1MB, 2)
        }
    }
    catch {
        Write-Warning "FortekCoreService.exe not running"
        return @{
            HandleCount = -1
            ThreadCount = -1
            PrivateMemoryMB = -1
            WorkingSetMB = -1
        }
    }
}

function Get-NonpagedPoolMB {
    <#
    .SYNOPSIS
        Get kernel nonpaged pool memory usage
    #>
    try {
        $memory = Get-WmiObject Win32_PerfFormattedData_PerfOS_Memory -ErrorAction Stop
        return [math]::Round($memory.PoolNonpagedBytes / 1MB, 2)
    }
    catch {
        Write-Warning "Failed to get nonpaged pool: $_"
        return -1
    }
}

function Calculate-LinearRegressionSlope {
    <#
    .SYNOPSIS
        Calculate linear regression slope (growth rate per day) for a metric over time
    .DESCRIPTION
        Uses least squares linear regression to determine trend slope
        Returns slope normalized to "per day" rate
    #>
    param(
        [Parameter(Mandatory=$true)]
        [array]$Data,

        [Parameter(Mandatory=$true)]
        [string]$TimeColumn,

        [Parameter(Mandatory=$true)]
        [string]$ValueColumn
    )

    try {
        if ($Data.Count -lt 2) {
            return @{
                SlopePerDay = 0
                RSquared = 0
                TrendStrength = "Insufficient Data"
            }
        }

        # Convert timestamps to hours from start
        $startTime = [DateTime]::Parse($Data[0].$TimeColumn)
        $xValues = @()
        $yValues = @()

        foreach ($row in $Data) {
            $timestamp = [DateTime]::Parse($row.$TimeColumn)
            $hoursFromStart = ($timestamp - $startTime).TotalHours
            $value = [double]$row.$ValueColumn

            $xValues += $hoursFromStart
            $yValues += $value
        }

        $n = $xValues.Count

        # Calculate sums for linear regression
        $sumX = ($xValues | Measure-Object -Sum).Sum
        $sumY = ($yValues | Measure-Object -Sum).Sum
        $sumXY = 0
        $sumX2 = 0
        $sumY2 = 0

        for ($i = 0; $i -lt $n; $i++) {
            $sumXY += $xValues[$i] * $yValues[$i]
            $sumX2 += $xValues[$i] * $xValues[$i]
            $sumY2 += $yValues[$i] * $yValues[$i]
        }

        # Calculate slope (b = (n*?xy - ?x*?y) / (n*?x  - (?x) ))
        $numerator = ($n * $sumXY) - ($sumX * $sumY)
        $denominator = ($n * $sumX2) - ($sumX * $sumX)

        if ($denominator -eq 0) {
            return @{
                SlopePerDay = 0
                RSquared = 0
                TrendStrength = "No Trend"
            }
        }

        $slopePerHour = $numerator / $denominator
        $slopePerDay = $slopePerHour * 24  # Convert to per-day rate

        # Calculate R  (coefficient of determination)
        $meanY = $sumY / $n
        $ssTotal = 0
        $ssResidual = 0

        for ($i = 0; $i -lt $n; $i++) {
            $yPredicted = ($slopePerHour * $xValues[$i]) + (($sumY - ($slopePerHour * $sumX)) / $n)
            $ssTotal += [math]::Pow(($yValues[$i] - $meanY), 2)
            $ssResidual += [math]::Pow(($yValues[$i] - $yPredicted), 2)
        }

        $rSquared = if ($ssTotal -gt 0) {
            1 - ($ssResidual / $ssTotal)
        } else {
            0
        }

        # Determine trend strength based on R  and slope
        $trendStrength = if ($rSquared -gt 0.7) {
            "Strong"
        } elseif ($rSquared -gt 0.4) {
            "Moderate"
        } elseif ($rSquared -gt 0.2) {
            "Weak"
        } else {
            "None"
        }

        return @{
            SlopePerDay = [math]::Round($slopePerDay, 2)
            RSquared = [math]::Round($rSquared, 3)
            TrendStrength = $trendStrength
        }
    }
    catch {
        Write-Warning "Failed to calculate regression: $_"
        return @{
            SlopePerDay = 0
            RSquared = 0
            TrendStrength = "Error"
        }
    }
}

#endregion

#region Monitor Mode

function Start-Monitoring {
    param(
        [string]$ServerRole,
        [int]$DurationHours,
        [int]$IntervalMinutes
    )

    # Create output directory
    if (-not (Test-Path $OutputPath)) {
        New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
    }

    $hostname = $env:COMPUTERNAME
    $csvFile = Join-Path $OutputPath "${ServerRole}_${hostname}_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"

    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host "VAS Connection Leak Monitor" -ForegroundColor Cyan
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host "Server Role    : $ServerRole" -ForegroundColor Yellow
    Write-Host "Hostname       : $hostname" -ForegroundColor Yellow
    Write-Host "Duration       : $DurationHours hours" -ForegroundColor Yellow
    Write-Host "Sample Interval: $IntervalMinutes minutes" -ForegroundColor Yellow
    Write-Host "Output File    : $csvFile" -ForegroundColor Yellow
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host ""

    # CSV header
    $header = "Timestamp,ServerRole,Hostname,SQL_Connections,TCP_Established,TCP_CloseWait,TCP_Total,Process_Handles,Process_Threads,Process_MemoryMB,Nonpaged_Pool_MB,Divergence_Ratio"
    $header | Out-File $csvFile -Encoding UTF8

    $endTime = (Get-Date).AddHours($DurationHours)
    $sampleCount = 0

    Write-Host "Starting monitoring... (Press Ctrl+C to stop early)" -ForegroundColor Green
    Write-Host ""

    while ((Get-Date) -lt $endTime) {
        $sampleCount++
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

        Write-Host "[$timestamp] Sample #$sampleCount" -ForegroundColor Cyan

        # Collect metrics
        $sqlCount = Get-SQLConnectionCount
        $tcpMetrics = Get-TCPConnectionCount
        $processMetrics = Get-ProcessMetrics
        $nonpagedPool = Get-NonpagedPoolMB

        # Calculate divergence ratio
        if ($sqlCount -gt 0 -and $tcpMetrics.Total -gt 0) {
            $divergenceRatio = [math]::Round($tcpMetrics.Total / $sqlCount, 2)
        } else {
            $divergenceRatio = 0
        }

        # Display current values
        Write-Host "  SQL Connections    : $sqlCount" -ForegroundColor White
        Write-Host "  TCP Established    : $($tcpMetrics.Established)" -ForegroundColor White
        Write-Host "  TCP CloseWait      : $($tcpMetrics.CloseWait)" -ForegroundColor $(if ($tcpMetrics.CloseWait -gt 0) { "Yellow" } else { "White" })
        Write-Host "  TCP Total          : $($tcpMetrics.Total)" -ForegroundColor White
        Write-Host "  Process Handles    : $($processMetrics.HandleCount)" -ForegroundColor White
        Write-Host "  Nonpaged Pool      : $nonpagedPool MB" -ForegroundColor White
        Write-Host "  Divergence Ratio   : $divergenceRatio" -ForegroundColor $(if ($divergenceRatio -gt 2.0) { "Red" } elseif ($divergenceRatio -gt 1.5) { "Yellow" } else { "Green" })

        # Detect anomalies
        if ($divergenceRatio -gt 2.0) {
            Write-Host "  [!] WARNING: TCP connections significantly exceed SQL connections!" -ForegroundColor Red
        }

        if ($tcpMetrics.CloseWait -gt 10) {
            Write-Host "  [!] WARNING: High CLOSE_WAIT count indicates improper connection closure!" -ForegroundColor Red
        }

        # Log to CSV
        $row = "$timestamp,$ServerRole,$hostname,$sqlCount,$($tcpMetrics.Established),$($tcpMetrics.CloseWait),$($tcpMetrics.Total),$($processMetrics.HandleCount),$($processMetrics.ThreadCount),$($processMetrics.PrivateMemoryMB),$nonpagedPool,$divergenceRatio"
        $row | Out-File $csvFile -Append -Encoding UTF8

        Write-Host ""

        # Sleep until next sample
        Start-Sleep -Seconds ($IntervalMinutes * 60)
    }

    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host "Monitoring complete!" -ForegroundColor Green
    Write-Host "Data saved to: $csvFile" -ForegroundColor Yellow
    Write-Host "=====================================================================" -ForegroundColor Cyan
}

#endregion

#region Compare Mode

function Compare-Results {

    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host "VAS Connection Leak Comparison - Master vs Replica" -ForegroundColor Cyan
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host ""

    # Find latest CSV files
    $masterFiles = Get-ChildItem -Path $OutputPath -Filter "Master_*.csv" | Sort-Object LastWriteTime -Descending
    $replicaFiles = Get-ChildItem -Path $OutputPath -Filter "Replica_*.csv" | Sort-Object LastWriteTime -Descending

    if ($masterFiles.Count -eq 0) {
        Write-Host "[ERROR] No Master monitoring data found in $OutputPath" -ForegroundColor Red
        return
    }

    if ($replicaFiles.Count -eq 0) {
        Write-Host "[ERROR] No Replica monitoring data found in $OutputPath" -ForegroundColor Red
        return
    }

    # Allow user to select files
    Write-Host "Master Files:" -ForegroundColor Yellow
    for ($i = 0; $i -lt [math]::Min(5, $masterFiles.Count); $i++) {
        Write-Host "  [$i] $($masterFiles[$i].Name) - $($masterFiles[$i].LastWriteTime)" -ForegroundColor White
    }

    Write-Host ""
    Write-Host "Replica Files:" -ForegroundColor Yellow
    for ($i = 0; $i -lt [math]::Min(5, $replicaFiles.Count); $i++) {
        Write-Host "  [$i] $($replicaFiles[$i].Name) - $($replicaFiles[$i].LastWriteTime)" -ForegroundColor White
    }

    Write-Host ""
    $masterIndex = Read-Host "Select Master file index (default: 0)"
    if ([string]::IsNullOrWhiteSpace($masterIndex)) { $masterIndex = 0 }

    $replicaIndex = Read-Host "Select Replica file index (default: 0)"
    if ([string]::IsNullOrWhiteSpace($replicaIndex)) { $replicaIndex = 0 }

    $masterFile = $masterFiles[$masterIndex].FullName
    $replicaFile = $replicaFiles[$replicaIndex].FullName

    Write-Host ""
    Write-Host "Comparing:" -ForegroundColor Cyan
    Write-Host "  Master : $masterFile" -ForegroundColor White
    Write-Host "  Replica: $replicaFile" -ForegroundColor White
    Write-Host ""

    # Import data
    $masterData = Import-Csv $masterFile
    $replicaData = Import-Csv $replicaFile

    # Filter out failed samples (-1 values) and count them
    $masterValidSamples = $masterData | Where-Object {
        $_.SQL_Connections -ne -1 -and $_.TCP_Total -ne -1 -and $_.Process_Handles -ne -1
    }
    $replicaValidSamples = $replicaData | Where-Object {
        $_.SQL_Connections -ne -1 -and $_.TCP_Total -ne -1 -and $_.Process_Handles -ne -1
    }

    $masterFailedCount = $masterData.Count - $masterValidSamples.Count
    $replicaFailedCount = $replicaData.Count - $replicaValidSamples.Count

    $masterFailureRate = if ($masterData.Count -gt 0) {
        [math]::Round(($masterFailedCount / $masterData.Count) * 100, 1)
    } else { 0 }

    $replicaFailureRate = if ($replicaData.Count -gt 0) {
        [math]::Round(($replicaFailedCount / $replicaData.Count) * 100, 1)
    } else { 0 }

    # Calculate statistics (using only valid samples)
    $masterStats = @{
        ServerRole = "Master"
        TotalSamples = $masterData.Count
        ValidSamples = $masterValidSamples.Count
        FailedSamples = $masterFailedCount
        FailureRate = $masterFailureRate
        AvgSQLConnections = if ($masterValidSamples.Count -gt 0) {
            ($masterValidSamples.SQL_Connections | Measure-Object -Average).Average
        } else { 0 }
        AvgTCPTotal = if ($masterValidSamples.Count -gt 0) {
            ($masterValidSamples.TCP_Total | Measure-Object -Average).Average
        } else { 0 }
        AvgDivergence = if ($masterValidSamples.Count -gt 0) {
            ($masterValidSamples.Divergence_Ratio | Measure-Object -Average).Average
        } else { 0 }
        MaxDivergence = if ($masterValidSamples.Count -gt 0) {
            ($masterValidSamples.Divergence_Ratio | Measure-Object -Maximum).Maximum
        } else { 0 }
        AvgHandles = if ($masterValidSamples.Count -gt 0) {
            ($masterValidSamples.Process_Handles | Measure-Object -Average).Average
        } else { 0 }
        AvgCloseWait = if ($masterValidSamples.Count -gt 0) {
            ($masterValidSamples.TCP_CloseWait | Measure-Object -Average).Average
        } else { 0 }

        # Growth analysis (first vs last valid sample)
        InitialTCPTotal = if ($masterValidSamples.Count -gt 0) { [int]$masterValidSamples[0].TCP_Total } else { 0 }
        FinalTCPTotal = if ($masterValidSamples.Count -gt 0) { [int]$masterValidSamples[-1].TCP_Total } else { 0 }
        InitialHandles = if ($masterValidSamples.Count -gt 0) { [int]$masterValidSamples[0].Process_Handles } else { 0 }
        FinalHandles = if ($masterValidSamples.Count -gt 0) { [int]$masterValidSamples[-1].Process_Handles } else { 0 }
    }

    $replicaStats = @{
        ServerRole = "Replica"
        TotalSamples = $replicaData.Count
        ValidSamples = $replicaValidSamples.Count
        FailedSamples = $replicaFailedCount
        FailureRate = $replicaFailureRate
        AvgSQLConnections = if ($replicaValidSamples.Count -gt 0) {
            ($replicaValidSamples.SQL_Connections | Measure-Object -Average).Average
        } else { 0 }
        AvgTCPTotal = if ($replicaValidSamples.Count -gt 0) {
            ($replicaValidSamples.TCP_Total | Measure-Object -Average).Average
        } else { 0 }
        AvgDivergence = if ($replicaValidSamples.Count -gt 0) {
            ($replicaValidSamples.Divergence_Ratio | Measure-Object -Average).Average
        } else { 0 }
        MaxDivergence = if ($replicaValidSamples.Count -gt 0) {
            ($replicaValidSamples.Divergence_Ratio | Measure-Object -Maximum).Maximum
        } else { 0 }
        AvgHandles = if ($replicaValidSamples.Count -gt 0) {
            ($replicaValidSamples.Process_Handles | Measure-Object -Average).Average
        } else { 0 }
        AvgCloseWait = if ($replicaValidSamples.Count -gt 0) {
            ($replicaValidSamples.TCP_CloseWait | Measure-Object -Average).Average
        } else { 0 }

        InitialTCPTotal = if ($replicaValidSamples.Count -gt 0) { [int]$replicaValidSamples[0].TCP_Total } else { 0 }
        FinalTCPTotal = if ($replicaValidSamples.Count -gt 0) { [int]$replicaValidSamples[-1].TCP_Total } else { 0 }
        InitialHandles = if ($replicaValidSamples.Count -gt 0) { [int]$replicaValidSamples[0].Process_Handles } else { 0 }
        FinalHandles = if ($replicaValidSamples.Count -gt 0) { [int]$replicaValidSamples[-1].Process_Handles } else { 0 }
    }

    # Calculate growth
    $masterStats.TCPGrowth = $masterStats.FinalTCPTotal - $masterStats.InitialTCPTotal
    $masterStats.TCPGrowthPercent = if ($masterStats.InitialTCPTotal -gt 0) {
        [math]::Round(($masterStats.TCPGrowth / $masterStats.InitialTCPTotal) * 100, 2)
    } else { 0 }

    $masterStats.HandleGrowth = $masterStats.FinalHandles - $masterStats.InitialHandles
    $masterStats.HandleGrowthPercent = if ($masterStats.InitialHandles -gt 0) {
        [math]::Round(($masterStats.HandleGrowth / $masterStats.InitialHandles) * 100, 2)
    } else { 0 }

    $replicaStats.TCPGrowth = $replicaStats.FinalTCPTotal - $replicaStats.InitialTCPTotal
    $replicaStats.TCPGrowthPercent = if ($replicaStats.InitialTCPTotal -gt 0) {
        [math]::Round(($replicaStats.TCPGrowth / $replicaStats.InitialTCPTotal) * 100, 2)
    } else { 0 }

    $replicaStats.HandleGrowth = $replicaStats.FinalHandles - $replicaStats.InitialHandles
    $replicaStats.HandleGrowthPercent = if ($replicaStats.InitialHandles -gt 0) {
        [math]::Round(($replicaStats.HandleGrowth / $replicaStats.InitialHandles) * 100, 2)
    } else { 0 }

    # Calculate linear regression slopes (trend analysis)
    Write-Host "Calculating trend slopes..." -ForegroundColor Cyan

    $masterTCPSlope = Calculate-LinearRegressionSlope -Data $masterValidSamples -TimeColumn "Timestamp" -ValueColumn "TCP_Total"
    $masterHandleSlope = Calculate-LinearRegressionSlope -Data $masterValidSamples -TimeColumn "Timestamp" -ValueColumn "Process_Handles"
    $masterDivergenceSlope = Calculate-LinearRegressionSlope -Data $masterValidSamples -TimeColumn "Timestamp" -ValueColumn "Divergence_Ratio"

    $replicaTCPSlope = Calculate-LinearRegressionSlope -Data $replicaValidSamples -TimeColumn "Timestamp" -ValueColumn "TCP_Total"
    $replicaHandleSlope = Calculate-LinearRegressionSlope -Data $replicaValidSamples -TimeColumn "Timestamp" -ValueColumn "Process_Handles"
    $replicaDivergenceSlope = Calculate-LinearRegressionSlope -Data $replicaValidSamples -TimeColumn "Timestamp" -ValueColumn "Divergence_Ratio"

    $masterStats.TCPSlopePerDay = $masterTCPSlope.SlopePerDay
    $masterStats.TCPTrendStrength = $masterTCPSlope.TrendStrength
    $masterStats.TCPRSquared = $masterTCPSlope.RSquared

    $masterStats.HandleSlopePerDay = $masterHandleSlope.SlopePerDay
    $masterStats.HandleTrendStrength = $masterHandleSlope.TrendStrength
    $masterStats.HandleRSquared = $masterHandleSlope.RSquared

    $masterStats.DivergenceSlopePerDay = $masterDivergenceSlope.SlopePerDay
    $masterStats.DivergenceTrendStrength = $masterDivergenceSlope.TrendStrength

    $replicaStats.TCPSlopePerDay = $replicaTCPSlope.SlopePerDay
    $replicaStats.TCPTrendStrength = $replicaTCPSlope.TrendStrength
    $replicaStats.TCPRSquared = $replicaTCPSlope.RSquared

    $replicaStats.HandleSlopePerDay = $replicaHandleSlope.SlopePerDay
    $replicaStats.HandleTrendStrength = $replicaHandleSlope.TrendStrength
    $replicaStats.HandleRSquared = $replicaHandleSlope.RSquared

    $replicaStats.DivergenceSlopePerDay = $replicaDivergenceSlope.SlopePerDay
    $replicaStats.DivergenceTrendStrength = $replicaDivergenceSlope.TrendStrength

    # Display comparison
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host "COMPARISON SUMMARY" -ForegroundColor Cyan
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host ""

    # Display sample quality metrics
    Write-Host "Sample Quality:" -ForegroundColor Yellow
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Metric", "Master", "Replica") -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "-" * 30, "-" * 15, "-" * 15) -ForegroundColor Gray
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Total Samples", $masterStats.TotalSamples, $replicaStats.TotalSamples) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Valid Samples", $masterStats.ValidSamples, $replicaStats.ValidSamples) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Failed Samples", $masterStats.FailedSamples, $replicaStats.FailedSamples) -ForegroundColor $(if ($masterStats.FailedSamples -gt 0 -or $replicaStats.FailedSamples -gt 0) { "Yellow" } else { "White" })
    Write-Host ("  {0,-30} {1,14}% {2,14}%" -f "Failure Rate", $masterStats.FailureRate, $replicaStats.FailureRate) -ForegroundColor $(if ($masterStats.FailureRate -gt 25 -or $replicaStats.FailureRate -gt 25) { "Red" } elseif ($masterStats.FailureRate -gt 10 -or $replicaStats.FailureRate -gt 10) { "Yellow" } else { "White" })
    Write-Host ""

    # Show warning if failure rate is high
    if ($masterStats.FailureRate -gt 25) {
        Write-Host "  [!] WARNING: Master failure rate >25% - data may be unreliable!" -ForegroundColor Red
    }
    if ($replicaStats.FailureRate -gt 25) {
        Write-Host "  [!] WARNING: Replica failure rate >25% - data may be unreliable!" -ForegroundColor Red
    }
    if ($masterStats.FailureRate -gt 25 -or $replicaStats.FailureRate -gt 25) {
        Write-Host ""
    }

    Write-Host "Connection Metrics:" -ForegroundColor Yellow
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Metric", "Master", "Replica") -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "-" * 30, "-" * 15, "-" * 15) -ForegroundColor Gray
    Write-Host ("  {0,-30} {1,15:N1} {2,15:N1}" -f "Avg SQL Connections", $masterStats.AvgSQLConnections, $replicaStats.AvgSQLConnections) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15:N1} {2,15:N1}" -f "Avg TCP Total", $masterStats.AvgTCPTotal, $replicaStats.AvgTCPTotal) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15:N2} {2,15:N2}" -f "Avg Divergence Ratio", $masterStats.AvgDivergence, $replicaStats.AvgDivergence) -ForegroundColor $(if ($masterStats.AvgDivergence -gt 2.0) { "Red" } elseif ($masterStats.AvgDivergence -gt 1.5) { "Yellow" } else { "White" })
    Write-Host ("  {0,-30} {1,15:N2} {2,15:N2}" -f "Max Divergence Ratio", $masterStats.MaxDivergence, $replicaStats.MaxDivergence) -ForegroundColor $(if ($masterStats.MaxDivergence -gt 2.0) { "Red" } else { "White" })
    Write-Host ("  {0,-30} {1,15:N1} {2,15:N1}" -f "Avg CLOSE_WAIT", $masterStats.AvgCloseWait, $replicaStats.AvgCloseWait) -ForegroundColor $(if ($masterStats.AvgCloseWait -gt 5) { "Yellow" } else { "White" })
    Write-Host ""

    Write-Host "Growth Analysis:" -ForegroundColor Yellow
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Metric", "Master", "Replica") -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "-" * 30, "-" * 15, "-" * 15) -ForegroundColor Gray
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Initial TCP Total", $masterStats.InitialTCPTotal, $replicaStats.InitialTCPTotal) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Final TCP Total", $masterStats.FinalTCPTotal, $replicaStats.FinalTCPTotal) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "TCP Growth", $masterStats.TCPGrowth, $replicaStats.TCPGrowth) -ForegroundColor $(if ($masterStats.TCPGrowth -gt 50) { "Red" } elseif ($masterStats.TCPGrowth -gt 20) { "Yellow" } else { "White" })
    Write-Host ("  {0,-30} {1,14}% {2,14}%" -f "TCP Growth %", $masterStats.TCPGrowthPercent, $replicaStats.TCPGrowthPercent) -ForegroundColor $(if ($masterStats.TCPGrowthPercent -gt 20) { "Red" } elseif ($masterStats.TCPGrowthPercent -gt 10) { "Yellow" } else { "White" })
    Write-Host ""
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Initial Handles", $masterStats.InitialHandles, $replicaStats.InitialHandles) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Final Handles", $masterStats.FinalHandles, $replicaStats.FinalHandles) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Handle Growth", $masterStats.HandleGrowth, $replicaStats.HandleGrowth) -ForegroundColor $(if ($masterStats.HandleGrowth -gt 500) { "Red" } elseif ($masterStats.HandleGrowth -gt 200) { "Yellow" } else { "White" })
    Write-Host ("  {0,-30} {1,14}% {2,14}%" -f "Handle Growth %", $masterStats.HandleGrowthPercent, $replicaStats.HandleGrowthPercent) -ForegroundColor $(if ($masterStats.HandleGrowthPercent -gt 20) { "Red" } elseif ($masterStats.HandleGrowthPercent -gt 10) { "Yellow" } else { "White" })
    Write-Host ""

    Write-Host "Trend Analysis (Linear Regression):" -ForegroundColor Yellow
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Metric", "Master", "Replica") -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "-" * 30, "-" * 15, "-" * 15) -ForegroundColor Gray

    # TCP slope
    $masterTCPColor = if ($masterStats.TCPSlopePerDay -gt 5) { "Red" } elseif ($masterStats.TCPSlopePerDay -gt 2) { "Yellow" } else { "White" }
    $replicaTCPColor = if ($replicaStats.TCPSlopePerDay -gt 5) { "Red" } elseif ($replicaStats.TCPSlopePerDay -gt 2) { "Yellow" } else { "White" }
    Write-Host ("  {0,-30} {1,15:N2} {2,15:N2}" -f "TCP Slope (per day)", $masterStats.TCPSlopePerDay, $replicaStats.TCPSlopePerDay) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "TCP Trend Strength", $masterStats.TCPTrendStrength, $replicaStats.TCPTrendStrength) -ForegroundColor $(if ($masterStats.TCPTrendStrength -eq "Strong" -and $masterStats.TCPSlopePerDay -gt 2) { "Red" } elseif ($masterStats.TCPTrendStrength -in @("Strong","Moderate") -and $masterStats.TCPSlopePerDay -gt 1) { "Yellow" } else { "White" })
    Write-Host ("  {0,-30} {1,15:N3} {2,15:N3}" -f "TCP R  (fit quality)", $masterStats.TCPRSquared, $replicaStats.TCPRSquared) -ForegroundColor Gray
    Write-Host ""

    # Handle slope
    Write-Host ("  {0,-30} {1,15:N2} {2,15:N2}" -f "Handle Slope (per day)", $masterStats.HandleSlopePerDay, $replicaStats.HandleSlopePerDay) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Handle Trend Strength", $masterStats.HandleTrendStrength, $replicaStats.HandleTrendStrength) -ForegroundColor $(if ($masterStats.HandleTrendStrength -eq "Strong" -and $masterStats.HandleSlopePerDay -gt 50) { "Red" } elseif ($masterStats.HandleTrendStrength -in @("Strong","Moderate") -and $masterStats.HandleSlopePerDay -gt 20) { "Yellow" } else { "White" })
    Write-Host ("  {0,-30} {1,15:N3} {2,15:N3}" -f "Handle R  (fit quality)", $masterStats.HandleRSquared, $replicaStats.HandleRSquared) -ForegroundColor Gray
    Write-Host ""

    # Divergence slope
    Write-Host ("  {0,-30} {1,15:N2} {2,15:N2}" -f "Divergence Slope (per day)", $masterStats.DivergenceSlopePerDay, $replicaStats.DivergenceSlopePerDay) -ForegroundColor White
    Write-Host ("  {0,-30} {1,15} {2,15}" -f "Divergence Trend Strength", $masterStats.DivergenceTrendStrength, $replicaStats.DivergenceTrendStrength) -ForegroundColor $(if ($masterStats.DivergenceTrendStrength -eq "Strong" -and $masterStats.DivergenceSlopePerDay -gt 0.1) { "Red" } elseif ($masterStats.DivergenceTrendStrength -in @("Strong","Moderate") -and $masterStats.DivergenceSlopePerDay -gt 0.05) { "Yellow" } else { "White" })
    Write-Host ""

    # Analysis and conclusions
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host "FINDINGS" -ForegroundColor Cyan
    Write-Host "=====================================================================" -ForegroundColor Cyan
    Write-Host ""

    $findings = @()

    # Check for positive trend slope (STRONGEST EVIDENCE)
    if ($masterStats.TCPTrendStrength -in @("Strong","Moderate") -and $masterStats.TCPSlopePerDay -gt 2 -and $replicaStats.TCPSlopePerDay -le 1) {
        $findings += "[LEAK INDICATOR - TREND] Master TCP connections show $($masterStats.TCPTrendStrength.ToLower()) upward trend (+$($masterStats.TCPSlopePerDay)/day), Replica flat (+$($replicaStats.TCPSlopePerDay)/day)"
    }

    if ($masterStats.HandleTrendStrength -in @("Strong","Moderate") -and $masterStats.HandleSlopePerDay -gt 20 -and $replicaStats.HandleSlopePerDay -le 10) {
        $findings += "[LEAK INDICATOR - TREND] Master handles show $($masterStats.HandleTrendStrength.ToLower()) upward trend (+$($masterStats.HandleSlopePerDay)/day), Replica flat (+$($replicaStats.HandleSlopePerDay)/day)"
    }

    if ($masterStats.DivergenceTrendStrength -in @("Strong","Moderate") -and $masterStats.DivergenceSlopePerDay -gt 0.05 -and $replicaStats.DivergenceSlopePerDay -le 0.02) {
        $findings += "[LEAK INDICATOR - TREND] Master divergence ratio increasing ($($masterStats.DivergenceTrendStrength.ToLower()) trend), Replica stable"
    }

    # Check for divergence difference
    if ($masterStats.AvgDivergence -gt 1.5 -and $replicaStats.AvgDivergence -le 1.5) {
        $findings += "[LEAK INDICATOR - DIVERGENCE] Master shows TCP/SQL divergence (avg $([math]::Round($masterStats.AvgDivergence, 2))x), Replica does not (avg $([math]::Round($replicaStats.AvgDivergence, 2))x)"
    }

    # Check for growth difference
    if ($masterStats.TCPGrowthPercent -gt 10 -and $replicaStats.TCPGrowthPercent -le 10) {
        $findings += "[LEAK INDICATOR - GROWTH] Master TCP connections growing ($($masterStats.TCPGrowthPercent)%), Replica stable ($($replicaStats.TCPGrowthPercent)%)"
    }

    # Check for CLOSE_WAIT accumulation
    if ($masterStats.AvgCloseWait -gt 5 -and $replicaStats.AvgCloseWait -le 5) {
        $findings += "[LEAK INDICATOR - CLOSE_WAIT] Master accumulating CLOSE_WAIT connections (avg $([math]::Round($masterStats.AvgCloseWait, 1))), Replica not (avg $([math]::Round($replicaStats.AvgCloseWait, 1)))"
    }

    # Check for handle growth difference
    if ($masterStats.HandleGrowthPercent -gt 10 -and $replicaStats.HandleGrowthPercent -le 10) {
        $findings += "[LEAK INDICATOR - GROWTH] Master process handles growing ($($masterStats.HandleGrowthPercent)%), Replica stable ($($replicaStats.HandleGrowthPercent)%)"
    }

    if ($findings.Count -eq 0) {
        Write-Host "[NO LEAK DETECTED] Both servers show similar patterns" -ForegroundColor Green
    } else {
        foreach ($finding in $findings) {
            Write-Host $finding -ForegroundColor Red
        }

        Write-Host ""
        Write-Host "INTERPRETATION:" -ForegroundColor Yellow
        Write-Host "The master VAS server exhibits resource leak patterns that the replica" -ForegroundColor White
        Write-Host "server does NOT exhibit in the same environment. This suggests the leak" -ForegroundColor White
        Write-Host "correlates with the master's unique workload (handling sync requests from" -ForegroundColor White
        Write-Host "replica servers)." -ForegroundColor White
        Write-Host ""
        Write-Host "Statistical trend analysis (linear regression) confirms sustained growth" -ForegroundColor White
        Write-Host "over time, which is characteristic of a resource leak rather than normal" -ForegroundColor White
        Write-Host "workload variation or temporary spikes." -ForegroundColor White
    }

    Write-Host ""
    Write-Host "=====================================================================" -ForegroundColor Cyan
}

#endregion

#region Main

if ($Mode -eq "Monitor") {
    if (-not $ServerRole) {
        Write-Host "[ERROR] -ServerRole is required for Monitor mode" -ForegroundColor Red
        Write-Host "Usage: .\Monitor_VAS_Connections.ps1 -Mode Monitor -ServerRole Master|Replica" -ForegroundColor Yellow
        exit 1
    }

    Start-Monitoring -ServerRole $ServerRole -DurationHours $Duration -IntervalMinutes $Interval
}
elseif ($Mode -eq "Compare") {
    Compare-Results
}

#endregion
