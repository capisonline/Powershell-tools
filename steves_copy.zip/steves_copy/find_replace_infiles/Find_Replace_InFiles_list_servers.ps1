﻿# Create a list of Servers 
$Servers = Get-Content "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"

# CSV log file path
$CsvLogFilePath = "C:\temp\QCAD\VT\Networking\firewall-logs\firewall_script_update.csv"

# Initialize an array for CSV log content
$CsvLogContent = @()

#----------------------------------------------------------------------

foreach ($Server in $Servers) {
    $ServerLogEntries = Invoke-Command -ComputerName $Server -ScriptBlock {
        $Server = $using:Server

        # Define replacements
        $Replacements = @(
            @{ Old = 'Export-Csv -Path $outputPath -Append -NoTypeInformation -Encoding UTF8'; New = 'Export-Csv -Path $outputPath -NoTypeInformation -Encoding UTF8' }
           
        )

        # Find all .config files under D:\ recursively
        $Files = Get-ChildItem -Path 'D:\scripts' -Filter 'ExportFirewallLog.ps1' -ErrorAction SilentlyContinue -Force | Where-Object { -not $_.PSIsContainer }

        # Log entries
        $LogEntries = @()

        foreach ($File in $Files) {
            try {
                $FilePath = $File.FullName
                $Content = Get-Content $FilePath -Raw

                foreach ($Replacement in $Replacements) {
                    if ($Content -match [regex]::Escape($Replacement.Old)) {
                        $Content = $Content -Replace [regex]::Escape($Replacement.Old), $Replacement.New
                        $LogEntries += [PSCustomObject]@{
                            FilePath = $FilePath
                            OldSetting = $Replacement.Old
                            NewSetting = $Replacement.New
                        }
                    }
                }

                # Write back if modified
                if ($LogEntries.Count -gt 0) {
                    $Content | Set-Content $FilePath -Force -Encoding UTF8
                }
            } catch {
                $LogEntries += [PSCustomObject]@{
                    FilePath = $File.FullName
                    OldSetting = "Error"
                    NewSetting = $_.Exception.Message
                }
            }
        }

        return $LogEntries
    }

    # Append the server's log entries to the main log content
    $CsvLogContent += $ServerLogEntries
}

# Export the log content to a CSV file
$CsvLogContent | Export-Csv -Path $CsvLogFilePath -NoTypeInformation -Encoding UTF8 -Append
