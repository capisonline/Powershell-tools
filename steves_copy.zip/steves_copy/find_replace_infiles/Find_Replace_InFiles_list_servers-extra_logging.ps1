﻿# PowerShell script to recursively update *.config files across QCAD servers
# Applies all defined replacements, logs every match, and shows output in CLI

# List of servers to connect to
$Servers = 'PC556292'
#Get-Content "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"

# CSV log file path
$CsvLogFilePath = "C:\temp\QCAD\VT\Configs\Merging\NLB_update.csv"

# Initialize an array for CSV log content
$CsvLogContent = @()

#---------------------------------------------------------------------- 

foreach ($Server in $Servers) {
    Write-Host "`nConnecting to $Server..." -ForegroundColor Cyan

    $ServerLogEntries = Invoke-Command -ComputerName $Server -ScriptBlock {
        $Server = $using:Server

        # Define replacements
        $Replacements = @(
            @{ Old = 'qps-qcad-pa-vcs.prds.qldpol' ; New =  'vtcad-vcsnlb.prds.qldpol'},
            @{ Old = 'qps-qcad-pa-vws.prds.qldpol' ; New = 'VTcad-vwsnlb.prds.qldpol' },
            @{ Old = 'qps-qcad-pa-vim.prds.qldpol' ; New = 'VTcad-vimnlb.prds.qldpol' }
        )

        # Find all .config files under D:\ recursively
        $Files = Get-ChildItem -Path 'C:\temp\QCAD\VT\Configs\Merging\' -Recurse -include '*.config', '*.settings', '*.ini' -ErrorAction SilentlyContinue -Force | Where-Object { -not $_.PSIsContainer }

        # Log entries
        $LogEntries = @()

        foreach ($File in $Files) {
            try {
                $FilePath = $File.FullName
                $Content = Get-Content $FilePath -Raw
                $OriginalContent = $Content
                $Modified = $false

                foreach ($Replacement in $Replacements) {
                    $Matches = ([regex]::Matches($Content, [regex]::Escape($Replacement.Old))).Count

                    if ($Matches -gt 0) {
                        $Content = $Content -Replace [regex]::Escape($Replacement.Old), $Replacement.New
                        $Modified = $true

                        for ($i = 1; $i -le $Matches; $i++) {
                            $LogEntries += [PSCustomObject]@{
                                FilePath = $FilePath
                                OldSetting = $Replacement.Old
                                NewSetting = $Replacement.New
                            }

                            Write-Output "[$env:COMPUTERNAME] Replaced '$($Replacement.Old)' with '$($Replacement.New)' in file: $FilePath (Match #$i)"
                        }
                    }
                }

                # Save file if it was modified
                if ($Modified -and $Content -ne $OriginalContent) {
                    $Content | Set-Content $FilePath -Force -Encoding UTF8
                }

            } catch {
                $LogEntries += [PSCustomObject]@{
                    FilePath = $File.FullName
                    OldSetting = "Error"
                    NewSetting = $_.Exception.Message
                }

                Write-Output "[$env:COMPUTERNAME] ERROR processing file: $($File.FullName) - $($_.Exception.Message)"
            }
        }

        return $LogEntries
    }

    # Append this server's log entries to the main log content
    $CsvLogContent += $ServerLogEntries
}

# Export the log content to a CSV file
$CsvLogContent | Export-Csv -Path $CsvLogFilePath -NoTypeInformation -Encoding UTF8 -Append

Write-Host "`nUpdate complete. Log saved to: $CsvLogFilePath" -ForegroundColor Green
