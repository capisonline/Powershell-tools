﻿Install-WindowsFeature Net-Framework-Core -source C:\Temp

Install-WindowsFeature Net-Framework-Core -source \\POLQPSMGTPR87\e\ISO\sxs