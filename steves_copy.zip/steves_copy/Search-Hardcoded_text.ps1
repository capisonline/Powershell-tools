﻿# Set the path to the file containing the list of servers 
$serversListFilePath = "C:\temp\scripts\server_list.txt"

# Set the hardcoded text to search for
$textToSearch = "4.122"

# Set the folder path where files will be searched
$folderPath = "C:\Windows\Microsoft.NET"

# Set the output directory path
$outputDirectory = "C:\temp\QCAD\Issues"

# Function to search files for the text on a specific server
function SearchFilesForTextOnServer {
    param (
        [string]$serverName,
        [string]$textToSearch,
        [string]$folderPath,
        [string]$outputDirectory
    )

    # Set the output text file path for the current server
    $outputFilePath = Join-Path -Path $outputDirectory -ChildPath "$serverName`_$textToSearch.txt"

    # Create the output directory if it doesn't exist
    if (-not (Test-Path -Path $outputDirectory)) {
        New-Item -Path $outputDirectory -ItemType Directory | Out-Null
    }

    # Establish a remote session to the server
    $session = New-PSSession -ComputerName $serverName

    # Search for the text in files on the server
    $filesContainingText = Invoke-Command -Session $session -ScriptBlock {
        param ($textToSearch, $folderPath)

        # Search for the text in files within the folder and its subfolders
        Get-ChildItem -Path $folderPath -Recurse -File | Where-Object {
            Select-String -Path $_.FullName -Pattern $textToSearch -Quiet
        } | Select-Object -ExpandProperty FullName
    } -ArgumentList $textToSearch, $folderPath

    # If no files contain the text, write a message to the output file
    if ($filesContainingText.Count -eq 0) {
        Add-Content -Path $outputFilePath -Value "Text '$textToSearch' not found on server $serverName"
    } else {
        # If files contain the text, save the file paths to the output file
        $filesContainingText | ForEach-Object {
            Add-Content -Path $outputFilePath -Value $_
        }
    }

    # End the remote session
    Remove-PSSession -Session $session
}

# Read the list of servers from the file and perform the search for each server
Get-Content -Path $serversListFilePath | ForEach-Object {
    SearchFilesForTextOnServer -serverName $_ -textToSearch $textToSearch -folderPath $folderPath -outputDirectory $outputDirectory
}
