﻿<#
This works on both txt & csv files... haven't tested other formats
#>
# Define the directory containing the CSV files 
$sourceDirectory = "C:\temp\QCAD\PS\Issues\File_Hashes\hashes"

# Define the path for the new merged CSV file
$mergedCSV = "C:\temp\QCAD\PS\Issues\File_Hashes\hashes\Merged-services.csv"

# Get all CSV/txt files in the directory - change the extension based on file type
$csvFiles = Get-ChildItem -Path $sourceDirectory -Filter "*.*"

# Check if any CSV files found
if ($csvFiles.Count -eq 0) {
    Write-Host "No CSV files found in the directory."
    exit
}

# Create or clear the merged CSV file
if (Test-Path $mergedCSV) {
    Clear-Content $mergedCSV
} else {
    New-Item -Path $mergedCSV -ItemType File
}

# Loop through each CSV file
foreach ($file in $csvFiles) {
    # Get the content of the CSV file
    $content = Get-Content $file.FullName

    # If it's the first file, modify header to include filename
    if ($file -eq $csvFiles[0]) {
        $header = "Filename," + $content[0]
        Add-Content -Path $mergedCSV -Value $header
        $content = $content | Select-Object -Skip 1
    }

    # Add filename to each line except the header
    $updatedContent = $content | ForEach-Object {
        "$($file.Name),$_"
    }

    # Append the updated content to the merged CSV file
    Add-Content -Path $mergedCSV -Value $updatedContent
}

Write-Host "CSV files have been merged into $mergedCSV"

