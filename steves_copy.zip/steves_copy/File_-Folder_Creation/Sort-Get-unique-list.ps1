﻿
# Define the folder containing input files 
$inputFolder = "C:\temp\QCAD\VT\Networking\Netstat_Results"

# Define the folder to save output files
$outputFolder = "C:\temp\QCAD\VT\Networking\Netstat_Results\Sorted"

# Make sure the output directory exists
if (!(Test-Path -Path $outputFolder)) {
    New-Item -ItemType Directory -Path $outputFolder
}

# Define file extension to filter input files
$fileExtension = "*.txt"

# Retrieve all text files in the input folder
$inputFiles = Get-ChildItem -Path $inputFolder -Filter $fileExtension

# Process each file
foreach ($file in $inputFiles) {
    # Get the file name without extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($file.Name)
    
    # Create the output file path with "_sorted" suffix
    $outputFile = Join-Path -Path $outputFolder -ChildPath "${fileNameWithoutExtension}_sorted.txt"
    
    # Sort, remove duplicates, and write to the output file
    Get-Content $file.FullName | Sort-Object | Get-Unique | Set-Content -Path $outputFile
}

Write-Output "Processing complete. Sorted files saved in: $outputFolder"
