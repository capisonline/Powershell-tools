﻿# This script compares folders between an OLDServer and a NEWServer
# Define variables 
$inputCsv = "C:\temp\QCAD\TP\Old_Server-New_Server.csv"  # Path to the input CSV file containing old and new server pairs
$outputCsv = "C:\temp\QCAD\TP\LogMan\folder_comparison.csv"  # Path to the output CSV file to save the comparison results
$drivesToScan = @("D", "E")  # Drives to scan on both old and new servers

# Function to get folder structure
function Get-FolderStructure {
    param (
        [string]$server,
        [string[]]$drives
    )

    $folders = @()
    foreach ($drive in $drives) {
        $path = "\\$server\$drive`$"
        try {
            $folders += Get-ChildItem -Path $path -Directory -Recurse -ErrorAction Stop | Select-Object -ExpandProperty FullName
        } catch {
            Write-Host "Failed to scan $drive`$ on $server. Error: $_"
        }
    }
    return $folders
}

# Read the input CSV file
$serverPairs = Import-Csv -Path $inputCsv

# Initialize an array to store the comparison results
$comparisonResults = @()

# Loop through each server pair and compare the folder structures
foreach ($pair in $serverPairs) {
    $oldServer = $pair.OldServer
    $newServer = $pair.NewServer

    Write-Host "Comparing folder structures for $oldServer and $newServer..."

    # Get folder structures
    $oldFolders = Get-FolderStructure -server $oldServer -drives $drivesToScan
    $newFolders = Get-FolderStructure -server $newServer -drives $drivesToScan

    # Normalize folder paths for comparison
    $oldFolders = $oldFolders -replace "\\$oldServer", ""
    $newFolders = $newFolders -replace "\\$newServer", ""

    # Compare folder structures
    foreach ($folder in $oldFolders) {
        $existsOnNewServer = $newFolders -contains $folder
        $comparisonResults += [pscustomobject]@{
            OldServer         = $oldServer
            NewServer         = $newServer
            Folder            = $folder
            ExistsOnNewServer = $existsOnNewServer
        }
    }
}

# Export the comparison results to a CSV file
$comparisonResults | Export-Csv -Path $outputCsv -NoTypeInformation

Write-Host "Folder structure comparison completed. Results saved to $outputCsv."
