﻿# Define the root folder to scan and the output CSV file path 
$rootFolderPath = "C:\temp\QCAD\TP\LogMan"
$outputCsv = "C:\temp\QCAD\TP\LogMan\All_files_compared_Results.csv"

# Function to compute the hash of a file's contents
function Get-FileHashString {
    param ([string]$filePath)
    $fileHash = Get-FileHash -Algorithm SHA256 -Path $filePath
    return $fileHash.Hash
}

# Retrieve all files under the root folder, including subdirectories
$files = Get-ChildItem -Path $rootFolderPath -File -Recurse

# Initialize an empty hash table to store file hashes
$hashTable = @{}

# Loop through each file and calculate its hash
foreach ($file in $files) {
    $filePath = $file.FullName
    $fileHash = Get-FileHashString -filePath $filePath
    
    # Use the hash as key, and append the full path to avoid name collisions
    if ($hashTable.ContainsKey($fileHash)) {
        $hashTable[$fileHash] += ", " + $filePath
    } else {
        $hashTable[$fileHash] = $filePath
    }
}

# Prepare an array of objects for the CSV output
$outputArray = @()

# Populate the output array with file path and matching file information
foreach ($hash in $hashTable.Keys) {
    $filePaths = $hashTable[$hash] -split ", "
    foreach ($filePath in $filePaths) {
        $matchingFiles = $filePaths -ne $filePath
        $matchList = if ($matchingFiles.Count -gt 0) { [string]::Join(", ", $matchingFiles) } else { "No Matches" }

        $outputArray += [pscustomobject]@{
            FilePath = $filePath
            MatchingFiles = $matchList
        }
    }
}

# Export the results to a CSV file
$outputArray | Export-Csv -Path $outputCsv -NoTypeInformation

Write-Output "File comparison results have been exported to $outputCsv."
