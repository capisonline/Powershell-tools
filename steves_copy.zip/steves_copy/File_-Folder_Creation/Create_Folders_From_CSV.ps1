﻿# Path to the CSV file 
$csvPath = "C:\temp\QCAD\TP\LogMan\LogMan_Folder_list.csv"

# Path to the output CSV file to store the results
$outputCsvPath = "C:\temp\QCAD\TP\LogMan\folder_creation_results.csv"

# Import the CSV file
$folders = Import-Csv -Path $csvPath

# Initialize an array to store the results
$results = @()

# Loop through each row in the CSV
foreach ($folder in $folders) {
    $serverName = $folder.ServerName
    $folderPath = $folder.FolderPath

    # Use Invoke-Command to create the folder on the remote server
    $result = Invoke-Command -ComputerName $serverName -ScriptBlock {
        param ($folderPath, $serverName)
        if (-not (Test-Path -Path $folderPath)) {
            New-Item -Path $folderPath -ItemType Directory -Force
            return "Created"
        } else {
            return "Already Exists"
        }
    } -ArgumentList $folderPath, $serverName -ErrorAction SilentlyContinue

    # Store the result in the array
    $results += [PSCustomObject]@{
        ServerName = $serverName
        FolderPath = $folderPath
        Status     = $result
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation -Force

Write-Host "Folder creation process completed. Results saved to $outputCsvPath"
