﻿# Define the path to your servers file and the directory containing the CSV files 
$serversFilePath = "C:\temp\QCAD\PR\PR_New_Servers.txt"
$csvDirectory = "C:\temp\scripts\File_-Folder_Creation\Input_CSVs"

# Read the server names from the text file
$serverNames = Get-Content $serversFilePath

# Define server types that are expected to match with CSV filenames
$serverTypes = @("AAS", "APL", "CCM", "GGS", "VCS","VMG","VIM","VAS","VWS") # Add more types as needed

# Process each server name
foreach ($serverName in $serverNames) {
    $serverName = $serverName.Trim()
    # Initialize an array to hold matching texts
    $matchingTexts = @()

    # Determine the server type based on the known types
    $serverType = $serverTypes | Where-Object { $serverName -like "*$_*" }

    if ($serverType) {
        # Construct the expected CSV filename from the server type
        $expectedCsvFileName = "$serverType.csv"
        $csvFilePath = Join-Path -Path $csvDirectory -ChildPath $expectedCsvFileName

        if (Test-Path $csvFilePath) {
            # Import the CSV file and collect the values from the specified column
            $csvData = Import-Csv -Path $csvFilePath
            foreach ($row in $csvData) {
                # Assuming the column you're interested in is named 'ColumnA'
                $matchingTexts += $row.Roles_Features
            }

            # If matching texts were found, write them to a new text file named after the server
            if ($matchingTexts.Count -gt 0) {
                $outputFilePath = "C:\temp\QCAD\PR\Roles_Features\Input_Txt_Files\$serverName.txt" # Specify the output directory
                $matchingTexts | Out-File -FilePath $outputFilePath
            }
        } else {
            Write-Warning "No CSV file found for server type $serverType"
        }
    } else {
        Write-Warning "Server type for $serverName could not be determined"
    }
}
