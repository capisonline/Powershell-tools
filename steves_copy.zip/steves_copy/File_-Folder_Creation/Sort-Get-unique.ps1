﻿# Once file is saved - clean up the file (sometimes they get really big)
$inputfile = "C:\temp\QCAD\TP\Networking\Netstat\QPS-CCM-TP-03_netstat.txt"
$outputfile = "C:\temp\QCAD\TP\Networking\Netstat\QPS-CCM-TP-03-FormattedNetstat-cleaned_outputfile.txt"
Get-Content $inputfile | sort | get-unique > $outputfile