﻿# Define path to the CSV file 
$csvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\User-Groups.csv"
$serverListPath = "C:\temp\QCAD\PA\NEW_Server_list.txt"
$outputCsvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\output_results22222.csv"
# Import data from CSV and server list
$appGroups = Import-Csv -Path $csvPath
$servers = Get-Content -Path $serverListPath

# Initialize an array to hold the results
$results = @()

# Loop through each app group configuration
foreach ($appGroup in $appGroups) {
    # Find servers that match the app type
    $matchedServers = $servers | Where-Object { $_ -like "*$($appGroup.AppType)*" }

    # Check each matched server
    foreach ($serverName in $matchedServers) {
        # Preprocess group names to escape backslashes for regex
        $escapedAdminGroup = $appGroup.AdminGroup #-replace '\', '\\'
        $escapedBatchJobGroup = $appGroup.BatchJobGroup #-replace '\', '\\'
        $escapedServiceGroup = $appGroup.ServiceGroup #-replace '\', '\\'
        $escapedDebugGroup = $appGroup.DebugGroup #-replace '\', '\\'

        # Collect results for each server
        $result = [PSCustomObject]@{
            ServerName = $serverName
            AppType = $appGroup.AppType
            AdminGroup = $appGroup.AdminGroup
            IsAdmin = $null
            BatchJobGroup = $appGroup.BatchJobGroup
            CanLogonAsBatch = $null
            ServiceGroup = $appGroup.ServiceGroup
            CanLogonAsService = $null
            DebugGroup = $appGroup.DebugGroup
            CanDebugPrograms = $null
        }

        # Check local Administrators group if AdminGroup is not empty
        if (![string]::IsNullOrWhiteSpace($appGroup.AdminGroup)) {
            $adminGroup = Get-WmiObject Win32_GroupUser -ComputerName $serverName |
                          Where-Object { $_.GroupComponent -like "*Administrators" } |
                          ForEach-Object { ([WMI]$_).PartComponent } |
                          Select-String -Pattern $escapedAdminGroup

            $result.IsAdmin = $adminGroup -ne $null
        }

        # Check rights using secedit /export and parse the resulting file
        $seceditExportPath = "C:\temp\$($serverName)_secedit.inf"
        secedit /export /cfg $seceditExportPath /areas USER_RIGHTS /quiet

        if (![string]::IsNullOrWhiteSpace($appGroup.BatchJobGroup)) {
            $batchJobRights = Select-String -Path $seceditExportPath -Pattern $escapedBatchJobGroup
            $result.CanLogonAsBatch = $batchJobRights -ne $null
        }

        if (![string]::IsNullOrWhiteSpace($appGroup.ServiceGroup)) {
            $serviceRights = Select-String -Path $seceditExportPath -Pattern $escapedServiceGroup
            $result.CanLogonAsService = $serviceRights -ne $null
        }

        if (![string]::IsNullOrWhiteSpace($appGroup.DebugGroup)) {
            $debugRights = Select-String -Path $seceditExportPath -Pattern $escapedDebugGroup
            $result.CanDebugPrograms = $debugRights -ne $null
        }

        # Add result to the results array
        $results += $result
    }
}

# Export results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

# Cleanup temporary files
Remove-Item -Path "C:\temp\*.inf" -Force
