﻿# Define path to the CSV file 
$csvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\User-Groups.csv"
$serverListPath = "C:\temp\QCAD\PA\Server_list.txt"
$outputCsvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\output_results2.csv"


# Import data from CSV and server list
$appGroups = Import-Csv -Path $csvPath
$servers = Get-Content -Path $serverListPath

# Initialize an array to hold the results
$results = @()

# Loop through each app group configuration
foreach ($appGroup in $appGroups) {
    # Find servers that match the app type
    $matchedServers = $servers | Where-Object { $_ -like "*$($appGroup.AppType)*" }

    # Check each matched server
    foreach ($serverName in $matchedServers) {
        # Collect results for each server
        $result = [PSCustomObject]@{
            ServerName = $serverName
            AppType = $appGroup.AppType
            AdminGroup = $appGroup.AdminGroup
            IsAdmin = $null
            BatchJobGroup = $appGroup.BatchJobGroup
            CanLogonAsBatch = $null
            ServiceGroup = $appGroup.ServiceGroup
            CanLogonAsService = $null
            DebugGroup = $appGroup.DebugGroup
            CanDebugPrograms = $null
        }

        # Check local Administrators group if AdminGroup is not empty
        if (![string]::IsNullOrWhiteSpace($appGroup.AdminGroup)) {
            $adminGroup = Get-WmiObject Win32_GroupUser -ComputerName $serverName |
                          Where-Object { $_.GroupComponent -like "*Administrators" } |
                          ForEach-Object { ([WMI]$_).PartComponent } |
                          Select-String -Pattern $appGroup.AdminGroup -replace '\\', '\\\\'

            $result.IsAdmin = $adminGroup -ne $null
        }

        # Check rights using secedit /export and parse the resulting file
        $seceditExportPath = "C:\temp\$($serverName)_secedit.inf"
        secedit /export /cfg $seceditExportPath /areas USER_RIGHTS /quiet

       <# if (![string]::IsNullOrWhiteSpace($appGroup.BatchJobGroup)) {
            $batchJobRights = Select-String -Path $seceditExportPath -Pattern "SeBatchLogonRight" -SimpleMatch
            $result.CanLogonAsBatch = $batchJobRights.Line -like "*$($appGroup.BatchJobGroup.Replace('\', '\\'))*"
        }

        if (![string]::IsNullOrWhiteSpace($appGroup.ServiceGroup)) {
            $serviceRights = Select-String -Path $seceditExportPath -Pattern "SeServiceLogonRight" -SimpleMatch
            $result.CanLogonAsService = $serviceRights.Line -like "*$($appGroup.ServiceGroup.Replace('\', '\\'))*"
        }

        if (![string]::IsNullOrWhiteSpace($appGroup.DebugGroup)) {
            $debugRights = Select-String -Path $seceditExportPath -Pattern "SeDebugPrivilege" -SimpleMatch
            $result.CanDebugPrograms = $debugRights.Line -like "*$($appGroup.DebugGroup.Replace('\', '\\'))*"
        }
        #>
        # Add result to the results array
        $results += $result
    }
}

# Export results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

# Cleanup temporary files
Remove-Item -Path "C:\temp\*.inf" -Force
