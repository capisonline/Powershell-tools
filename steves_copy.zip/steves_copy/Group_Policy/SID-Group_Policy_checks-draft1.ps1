﻿# Define path to the CSV file 
$csvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\SID-User-Groups.csv"
$serverListPath = "C:\temp\QCAD\PA\NEW_Server_list.txt"
$outputCsvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\output_results33333.csv"


# Import data from CSV and server list
$appGroups = Import-Csv -Path $csvPath
$servers = Get-Content -Path $serverListPath

# Initialize an array to hold the results
$results = @()

# Loop through each app group configuration
foreach ($appGroup in $appGroups) {
    # Find servers that match the app type
    $matchedServers = $servers | Where-Object { $_ -like "*$($appGroup.AppType)*" }

    # Check each matched server
    foreach ($serverName in $matchedServers) {
        # Collect results for each server
        $result = [PSCustomObject]@{
            ServerName = $serverName
            AppType = $appGroup.AppType
            AdminGroupSID = $appGroup.AdminGroupSID
            IsAdmin = $null
            BatchJobGroupSID = $appGroup.BatchJobGroupSID
            CanLogonAsBatch = $null
            ServiceGroupSID = $appGroup.ServiceGroupSID
            CanLogonAsService = $null
            DebugGroupSID = $appGroup.DebugGroupSID
            CanDebugPrograms = $null
        }

        # Check local Administrators group if AdminGroupSID is not empty
        if (![string]::IsNullOrWhiteSpace($appGroup.AdminGroupSID)) {
            $adminGroup = Get-WmiObject Win32_GroupUser -ComputerName $serverName |
                          Where-Object { $_.GroupComponent -like "*Administrators" } |
                          ForEach-Object { ([WMI]$_).PartComponent } |
                          Select-String -Pattern $appGroup.AdminGroupSID

            $result.IsAdmin = $adminGroup -ne $null
        }

        # Check rights using secedit /export and parse the resulting file
        $seceditExportPath = "C:\temp\$($serverName)_secedit.inf"
        secedit /export /cfg $seceditExportPath /areas USER_RIGHTS /quiet

        if (![string]::IsNullOrWhiteSpace($appGroup.BatchJobGroupSID)) {
            $batchJobRights = Select-String -Path $seceditExportPath -Pattern $appGroup.BatchJobGroupSID
            $result.CanLogonAsBatch = $batchJobRights -ne $null
        }

        if (![string]::IsNullOrWhiteSpace($appGroup.ServiceGroupSID)) {
            $serviceRights = Select-String -Path $seceditExportPath -Pattern $appGroup.ServiceGroupSID
            $result.CanLogonAsService = $serviceRights -ne $null
        }

        if (![string]::IsNullOrWhiteSpace($appGroup.DebugGroupSID)) {
            $debugRights = Select-String -Path $seceditExportPath -Pattern $appGroup.DebugGroupSID
            $result.CanDebugPrograms = $debugRights -ne $null
        }

        # Add result to the results array
        $results += $result
    }
}

# Export results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

# Cleanup temporary files
Remove-Item -Path "C:\temp\*.inf" -Force
