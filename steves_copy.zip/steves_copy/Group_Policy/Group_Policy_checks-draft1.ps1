﻿# Define path to the CSV file 
$csvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\User-Groups.csv"
$serverListPath = "C:\temp\QCAD\PA\Server_list.txt"
$outputCsvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\output_results.csv"

# Import data from CSV and server list
$appGroups = Import-Csv -Path $csvPath
$servers = Get-Content -Path $serverListPath

# Initialize an array to hold the results
$results = @()

# Loop through each app group configuration
foreach ($appGroup in $appGroups) {
    # Find servers that match the app type
    $matchedServers = $servers | Where-Object { $_ -like "*$($appGroup.AppType)*" }

    # Check each matched server
    foreach ($serverName in $matchedServers) {
        # Collect results for each server
        $result = New-Object PSObject -Property @{
            ServerName = $serverName
            AppType = $appGroup.AppType
            AdminGroup = $appGroup.AdminGroup
            IsAdmin = $false
            BatchJobGroup = $appGroup.BatchJobGroup
            CanLogonAsBatch = $false
            ServiceGroup = $appGroup.ServiceGroup
            CanLogonAsService = $false
            DebugGroup = $appGroup.DebugGroup
            CanDebugPrograms = $false
        }

        # Check local Administrators group
        $adminGroup = Get-WmiObject Win32_GroupUser -ComputerName $serverName |
                      Where-Object { $_.GroupComponent -like "*Administrators" } |
                      ForEach-Object { ([WMI]$_).PartComponent } |
                      Select-String -Pattern $appGroup.AdminGroup

        if ($adminGroup) {
            $result.IsAdmin = $true
        }

        # Check rights using secedit /export and parse the resulting file
        $seceditExportPath = "C:\temp\$($serverName)_secedit.inf"
        secedit /export /cfg $seceditExportPath /areas USER_RIGHTS /quiet
        $batchJobRights = Select-String -Path $seceditExportPath -Pattern "SeBatchLogonRight"
        $serviceRights = Select-String -Path $seceditExportPath -Pattern "SeServiceLogonRight"
        $debugRights = Select-String -Path $seceditExportPath -Pattern "SeDebugPrivilege"

        if ($batchJobRights.Line -like "*$($appGroup.BatchJobGroup)*") {
            $result.CanLogonAsBatch = $true
        }
        if ($serviceRights.Line -like "*$($appGroup.ServiceGroup)*") {
            $result.CanLogonAsService = $true
        }
        if ($debugRights.Line -like "*$($appGroup.DebugGroup)*") {
            $result.CanDebugPrograms = $true
        }

        # Add result to the results array
        $results += $result
    }
}

# Export results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

# Cleanup temporary files
Remove-Item -Path "C:\temp\*_secedit.inf" -Force
