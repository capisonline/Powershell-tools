﻿
# Specify the path to the text file containing server names 
$serversFile = "C:\temp\scripts\server_list.txt"

# Specify the local path to store the copied files
$localPath = "C:\temp\QCAD\PA\Roles_Features\"

# Check if the file exists
if (Test-Path $serversFile) {
    # Read the list of server names from the file
    $servers = Get-Content $serversFile

    # Loop through each server
    foreach ($server in $servers) {
        # Construct the remote PowerShell session
        $session = New-PSSession -ComputerName $server

        # Copy the file back to the local machine
        Copy-Item -Path "\\$server\C$\temp\$($server)_roles-features777.csv" -Destination $localPath -Force

        # Close the remote PowerShell session
        Remove-PSSession $session
    }
} else {
    Write-Host "Server list file not found: $serversFile"
}
