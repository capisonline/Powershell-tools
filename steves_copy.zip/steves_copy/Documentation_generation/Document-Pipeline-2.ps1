﻿<#
.SYNOPSIS
    Generates structured operational documentation from Azure DevOps pipeline
    YAML definitions.

.DESCRIPTION
    Document-Pipeline.ps1 automates the generation of release and cutover
    documentation from Azure DevOps YAML pipelines. It is intended for
    platform engineering, DevOps, and release management teams that require
    auditable, consistent, and version-controlled documentation for change
    management, CAB approvals, and operational handover.

    The script parses one or more pipeline YAML files and produces the
    following artefacts, individually or in combination:

    ARTEFACT                  SWITCH              USE CASE
    ─────────────────────────────────────────────────────────────────────
    Execution Runbook         (default)            Step-by-step execution
                                                   reference for operators
    Mermaid Flow Diagram      -Diagram             Visual dependency map for
                                                   architecture reviews
    Diagram Only              -DiagramOnly         Standalone visual for wiki
                                                   or presentation embedding
    Standalone .mmd Files     -MermaidDir <path>   Offline/CI rendering via
                                                   mmdc or VS Code extensions
    Draw.io Diagrams          -DrawIO <path>       Editable diagrams for draw.io
                                                   desktop, web, VS Code, Confluence
    Rollback Plan             -Rollback            Backout procedure with
                                                   suggested reversal actions
    Cutover Checklist         -Checklist           Printable sign-off sheet
                                                   for change execution
    Environment Matrix        -EnvironmentMatrix   Cross-pipeline impact
                                                   assessment for CAB review
    Duration Estimate         -EstimateDuration    Maintenance window sizing
                                                   from timeout values
    Validation Report         -Validate            Pre-deployment quality
                                                   gate and lint checks
    Pipeline Comparison       -Diff <a> <b>        Change impact analysis
                                                   between pipeline versions
    HTML Report               -Html <path>         Self-contained shareable
                                                   report with rendered diagrams
    Interactive Mind Map      -MindMap <path>      Collapsible/expandable
                              (auto with -Html)    hierarchical drill-down view
    Script Discovery          -ScanScripts         Stage 1: find and resolve
                                                   external script references
    Inline Script Tracing     -TraceInline          AST-parse inline PowerShell
                                                   blocks directly from YAML
    Script Trace Analysis     -TraceScripts        Stage 2: AST-parsed nested
                                                   diagrams of called scripts
    All Features              -All                 Enables Diagram, Rollback,
                                                   Checklist, EstimateDuration,
                                                   and Validate in one switch

    SCRIPT TRACING (two-stage workflow):
      Stage 1 (-ScanScripts): Scans pipeline YAML for references to external
      scripts (.ps1, .psm1, .bat, .py), resolves them against a -ScriptRoot
      directory, and writes a manifest JSON file categorising each reference
      as RESOLVED, UNRESOLVED, INLINE, DYNAMIC, or UNSUPPORTED. The operator
      reviews the manifest and fills in paths for UNRESOLVED entries.

      Stage 2 (-TraceScripts): Reads the completed manifest, parses each
      RESOLVED PowerShell script using the AST parser, and generates nested
      Mermaid diagrams showing function definitions, call graphs, key command
      invocations, external system calls (REST, SQL, email), and sub-script
      references. Newly discovered dependencies are reported for iterative
      manifest updates.

    INTERACTIVE MIND MAP:
      When -Html is specified, a companion interactive mind map is generated
      automatically alongside the static report (suppress with -NoMindMap).
      The mind map uses Markmap to render the full pipeline hierarchy as a
      collapsible/expandable tree with preset depth controls: Stages Only,
      Stages + Jobs, Stages + Jobs + Steps, Include Scripts. When combined
      with -TraceScripts or -TraceInline, the mind map extends to function
      and command level.

    SUPPORTED PIPELINE STRUCTURES:
      The script handles the three Azure DevOps YAML structures:
        - Full schema   : stages > jobs > steps
        - Jobs-only     : jobs > steps  (normalised to a default stage)
        - Steps-only    : steps         (normalised to a default stage/job)
      Deployment jobs with runOnce, rolling, and canary strategies are fully
      supported. Template references are documented but not expanded; use the
      Azure DevOps "View YAML" export to obtain the resolved definition.

    OUTPUT MODES:
      stdout (default) | -SingleFile <path> | -OutputDir <path> | -Html <path>
      Multiple output modes may be combined in a single invocation.

    DEPENDENCIES:
      The powershell-yaml module is required and will be installed
      automatically from PSGallery on first run if not already present.

    SECURITY CONSIDERATIONS:
      - The script performs read-only operations against local YAML files
        and PowerShell script files. No files are modified.
      - No credentials, tokens, or secrets are accessed or transmitted.
      - The HTML report loads Mermaid JS from a public CDN; the mind map
        loads Markmap + D3 from CDN. For air-gapped environments, host
        these libraries internally and update the script src attributes.
      - Variable values from YAML definitions are included in output.
        Ensure pipeline YAML files do not contain inline secrets before
        generating documentation for distribution.
      - Script tracing (-TraceScripts) parses PowerShell files as data
        using the AST parser. Script code is never evaluated or executed.
        However, traced script bodies are documented in the output and
        may contain sensitive operational details.

.PARAMETER Path
    One or more file paths, directory paths, or wildcard expressions
    identifying Azure DevOps pipeline YAML files (.yml or .yaml).
    Directories are searched non-recursively. Required unless -Diff is used.

.PARAMETER OutputDir
    Directory path for individual output files. One Markdown file is created
    per pipeline, named after the source YAML (e.g., release.yml produces
    release.md). The directory is created if it does not exist. When
    -EnvironmentMatrix is also specified, an additional
    _environment-matrix.md file is generated.

.PARAMETER SingleFile
    File path for combined output. All pipeline documentation is written to
    a single Markdown file. Parent directories are created as needed.

.PARAMETER Diagram
    Appends a Mermaid flowchart diagram to the runbook for each pipeline.
    The diagram renders stage dependencies, job relationships, and step
    sequences using standard Mermaid flowchart notation.

.PARAMETER DiagramOnly
    Generates only the Mermaid diagram, suppressing all other runbook
    content. Intended for embedding diagrams directly into wiki pages or
    presentation materials.

.PARAMETER DrawIO
    Directory path for draw.io (diagrams.net) export files. One .drawio file
    is generated per pipeline, using the mxGraph XML format. The diagram uses
    swimlane layout with stages as top-level containers, jobs as nested
    containers, steps as process nodes with sequential connection arrows, and
    dependency arrows between stages. Colour coding follows the Mermaid diagram
    scheme (blue stages, green deployment jobs, yellow conditional steps, grey
    disabled steps). If trace results are available, script details appear as
    annotation notes attached to their parent step. Files are compatible with
    draw.io desktop, diagrams.net web, the VS Code draw.io extension, and the
    Confluence draw.io plugin.

.PARAMETER MermaidDir
    Directory path for standalone Mermaid diagram files. One .mmd file is
    exported per pipeline, containing raw Mermaid syntax without Markdown
    fencing. These files are compatible with the Mermaid CLI (mmdc),
    the VS Code Mermaid Preview extension, and CI/CD diagram rendering
    pipelines. All labels are sanitised to prevent rendering failures
    from special characters in step names.

.PARAMETER Rollback
    Generates a rollback plan by reversing the pipeline execution order.
    Rollback actions are suggested using keyword analysis of step display
    names (e.g., service start/stop inversion, config restore, migration
    warnings). The output should be reviewed and adapted by the release
    manager before use; automated suggestions are heuristic-based.

.PARAMETER Checklist
    Generates a structured cutover checklist with Markdown checkboxes.
    Includes pre-cutover preparation items, parameter confirmation fields,
    per-step execution checkpoints with stage numbering, and post-cutover
    verification items. Suitable for print or digital sign-off workflows.

.PARAMETER EnvironmentMatrix
    Generates a consolidated cross-pipeline matrix identifying every
    environment and agent pool referenced across all provided YAML files.
    Each entry shows the originating pipeline, stage, job, and resource
    type. This output supports CAB impact assessment and environment
    contention analysis during parallel deployments.

.PARAMETER EstimateDuration
    Calculates estimated pipeline execution duration from timeoutInMinutes
    values defined at the step and job levels. The estimate accounts for
    parallel job execution within stages (longest duration) and sequential
    stage execution (cumulative duration). Output includes a per-component
    breakdown and a total worst-case estimate for maintenance window
    planning.

.PARAMETER Validate
    Executes a set of static analysis checks against each pipeline
    definition. Findings are categorised as:
      ERRORS   - Broken dependency references (will cause pipeline failure)
      WARNINGS - Unintended parallelism, missing environments, non-manual
                 triggers on production-named pipelines
      INFO     - Disabled steps, continueOnError usage, missing timeouts
    This output is suitable for inclusion in pre-deployment quality gates
    and pipeline review processes.

.PARAMETER Html
    File path for a self-contained HTML report. The report uses a dark
    theme optimised for screen review, includes rendered Mermaid diagrams
    (via CDN), styled data tables, interactive checkboxes, and a
    generation timestamp. The file has no local dependencies and can be
    distributed as a standalone artefact. May be combined with any other
    output mode. By default, a companion interactive mind map HTML file
    is generated alongside (with "-mindmap" appended to the filename).
    Use -NoMindMap to suppress the automatic mind map.

.PARAMETER MindMap
    File path for a standalone interactive mind map HTML file. The mind
    map uses Markmap (loaded from CDN) to render the full pipeline
    hierarchy as a collapsible/expandable tree. Each node can be clicked
    to show or hide its children. Toolbar buttons provide preset depth
    levels: Stages Only, Stages + Jobs, Stages + Jobs + Steps, and
    Include Scripts. If -TraceScripts was also run, traced script details
    (functions, commands, external calls) appear as deeper nodes. The
    mind map can be generated independently of -Html.

.PARAMETER NoMindMap
    Suppresses the automatic mind map generation that occurs when -Html
    is specified. Has no effect when -MindMap is explicitly provided.

.PARAMETER Diff
    Accepts exactly two YAML file paths and produces a structural
    comparison report. The diff operates at three levels: stage
    additions/removals/modifications, job-level changes within modified
    stages, and step-level additions/removals within modified jobs.
    Elements are matched by their YAML identifier (stage:/job:/deployment:
    key), not by display name. This mode cannot be combined with -Path.

.PARAMETER All
    Convenience switch that enables -Diagram, -Rollback, -Checklist,
    -EstimateDuration, and -Validate simultaneously. Does not enable
    -EnvironmentMatrix (which requires multiple pipeline files to be
    meaningful) or -Diff (which uses separate invocation syntax).

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\pipeline.yml

    Generates a Markdown runbook for a single pipeline and writes it to
    standard output. Suitable for piping to clipboard or redirection.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\pipelines\ -All -SingleFile .\docs\runbook.md

    Processes all YAML files in the specified directory with all standard
    features enabled and consolidates the output into a single document.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\pipelines\ -All -Html .\docs\report.html -EnvironmentMatrix

    Produces a comprehensive HTML report including runbooks, diagrams,
    rollback plans, checklists, duration estimates, validation findings,
    and a cross-pipeline environment matrix.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\pipelines\ -OutputDir .\docs\ -EnvironmentMatrix

    Generates individual Markdown runbooks per pipeline plus a consolidated
    environment matrix. Suitable for committing to a documentation repository.

.EXAMPLE
    .\Document-Pipeline.ps1 -Diff .\baseline.yml .\proposed.yml -Html .\review\diff.html

    Compares a baseline pipeline against a proposed revision and generates
    an HTML diff report for change advisory review.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\cutover.yml -Checklist -Rollback -SingleFile .\cab\cutover-pack.md

    Generates a combined runbook, cutover checklist, and rollback plan
    suitable for inclusion in a Change Advisory Board submission.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\deploy.yml -DiagramOnly

    Outputs only the Mermaid diagram to standard output for direct
    embedding in an Azure DevOps wiki page or Confluence document.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\release.yml -Validate -EstimateDuration

    Runs validation checks and duration estimation, providing a
    pre-deployment quality assessment and maintenance window sizing.

.PARAMETER ScriptRoot
    Base directory to resolve script file references against when using
    -ScanScripts or -TraceScripts. Script paths found in pipeline YAML
    (e.g., .\scripts\deploy.ps1 or $(Build.SourcesDirectory)\tools\run.ps1)
    are resolved relative to this directory. Required when -ScanScripts is
    specified.

.PARAMETER ScanScripts
    Enables Stage 1 script discovery mode. Scans all parsed pipeline YAML
    files for references to external scripts (PowerShell, Bash, Batch, Python)
    and attempts to resolve them against the -ScriptRoot directory. Outputs a
    manifest JSON file listing all discovered references with resolution status.
    The manifest can be edited manually to fix unresolved entries before running
    Stage 2 (-TraceScripts).

.PARAMETER ManifestPath
    File path for the script discovery manifest JSON file. Defaults to
    script-manifest.json in the current working directory. Used by both
    -ScanScripts (write) and -TraceScripts (read).

.PARAMETER TraceInline
    Traces inline PowerShell script blocks embedded directly in pipeline YAML
    steps using the PowerShell AST parser. Requires no manifest, -ScriptRoot,
    or external files - the script bodies are parsed directly from the YAML.
    Generates the same trace output as -TraceScripts (nested diagrams, function
    inventories, command maps, external call detection). Results feed into the
    mind map and HTML report. Can be combined with -TraceScripts to trace both
    inline blocks and external script files in a single run.

.PARAMETER TraceScripts
    Stage 2: Script tracing. Reads the manifest produced by -ScanScripts,
    parses each RESOLVED PowerShell script (.ps1/.psm1) using the PowerShell
    AST parser, and generates nested Mermaid diagrams showing function
    definitions, call relationships, key command invocations, external system
    calls (REST APIs, SQL, email), and sub-script references. Newly discovered
    references not present in the manifest are flagged for iterative discovery.
    Entries marked with traceDepth "skip" in the manifest are excluded.
    Requires a valid manifest file (default: script-manifest.json in $PWD,
    or specify via -ManifestPath).

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\pipelines\ -MermaidDir .\artefacts\diagrams\

    Exports standalone .mmd diagram files for integration with CI/CD
    documentation pipelines or offline rendering toolchains.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\cutover.yml -TraceInline -Html report.html

    Traces all inline PowerShell blocks directly from the pipeline YAML,
    generates an HTML report with nested diagrams, and an interactive mind
    map with full drill-down to command level. No manifest or -ScriptRoot
    needed - ideal for pipelines with embedded scripts.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\cutover.yml -TraceInline -All -Html full-report.html

    Generates complete documentation with all features plus inline script
    tracing. The mind map includes the full hierarchy from pipeline down
    to individual PowerShell commands.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\cutover.yml -TraceScripts -ManifestPath .\script-manifest.json -Html trace-report.html

    Reads a completed manifest, traces all resolved scripts via PowerShell
    AST analysis, and generates an HTML report with nested script diagrams,
    function inventories, external system call maps, and newly discovered
    sub-references.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\pipelines\ -DrawIO .\diagrams\ -TraceInline

    Exports editable draw.io diagram files with inline script trace annotations
    for each pipeline. Open in draw.io desktop, diagrams.net, or VS Code.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\release.yml -ScanScripts -ScriptRoot C:\Repos\MyProject

    Scans the release pipeline for all script references, resolves them against
    the repository root, and writes a manifest to script-manifest.json.

.EXAMPLE
    .\Document-Pipeline.ps1 -Path .\pipelines\ -ScanScripts -ScriptRoot .\src -ManifestPath .\docs\manifest.json -All

    Scans all pipelines for script references while also generating full
    documentation. The manifest is written to a custom path.

.NOTES
    Script Name : Document-Pipeline.ps1
    Version     : 1.3.0
    Requires    : PowerShell 5.1 or later (Windows PowerShell or PowerShell 7+)
    Module Dep  : powershell-yaml (auto-installed from PSGallery if absent)
    Licence     : Internal use - refer to your organisation's software policy

    CHANGE HISTORY:
    ───────────────────────────────────────────────────────────────────────
    1.3.0   Draw.io export (-DrawIO), inline script tracing (-TraceInline),
            fixed inline script capture from PowerShell@2 task inputs.
            Split Mermaid diagrams into overview + per-stage to stay within
            Mermaid text size limits. Mind map uses direct JSON tree data
            with markmap-view (removed markmap-lib dependency). Full PS 5.1
            compatibility (format string escaping, UTF-8 BOM).
    1.2.0   Interactive mind map (-MindMap / auto with -Html). Markmap-based
            collapsible/expandable tree with depth controls. Integrates
            with TraceScripts for full pipeline-to-function drill-down.
    1.1.0   Script discovery and tracing (-ScanScripts / -TraceScripts).
            Two-stage workflow: manifest-based discovery with iterative
            resolution, then PowerShell AST parsing for nested diagrams.
    1.0.0   Initial release. Core runbook, Mermaid diagrams, rollback
            plans, checklists, environment matrix, duration estimates,
            validation, pipeline diff, HTML reports, standalone .mmd
            export with label sanitisation.

.LINK
    https://url.au.m.mimecastprotect.com/s/CzUECxngZBu0m66qhvh0Ty8WUL?domain=learn.microsoft.com

.LINK
    https://url.au.m.mimecastprotect.com/s/YtZ2Cyoj1DHW6vvmcQiPTxvcYZ?domain=mermaid.js.org

.LINK
    https://url.au.m.mimecastprotect.com/s/NQRyCzvk2EsB8llNiKsgT9_kDK?domain=markmap.js.org

.LINK
    https://url.au.m.mimecastprotect.com/s/9uX1CANpJ2uoryyJhQtBTGjHEm?domain=drawio.com
#>

[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string[]]$Path,

    [string]$OutputDir,
    [string]$SingleFile,

    [switch]$Diagram,
    [switch]$DiagramOnly,
    [switch]$Rollback,
    [switch]$Checklist,
    [switch]$EnvironmentMatrix,
    [switch]$EstimateDuration,
    [switch]$Validate,
    [string]$Html,
    [string]$MindMap,
    [switch]$NoMindMap,
    [string]$MermaidDir,
    [string]$DrawIO,
    [string[]]$Diff,
    [switch]$All,

    # Feature 9: Script Discovery and Tracing
    [string]$ScriptRoot,
    [switch]$ScanScripts,
    [string]$ManifestPath = (Join-Path $PWD 'script-manifest.json'),
    [switch]$TraceScripts,
    [switch]$TraceInline
)

$ErrorActionPreference = 'Stop'

if ($All) {
    $Diagram = $true
    $Rollback = $true
    $Checklist = $true
    $EstimateDuration = $true
    $Validate = $true
}

if (-not $Path -and -not $Diff) {
    Write-Error 'You must provide -Path or -Diff.'
    exit 1
}

# ── Install powershell-yaml if missing ──
if (-not (Get-Module -ListAvailable -Name powershell-yaml)) {
    Write-Host "Installing powershell-yaml module..." -ForegroundColor Yellow
    Install-Module -Name powershell-yaml -Scope CurrentUser -Force -AllowClobber
}
Import-Module powershell-yaml

# ══════════════════════════════════════════════════════════════════════════════
# MAINTENANCE NOTES FOR DEVELOPERS
# ══════════════════════════════════════════════════════════════════════════════
# 1. POWERSHELL 5.1 STRING COMPATIBILITY: All Markdown output strings that
#    contain ** (bold), | (table pipes), or { } (braces) with variable
#    interpolation MUST use the -f format operator with single-quoted format
#    strings, OR string concatenation with +. Double-quoted strings with these
#    characters will cause parse errors in Windows PowerShell 5.1. Use
#    Esc-Format to escape { } in content that passes through -f.
#
# 2. HTML TEMPLATES: ConvertTo-HtmlReport uses a double-quoted here-string
#    (@" ... "@) for the template. ConvertTo-MindMapHtml uses a single-quoted
#    here-string (@' ... '@) with placeholder replacement. Never put JavaScript
#    containing $ or { } in a double-quoted here-string.
#
# 3. MERMAID DIAGRAM SIZE: Mermaid has a default maxTextSize of 50,000
#    characters. ConvertTo-PipelineDiagram splits output into an overview
#    diagram (stages only) plus per-stage detail diagrams to stay within
#    this limit. If a single stage exceeds the limit, further splitting
#    at the job level would be needed.
#
# 4. DRAW.IO XML: Export-DrawIO uses helper functions (Add-MxCell, Add-MxGeo)
#    to build XML without quote escaping issues. All user-provided text must
#    pass through the Esc() function ([SecurityElement]::Escape) before
#    embedding in XML attributes. Output is written without BOM.
#
# 5. MIND MAP: The mind map bypasses markmap-lib entirely. Tree data is built
#    as PowerShell hashtables, serialised to JSON via ConvertTo-Json -Depth 20,
#    and passed directly to markmap.Markmap.create(). Only markmap-view and d3
#    are loaded from CDN. The render target must be an <svg> element (not div).
#
# 6. TESTING: Run Test-DocumentPipeline.ps1 after any changes. All 20 tests
#    must pass. The test suite uses yaml.txt as the test fixture.
# ══════════════════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

# This function sanitises a string into a valid Mermaid node ID by replacing
# all non-alphanumeric characters (except underscore) with underscores.
# Used by ConvertTo-PipelineDiagram to generate safe subgraph/node identifiers.
function Safe-Id { param([string]$s) ($s -replace '[^a-zA-Z0-9_]', '_') }

# This function sanitises a string for use as a Mermaid node label.
# Strips characters that can break Mermaid rendering (quotes, brackets, braces,
# This function escapes curly braces in strings before use with the -f format
# operator. PowerShell script content often contains { } which conflicts with
# format placeholders. Replaces { with {{ and } with }}.
function Esc-Format { param([string]$s) $s -replace '\{', '{{' -replace '\}', '}}' }

# This function sanitises a string for use as a Mermaid node or arrow label by
# removing characters that cause rendering failures (quotes, brackets, braces,
# semicolons, backticks, hash symbols, ampersands) while preserving readability.
# Retained characters: letters, numbers, spaces, hyphens, underscores, dots,
# forward slashes, parentheses, colons, equals signs, commas.
# Adapted from auto_Diagram_Python.py's sanitize_label pattern.
function Sanitize-Label { param([string]$s) ($s -replace '[^\w\-/(). :=,]', '' -replace '\s+', ' ').Trim() }

# This function determines the display name for a pipeline step.
# It checks for an explicit displayName first, then falls back to deriving a
# name from the step type (task, template, checkout, script, bash, powershell, pwsh).
# For script-type steps without a displayName, it uses the first line of the script
# body (truncated to 120 chars) as the display name.
function Get-StepDisplayName {
    param([hashtable]$Step)
    if ($Step.displayName) { return $Step.displayName }
    foreach ($key in @('script', 'bash', 'powershell', 'pwsh', 'checkout', 'task', 'template')) {
        if ($Step.ContainsKey($key)) {
            $val = $Step[$key]
            switch ($key) {
                'task'     { return "Task: $val" }
                'template' { return "Template: $val" }
                'checkout' { return "Checkout: $val" }
                default {
                    if ($val -is [string]) {
                        $firstLine = ($val.Trim() -split "`n")[0]
                        if ($firstLine.Length -gt 120) { $firstLine = $firstLine.Substring(0, 117) + '...' }
                        return "``$firstLine``"
                    }
                    return $key
                }
            }
        }
    }
    return 'Unknown step'
}

# This function translates Azure DevOps condition expressions into human-readable
# descriptions. Common conditions like succeeded(), failed(), always(), and canceled()
# are mapped to plain English. Custom conditions are returned as inline code.
function Format-Condition {
    param([string]$Condition)
    if (-not $Condition) { return '' }
    $Condition = $Condition.Trim()
    $map = @{
        'succeeded()' = 'previous stage/job succeeded'
        'failed()'    = 'previous stage/job failed'
        'always()'    = 'always runs'
        'canceled()'  = 'pipeline was canceled'
    }
    if ($map.ContainsKey($Condition)) { return $map[$Condition] }
    return "``$Condition``"
}

# This function extracts pipeline-level parameters from the YAML and returns them
# as an array of PSCustomObjects with Name, Type, Default, DisplayName, and Values
# properties. Parameters define the runtime inputs shown when manually triggering
# a pipeline in Azure DevOps.
function Get-Parameters {
    param([hashtable]$Pipeline)
    $params = $Pipeline['parameters']
    if (-not $params) { return @() }
    $result = @()
    foreach ($p in $params) {
        if ($p -is [hashtable]) {
            $result += [PSCustomObject]@{
                Name        = $p['name']
                Type        = if ($p['type']) { $p['type'] } else { 'string' }
                Default     = if ($null -ne $p['default']) { $p['default'] } else { '' }
                DisplayName = if ($p['displayName']) { $p['displayName'] } else { $p['name'] }
                Values      = if ($p['values']) { $p['values'] } else { @() }
            }
        }
    }
    return $result
}

# This function extracts variables from a pipeline or stage definition.
# Handles three YAML formats: key-value hashtable, list of name/value pairs,
# variable group references, and template variable includes.
# Returns an array of PSCustomObjects with Name, Value, and Group properties.
function Get-Variables {
    param([hashtable]$Source)
    $variables = $Source['variables']
    if (-not $variables) { return @() }
    if ($variables -is [hashtable]) {
        $result = @()
        foreach ($key in $variables.Keys) {
            $result += [PSCustomObject]@{ Name = $key; Value = $variables[$key]; Group = '' }
        }
        return $result
    }
    $result = @()
    foreach ($v in $variables) {
        if ($v -is [hashtable]) {
            if ($v.ContainsKey('name')) {
                $result += [PSCustomObject]@{ Name = $v['name']; Value = $v['value']; Group = '' }
            }
            elseif ($v.ContainsKey('group')) {
                $result += [PSCustomObject]@{ Name = ''; Value = ''; Group = $v['group'] }
            }
            elseif ($v.ContainsKey('template')) {
                $result += [PSCustomObject]@{ Name = "(from template: $($v['template']))"; Value = ''; Group = '' }
            }
        }
    }
    return $result
}

# This function parses a list of step definitions from a job and returns them
# as an array of PSCustomObjects. Each object captures the step's display name,
# condition, enabled state, timeout, continueOnError flag, script body/type
# (for script/bash/powershell/pwsh steps), and task inputs.
# This normalised structure is consumed by all output generators.
function Get-Steps {
    param([array]$StepsList)
    if (-not $StepsList) { return @() }
    $result = @()
    foreach ($step in $StepsList) {
        if ($step -isnot [hashtable]) { continue }
        $info = [PSCustomObject]@{
            Name            = Get-StepDisplayName $step
            Condition       = $step['condition']
            Enabled         = if ($null -ne $step['enabled']) { $step['enabled'] } else { $true }
            Timeout         = $step['timeoutInMinutes']
            ContinueOnError = if ($step['continueOnError']) { $true } else { $false }
            ScriptBody      = $null
            ScriptType      = $null
            Inputs          = @{}
        }
        foreach ($key in @('script', 'bash', 'powershell', 'pwsh')) {
            if ($step.ContainsKey($key) -and $step[$key] -is [string]) {
                $info.ScriptBody = $step[$key].Trim()
                $info.ScriptType = $key
                break
            }
        }
        if ($step.ContainsKey('task') -and $step.ContainsKey('inputs')) {
            $info.Inputs = $step['inputs']
            # Capture inline scripts from PowerShell@2 / Bash@3 / CmdLine@2 task inputs.
            # Azure DevOps tasks store inline code in inputs.script with targetType "inline".
            if (-not $info.ScriptBody -and $step['inputs'] -is [hashtable]) {
                $inputs = $step['inputs']
                $taskName = "$($step['task'])"
                if ($inputs.ContainsKey('script') -and $inputs['script'] -is [string]) {
                    $info.ScriptBody = $inputs['script'].Trim()
                    if ($taskName -match 'PowerShell|pwsh') { $info.ScriptType = 'powershell' }
                    elseif ($taskName -match 'Bash') { $info.ScriptType = 'bash' }
                    else { $info.ScriptType = 'shell' }
                }
            }
        }
        $result += $info
    }
    return $result
}

# This function parses a list of job definitions from a stage. Handles both
# regular jobs (key: 'job') and deployment jobs (key: 'deployment').
# For deployment jobs, it extracts the environment name and parses steps from
# within the deployment strategy block (runOnce, rolling, or canary).
# Normalises dependsOn to always be an array. Returns PSCustomObjects with
# Name, Id, Type, DependsOn, Condition, Environment, Pool, Steps, Timeout,
# and ContinueOnError properties.
function Get-Jobs {
    param([array]$JobsList)
    if (-not $JobsList) { return @() }
    $result = @()
    foreach ($job in $JobsList) {
        if ($job -isnot [hashtable]) { continue }
        $isDeployment = $job.ContainsKey('deployment')
        $jobName = if ($isDeployment) { $job['deployment'] } elseif ($job['job']) { $job['job'] } else { 'Unnamed Job' }
        $dependsOn = $job['dependsOn']
        if ($dependsOn -is [string]) { $dependsOn = @($dependsOn) }
        if (-not $dependsOn) { $dependsOn = @() }
        $info = [PSCustomObject]@{
            Name            = if ($job['displayName']) { $job['displayName'] } else { $jobName }
            Id              = $jobName
            Type            = if ($isDeployment) { 'deployment' } else { 'job' }
            DependsOn       = $dependsOn
            Condition       = $job['condition']
            Environment     = ''
            Pool            = $job['pool']
            Steps           = @()
            Timeout         = $job['timeoutInMinutes']
            ContinueOnError = if ($job['continueOnError']) { $true } else { $false }
        }
        if ($isDeployment) {
            $env = $job['environment']
            if ($env -is [hashtable]) { $info.Environment = $env['name'] }
            elseif ($env) { $info.Environment = [string]$env }
            $strategy = $job['strategy']
            if ($strategy) {
                foreach ($stratType in @('runOnce', 'rolling', 'canary')) {
                    if ($strategy.ContainsKey($stratType)) {
                        $deployBlock = $strategy[$stratType]['deploy']
                        if ($deployBlock -and $deployBlock['steps']) {
                            $info.Steps = Get-Steps $deployBlock['steps']
                        }
                        break
                    }
                }
            }
        }
        else {
            $info.Steps = Get-Steps $job['steps']
        }
        $result += $info
    }
    return $result
}

# This function extracts stages from the pipeline YAML. Handles all three Azure
# DevOps pipeline structures:
#   1. Full schema: stages > jobs > steps - parses each stage with its jobs
#   2. Jobs-only: jobs > steps - wraps in a synthetic "Default Stage"
#   3. Steps-only: steps - wraps in a synthetic "Default Stage" and "Default Job"
# Returns an array of PSCustomObjects with Name, Id, DependsOn, Condition,
# Jobs, and Variables properties. This is the main entry point for understanding
# pipeline structure - all output generators call this function.
function Get-Stages {
    param([hashtable]$Pipeline)
    $stages = $Pipeline['stages']
    if (-not $stages) {
        $jobs = $Pipeline['jobs']
        if ($jobs) {
            return @([PSCustomObject]@{
                Name = 'Default Stage'; Id = 'default'; DependsOn = @(); Condition = ''
                Jobs = Get-Jobs $jobs; Variables = @()
            })
        }
        $steps = $Pipeline['steps']
        if ($steps) {
            return @([PSCustomObject]@{
                Name = 'Default Stage'; Id = 'default'; DependsOn = @(); Condition = ''
                Jobs = @([PSCustomObject]@{
                    Name = 'Default Job'; Id = 'default'; Type = 'job'; DependsOn = @()
                    Condition = ''; Environment = ''; Pool = $Pipeline['pool']
                    Steps = Get-Steps $steps; Timeout = $null; ContinueOnError = $false
                })
                Variables = @()
            })
        }
        return @()
    }
    $result = @()
    foreach ($stage in $stages) {
        if ($stage -isnot [hashtable]) { continue }
        $stageName = if ($stage['stage']) { $stage['stage'] } else { 'Unnamed Stage' }
        $dependsOn = $stage['dependsOn']
        if ($dependsOn -is [string]) { $dependsOn = @($dependsOn) }
        if (-not $dependsOn) { $dependsOn = @() }
        $result += [PSCustomObject]@{
            Name      = if ($stage['displayName']) { $stage['displayName'] } else { $stageName }
            Id        = $stageName
            DependsOn = $dependsOn
            Condition = $stage['condition']
            Jobs      = Get-Jobs $stage['jobs']
            Variables = if ($stage.ContainsKey('variables')) { Get-Variables $stage } else { @() }
        }
    }
    return $result
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE: RUNBOOK DOCUMENTATION (Core Output)
# ══════════════════════════════════════════════════════════════════════════════

# This function generates the main Markdown runbook documentation for a pipeline.
# It produces the following sections:
#   1. Pipeline header with name, trigger type, PR trigger, default pool, and source file
#   2. Parameters table (if any) with type, default, and allowed values
#   3. Variables list including variable groups and template references
#   4. Execution Order - numbered stages, each containing numbered jobs, each
#      containing a step table with conditions, enabled state, timeouts, and notes
#   5. Collapsible script details for any steps that contain inline scripts
# This is the default output and is always generated unless -DiagramOnly is used.
function ConvertTo-PipelineMarkdown {
    param([hashtable]$Pipeline, [string]$SourceFile)

    $md = [System.Text.StringBuilder]::new()
    $name = if ($Pipeline['name']) { $Pipeline['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($SourceFile) }

    [void]$md.AppendLine(('# Pipeline: {0}' -f $name))
    [void]$md.AppendLine()

    $trigger = $Pipeline['trigger']
    if ($null -ne $trigger) {
        if ($trigger -eq 'none' -or $trigger -eq $false) {
            [void]$md.AppendLine('**Trigger:** Manual only')
        } elseif ($trigger -is [array]) {
            [void]$md.AppendLine(('**Trigger:** Branches - {0}' -f ($trigger -join ', ')))
        } elseif ($trigger -is [hashtable]) {
            $branches = $trigger['branches']
            if ($branches -and $branches['include']) {
                [void]$md.AppendLine(('**Trigger:** Branches - {0}' -f ($branches['include'] -join ', ')))
            }
        } else {
            [void]$md.AppendLine(('**Trigger:** ``{0}``' -f $trigger))
        }
    } else {
        [void]$md.AppendLine('**Trigger:** Not specified (defaults to CI on all branches)')
    }

    $pr = $Pipeline['pr']
    if ($null -ne $pr) {
        if ($pr -eq 'none' -or $pr -eq $false) { [void]$md.AppendLine('**PR Trigger:** Disabled') }
        elseif ($pr -is [array]) { [void]$md.AppendLine(('**PR Trigger:** Branches - {0}' -f ($pr -join ', '))) }
    }

    $pool = $Pipeline['pool']
    if ($pool) {
        if ($pool -is [string]) { [void]$md.AppendLine(('**Default Pool:** {0}' -f $pool)) }
        elseif ($pool -is [hashtable]) {
            $vm = if ($pool['vmImage']) { $pool['vmImage'] } elseif ($pool['name']) { $pool['name'] } else { '' }
            if ($vm) { [void]$md.AppendLine(('**Default Pool:** {0}' -f $vm)) }
        }
    }

    [void]$md.AppendLine(('**Source:** ``{0}``' -f $SourceFile))
    [void]$md.AppendLine()

    $params = Get-Parameters $Pipeline
    if ($params.Count -gt 0) {
        [void]$md.AppendLine('## Parameters')
        [void]$md.AppendLine()
        [void]$md.AppendLine('| Parameter | Type | Default | Values |')
        [void]$md.AppendLine('|-----------|------|---------|--------|')
        foreach ($p in $params) {
            $values = if ($p.Values.Count -gt 0) { ($p.Values -join ', ') } else { '-' }
            $default = if ("$($p.Default)" -ne '') { $p.Default } else { '-' }
            [void]$md.AppendLine(('| **{0}** | {1} | {2} | {3} |' -f $p.DisplayName, $p.Type, $default, $values))
        }
        [void]$md.AppendLine()
    }

    $variables = Get-Variables $Pipeline
    if ($variables.Count -gt 0) {
        [void]$md.AppendLine('## Variables')
        [void]$md.AppendLine()
        foreach ($v in $variables) {
            if ($v.Group) { [void]$md.AppendLine(('- **Variable Group:** ``{0}``' -f $v.Group)) }
            elseif ($v.Name) {
                $val = "$($v.Value)"
                if ($val.Length -gt 80) { $val = $val.Substring(0, 77) + '...' }
                [void]$md.AppendLine(('- ``{0}`` = ``{1}``' -f $($v.Name), $val))
            }
        }
        [void]$md.AppendLine()
    }

    $stages = Get-Stages $Pipeline
    if ($stages.Count -eq 0) {
        [void]$md.AppendLine('*No stages, jobs, or steps found in this pipeline.*')
        return $md.ToString()
    }

    [void]$md.AppendLine('## Execution Order')
    [void]$md.AppendLine()

    $stageNum = 0
    foreach ($stage in $stages) {
        $stageNum++
        $header = "### Stage ${stageNum}: $($stage.Name)"
        if ($stage.Id -ne $stage.Name -and $stage.Id -ne 'default') { $header += " (``$($stage.Id)``)" }
        [void]$md.AppendLine($header)
        [void]$md.AppendLine()

        if ($stage.DependsOn.Count -gt 0) { [void]$md.AppendLine(('**Depends on:** {0}' -f ($stage.DependsOn -join ', '))) }
        if ($stage.Condition) { [void]$md.AppendLine(('**Condition:** {0}' -f (Format-Condition $stage.Condition))) }
        if ($stage.DependsOn.Count -gt 0 -or $stage.Condition) { [void]$md.AppendLine() }

        $jobNum = 0
        foreach ($job in $stage.Jobs) {
            $jobNum++
            $jobHeader = "#### Job ${stageNum}.${jobNum}: $($job.Name)"
            if ($job.Type -eq 'deployment') { $jobHeader += ' *(deployment)*' }
            [void]$md.AppendLine($jobHeader)
            [void]$md.AppendLine()

            if ($job.Environment) { [void]$md.AppendLine(('**Environment:** ``{0}``' -f $job.Environment)) }
            if ($job.DependsOn.Count -gt 0) { [void]$md.AppendLine(('**Depends on:** {0}' -f ($job.DependsOn -join ', '))) }
            if ($job.Condition) { [void]$md.AppendLine(('**Condition:** {0}' -f (Format-Condition $job.Condition))) }
            if ($job.Timeout) { [void]$md.AppendLine(('**Timeout:** {0} minutes' -f $job.Timeout)) }
            if ($job.Pool -and $job.Pool -is [hashtable]) {
                $vm = if ($job.Pool['vmImage']) { $job.Pool['vmImage'] } elseif ($job.Pool['name']) { $job.Pool['name'] } else { '' }
                if ($vm) { [void]$md.AppendLine(('**Pool:** {0}' -f $vm)) }
            }
            if ($job.Environment -or $job.DependsOn.Count -gt 0 -or $job.Condition) { [void]$md.AppendLine() }

            if ($job.Steps.Count -gt 0) {
                [void]$md.AppendLine('| # | Step | Notes |')
                [void]$md.AppendLine('|---|------|-------|')
                $stepNum = 0
                foreach ($step in $job.Steps) {
                    $stepNum++
                    $notes = @()
                    if ($step.Condition) { $notes += "Condition: $(Format-Condition $step.Condition)" }
                    if (-not $step.Enabled) { $notes += '**DISABLED**' }
                    if ($step.ContinueOnError) { $notes += 'continues on error' }
                    if ($step.Timeout) { $notes += "timeout: $($step.Timeout)m" }
                    $notesStr = if ($notes.Count -gt 0) { $notes -join '; ' } else { '-' }
                    $stepName = $step.Name -replace '\|', '\|'
                    [void]$md.AppendLine(('| {0} | {1} | {2} |' -f $stepNum, $stepName, $notesStr))
                }
                [void]$md.AppendLine()

                $hasScripts = $job.Steps | Where-Object { $_.ScriptBody }
                if ($hasScripts) {
                    [void]$md.AppendLine('<details>')
                    [void]$md.AppendLine('<summary>Script Details</summary>')
                    [void]$md.AppendLine()
                    $stepNum = 0
                    foreach ($step in $job.Steps) {
                        $stepNum++
                        if ($step.ScriptBody) {
                            $lang = switch ($step.ScriptType) { 'powershell' { 'powershell' }; 'pwsh' { 'powershell' }; default { 'shell' } }
                            [void]$md.AppendLine(('**Step {0}: {1}**' -f $stepNum, $step.Name))
                            [void]$md.AppendLine()
                            [void]$md.AppendLine(('``````{0}' -f $lang))
                            [void]$md.AppendLine($step.ScriptBody)
                            [void]$md.AppendLine('``````')
                            [void]$md.AppendLine()
                        }
                    }
                    [void]$md.AppendLine('</details>')
                    [void]$md.AppendLine()
                }
            } else {
                [void]$md.AppendLine('*No steps defined.*')
                [void]$md.AppendLine()
            }
        }
    }

    [void]$md.AppendLine('---')
    [void]$md.AppendLine(('*Generated from ``{0}``*' -f $SourceFile))
    [void]$md.AppendLine()
    return $md.ToString()
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 1: MERMAID DIAGRAM (-Diagram / -DiagramOnly)
# ══════════════════════════════════════════════════════════════════════════════

# This function generates a Mermaid flowchart diagram representing the pipeline
# execution flow. The diagram structure is:
#   - Each stage becomes a blue subgraph labelled "Stage N : Name"
#   - Each job becomes a nested subgraph (or node if no steps) inside its stage
#   - Deployment jobs are styled green; regular jobs use default styling
#   - Steps are rendered as numbered nodes inside their job subgraph:
#       * Regular steps: rectangle nodes
#       * Conditional steps: yellow diamond nodes
#       * Disabled steps: grey parallelogram nodes with "DISABLED" label
#   - Steps within a job are connected sequentially with --> arrows
#   - Stages are connected with thick ==> arrows based on dependsOn or implicit order
#   - Job-level dependencies within a stage use --> arrows with condition labels
# The output is a fenced ```mermaid code block that renders in Azure DevOps wikis,
# GitHub, VS Code, and the HTML report.
function ConvertTo-PipelineDiagram {
    param([hashtable]$Pipeline, [string]$SourceFile)

    $stages = Get-Stages $Pipeline
    if ($stages.Count -eq 0) { return '' }

    $name = if ($Pipeline['name']) { $Pipeline['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($SourceFile) }
    $mm = [System.Text.StringBuilder]::new()
    [void]$mm.AppendLine(('## Diagram: {0}' -f $name))
    [void]$mm.AppendLine()

    # ── Overview diagram: stages and their dependencies only ──
    [void]$mm.AppendLine('### Pipeline Overview')
    [void]$mm.AppendLine()
    [void]$mm.AppendLine('```mermaid')
    [void]$mm.AppendLine('flowchart TD')

    $prevStageId = $null
    $stageNum = 0
    foreach ($stage in $stages) {
        $stageNum++
        $sId = "S_$(Safe-Id $stage.Id)"
        $sLabel = Sanitize-Label $stage.Name
        $jobCount = $stage.Jobs.Count
        $stepCount = ($stage.Jobs | ForEach-Object { $_.Steps.Count } | Measure-Object -Sum).Sum
        [void]$mm.AppendLine(('    {0}["{1}. {2}<br/>{3} job(s), {4} step(s)"]' -f $sId, $stageNum, $sLabel, $jobCount, $stepCount))
        [void]$mm.AppendLine(('    style {0} fill:#1565c0,stroke:#90caf9,color:#fff' -f $sId))

        if ($stage.DependsOn.Count -gt 0) {
            foreach ($dep in $stage.DependsOn) {
                $depSId = "S_$(Safe-Id $dep)"
                [void]$mm.AppendLine(('    {0} ==> {1}' -f $depSId, $sId))
            }
        } elseif ($prevStageId) {
            [void]$mm.AppendLine(('    {0} ==> {1}' -f $prevStageId, $sId))
        }
        $prevStageId = $sId
    }
    [void]$mm.AppendLine('```')
    [void]$mm.AppendLine()

    # ── Per-stage detail diagrams ──
    $stageNum = 0
    foreach ($stage in $stages) {
        $stageNum++
        $sLabel = Sanitize-Label $stage.Name

        [void]$mm.AppendLine(('### Stage {0}: {1}' -f $stageNum, $sLabel))
        [void]$mm.AppendLine()
        [void]$mm.AppendLine('```mermaid')
        [void]$mm.AppendLine('flowchart TD')

        $prevJobId = $null
        $jobNum = 0
        foreach ($job in $stage.Jobs) {
            $jobNum++
            $jId = "J_$(Safe-Id $job.Id)"
            $jLabel = Sanitize-Label $job.Name

            if ($job.Steps.Count -gt 0) {
                [void]$mm.AppendLine(('    subgraph {0} ["{1}"]' -f $jId, $jLabel))
                [void]$mm.AppendLine('        direction TB')
                $prevStepId = $null
                $stepNum = 0
                foreach ($step in $job.Steps) {
                    $stepNum++
                    $stepId = "${jId}_s${stepNum}"
                    $stepLabel = Sanitize-Label $step.Name
                    if ($stepLabel.Length -gt 60) { $stepLabel = $stepLabel.Substring(0, 57) + '...' }

                    if (-not $step.Enabled) {
                        [void]$mm.AppendLine(('        {0}[/"{1}. {2} DISABLED"/]' -f $stepId, $stepNum, $stepLabel))
                        [void]$mm.AppendLine(('        style {0} fill:#424242,stroke:#757575,color:#9e9e9e' -f $stepId))
                    } elseif ($step.Condition) {
                        [void]$mm.AppendLine(('        {0}{{"{1}. {2}"}}' -f $stepId, $stepNum, $stepLabel))
                        [void]$mm.AppendLine(('        style {0} fill:#f57f17,stroke:#ffd54f,color:#fff' -f $stepId))
                    } else {
                        [void]$mm.AppendLine(('        {0}["{1}. {2}"]' -f $stepId, $stepNum, $stepLabel))
                    }
                    if ($prevStepId) { [void]$mm.AppendLine("        $prevStepId --> $stepId") }
                    $prevStepId = $stepId
                }
                [void]$mm.AppendLine('    end')
                if ($job.Type -eq 'deployment') { [void]$mm.AppendLine(('    style {0} fill:#2e7d32,stroke:#81c784,color:#fff' -f $jId)) }
            } else {
                $jobShape = if ($job.Type -eq 'deployment') { '(["' + $jLabel + '"])' } else { '["' + $jLabel + '"]' }
                [void]$mm.AppendLine(('    {0}{1}' -f $jId, $jobShape))
                if ($job.Type -eq 'deployment') { [void]$mm.AppendLine(('    style {0} fill:#2e7d32,stroke:#81c784,color:#fff' -f $jId)) }
            }

            if ($job.DependsOn.Count -gt 0) {
                foreach ($dep in $job.DependsOn) {
                    $depId = "J_$(Safe-Id $dep)"
                    [void]$mm.AppendLine(('    {0} --> {1}' -f $depId, $jId))
                }
            }
            $prevJobId = $jId
        }

        [void]$mm.AppendLine('```')
        [void]$mm.AppendLine()
    }

    return $mm.ToString()
}

# This function extracts the raw Mermaid diagram content (without markdown fencing)
# for writing standalone .mmd files. Calls ConvertTo-PipelineDiagram and strips
# the markdown header, ```mermaid fences, and trailing whitespace.
# Borrowed from auto_Diagram_Python.py's pattern of writing standalone .mmd files
# that can be rendered by the Mermaid CLI (mmdc), VS Code Mermaid extension, or
# any other Mermaid-compatible tool.
function Export-PipelineMermaid {
    param([hashtable]$Pipeline, [string]$SourceFile, [string]$OutputDir)

    $mdContent = ConvertTo-PipelineDiagram -Pipeline $Pipeline -SourceFile $SourceFile
    if (-not $mdContent) { return }

    # Strip the markdown wrapper - extract just the Mermaid content between fences
    $mermaidContent = $mdContent -replace '(?s)^.*?```mermaid\r?\n', '' -replace '(?s)```\s*$', ''

    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($SourceFile)
    $outPath = Join-Path $OutputDir "${baseName}.mmd"

    if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }
    Set-Content -Path $outPath -Value $mermaidContent.TrimEnd() -Encoding UTF8
    Write-Host "  -> $outPath" -ForegroundColor Green
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 2: ROLLBACK / BACKOUT PLAN (-Rollback)
# ══════════════════════════════════════════════════════════════════════════════

# This function generates a rollback/backout plan by reversing the pipeline
# execution order. It works in three layers:
#   1. Reverses the stage order (last stage is undone first)
#   2. Within each stage, reverses the job order
#   3. Within each job, reverses the step order
# For each enabled step, it uses keyword matching against the step's display
# name to suggest an appropriate rollback action. The keyword detection covers:
#   - stop/start service toggles (reversed)
#   - deploy/copy/config (restore from backup)
#   - backup steps (no rollback needed)
#   - enable/disable toggles
#   - install/update/upgrade (downgrade)
#   - delete/remove (restore from backup)
#   - create/add (remove)
#   - migrate/migration (flagged CRITICAL)
#   - checkout/clone (no rollback needed)
#   - test/validate (re-run against previous state)
#   - notify/email/slack/teams (send rollback notification)
# Disabled steps are skipped. Unrecognised steps default to "Manual review required".
function ConvertTo-RollbackPlan {
    param([hashtable]$Pipeline, [string]$SourceFile)

    $stages = Get-Stages $Pipeline
    if ($stages.Count -eq 0) { return '' }

    $name = if ($Pipeline['name']) { $Pipeline['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($SourceFile) }
    $md = [System.Text.StringBuilder]::new()

    [void]$md.AppendLine(('## Rollback Plan: {0}' -f $name))
    [void]$md.AppendLine()
    [void]$md.AppendLine('> **Purpose:** Reverse the cutover steps in the correct order to restore the previous state.')
    [void]$md.AppendLine('> Review each step - not all steps are reversible (e.g., data migrations).')
    [void]$md.AppendLine()

    $reversedStages = @($stages)
    [array]::Reverse($reversedStages)

    $rollbackNum = 0
    foreach ($stage in $reversedStages) {
        $rollbackNum++
        [void]$md.AppendLine(('### Rollback Step {1}: Undo `{0}`' -f $($stage.Name), ${rollbackNum}))
        [void]$md.AppendLine()

        $reversedJobs = @($stage.Jobs)
        [array]::Reverse($reversedJobs)

        foreach ($job in $reversedJobs) {
            if ($job.Environment) { [void]$md.AppendLine(('**Environment:** ``{0}``' -f $job.Environment)) }

            $reversedSteps = @($job.Steps)
            [array]::Reverse($reversedSteps)

            if ($reversedSteps.Count -gt 0) {
                [void]$md.AppendLine()
                [void]$md.AppendLine('| # | Original Step | Rollback Action |')
                [void]$md.AppendLine('|---|---------------|-----------------|')

                $stepNum = 0
                foreach ($step in $reversedSteps) {
                    if (-not $step.Enabled) { continue }
                    $stepNum++
                    $stepName = $step.Name -replace '\|', '\|'

                    $rollbackAction = 'Manual review required'
                    $nameLower = $step.Name.ToLower()
                    if ($nameLower -match 'stop.*(service|app|process)') { $rollbackAction = 'START the service/app' }
                    elseif ($nameLower -match 'start.*(service|app|process)') { $rollbackAction = 'STOP the service/app' }
                    elseif ($nameLower -match 'deploy|copy|replace|config') { $rollbackAction = 'Restore from backup / redeploy previous version' }
                    elseif ($nameLower -match 'backup') { $rollbackAction = 'No rollback needed (backup step)' }
                    elseif ($nameLower -match 'disable|enable') { $rollbackAction = 'Toggle back to previous state' }
                    elseif ($nameLower -match 'restart') { $rollbackAction = 'Restart with previous configuration' }
                    elseif ($nameLower -match 'install|update|upgrade') { $rollbackAction = 'Uninstall / downgrade to previous version' }
                    elseif ($nameLower -match 'delete|remove') { $rollbackAction = 'Restore deleted items from backup' }
                    elseif ($nameLower -match 'create|add') { $rollbackAction = 'Remove/delete the created items' }
                    elseif ($nameLower -match 'register') { $rollbackAction = 'Unregister / deregister' }
                    elseif ($nameLower -match 'migrate|migration') { $rollbackAction = '**CRITICAL:** Run reverse migration or restore DB backup' }
                    elseif ($nameLower -match 'checkout|clone') { $rollbackAction = 'No rollback needed (source control step)' }
                    elseif ($nameLower -match 'test|validate|verify|health') { $rollbackAction = 'Re-run validation against previous state' }
                    elseif ($nameLower -match 'notify|email|slack|teams') { $rollbackAction = 'Send rollback notification' }

                    [void]$md.AppendLine(('| {0} | {1} | {2} |' -f $stepNum, $stepName, $rollbackAction))
                }
                [void]$md.AppendLine()
            }
        }
    }

    [void]$md.AppendLine('---')
    [void]$md.AppendLine()
    return $md.ToString()
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 3: CUTOVER CHECKLIST (-Checklist)
# ══════════════════════════════════════════════════════════════════════════════

# This function generates a printable cutover checklist with markdown checkboxes.
# The checklist is structured in three sections:
#   1. Pre-Cutover: Standard preparation items (change request approved, rollback
#      plan reviewed, stakeholders notified, backups verified) plus fill-in fields
#      for each pipeline parameter value
#   2. Execution: Every step listed with stage.step numbering, checkbox, timeout
#      info, and condition notes. Disabled steps shown with strikethrough.
#   3. Post-Cutover: Standard verification items (services healthy, smoke tests,
#      monitoring dashboards, stakeholder notification, change request closure)
# Includes a header line for Date, Operator, and Approver fields.
function ConvertTo-Checklist {
    param([hashtable]$Pipeline, [string]$SourceFile)

    $stages = Get-Stages $Pipeline
    if ($stages.Count -eq 0) { return '' }

    $name = if ($Pipeline['name']) { $Pipeline['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($SourceFile) }
    $md = [System.Text.StringBuilder]::new()

    [void]$md.AppendLine(('## Cutover Checklist: {0}' -f $name))
    [void]$md.AppendLine()
    [void]$md.AppendLine('**Date:** _______________  **Operator:** _______________  **Approver:** _______________')
    [void]$md.AppendLine()

    [void]$md.AppendLine('### Pre-Cutover')
    [void]$md.AppendLine('- [ ] Change request approved')
    [void]$md.AppendLine('- [ ] Rollback plan reviewed and understood')
    [void]$md.AppendLine('- [ ] Stakeholders notified of maintenance window')
    [void]$md.AppendLine('- [ ] Backups verified')
    [void]$md.AppendLine('- [ ] Pipeline parameters confirmed')

    $params = Get-Parameters $Pipeline
    foreach ($p in $params) {
        [void]$md.AppendLine(('  - [ ] ``{0}`` = _______________' -f $($p.DisplayName)))
    }
    [void]$md.AppendLine()

    $stageNum = 0
    foreach ($stage in $stages) {
        $stageNum++
        [void]$md.AppendLine(('### Stage {1}: {0}' -f $($stage.Name), ${stageNum}))
        [void]$md.AppendLine()

        foreach ($job in $stage.Jobs) {
            if ($job.Environment) { [void]$md.AppendLine(('**Environment:** ``{0}``' -f $job.Environment)) }
            [void]$md.AppendLine()

            $stepNum = 0
            foreach ($step in $job.Steps) {
                $stepNum++
                $prefix = if (-not $step.Enabled) { '- [ ] ~~' } else { '- [ ] ' }
                $suffix = if (-not $step.Enabled) { '~~ *(DISABLED)*' } else { '' }
                $timeStr = if ($step.Timeout) { " *(timeout: $($step.Timeout)m)*" } else { '' }
                $condStr = if ($step.Condition) { " - Condition: $(Format-Condition $step.Condition)" } else { '' }

                [void]$md.AppendLine(('{1}**Step {2}.{3}:** {0}{4}{5}{6}' -f $($step.Name), ${prefix}, ${stageNum}, ${stepNum}, ${suffix}, ${timeStr}, ${condStr}))
            }
            [void]$md.AppendLine()
        }
    }

    [void]$md.AppendLine('### Post-Cutover')
    [void]$md.AppendLine('- [ ] All services healthy')
    [void]$md.AppendLine('- [ ] Smoke tests passed')
    [void]$md.AppendLine('- [ ] Monitoring dashboards checked')
    [void]$md.AppendLine('- [ ] Stakeholders notified of completion')
    [void]$md.AppendLine('- [ ] Change request closed')
    [void]$md.AppendLine()
    [void]$md.AppendLine('---')
    [void]$md.AppendLine()
    return $md.ToString()
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 4: ENVIRONMENT MATRIX (-EnvironmentMatrix)
# ══════════════════════════════════════════════════════════════════════════════

# This function builds a cross-pipeline environment matrix. It iterates through
# ALL provided pipelines (not just one) and collects every environment reference
# (from deployment jobs) and agent pool reference (from job pool settings).
# The output is a single consolidated table grouped by environment/pool name,
# showing which pipeline, stage, job, and type touches each environment.
# This is useful for identifying environment contention when multiple pipelines
# run during the same maintenance window, or for documenting which servers/pools
# are involved across your entire cutover process.
# Note: This function receives the full array of parsed pipelines, unlike other
# feature functions which process one pipeline at a time.
function ConvertTo-EnvironmentMatrix {
    param([array]$ParsedPipelines)

    $md = [System.Text.StringBuilder]::new()
    [void]$md.AppendLine('## Environment Matrix')
    [void]$md.AppendLine()

    $envMap = [ordered]@{}
    foreach ($pp in $ParsedPipelines) {
        $pipeline = $pp.Pipeline
        $fileName = $pp.FileName
        $name = if ($pipeline['name']) { $pipeline['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($fileName) }

        $stages = Get-Stages $pipeline
        $stageNum = 0
        foreach ($stage in $stages) {
            $stageNum++
            foreach ($job in $stage.Jobs) {
                if ($job.Environment) {
                    if (-not $envMap.Contains($job.Environment)) { $envMap[$job.Environment] = @() }
                    $envMap[$job.Environment] += [PSCustomObject]@{
                        Pipeline = $name
                        Stage    = "$stageNum. $($stage.Name)"
                        Job      = $job.Name
                        Type     = $job.Type
                        File     = $fileName
                    }
                }

                $poolName = ''
                if ($job.Pool -is [hashtable]) {
                    $poolName = if ($job.Pool['name']) { $job.Pool['name'] } elseif ($job.Pool['vmImage']) { $job.Pool['vmImage'] } else { '' }
                } elseif ($job.Pool -is [string]) { $poolName = $job.Pool }

                if ($poolName -and -not $envMap.Contains("Pool: $poolName")) {
                    $envMap["Pool: $poolName"] = @()
                }
                if ($poolName) {
                    $envMap["Pool: $poolName"] += [PSCustomObject]@{
                        Pipeline = $name
                        Stage    = "$stageNum. $($stage.Name)"
                        Job      = $job.Name
                        Type     = 'agent pool'
                        File     = $fileName
                    }
                }
            }
        }
    }

    if ($envMap.Count -eq 0) {
        [void]$md.AppendLine('*No environments or agent pools found across the provided pipelines.*')
        [void]$md.AppendLine()
        return $md.ToString()
    }

    [void]$md.AppendLine('| Environment / Pool | Pipeline | Stage | Job | Type |')
    [void]$md.AppendLine('|-------------------|----------|-------|-----|------|')

    foreach ($env in $envMap.Keys) {
        $first = $true
        foreach ($entry in $envMap[$env]) {
            $envCol = if ($first) { "**$env**" } else { '' }
            [void]$md.AppendLine(('| {4} | {0} | {1} | {2} | {3} |' -f $($entry.Pipeline), $($entry.Stage), $($entry.Job), $($entry.Type), $envCol))
            $first = $false
        }
    }

    [void]$md.AppendLine()
    [void]$md.AppendLine('---')
    [void]$md.AppendLine()
    return $md.ToString()
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 5: ESTIMATED DURATION (-EstimateDuration)
# ══════════════════════════════════════════════════════════════════════════════

# This function calculates estimated pipeline duration from timeoutInMinutes
# values. The calculation logic is:
#   1. For each job: if a job-level timeout exists, use that as the job duration.
#      Otherwise, sum all step-level timeouts within the job.
#   2. For parallel jobs (no dependsOn): use the LONGEST job as the stage duration
#      (since parallel jobs run concurrently, only the slowest matters).
#   3. For sequential jobs (has dependsOn): ADD the job duration to the stage total
#      (since dependent jobs must wait for predecessors).
#   4. Sum all stage durations for the total pipeline estimate.
# This produces a worst-case estimate (timeouts represent maximums, not actuals).
# If no timeoutInMinutes values are found, a message suggests adding them.
function ConvertTo-DurationEstimate {
    param([hashtable]$Pipeline, [string]$SourceFile)

    $stages = Get-Stages $Pipeline
    if ($stages.Count -eq 0) { return '' }

    $name = if ($Pipeline['name']) { $Pipeline['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($SourceFile) }
    $md = [System.Text.StringBuilder]::new()

    [void]$md.AppendLine(('## Estimated Duration: {0}' -f $name))
    [void]$md.AppendLine()

    $totalMin = 0
    $hasAnyTimeout = $false

    [void]$md.AppendLine('| Stage | Job | Step | Timeout (min) |')
    [void]$md.AppendLine('|-------|-----|------|---------------|')

    foreach ($stage in $stages) {
        $stageMax = 0
        foreach ($job in $stage.Jobs) {
            $jobTotal = 0

            if ($job.Timeout) {
                $jobTotal = [int]$job.Timeout
                $hasAnyTimeout = $true
                [void]$md.AppendLine(('| {0} | **{1}** | *(job-level timeout)* | {2} |' -f $($stage.Name), $($job.Name), $($job.Timeout)))
            } else {
                foreach ($step in $job.Steps) {
                    if ($step.Timeout -and $step.Enabled) {
                        $hasAnyTimeout = $true
                        $jobTotal += [int]$step.Timeout
                        [void]$md.AppendLine(('| {0} | {1} | {2} | {3} |' -f $($stage.Name), $($job.Name), $($step.Name), $($step.Timeout)))
                    }
                }
            }

            if ($job.DependsOn.Count -eq 0) {
                if ($jobTotal -gt $stageMax) { $stageMax = $jobTotal }
            } else {
                $stageMax += $jobTotal
            }
        }
        $totalMin += $stageMax
    }

    [void]$md.AppendLine()

    if (-not $hasAnyTimeout) {
        [void]$md.AppendLine('*No timeoutInMinutes values found. Add timeouts to your steps/jobs for duration estimates.*')
    } else {
        $hours = [math]::Floor($totalMin / 60)
        $mins = $totalMin % 60
        $timeStr = if ($hours -gt 0) { "${hours}h ${mins}m" } else { "${mins}m" }
        [void]$md.AppendLine(('**Estimated total duration:** {0} ({1} minutes)' -f $timeStr, $totalMin))
        [void]$md.AppendLine()
        [void]$md.AppendLine('> *Estimate based on timeout values (worst case). Parallel jobs use the longest job duration.*')
    }

    [void]$md.AppendLine()
    [void]$md.AppendLine('---')
    [void]$md.AppendLine()
    return $md.ToString()
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 6: VALIDATION / LINTING (-Validate)
# ══════════════════════════════════════════════════════════════════════════════

# This function lints a pipeline YAML for common issues. It performs the
# following checks, categorised by severity:
#
# ERRORS (will likely cause pipeline failure):
#   - Pipeline has no stages, jobs, or steps
#   - Stage dependsOn references a stage ID that does not exist
#   - Job dependsOn references a job ID that does not exist in its stage
#
# WARNINGS (may cause unexpected behaviour):
#   - Multiple jobs in a stage with no dependsOn (will run in PARALLEL - may be
#     unintentional if the pipeline is meant to be sequential)
#   - Deployment job has no environment specified
#   - Job has no steps defined
#   - Pipeline name contains "cutover/release/deploy/prod" but trigger is not
#     manual-only (risk of accidental execution)
#
# INFO (worth noting):
#   - Disabled steps that may be forgotten
#   - continueOnError steps that may silently swallow failures
#   - Steps/jobs with no timeouts (could hang indefinitely)
#   - No trigger defined (defaults to CI on all branches)
#
# Returns a formatted Markdown section with error/warning/info lists and a
# summary count.
function Invoke-PipelineValidation {
    param([hashtable]$Pipeline, [string]$SourceFile)

    $stages = Get-Stages $Pipeline
    $name = if ($Pipeline['name']) { $Pipeline['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($SourceFile) }
    $md = [System.Text.StringBuilder]::new()

    [void]$md.AppendLine(('## Validation: {0}' -f $name))
    [void]$md.AppendLine()

    $warnings = @()
    $errors = @()
    $info = @()

    # Check: no stages/jobs/steps
    if ($stages.Count -eq 0) {
        $errors += 'Pipeline has no stages, jobs, or steps defined.'
    }

    # Build stage ID set for dependency checking
    $stageIds = @{}
    foreach ($stage in $stages) { $stageIds[$stage.Id] = $true }

    foreach ($stage in $stages) {
        # Check: stage depends on non-existent stage
        foreach ($dep in $stage.DependsOn) {
            if (-not $stageIds.ContainsKey($dep)) {
                $errors += "Stage ``$($stage.Name)`` depends on ``$dep`` which does not exist."
            }
        }

        # Build job ID set within stage
        $jobIds = @{}
        foreach ($job in $stage.Jobs) { $jobIds[$job.Id] = $true }

        $jobsWithNoDeps = @($stage.Jobs | Where-Object { $_.DependsOn.Count -eq 0 })

        # Check: multiple jobs with no dependsOn - could be unintentionally parallel
        if ($jobsWithNoDeps.Count -gt 1) {
            $jobNames = ($jobsWithNoDeps | ForEach-Object { $_.Name }) -join ', '
            $warnings += "Stage ``$($stage.Name)`` has $($jobsWithNoDeps.Count) jobs with no dependsOn (will run in PARALLEL): $jobNames"
        }

        foreach ($job in $stage.Jobs) {
            # Check: job depends on non-existent job
            foreach ($dep in $job.DependsOn) {
                if (-not $jobIds.ContainsKey($dep)) {
                    $errors += "Job ``$($job.Name)`` in stage ``$($stage.Name)`` depends on ``$dep`` which does not exist in this stage."
                }
            }

            # Check: deployment job without environment
            if ($job.Type -eq 'deployment' -and -not $job.Environment) {
                $warnings += "Deployment job ``$($job.Name)`` in stage ``$($stage.Name)`` has no environment specified."
            }

            # Check: no steps
            if ($job.Steps.Count -eq 0) {
                $warnings += "Job ``$($job.Name)`` in stage ``$($stage.Name)`` has no steps."
            }

            # Check: disabled steps
            $disabledSteps = @($job.Steps | Where-Object { -not $_.Enabled })
            if ($disabledSteps.Count -gt 0) {
                $info += "Job ``$($job.Name)`` has $($disabledSteps.Count) disabled step(s) - ensure these are intentional."
            }

            # Check: continueOnError steps
            $continueSteps = @($job.Steps | Where-Object { $_.ContinueOnError })
            if ($continueSteps.Count -gt 0) {
                $info += "Job ``$($job.Name)`` has $($continueSteps.Count) step(s) with continueOnError - failures may be silently ignored."
            }

            # Check: no timeouts
            $stepsWithoutTimeout = @($job.Steps | Where-Object { $_.Enabled -and -not $_.Timeout })
            if ($stepsWithoutTimeout.Count -gt 0 -and -not $job.Timeout) {
                $info += "Job ``$($job.Name)`` in stage ``$($stage.Name)`` has $($stepsWithoutTimeout.Count) step(s) with no timeout."
            }
        }
    }

    # Check: no trigger defined
    if (-not $Pipeline.ContainsKey('trigger')) {
        $info += 'No trigger defined - pipeline will default to CI on all branches.'
    }

    # Check: trigger is not manual-only for what looks like a cutover pipeline
    $trigger = $Pipeline['trigger']
    if ($null -ne $trigger -and $trigger -ne 'none' -and $trigger -ne $false) {
        $nameLower = $name.ToLower()
        if ($nameLower -match 'cutover|release|deploy|prod') {
            $warnings += "Pipeline name suggests production use but trigger is not manual-only. Consider setting ``trigger: none``."
        }
    }

    # Output results
    if ($errors.Count -gt 0) {
        [void]$md.AppendLine('### Errors')
        foreach ($e in $errors) { [void]$md.AppendLine("- :x: $e") }
        [void]$md.AppendLine()
    }

    if ($warnings.Count -gt 0) {
        [void]$md.AppendLine('### Warnings')
        foreach ($w in $warnings) { [void]$md.AppendLine("- :warning: $w") }
        [void]$md.AppendLine()
    }

    if ($info.Count -gt 0) {
        [void]$md.AppendLine('### Info')
        foreach ($i in $info) { [void]$md.AppendLine("- :information_source: $i") }
        [void]$md.AppendLine()
    }

    if ($errors.Count -eq 0 -and $warnings.Count -eq 0 -and $info.Count -eq 0) {
        [void]$md.AppendLine('No issues found.')
        [void]$md.AppendLine()
    }

    $summary = "$($errors.Count) error(s), $($warnings.Count) warning(s), $($info.Count) info"
    [void]$md.AppendLine(('**Result:** {0}' -f $summary))
    [void]$md.AppendLine()
    [void]$md.AppendLine('---')
    [void]$md.AppendLine()
    return $md.ToString()
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 7: DIFF TWO PIPELINES (-Diff)
# ══════════════════════════════════════════════════════════════════════════════

# This function compares two pipeline YAML files and produces a diff report.
# The comparison works at three levels:
#   1. Stage-level: identifies stages that were ADDED, REMOVED, or MODIFIED
#      between the two files. Modified stages show what changed (name, job count,
#      dependsOn, condition).
#   2. Job-level: for each modified stage, identifies jobs that were ADDED,
#      REMOVED, or MODIFIED. Modified jobs show step count changes.
#   3. Step-level: for modified jobs, lists specific steps that were added or
#      removed (compared by display name).
# Stages and jobs are matched by their ID (the 'stage:' or 'job:' key value),
# not by display name - so renaming a stage's displayName shows as a modification,
# not an add+remove.
function Compare-Pipelines {
    param([string]$PathA, [string]$PathB)

    $contentA = Get-Content -Path $PathA -Raw -Encoding UTF8
    $contentB = Get-Content -Path $PathB -Raw -Encoding UTF8
    $pipelineA = ConvertFrom-Yaml $contentA
    $pipelineB = ConvertFrom-Yaml $contentB

    $nameA = if ($pipelineA['name']) { $pipelineA['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($PathA) }
    $nameB = if ($pipelineB['name']) { $pipelineB['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($PathB) }

    $stagesA = Get-Stages $pipelineA
    $stagesB = Get-Stages $pipelineB

    $md = [System.Text.StringBuilder]::new()
    [void]$md.AppendLine("## Pipeline Diff")
    [void]$md.AppendLine()
    $leftFile = [System.IO.Path]::GetFileName($PathA)
    $rightFile = [System.IO.Path]::GetFileName($PathB)
    [void]$md.AppendLine(('**Left:** ``{0}`` ({1})' -f $leftFile, $nameA))
    [void]$md.AppendLine(('**Right:** ``{0}`` ({1})' -f $rightFile, $nameB))
    [void]$md.AppendLine()

    # Compare stages
    $stageIdsA = @{}; foreach ($s in $stagesA) { $stageIdsA[$s.Id] = $s }
    $stageIdsB = @{}; foreach ($s in $stagesB) { $stageIdsB[$s.Id] = $s }

    $allStageIds = @($stageIdsA.Keys) + @($stageIdsB.Keys) | Sort-Object -Unique

    [void]$md.AppendLine('### Stage Comparison')
    [void]$md.AppendLine()
    [void]$md.AppendLine('| Stage | Left | Right | Status |')
    [void]$md.AppendLine('|-------|------|-------|--------|')

    foreach ($sId in $allStageIds) {
        $inA = $stageIdsA.ContainsKey($sId)
        $inB = $stageIdsB.ContainsKey($sId)

        if ($inA -and $inB) {
            $sA = $stageIdsA[$sId]
            $sB = $stageIdsB[$sId]
            $jobCountA = $sA.Jobs.Count
            $jobCountB = $sB.Jobs.Count
            $changes = @()
            if ($sA.Name -ne $sB.Name) { $changes += "name: $($sA.Name) -> $($sB.Name)" }
            if ($jobCountA -ne $jobCountB) { $changes += "jobs: $jobCountA -> $jobCountB" }
            if (($sA.DependsOn -join ',') -ne ($sB.DependsOn -join ',')) { $changes += "dependsOn changed" }
            if ($sA.Condition -ne $sB.Condition) { $changes += "condition changed" }

            $status = if ($changes.Count -gt 0) { "MODIFIED ($($changes -join '; '))" } else { 'Unchanged' }
            [void]$md.AppendLine(('| {2} | {0} ({3} jobs) | {1} ({4} jobs) | {5} |' -f $($sA.Name), $($sB.Name), $sId, $jobCountA, $jobCountB, $status))
        }
        elseif ($inA) {
            [void]$md.AppendLine(('| {1} | {0} | - | **REMOVED** |' -f $($stageIdsA[$sId].Name), $sId))
        }
        else {
            [void]$md.AppendLine(('| {1} | - | {0} | **ADDED** |' -f $($stageIdsB[$sId].Name), $sId))
        }
    }
    [void]$md.AppendLine()

    # Detailed job/step diff for modified stages
    foreach ($sId in $allStageIds) {
        $inA = $stageIdsA.ContainsKey($sId)
        $inB = $stageIdsB.ContainsKey($sId)
        if (-not ($inA -and $inB)) { continue }

        $sA = $stageIdsA[$sId]
        $sB = $stageIdsB[$sId]

        $jobIdsA = @{}; foreach ($j in $sA.Jobs) { $jobIdsA[$j.Id] = $j }
        $jobIdsB = @{}; foreach ($j in $sB.Jobs) { $jobIdsB[$j.Id] = $j }
        $allJobIds = @($jobIdsA.Keys) + @($jobIdsB.Keys) | Sort-Object -Unique

        $hasJobDiff = $false
        foreach ($jId in $allJobIds) {
            $jInA = $jobIdsA.ContainsKey($jId)
            $jInB = $jobIdsB.ContainsKey($jId)
            if (-not ($jInA -and $jInB)) { $hasJobDiff = $true; break }
            $jA = $jobIdsA[$jId]; $jB = $jobIdsB[$jId]
            if ($jA.Steps.Count -ne $jB.Steps.Count) { $hasJobDiff = $true; break }
            for ($i = 0; $i -lt $jA.Steps.Count; $i++) {
                if ($jA.Steps[$i].Name -ne $jB.Steps[$i].Name) { $hasJobDiff = $true; break }
            }
            if ($hasJobDiff) { break }
        }

        if (-not $hasJobDiff) { continue }

        [void]$md.AppendLine(('#### Stage: {0} - Job/Step Diff' -f $($sA.Name)))
        [void]$md.AppendLine()

        foreach ($jId in $allJobIds) {
            $jInA = $jobIdsA.ContainsKey($jId)
            $jInB = $jobIdsB.ContainsKey($jId)

            if ($jInA -and -not $jInB) {
                [void]$md.AppendLine(('- **Job REMOVED:** ``{0}`` ({1} steps)' -f $($jobIdsA[$jId].Name), $($jobIdsA[$jId].Steps.Count)))
            }
            elseif (-not $jInA -and $jInB) {
                [void]$md.AppendLine(('- **Job ADDED:** ``{0}`` ({1} steps)' -f $($jobIdsB[$jId].Name), $($jobIdsB[$jId].Steps.Count)))
            }
            else {
                $jA = $jobIdsA[$jId]; $jB = $jobIdsB[$jId]
                if ($jA.Steps.Count -ne $jB.Steps.Count -or ($jA.Steps | ForEach-Object { $_.Name }) -join '|' -ne ($jB.Steps | ForEach-Object { $_.Name }) -join '|') {
                    [void]$md.AppendLine(('- **Job MODIFIED:** ``{0}`` - steps: {1} -> {2}' -f $($jA.Name), $($jA.Steps.Count), $($jB.Steps.Count)))

                    $stepNamesA = $jA.Steps | ForEach-Object { $_.Name }
                    $stepNamesB = $jB.Steps | ForEach-Object { $_.Name }

                    $added = $stepNamesB | Where-Object { $_ -notin $stepNamesA }
                    $removed = $stepNamesA | Where-Object { $_ -notin $stepNamesB }

                    foreach ($r in $removed) { [void]$md.AppendLine("  - Removed: ``$r``") }
                    foreach ($a in $added) { [void]$md.AppendLine("  - Added: ``$a``") }
                }
            }
        }
        [void]$md.AppendLine()
    }

    [void]$md.AppendLine('---')
    [void]$md.AppendLine()
    return $md.ToString()
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 8: HTML REPORT (-Html)
# ══════════════════════════════════════════════════════════════════════════════

# This function converts the combined Markdown output into a self-contained HTML
# file. The conversion performs the following transformations:
#   1. Mermaid code blocks → <div class="mermaid"> (rendered by Mermaid JS CDN)
#   2. Other code blocks → <pre><code> with language class
#   3. Headers (h1-h4) → HTML header tags
#   4. Markdown tables → HTML <table> with first row as <th>
#   5. Blockquotes → <blockquote>
#   6. Checkboxes (- [ ] / - [x]) → <li> with <input type="checkbox">
#   7. List items → <li>
#   8. Bold/italic → <strong>/<em>
#   9. Inline code → <code>
#  10. Horizontal rules → <hr>
# The HTML template uses a Catppuccin Mocha dark theme with responsive layout,
# hover effects on table rows, and interactive checkboxes. Mermaid JS is loaded
# from CDN (requires internet for diagram rendering). The file has no other
# external dependencies and can be shared as a single file.
function ConvertTo-HtmlReport {
    param([string]$MarkdownContent, [string]$OutputPath)

    $html = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pipeline Documentation</title>
<style>
  :root { --bg: #1e1e2e; --surface: #282840; --text: #cdd6f4; --accent: #89b4fa; --border: #45475a; --green: #a6e3a1; --yellow: #f9e2af; --red: #f38ba8; }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); line-height: 1.6; padding: 2rem; max-width: 1400px; margin: 0 auto; }
  h1 { color: var(--accent); border-bottom: 2px solid var(--accent); padding-bottom: 0.5rem; margin: 2rem 0 1rem; font-size: 1.8rem; }
  h2 { color: var(--green); margin: 1.5rem 0 0.75rem; font-size: 1.4rem; }
  h3 { color: var(--yellow); margin: 1.2rem 0 0.5rem; font-size: 1.15rem; }
  h4 { color: var(--text); margin: 1rem 0 0.5rem; font-size: 1rem; }
  p, li { margin: 0.3rem 0; }
  strong { color: #f5f5f5; }
  code, .inline-code { background: var(--surface); padding: 0.15rem 0.4rem; border-radius: 3px; font-family: 'Cascadia Code', 'Fira Code', monospace; font-size: 0.9em; color: var(--accent); }
  pre { background: var(--surface); border: 1px solid var(--border); border-radius: 6px; padding: 1rem; overflow-x: auto; margin: 0.75rem 0; }
  pre code { padding: 0; background: none; }
  table { width: 100%; border-collapse: collapse; margin: 0.75rem 0; }
  th { background: var(--surface); color: var(--accent); text-align: left; padding: 0.6rem 0.8rem; border: 1px solid var(--border); font-weight: 600; }
  td { padding: 0.5rem 0.8rem; border: 1px solid var(--border); }
  tr:nth-child(even) { background: rgba(255,255,255,0.02); }
  tr:hover { background: rgba(137,180,250,0.08); }
  blockquote { border-left: 4px solid var(--accent); background: var(--surface); padding: 0.75rem 1rem; margin: 0.75rem 0; border-radius: 0 4px 4px 0; }
  details { background: var(--surface); border: 1px solid var(--border); border-radius: 6px; margin: 0.75rem 0; }
  summary { padding: 0.75rem 1rem; cursor: pointer; font-weight: 600; color: var(--accent); }
  details[open] summary { border-bottom: 1px solid var(--border); }
  details > :not(summary) { padding: 0 1rem; }
  hr { border: none; border-top: 1px solid var(--border); margin: 1.5rem 0; }
  input[type="checkbox"] { margin-right: 0.5rem; accent-color: var(--accent); transform: scale(1.2); }
  .mermaid { background: #fff; border-radius: 8px; padding: 1.5rem; margin: 1rem 0; }
  ul { padding-left: 1.5rem; }
  em { color: #a6adc8; }
  .timestamp { color: #6c7086; font-size: 0.85rem; text-align: right; margin-top: 2rem; }
</style>
<script src="https://url.au.m.mimecastprotect.com/s/3iwECBNqK2umPQQJh1u4T2HKf7?domain=cdn.jsdelivr.net"></script>
<script>mermaid.initialize({ startOnLoad: true, theme: 'default', securityLevel: 'loose' });</script>
</head>
<body>
MARKDOWN_CONTENT_PLACEHOLDER
<div class="timestamp">Generated: TIMESTAMP_PLACEHOLDER</div>
</body>
</html>
"@

    $htmlBody = $MarkdownContent

    # Convert Mermaid code blocks
    $htmlBody = [regex]::Replace($htmlBody, '```mermaid\r?\n([\s\S]*?)```', '<div class="mermaid">$1</div>')

    # Convert other code blocks
    $htmlBody = [regex]::Replace($htmlBody, '``````(\w*)\r?\n([\s\S]*?)``````', '<pre><code class="language-$1">$2</code></pre>')
    $htmlBody = [regex]::Replace($htmlBody, '```(\w*)\r?\n([\s\S]*?)```', '<pre><code class="language-$1">$2</code></pre>')

    # Convert headers
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^#### (.+)$', '<h4>$1</h4>')
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^### (.+)$', '<h3>$1</h3>')
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^## (.+)$', '<h2>$1</h2>')
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^# (.+)$', '<h1>$1</h1>')

    # Convert tables
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^\|[-\s|:]+\|$', '')
    $tablePattern = '(?m)((?:^\|.+\|\r?\n)+)'
    $htmlBody = [regex]::Replace($htmlBody, $tablePattern, {
        param($m)
        $rows = $m.Value.Trim() -split "`n" | Where-Object { $_.Trim() }
        $tableHtml = "<table>`n"
        $isFirst = $true
        foreach ($row in $rows) {
            $cells = ($row.Trim().Trim('|') -split '\|') | ForEach-Object { $_.Trim() }
            $tag = if ($isFirst) { 'th' } else { 'td' }
            $tableHtml += "<tr>"
            foreach ($cell in $cells) { $tableHtml += "<$tag>$cell</$tag>" }
            $tableHtml += "</tr>`n"
            $isFirst = $false
        }
        $tableHtml += "</table>`n"
        return $tableHtml
    })

    # Convert blockquotes
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^> (.+)$', '<blockquote>$1</blockquote>')

    # Convert details/summary
    $htmlBody = $htmlBody -replace '<details>', '<details>'
    $htmlBody = $htmlBody -replace '</details>', '</details>'

    # Convert checkboxes
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^- \[ \] (.+)$', '<li><input type="checkbox"> $1</li>')
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^- \[x\] (.+)$', '<li><input type="checkbox" checked> $1</li>')
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^  - \[ \] (.+)$', '<li style="margin-left:1.5rem"><input type="checkbox"> $1</li>')

    # Convert list items
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^- (.+)$', '<li>$1</li>')

    # Convert bold and italic
    $htmlBody = [regex]::Replace($htmlBody, '\*\*(.+?)\*\*', '<strong>$1</strong>')
    $htmlBody = [regex]::Replace($htmlBody, '\*(.+?)\*', '<em>$1</em>')

    # Convert inline code
    $htmlBody = [regex]::Replace($htmlBody, '``([^`]+)``', '<code>$1</code>')
    $htmlBody = [regex]::Replace($htmlBody, '`([^`]+)`', '<code>$1</code>')

    # Convert horizontal rules
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^---$', '<hr>')

    # Convert remaining paragraph breaks
    $htmlBody = [regex]::Replace($htmlBody, '(?m)^\s*$', '<br>')

    $html = $html -replace 'MARKDOWN_CONTENT_PLACEHOLDER', $htmlBody
    $html = $html -replace 'TIMESTAMP_PLACEHOLDER', (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')

    Set-Content -Path $OutputPath -Value $html -Encoding UTF8
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 9: SCRIPT DISCOVERY AND TRACING (-ScanScripts / -TraceScripts)
# ══════════════════════════════════════════════════════════════════════════════
# Stage 1 (-ScanScripts): Scans pipeline YAML for references to external script
# files (PowerShell, Bash, Batch, Python) and produces a manifest JSON file.
# The manifest lists every discovered reference, its resolution status against
# the -ScriptRoot directory, and metadata for downstream consumption.
#
# Stage 2 (-TraceScripts): Implemented in Feature 10 section. Reads the
# manifest, parse PowerShell ASTs, and generate nested dependency diagrams.
#
# Script reference discovery covers:
#   - Inline script steps (powershell, pwsh, bash, script) with external calls
#   - PowerShell@2 task steps with filePath inputs
#   - Template references
#   - Dynamic invocations (& $variable, Invoke-Expression) flagged for review
#   - Import-Module references to .psm1 files

# This function extracts the file extension from a script path and maps it to a
# known file type category. Returns 'unknown' for unrecognised extensions.
function Get-ScriptFileType {
    param([string]$FilePath)
    if (-not $FilePath) { return 'unknown' }
    $ext = [System.IO.Path]::GetExtension($FilePath).TrimStart('.').ToLower()
    switch ($ext) {
        'ps1'  { return 'ps1' }
        'psm1' { return 'psm1' }
        'bat'  { return 'bat' }
        'cmd'  { return 'cmd' }
        'py'   { return 'py' }
        'sh'   { return 'sh' }
        default { return 'unknown' }
    }
}

# This function strips common Azure DevOps predefined variables from a file path
# so that the remaining relative path can be joined with ScriptRoot. Handles
# patterns such as $(Build.SourcesDirectory), $(System.DefaultWorkingDirectory),
# $(Pipeline.Workspace), and similar constructs.
function Remove-AzureDevOpsVariables {
    param([string]$Path)
    # Strip $( ... ) variable references commonly used in Azure DevOps YAML
    $cleaned = $Path -replace '\$\([^)]+\)[\\\/]?', ''
    # Remove leading path separators left after variable stripping
    $cleaned = $cleaned.TrimStart('\', '/')
    return $cleaned
}

# This function attempts to resolve a script reference against ScriptRoot.
# It strips Azure DevOps variables, normalises path separators, and checks
# whether the target file exists on disk. Returns the full resolved path if
# found, or an empty string if the file cannot be located.
function Resolve-ScriptReference {
    param([string]$Reference, [string]$ScriptRoot)
    if (-not $Reference -or -not $ScriptRoot) { return '' }

    # Clean the reference: strip variables, quotes, and the call operator
    $cleaned = $Reference.Trim()
    $cleaned = $cleaned -replace '^[&\.]\s+', ''          # Remove & or . call operators
    $cleaned = $cleaned.Trim('"', "'")                     # Remove surrounding quotes
    $cleaned = Remove-AzureDevOpsVariables $cleaned

    if (-not $cleaned) { return '' }

    # Normalise path separators for the current OS
    $cleaned = $cleaned -replace '[\\\/]', [IO.Path]::DirectorySeparatorChar

    # Strip leading .\ or ./ relative prefix
    $cleaned = $cleaned -replace '^\.[\\/]', ''

    # Attempt to resolve against ScriptRoot
    $candidate = Join-Path $ScriptRoot $cleaned
    if (Test-Path $candidate -PathType Leaf) {
        return (Resolve-Path $candidate).Path
    }

    # Also try the raw reference in case it is already absolute
    if (Test-Path $cleaned -PathType Leaf) {
        return (Resolve-Path $cleaned).Path
    }

    return ''
}

# This function scans a parsed pipeline for all script references. It walks the
# normalised stage > job > step hierarchy and examines:
#   - Inline script bodies (powershell/pwsh/bash/script) for external file calls
#   - PowerShell@2 (and other versions) task steps for filePath inputs
#   - Template references at the step level
# Returns an array of PSCustomObjects describing each discovered reference.
function Invoke-ScriptScan {
    param(
        [hashtable]$Pipeline,
        [string]$SourceFile,
        [string]$ScriptRoot
    )

    $results = @()
    $stages = Get-Stages $Pipeline

    foreach ($stage in $stages) {
        foreach ($job in $stage.Jobs) {
            foreach ($step in $job.Steps) {

                # ── PowerShell task steps with filePath input ──
                # Azure DevOps PowerShell@2 (or any version) tasks can specify
                # a filePath input pointing to an external .ps1 script.
                if ($step.Inputs -and $step.Inputs['filePath']) {
                    $filePath = $step.Inputs['filePath']
                    $resolved = Resolve-ScriptReference -Reference $filePath -ScriptRoot $ScriptRoot
                    $fileType = Get-ScriptFileType $filePath
                    $status = if ($resolved) { 'RESOLVED' } else { 'UNRESOLVED' }
                    $results += [PSCustomObject]@{
                        Pipeline    = $SourceFile
                        Stage       = $stage.Name
                        Job         = $job.Name
                        Step        = $step.Name
                        Reference   = $filePath
                        ResolvedPath = $resolved
                        Status      = $status
                        FileType    = $fileType
                        TraceDepth  = 'detailed'
                        Notes       = ''
                    }
                }

                # ── Inline script blocks - scan for external file references ──
                # Steps of type script/bash/powershell/pwsh may contain inline code
                # that calls external scripts via & .\path, dot-sourcing, direct
                # invocation, or Import-Module.
                if ($step.ScriptBody) {
                    $scriptBody = $step.ScriptBody
                    $hasExternalRef = $false

                    # Regex patterns for external script references within inline code
                    # Pattern 1: & .\path\script.ps1 or & ".\path\script.ps1"
                    $callOperatorPattern = '&\s+["\u0027]?([^\s"\u0027;|]+\.\w+)["\u0027]?'
                    # Pattern 2: . .\path\script.ps1 (dot-sourcing, but not '. ' alone)
                    $dotSourcePattern = '\.\s+["\u0027]?(\.[\\\/][^\s"\u0027;|]+\.\w+)["\u0027]?'
                    # Pattern 3: .\path\script.ps1 (direct invocation at start of line)
                    $directCallPattern = '(?m)^\s*["\u0027]?(\.[\\\/][^\s"\u0027;|]+\.\w+)["\u0027]?'
                    # Pattern 4: Import-Module with file path (not module name)
                    $importModulePattern = 'Import-Module\s+["\u0027]?([^\s"\u0027;|]+\.psm1)["\u0027]?'
                    # Pattern 5: Dynamic invocations - & $variable or Invoke-Expression
                    $dynamicPattern = '(?:&\s+\$\w+|Invoke-Expression)'

                    # Extract call-operator references (& .\script.ps1)
                    $matches_co = [regex]::Matches($scriptBody, $callOperatorPattern)
                    foreach ($m in $matches_co) {
                        $ref = $m.Groups[1].Value
                        # Skip if the reference is a variable (starts with $)
                        if ($ref -match '^\$') { continue }
                        $resolved = Resolve-ScriptReference -Reference $ref -ScriptRoot $ScriptRoot
                        $fileType = Get-ScriptFileType $ref
                        $status = if ($resolved) { 'RESOLVED' } else { 'UNRESOLVED' }
                        $results += [PSCustomObject]@{
                            Pipeline    = $SourceFile
                            Stage       = $stage.Name
                            Job         = $job.Name
                            Step        = $step.Name
                            Reference   = $ref
                            ResolvedPath = $resolved
                            Status      = $status
                            FileType    = $fileType
                            TraceDepth  = 'detailed'
                            Notes       = "Found in inline $($step.ScriptType) block via call operator"
                        }
                        $hasExternalRef = $true
                    }

                    # Extract dot-sourced references (. .\script.ps1)
                    $matches_ds = [regex]::Matches($scriptBody, $dotSourcePattern)
                    foreach ($m in $matches_ds) {
                        $ref = $m.Groups[1].Value
                        $resolved = Resolve-ScriptReference -Reference $ref -ScriptRoot $ScriptRoot
                        $fileType = Get-ScriptFileType $ref
                        $status = if ($resolved) { 'RESOLVED' } else { 'UNRESOLVED' }
                        $results += [PSCustomObject]@{
                            Pipeline    = $SourceFile
                            Stage       = $stage.Name
                            Job         = $job.Name
                            Step        = $step.Name
                            Reference   = $ref
                            ResolvedPath = $resolved
                            Status      = $status
                            FileType    = $fileType
                            TraceDepth  = 'detailed'
                            Notes       = "Found in inline $($step.ScriptType) block via dot-sourcing"
                        }
                        $hasExternalRef = $true
                    }

                    # Extract direct invocation references (.\script.ps1 at line start)
                    $matches_dc = [regex]::Matches($scriptBody, $directCallPattern)
                    foreach ($m in $matches_dc) {
                        $ref = $m.Groups[1].Value
                        # Avoid duplicates with call-operator matches
                        $alreadyFound = $results | Where-Object {
                            $_.Step -eq $step.Name -and $_.Reference -eq $ref -and
                            $_.Stage -eq $stage.Name -and $_.Job -eq $job.Name
                        }
                        if ($alreadyFound) { continue }
                        $resolved = Resolve-ScriptReference -Reference $ref -ScriptRoot $ScriptRoot
                        $fileType = Get-ScriptFileType $ref
                        $status = if ($resolved) { 'RESOLVED' } else { 'UNRESOLVED' }
                        $results += [PSCustomObject]@{
                            Pipeline    = $SourceFile
                            Stage       = $stage.Name
                            Job         = $job.Name
                            Step        = $step.Name
                            Reference   = $ref
                            ResolvedPath = $resolved
                            Status      = $status
                            FileType    = $fileType
                            TraceDepth  = 'detailed'
                            Notes       = "Found in inline $($step.ScriptType) block via direct invocation"
                        }
                        $hasExternalRef = $true
                    }

                    # Extract Import-Module references to .psm1 files
                    $matches_im = [regex]::Matches($scriptBody, $importModulePattern)
                    foreach ($m in $matches_im) {
                        $ref = $m.Groups[1].Value
                        $resolved = Resolve-ScriptReference -Reference $ref -ScriptRoot $ScriptRoot
                        $status = if ($resolved) { 'RESOLVED' } else { 'UNRESOLVED' }
                        $results += [PSCustomObject]@{
                            Pipeline    = $SourceFile
                            Stage       = $stage.Name
                            Job         = $job.Name
                            Step        = $step.Name
                            Reference   = $ref
                            ResolvedPath = $resolved
                            Status      = $status
                            FileType    = 'psm1'
                            TraceDepth  = 'detailed'
                            Notes       = "Import-Module reference in inline $($step.ScriptType) block"
                        }
                        $hasExternalRef = $true
                    }

                    # Flag dynamic invocations that cannot be resolved statically
                    $matches_dyn = [regex]::Matches($scriptBody, $dynamicPattern)
                    if ($matches_dyn.Count -gt 0) {
                        $results += [PSCustomObject]@{
                            Pipeline    = $SourceFile
                            Stage       = $stage.Name
                            Job         = $job.Name
                            Step        = $step.Name
                            Reference   = $matches_dyn[0].Value
                            ResolvedPath = ''
                            Status      = 'DYNAMIC'
                            FileType    = 'unknown'
                            TraceDepth  = 'skip'
                            Notes       = 'Dynamic invocation detected - cannot trace statically'
                        }
                        $hasExternalRef = $true
                    }

                    # If no external references were found, mark the step as INLINE
                    if (-not $hasExternalRef) {
                        $results += [PSCustomObject]@{
                            Pipeline    = $SourceFile
                            Stage       = $stage.Name
                            Job         = $job.Name
                            Step        = $step.Name
                            Reference   = "(inline $($step.ScriptType))"
                            ResolvedPath = ''
                            Status      = 'INLINE'
                            FileType    = if ($step.ScriptType -in @('powershell','pwsh')) { 'ps1' } elseif ($step.ScriptType -eq 'bash') { 'sh' } else { 'unknown' }
                            TraceDepth  = 'detailed'
                            Notes       = "Inline $($step.ScriptType) block with no external file references"
                        }
                    }
                }

                # ── Template references at the step level ──
                # Steps can reference external YAML templates. These are noted but
                # marked as UNSUPPORTED since template expansion requires Azure DevOps
                # server-side resolution.
                if ($step.Name -match '^Template:\s*(.+)$') {
                    $templateRef = $Matches[1]
                    $results += [PSCustomObject]@{
                        Pipeline    = $SourceFile
                        Stage       = $stage.Name
                        Job         = $job.Name
                        Step        = $step.Name
                        Reference   = $templateRef
                        ResolvedPath = ''
                        Status      = 'UNSUPPORTED'
                        FileType    = 'unknown'
                        TraceDepth  = 'skip'
                        Notes       = 'Template reference - requires Azure DevOps server-side expansion'
                    }
                }
            }
        }
    }

    return $results
}

# This function writes the script discovery manifest to a JSON file. The manifest
# includes a header with generation metadata, all scan entries grouped by status,
# and a summary of counts by status category. Also prints a human-readable summary
# to the console for immediate operator feedback.
function Export-ScriptManifest {
    param(
        [array]$Entries,
        [string]$OutputPath,
        [string]$PipelineSource,
        [string]$ScriptRoot
    )

    # Build summary counts by status category
    $grouped = $Entries | Group-Object -Property Status
    $summary = @{}
    foreach ($g in $grouped) {
        $summary[$g.Name] = $g.Count
    }
    # Ensure all status keys exist for consistent output
    foreach ($status in @('RESOLVED', 'UNRESOLVED', 'INLINE', 'DYNAMIC', 'UNSUPPORTED')) {
        if (-not $summary.ContainsKey($status)) { $summary[$status] = 0 }
    }

    # Sort entries by status for readability (RESOLVED first, then UNRESOLVED, etc.)
    $statusOrder = @('RESOLVED', 'UNRESOLVED', 'DYNAMIC', 'INLINE', 'UNSUPPORTED')
    $sortedEntries = $Entries | Sort-Object {
        $idx = $statusOrder.IndexOf($_.Status)
        if ($idx -lt 0) { 999 } else { $idx }
    }, Pipeline, Stage, Job, Step

    # Construct the manifest object
    $manifest = [ordered]@{
        header  = [ordered]@{
            generatedAt     = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            generatedBy     = 'Document-Pipeline.ps1 -ScanScripts'
            pipelineSource  = $PipelineSource
            scriptRoot      = $ScriptRoot
            totalEntries    = $Entries.Count
        }
        summary = [ordered]@{
            resolved    = $summary['RESOLVED']
            unresolved  = $summary['UNRESOLVED']
            inline      = $summary['INLINE']
            dynamic     = $summary['DYNAMIC']
            unsupported = $summary['UNSUPPORTED']
        }
        entries = @($sortedEntries | ForEach-Object {
            [ordered]@{
                pipeline     = $_.Pipeline
                stage        = $_.Stage
                job          = $_.Job
                step         = $_.Step
                reference    = $_.Reference
                resolvedPath = $_.ResolvedPath
                status       = $_.Status
                fileType     = $_.FileType
                traceDepth   = $_.TraceDepth
                notes        = $_.Notes
            }
        })
    }

    # Write the manifest JSON to disk
    $dir = Split-Path $OutputPath -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $manifest | ConvertTo-Json -Depth 10 | Set-Content -Path $OutputPath -Encoding UTF8

    # Print human-readable summary to the console
    Write-Host ''
    Write-Host '╔══════════════════════════════════════════════════════════════╗' -ForegroundColor Cyan
    Write-Host '║              SCRIPT DISCOVERY SCAN RESULTS                  ║' -ForegroundColor Cyan
    Write-Host '╠══════════════════════════════════════════════════════════════╣' -ForegroundColor Cyan
    Write-Host "║  Pipeline source : $PipelineSource" -ForegroundColor Cyan
    Write-Host "║  Script root     : $ScriptRoot" -ForegroundColor Cyan
    Write-Host "║  Total entries   : $($Entries.Count)" -ForegroundColor Cyan
    Write-Host '╠══════════════════════════════════════════════════════════════╣' -ForegroundColor Cyan
    Write-Host "║  RESOLVED        : $($summary['RESOLVED'])" -ForegroundColor Green
    Write-Host "║  UNRESOLVED      : $($summary['UNRESOLVED'])" -ForegroundColor $(if ($summary['UNRESOLVED'] -gt 0) { 'Yellow' } else { 'Green' })
    Write-Host "║  INLINE          : $($summary['INLINE'])" -ForegroundColor Gray
    Write-Host "║  DYNAMIC         : $($summary['DYNAMIC'])" -ForegroundColor $(if ($summary['DYNAMIC'] -gt 0) { 'Yellow' } else { 'Gray' })
    Write-Host "║  UNSUPPORTED     : $($summary['UNSUPPORTED'])" -ForegroundColor $(if ($summary['UNSUPPORTED'] -gt 0) { 'Yellow' } else { 'Gray' })
    Write-Host '╚══════════════════════════════════════════════════════════════╝' -ForegroundColor Cyan
    Write-Host ''
    Write-Host "Manifest written to: $OutputPath" -ForegroundColor Green

    # If there are unresolved entries, print guidance for the operator
    if ($summary['UNRESOLVED'] -gt 0) {
        Write-Host ''
        Write-Host 'ACTION REQUIRED: Some script references could not be resolved.' -ForegroundColor Yellow
        Write-Host 'Open the manifest file and update the following for each UNRESOLVED entry:' -ForegroundColor Yellow
        Write-Host '  1. Set "resolvedPath" to the correct absolute path on disk' -ForegroundColor Yellow
        Write-Host '  2. Change "status" from "UNRESOLVED" to "RESOLVED"' -ForegroundColor Yellow
        Write-Host '  3. Optionally set "traceDepth" to "shallow" or "skip" to control analysis depth' -ForegroundColor Yellow
        Write-Host ''
        Write-Host 'Unresolved references:' -ForegroundColor Yellow
        $unresolved = $Entries | Where-Object { $_.Status -eq 'UNRESOLVED' }
        foreach ($u in $unresolved) {
            Write-Host "  - [$($u.Pipeline)] $($u.Stage) > $($u.Job) > $($u.Step): $($u.Reference)" -ForegroundColor Yellow
        }
    }

    if ($summary['DYNAMIC'] -gt 0) {
        Write-Host ''
        Write-Host 'NOTE: Dynamic invocations were detected and cannot be traced statically.' -ForegroundColor DarkYellow
        Write-Host 'Review these entries manually and add resolved paths if applicable.' -ForegroundColor DarkYellow
    }

    Write-Host ''
}

# This function reads and validates an existing script discovery manifest JSON file.
# Returns the parsed entries as an array of PSCustomObjects for consumption by
# Stage 2 (-TraceScripts) or other downstream tools. Validates that the file
# contains the expected structure (header, summary, entries).
function Import-ScriptManifest {
    param([string]$ManifestPath)

    if (-not (Test-Path $ManifestPath -PathType Leaf)) {
        Write-Error "Manifest file not found: $ManifestPath"
        return $null
    }

    try {
        $content = Get-Content -Path $ManifestPath -Raw -Encoding UTF8
        $manifest = $content | ConvertFrom-Json
    } catch {
        Write-Error "Failed to parse manifest JSON: $_"
        return $null
    }

    # Validate required structure
    if (-not $manifest.header) {
        Write-Error "Invalid manifest: missing 'header' section."
        return $null
    }
    if (-not $manifest.entries) {
        Write-Error "Invalid manifest: missing 'entries' section."
        return $null
    }
    if (-not $manifest.summary) {
        Write-Warning "Manifest is missing 'summary' section - entries will still be returned."
    }

    Write-Host "Loaded manifest from: $ManifestPath" -ForegroundColor Cyan
    Write-Host "  Generated: $($manifest.header.generatedAt) | Entries: $($manifest.entries.Count)" -ForegroundColor Gray

    # Convert JSON entries back to PSCustomObjects with consistent property names
    $entries = @()
    foreach ($e in $manifest.entries) {
        $entries += [PSCustomObject]@{
            Pipeline     = $e.pipeline
            Stage        = $e.stage
            Job          = $e.job
            Step         = $e.step
            Reference    = $e.reference
            ResolvedPath = $e.resolvedPath
            Status       = $e.status
            FileType     = $e.fileType
            TraceDepth   = $e.traceDepth
            Notes        = $e.notes
        }
    }

    return $entries
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 10: SCRIPT TRACING - STAGE 2 (-TraceScripts)
# ══════════════════════════════════════════════════════════════════════════════
# Stage 2 reads a completed manifest (produced by Stage 1 -ScanScripts), parses
# each RESOLVED PowerShell script using the PowerShell AST parser, extracts
# function definitions, function calls, command invocations, module imports,
# and control flow structures, then generates nested Mermaid diagrams showing
# what each script actually does. Discovered sub-references (dot-sourced files,
# imported modules) are flagged for iterative discovery.

# This function parses a PowerShell script using the AST and extracts structural
# information: function definitions, function calls, command invocations (e.g.,
# Stop-Service, Invoke-RestMethod), dot-source and Import-Module references,
# try/catch blocks, and if/else branches.
# Accepts EITHER a file path (-ScriptPath) OR an inline script string
# (-ScriptContent with -ScriptLabel). This dual-mode design supports both
# external .ps1 files (Stage 2 -TraceScripts) and inline PowerShell blocks
# embedded directly in pipeline YAML (-TraceInline).
# Returns a PSCustomObject with categorised findings.
function Invoke-ScriptTrace {
    param(
        [string]$ScriptPath,
        [string]$ScriptContent,
        [string]$ScriptLabel = 'inline',
        [string]$TraceDepth = 'detailed'
    )

    $isInline = [bool]$ScriptContent
    $displayName = if ($isInline) { $ScriptLabel } else { [System.IO.Path]::GetFileName($ScriptPath) }
    $displayPath = if ($isInline) { "(inline: $ScriptLabel)" } else { $ScriptPath }

    $result = [PSCustomObject]@{
        ScriptPath     = $displayPath
        FileName       = $displayName
        IsInline       = $isInline
        Functions      = @()
        FunctionCalls  = @()
        Commands       = @()
        SubReferences  = @()
        ExternalCalls  = @()
        HasTryCatch    = $false
        HasBranching   = $false
        ParseErrors    = @()
    }

    $errors = $null
    $tokens = $null
    if ($isInline) {
        $ast = [System.Management.Automation.Language.Parser]::ParseInput(
            $ScriptContent, [ref]$tokens, [ref]$errors
        )
    } else {
        $ast = [System.Management.Automation.Language.Parser]::ParseFile(
            $ScriptPath, [ref]$tokens, [ref]$errors
        )
    }

    if ($errors.Count -gt 0) {
        $result.ParseErrors = @($errors | ForEach-Object { $_.Message })
    }

    if (-not $ast) { return $result }

    # Extract function definitions
    $funcDefs = $ast.FindAll({ $args[0] -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true)
    foreach ($fd in $funcDefs) {
        $funcInfo = [PSCustomObject]@{
            Name       = $fd.Name
            StartLine  = $fd.Extent.StartLineNumber
            EndLine    = $fd.Extent.EndLineNumber
            Parameters = @()
        }
        if ($fd.Parameters) {
            $funcInfo.Parameters = @($fd.Parameters | ForEach-Object { $_.Name.VariablePath.UserPath })
        }
        if ($fd.Body.ParamBlock) {
            $funcInfo.Parameters = @($fd.Body.ParamBlock.Parameters | ForEach-Object { $_.Name.VariablePath.UserPath })
        }
        $result.Functions += $funcInfo
    }

    # Extract all command invocations
    $commands = $ast.FindAll({ $args[0] -is [System.Management.Automation.Language.CommandAst] }, $true)
    $funcNames = @($result.Functions | ForEach-Object { $_.Name })

    foreach ($cmd in $commands) {
        $cmdName = $cmd.GetCommandName()
        if (-not $cmdName) { continue }

        # Categorise the command
        if ($cmdName -in $funcNames) {
            $result.FunctionCalls += $cmdName
        }
        elseif ($cmdName -eq '.' -or $cmdName -eq '&') {
            # Dot-source or call operator - check if calling a file
            if ($cmd.CommandElements.Count -ge 2) {
                $target = $cmd.CommandElements[1].ToString()
                if ($target -match '\.(ps1|psm1)') {
                    $result.SubReferences += [PSCustomObject]@{
                        Type      = if ($cmdName -eq '.') { 'dot-source' } else { 'call-operator' }
                        Reference = $target
                        Line      = $cmd.Extent.StartLineNumber
                    }
                }
            }
        }
        elseif ($cmdName -eq 'Import-Module') {
            if ($cmd.CommandElements.Count -ge 2) {
                $modulePath = $cmd.CommandElements[1].ToString()
                $result.SubReferences += [PSCustomObject]@{
                    Type      = 'Import-Module'
                    Reference = $modulePath
                    Line      = $cmd.Extent.StartLineNumber
                }
            }
        }
        elseif ($cmdName -match '^(Invoke-RestMethod|Invoke-WebRequest|Invoke-SqlCmd|Send-MailMessage|Invoke-Command)$') {
            $argSummary = ''
            if ($cmd.CommandElements.Count -ge 2) {
                $argSummary = ($cmd.CommandElements | Select-Object -Skip 1 | ForEach-Object { $_.ToString() }) -join ' '
                if ($argSummary.Length -gt 100) { $argSummary = $argSummary.Substring(0, 97) + '...' }
            }
            $result.ExternalCalls += [PSCustomObject]@{
                Command   = $cmdName
                Arguments = $argSummary
                Line      = $cmd.Extent.StartLineNumber
            }
        }
        else {
            $result.Commands += $cmdName
        }
    }

    # Deduplicate commands, keep frequency
    $result.Commands = @($result.Commands | Group-Object | Sort-Object Count -Descending |
        ForEach-Object { [PSCustomObject]@{ Name = $_.Name; Count = $_.Count } })

    $result.FunctionCalls = @($result.FunctionCalls | Group-Object |
        ForEach-Object { [PSCustomObject]@{ Name = $_.Name; Count = $_.Count } })

    # Detect try/catch
    $tryCatch = $ast.FindAll({ $args[0] -is [System.Management.Automation.Language.TryStatementAst] }, $true)
    $result.HasTryCatch = ($tryCatch.Count -gt 0)

    # Detect branching (if/switch)
    $ifStatements = $ast.FindAll({ $args[0] -is [System.Management.Automation.Language.IfStatementAst] }, $true)
    $switchStatements = $ast.FindAll({ $args[0] -is [System.Management.Automation.Language.SwitchStatementAst] }, $true)
    $result.HasBranching = ($ifStatements.Count -gt 0 -or $switchStatements.Count -gt 0)

    if ($TraceDepth -eq 'shallow') {
        $result.Commands = @()
        $result.ExternalCalls = @()
    }

    return $result
}

# This function generates a Mermaid diagram for a single traced script, showing
# function definitions, call relationships, key commands, external system calls,
# and sub-script references. Returns a Mermaid flowchart string.
function ConvertTo-ScriptDiagram {
    param(
        [PSCustomObject]$TraceResult,
        [string]$PipelineStep
    )

    $mm = [System.Text.StringBuilder]::new()
    $scriptName = $TraceResult.FileName
    $safeBase = Safe-Id $scriptName

    [void]$mm.AppendLine("flowchart TD")

    # Entry point node
    [void]$mm.AppendLine(('    {1}_entry(["{0}"])' -f $( Sanitize-Label $PipelineStep ), ${safeBase}))
    [void]$mm.AppendLine(('    {0}_entry --> {1}_script' -f ${safeBase}, ${safeBase}))
    [void]$mm.AppendLine(('    style {0}_entry fill:#1565c0,stroke:#90caf9,color:#fff' -f ${safeBase}))

    # Script node
    [void]$mm.AppendLine(('    {1}_script["{0}"]' -f $(Sanitize-Label $scriptName), ${safeBase}))
    [void]$mm.AppendLine(('    style {0}_script fill:#263238,stroke:#90a4ae,color:#eceff1,stroke-width:2px' -f ${safeBase}))

    # Functions subgraph
    if ($TraceResult.Functions.Count -gt 0) {
        [void]$mm.AppendLine(('    subgraph {0}_funcs ["Functions"]' -f ${safeBase}))
        [void]$mm.AppendLine("        direction TB")
        foreach ($func in $TraceResult.Functions) {
            $fId = "${safeBase}_fn_$(Safe-Id $func.Name)"
            $paramStr = if ($func.Parameters.Count -gt 0) { " ($($func.Parameters.Count) params)" } else { '' }
            [void]$mm.AppendLine(('        {1}["{0}{2}"]' -f $(Sanitize-Label $func.Name), ${fId}, ${paramStr}))
        }
        [void]$mm.AppendLine("    end")
        [void]$mm.AppendLine(('    style {0}_funcs fill:#37474f,stroke:#78909c,color:#eceff1' -f ${safeBase}))
        [void]$mm.AppendLine(('    {0}_script --> {1}_funcs' -f ${safeBase}, ${safeBase}))

        # Function call relationships
        foreach ($call in $TraceResult.FunctionCalls) {
            $callerId = "${safeBase}_script"
            $targetId = "${safeBase}_fn_$(Safe-Id $call.Name)"
            [void]$mm.AppendLine(('    {1} -.->|"calls x{0}"|{2}' -f $($call.Count), ${callerId}, ${targetId}))
        }
    }

    # Key commands (top 10)
    $keyCommands = @($TraceResult.Commands |
        Where-Object { $_.Name -match '^(Stop|Start|Restart|Set|New|Remove|Get|Copy|Move|Invoke|Install|Uninstall|Enable|Disable|Register|Unregister|Test|Wait|Write)-' } |
        Select-Object -First 10)

    if ($keyCommands.Count -gt 0) {
        [void]$mm.AppendLine(('    subgraph {0}_cmds ["Key Operations"]' -f ${safeBase}))
        [void]$mm.AppendLine("        direction TB")
        $cmdIdx = 0
        foreach ($c in $keyCommands) {
            $cmdIdx++
            $cId = "${safeBase}_cmd${cmdIdx}"
            $countLabel = if ($c.Count -gt 1) { " x$($c.Count)" } else { '' }
            [void]$mm.AppendLine(('        {1}["{0}{2}"]' -f $(Sanitize-Label $c.Name), ${cId}, ${countLabel}))
        }
        [void]$mm.AppendLine("    end")
        [void]$mm.AppendLine(('    style {0}_cmds fill:#2e7d32,stroke:#81c784,color:#fff' -f ${safeBase}))
        [void]$mm.AppendLine(('    {0}_script --> {1}_cmds' -f ${safeBase}, ${safeBase}))
    }

    # External system calls
    if ($TraceResult.ExternalCalls.Count -gt 0) {
        [void]$mm.AppendLine(('    subgraph {0}_ext ["External Systems"]' -f ${safeBase}))
        [void]$mm.AppendLine("        direction TB")
        $extIdx = 0
        foreach ($ext in $TraceResult.ExternalCalls) {
            $extIdx++
            $eId = "${safeBase}_ext${extIdx}"
            [void]$mm.AppendLine(('        {1}[( "{0}" )]' -f $(Sanitize-Label $ext.Command), ${eId}))
            [void]$mm.AppendLine(('        style {0} fill:#e65100,stroke:#ffb74d,color:#fff' -f $eId))
        }
        [void]$mm.AppendLine("    end")
        [void]$mm.AppendLine(('    {0}_script --> {1}_ext' -f ${safeBase}, ${safeBase}))
    }

    # Sub-script references
    if ($TraceResult.SubReferences.Count -gt 0) {
        $subIdx = 0
        foreach ($sub in $TraceResult.SubReferences) {
            $subIdx++
            $subId = "${safeBase}_sub${subIdx}"
            $subLabel = Sanitize-Label $sub.Reference
            [void]$mm.AppendLine(('    {1}[/"{0}: {2}"/]' -f $($sub.Type), ${subId}, $subLabel))
            [void]$mm.AppendLine(('    style {0} fill:#880e4f,stroke:#f48fb1,color:#fff' -f $subId))
            [void]$mm.AppendLine(('    {0}_script --> {1}' -f ${safeBase}, $subId))
        }
    }

    # Error handling / branching indicators
    $indicators = @()
    if ($TraceResult.HasTryCatch) { $indicators += 'try/catch' }
    if ($TraceResult.HasBranching) { $indicators += 'if/switch' }
    if ($indicators.Count -gt 0) {
        $indId = "${safeBase}_flow"
        $flowLabel = $indicators -join ', '
        [void]$mm.AppendLine("    ${indId}{`"Control Flow: $flowLabel`"}")
        [void]$mm.AppendLine("    style $indId fill:#283593,stroke:#9fa8da,color:#fff")
        [void]$mm.AppendLine("    ${safeBase}_script --> $indId")
    }

    if ($TraceResult.ParseErrors.Count -gt 0) {
        $errId = "${safeBase}_parseerr"
        [void]$mm.AppendLine(('    {1}["Parse Errors: {0}"]' -f $($TraceResult.ParseErrors.Count), ${errId}))
        [void]$mm.AppendLine(('    style {0} fill:#b71c1c,stroke:#ef9a9a,color:#fff' -f $errId))
    }

    return $mm.ToString()
}

# This function generates the complete Markdown output for all traced scripts,
# including a summary table and individual script diagrams. Also produces a
# "newly discovered references" report for iterative manifest updates.
function ConvertTo-TraceReport {
    param(
        [array]$TraceResults,
        [array]$ManifestEntries
    )

    $md = [System.Text.StringBuilder]::new()

    [void]$md.AppendLine('## Script Trace Analysis')
    [void]$md.AppendLine()

    # Summary table
    [void]$md.AppendLine('### Traced Scripts Summary')
    [void]$md.AppendLine()
    [void]$md.AppendLine('| Script | Functions | Commands | External Calls | Sub-References | Error Handling |')
    [void]$md.AppendLine('|--------|-----------|----------|----------------|----------------|----------------|')

    foreach ($tr in $TraceResults) {
        $errHandling = @()
        if ($tr.Trace.HasTryCatch) { $errHandling += 'try/catch' }
        if ($tr.Trace.HasBranching) { $errHandling += 'branching' }
        $errStr = if ($errHandling.Count -gt 0) { $errHandling -join ', ' } else { 'none' }
        $extCount = $tr.Trace.ExternalCalls.Count
        $subCount = $tr.Trace.SubReferences.Count

        [void]$md.AppendLine(('| ``' + (Esc-Format $tr.Trace.FileName) + '`` | ' + $tr.Trace.Functions.Count + ' | ' + $tr.Trace.Commands.Count + ' | ' + $extCount + ' | ' + $subCount + ' | ' + $errStr + ' |'))
    }
    [void]$md.AppendLine()

    # Individual script diagrams
    [void]$md.AppendLine('### Script Detail Diagrams')
    [void]$md.AppendLine()

    foreach ($tr in $TraceResults) {
        [void]$md.AppendLine(('#### ' + (Esc-Format $tr.Trace.FileName)))
        [void]$md.AppendLine()
        [void]$md.AppendLine(('**Called from:** ' + (Esc-Format $tr.Entry.Pipeline) + ' > ' + (Esc-Format $tr.Entry.Stage) + ' > ' + (Esc-Format $tr.Entry.Job) + ' > ' + (Esc-Format $tr.Entry.Step)))
        [void]$md.AppendLine(('**Path:** ``' + (Esc-Format $tr.Trace.ScriptPath) + '``'))
        [void]$md.AppendLine()

        if ($tr.Trace.ParseErrors.Count -gt 0) {
            [void]$md.AppendLine('> **Parse Errors:** The following errors occurred while parsing this script:')
            foreach ($err in $tr.Trace.ParseErrors) {
                [void]$md.AppendLine(('> - ' + (Esc-Format $err)))
            }
            [void]$md.AppendLine()
        }

        $diagram = ConvertTo-ScriptDiagram -TraceResult $tr.Trace -PipelineStep $tr.Entry.Step
        [void]$md.AppendLine('```mermaid')
        [void]$md.AppendLine($diagram)
        [void]$md.AppendLine('```')
        [void]$md.AppendLine()

        # Function inventory
        if ($tr.Trace.Functions.Count -gt 0) {
            [void]$md.AppendLine('<details>')
            [void]$md.AppendLine('<summary>Functions in ' + (Esc-Format $tr.Trace.FileName) + ' (' + $tr.Trace.Functions.Count + ')</summary>')
            [void]$md.AppendLine()
            [void]$md.AppendLine('| Function | Lines | Parameters |')
            [void]$md.AppendLine('|----------|-------|------------|')
            foreach ($fn in $tr.Trace.Functions) {
                $paramList = if ($fn.Parameters.Count -gt 0) { $fn.Parameters -join ', ' } else { '-' }
                [void]$md.AppendLine(('| ``' + (Esc-Format $fn.Name) + '`` | ' + $fn.StartLine + '–' + $fn.EndLine + ' | ' + (Esc-Format $paramList) + ' |'))
            }
            [void]$md.AppendLine()
            [void]$md.AppendLine('</details>')
            [void]$md.AppendLine()
        }

        # External calls detail
        if ($tr.Trace.ExternalCalls.Count -gt 0) {
            [void]$md.AppendLine('<details>')
            [void]$md.AppendLine('<summary>External System Calls (' + $tr.Trace.ExternalCalls.Count + ')</summary>')
            [void]$md.AppendLine()
            [void]$md.AppendLine('| Command | Line | Arguments |')
            [void]$md.AppendLine('|---------|------|-----------|')
            foreach ($ext in $tr.Trace.ExternalCalls) {
                $args = if ($ext.Arguments) { "``$($ext.Arguments)``" } else { '-' }
                [void]$md.AppendLine(('| ``' + (Esc-Format $ext.Command) + '`` | ' + $ext.Line + ' | ' + (Esc-Format $args) + ' |'))
            }
            [void]$md.AppendLine()
            [void]$md.AppendLine('</details>')
            [void]$md.AppendLine()
        }
    }

    # Newly discovered sub-references
    $allNewRefs = @()
    foreach ($tr in $TraceResults) {
        foreach ($sub in $tr.Trace.SubReferences) {
            $alreadyInManifest = $ManifestEntries | Where-Object {
                $_.Reference -eq $sub.Reference -or $_.ResolvedPath -like "*$($sub.Reference)*"
            }
            if (-not $alreadyInManifest) {
                $allNewRefs += [PSCustomObject]@{
                    DiscoveredIn = $tr.Trace.FileName
                    Type         = $sub.Type
                    Reference    = $sub.Reference
                    Line         = $sub.Line
                }
            }
        }
    }

    if ($allNewRefs.Count -gt 0) {
        [void]$md.AppendLine('### Newly Discovered References')
        [void]$md.AppendLine()
        [void]$md.AppendLine('> The following script/module references were discovered during tracing but')
        [void]$md.AppendLine('> are not yet in the manifest. Re-run `-ScanScripts` to include them, or')
        [void]$md.AppendLine('> add them manually to the manifest JSON.')
        [void]$md.AppendLine()
        [void]$md.AppendLine('| Discovered In | Type | Reference | Line |')
        [void]$md.AppendLine('|---------------|------|-----------|------|')
        foreach ($ref in $allNewRefs) {
            [void]$md.AppendLine(('| ``' + (Esc-Format $ref.DiscoveredIn) + '`` | ' + $ref.Type + ' | ``' + (Esc-Format $ref.Reference) + '`` | ' + $ref.Line + ' |'))
        }
        [void]$md.AppendLine()
    }

    [void]$md.AppendLine('---')
    [void]$md.AppendLine()
    return $md.ToString()
}

# This function exports traced script diagrams as standalone .mmd files for
# external rendering. One file per traced script.
function Export-ScriptMermaid {
    param(
        [array]$TraceResults,
        [string]$OutputDir
    )

    if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

    foreach ($tr in $TraceResults) {
        $diagram = ConvertTo-ScriptDiagram -TraceResult $tr.Trace -PipelineStep $tr.Entry.Step
        $baseName = [System.IO.Path]::GetFileNameWithoutExtension($tr.Trace.FileName)
        $outPath = Join-Path $OutputDir "script_${baseName}.mmd"
        Set-Content -Path $outPath -Value $diagram.TrimEnd() -Encoding UTF8
        Write-Host "  -> $outPath" -ForegroundColor Green
    }
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 12: DRAW.IO EXPORT (-DrawIO)
# ══════════════════════════════════════════════════════════════════════════════
# Generates draw.io (diagrams.net) compatible XML files using the mxGraph format.
# These files can be opened in draw.io desktop, diagrams.net web app, the VS Code
# draw.io extension, and the Confluence draw.io plugin. The diagram uses swimlane
# layout with stages as containers, jobs as sub-containers, steps as process nodes,
# and dependency arrows between elements. Colour coding matches the Mermaid diagram
# scheme. If trace results are available, script details are included as nested
# child nodes within their parent step.

# This function generates a single draw.io XML file for a pipeline. The layout
# uses a top-down hierarchical arrangement with automatic positioning.
function Export-DrawIO {
    param(
        [hashtable]$Pipeline,
        [string]$SourceFile,
        [string]$OutputDir,
        [array]$TraceResults
    )

    $stages = Get-Stages $Pipeline
    if ($stages.Count -eq 0) { return }

    $name = if ($Pipeline['name']) { $Pipeline['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($SourceFile) }
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($SourceFile)

    if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

    $xml = [System.Text.StringBuilder]::new()
    [void]$xml.AppendLine('<?xml version="1.0" encoding="UTF-8"?>')
    [void]$xml.AppendLine('<mxfile host="app.diagrams.net" type="device">')
    [void]$xml.AppendLine('  <diagram name="Pipeline" id="pipeline_diagram">')
    [void]$xml.AppendLine('    <mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1654" pageHeight="1169" math="0" shadow="0">')
    [void]$xml.AppendLine('      <root>')
    [void]$xml.AppendLine('        <mxCell id="0"/>')
    [void]$xml.AppendLine('        <mxCell id="1" parent="0"/>')

    function Esc([string]$s) { [System.Security.SecurityElement]::Escape($s) }

    # Helper to build mxCell XML without backtick-quote issues
    function Add-MxCell {
        param([string]$Id, [string]$Value, [string]$Style, [string]$Vertex, [string]$Edge, [string]$Source, [string]$Target, [string]$Parent)
        $parts = @("id=""$Id""")
        if ($Value) { $parts += "value=""$Value""" }
        if ($Style) { $parts += "style=""$Style""" }
        if ($Vertex) { $parts += "vertex=""$Vertex""" }
        if ($Edge) { $parts += "edge=""$Edge""" }
        if ($Source) { $parts += "source=""$Source""" }
        if ($Target) { $parts += "target=""$Target""" }
        if ($Parent) { $parts += "parent=""$Parent""" }
        return '        <mxCell ' + ($parts -join ' ') + '>'
    }

    function Add-MxGeo {
        param([string]$X, [string]$Y, [string]$W, [string]$H, [switch]$Relative)
        if ($Relative) { return '          <mxGeometry relative="1" as="geometry"/>' }
        return "          <mxGeometry x=""$X"" y=""$Y"" width=""$W"" height=""$H"" as=""geometry""/>"
    }

    $cellId = 100
    $stageIds = @{}
    $prevStageId = $null

    $stageX = 40; $stageY = 40; $stageWidth = 340; $stageGap = 30
    $jobYOffset = 40; $stepHeight = 40; $stepGap = 10

    foreach ($stage in $stages) {
        $cellId++
        $sId = $cellId
        $stageIds[$stage.Id] = $sId

        $totalSteps = 0
        foreach ($job in $stage.Jobs) { $totalSteps += [Math]::Max($job.Steps.Count, 1) + 1 }
        $stageHeight = [Math]::Max(($totalSteps * ($stepHeight + $stepGap)) + 80, 120)

        $stageStyle = 'swimlane;startSize=30;fillColor=#dae8fc;strokeColor=#1976d2;rounded=1;arcSize=8;fontStyle=1;fontSize=13;'
        [void]$xml.AppendLine((Add-MxCell -Id $sId -Value (Esc $stage.Name) -Style $stageStyle -Vertex '1' -Parent '1'))
        [void]$xml.AppendLine((Add-MxGeo -X $stageX -Y $stageY -W $stageWidth -H $stageHeight))
        [void]$xml.AppendLine('        </mxCell>')

        $jobY = $jobYOffset
        foreach ($job in $stage.Jobs) {
            $cellId++; $jId = $cellId

            $jobLabel = Esc $job.Name
            if ($job.Type -eq 'deployment') { $jobLabel += ' [deploy]' }
            if ($job.Environment) { $jobLabel += " ($(Esc $job.Environment))" }

            $jobStyle = if ($job.Type -eq 'deployment') { 'swimlane;startSize=24;fillColor=#d5e8d4;strokeColor=#4caf50;rounded=1;arcSize=6;fontSize=11;fontStyle=1;' }
                        else { 'swimlane;startSize=24;fillColor=#f5f5f5;strokeColor=#666;rounded=1;arcSize=6;fontSize=11;fontStyle=1;' }
            $jobInnerHeight = [Math]::Max($job.Steps.Count * ($stepHeight + $stepGap) + 10, 50)
            $jobW = $stageWidth - 20

            [void]$xml.AppendLine((Add-MxCell -Id $jId -Value $jobLabel -Style $jobStyle -Vertex '1' -Parent $sId))
            [void]$xml.AppendLine((Add-MxGeo -X 10 -Y $jobY -W $jobW -H $jobInnerHeight))
            [void]$xml.AppendLine('        </mxCell>')

            $stepY = 30; $prevStepCellId = $null; $stepNum = 0
            foreach ($step in $job.Steps) {
                $stepNum++; $cellId++; $stepCellId = $cellId
                $stepLabel = Esc "$stepNum. $($step.Name -replace '``', '')"
                if (-not $step.Enabled) { $stepLabel += ' [DISABLED]' }

                $stepStyle = if (-not $step.Enabled) { 'rounded=1;whiteSpace=wrap;fillColor=#e0e0e0;strokeColor=#999;fontColor=#999;fontSize=10;' }
                             elseif ($step.Condition) { 'rhombus;whiteSpace=wrap;fillColor=#fff3cd;strokeColor=#ffc107;fontSize=10;' }
                             else { 'rounded=1;whiteSpace=wrap;fillColor=#fff;strokeColor=#333;fontSize=10;' }

                $stepW = $stageWidth - 50
                [void]$xml.AppendLine((Add-MxCell -Id $stepCellId -Value $stepLabel -Style $stepStyle -Vertex '1' -Parent $jId))
                [void]$xml.AppendLine((Add-MxGeo -X 5 -Y $stepY -W $stepW -H $stepHeight))
                [void]$xml.AppendLine('        </mxCell>')

                if ($prevStepCellId) {
                    $cellId++
                    [void]$xml.AppendLine((Add-MxCell -Id $cellId -Style 'edgeStyle=orthogonalEdgeStyle;rounded=1;strokeColor=#666;' -Edge '1' -Source $prevStepCellId -Target $stepCellId -Parent $jId))
                    [void]$xml.AppendLine((Add-MxGeo -Relative))
                    [void]$xml.AppendLine('        </mxCell>')
                }

                if ($TraceResults) {
                    $matchingTraces = @($TraceResults | Where-Object { $_.Entry.Pipeline -eq $SourceFile -and $_.Entry.Step -eq $step.Name })
                    foreach ($tr in $matchingTraces) {
                        $noteLines = @()
                        foreach ($fn in $tr.Trace.Functions) { $noteLines += "fn: $($fn.Name)" }
                        $topCmds = @($tr.Trace.Commands | Where-Object { $_.Name -match '^(Stop|Start|Restart|Set|New|Remove|Copy|Move|Invoke|Install|Enable|Disable|Test)-' } | Select-Object -First 6)
                        foreach ($c in $topCmds) { $noteLines += "cmd: $($c.Name)" }
                        foreach ($ext in $tr.Trace.ExternalCalls) { $noteLines += "ext: $($ext.Command)" }
                        if ($noteLines.Count -gt 0) {
                            $cellId++
                            $noteText = Esc ($noteLines -join '&#xa;')
                            $noteStyle = 'shape=note;whiteSpace=wrap;fillColor=#fff8e1;strokeColor=#ff9800;fontSize=9;align=left;spacingLeft=4;'
                            $noteH = [Math]::Max($noteLines.Count * 16 + 8, 30)
                            [void]$xml.AppendLine((Add-MxCell -Id $cellId -Value $noteText -Style $noteStyle -Vertex '1' -Parent $jId))
                            [void]$xml.AppendLine((Add-MxGeo -X ($stepW - 20) -Y ($stepY - 5) -W 160 -H $noteH))
                            [void]$xml.AppendLine('        </mxCell>')
                        }
                    }
                }

                $prevStepCellId = $stepCellId
                $stepY += $stepHeight + $stepGap
            }
            $jobY += $jobInnerHeight + 10
        }

        if ($stage.DependsOn.Count -gt 0) {
            foreach ($dep in $stage.DependsOn) {
                if ($stageIds.ContainsKey($dep)) {
                    $cellId++
                    $condLabel = if ($stage.Condition) { Esc (Format-Condition $stage.Condition) } else { '' }
                    [void]$xml.AppendLine((Add-MxCell -Id $cellId -Value $condLabel -Style 'edgeStyle=orthogonalEdgeStyle;rounded=1;strokeWidth=2;strokeColor=#1976d2;fontSize=9;' -Edge '1' -Source $stageIds[$dep] -Target $sId -Parent '1'))
                    [void]$xml.AppendLine((Add-MxGeo -Relative))
                    [void]$xml.AppendLine('        </mxCell>')
                }
            }
        } elseif ($prevStageId) {
            $cellId++
            [void]$xml.AppendLine((Add-MxCell -Id $cellId -Style 'edgeStyle=orthogonalEdgeStyle;rounded=1;strokeWidth=2;strokeColor=#1976d2;' -Edge '1' -Source $prevStageId -Target $sId -Parent '1'))
            [void]$xml.AppendLine((Add-MxGeo -Relative))
            [void]$xml.AppendLine('        </mxCell>')
        }

        $prevStageId = $sId
        $stageY += $stageHeight + $stageGap
    }

    [void]$xml.AppendLine('      </root>')
    [void]$xml.AppendLine('    </mxGraphModel>')
    [void]$xml.AppendLine('  </diagram>')
    [void]$xml.AppendLine('</mxfile>')

    if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }
    $outPath = Join-Path (Resolve-Path $OutputDir).Path "${baseName}.drawio"
    Set-Content -Path $outPath -Value $xml.ToString() -Encoding UTF8 -NoNewline
    Write-Host "  -> $outPath" -ForegroundColor Green
}

# This function walks all parsed pipelines and traces every inline PowerShell
# script block using the AST parser. It extracts the same structural information
# as Invoke-ScriptTrace does for external files (functions, commands, external
# calls, sub-references, control flow) but operates directly on the script body
# strings embedded in the YAML - no manifest or -ScriptRoot required.
# Returns an array of trace result objects compatible with ConvertTo-TraceReport
# and ConvertTo-MindMapData.
function Invoke-InlineTracing {
    param([array]$ParsedPipelines)

    $results = @()

    foreach ($pp in $ParsedPipelines) {
        $pipeline = $pp.Pipeline
        $fileName = $pp.FileName

        $stages = Get-Stages $pipeline
        $stageNum = 0
        foreach ($stage in $stages) {
            $stageNum++
            foreach ($job in $stage.Jobs) {
                foreach ($step in $job.Steps) {
                    if (-not $step.ScriptBody) { continue }
                    if ($step.ScriptType -notin @('powershell', 'pwsh')) { continue }
                    if (-not $step.Enabled) { continue }

                    $label = $step.Name -replace '``', ''
                    $trace = Invoke-ScriptTrace -ScriptContent $step.ScriptBody -ScriptLabel $label

                    # Only include if there's something meaningful to show
                    $hasContent = $trace.Functions.Count -gt 0 -or
                                  $trace.Commands.Count -gt 0 -or
                                  $trace.ExternalCalls.Count -gt 0 -or
                                  $trace.SubReferences.Count -gt 0

                    if ($hasContent) {
                        $entry = [PSCustomObject]@{
                            Pipeline     = $fileName
                            Stage        = $stage.Name
                            Job          = $job.Name
                            Step         = $step.Name
                            Reference    = '(inline)'
                            ResolvedPath = ''
                            Status       = 'INLINE'
                            FileType     = 'ps1'
                            TraceDepth   = 'detailed'
                            Notes        = ''
                        }
                        $results += [PSCustomObject]@{ Entry = $entry; Trace = $trace }
                    }
                }
            }
        }
    }

    return $results
}

# ══════════════════════════════════════════════════════════════════════════════
# FEATURE 11: INTERACTIVE MIND MAP (-MindMap / default with -Html)
# ══════════════════════════════════════════════════════════════════════════════
# Generates an interactive, collapsible/expandable mind map using Markmap.
# The mind map provides a hierarchical drill-down view of the entire pipeline
# structure: Pipeline > Stages > Jobs > Steps > Scripts > Functions > Commands.
# Each node can be clicked to expand or collapse its children, allowing users
# to explore at any depth without being overwhelmed by detail.
#
# By default, when -Html is specified, a companion mind map HTML file is
# generated alongside the main report (with "-mindmap" appended to the
# filename). Use -NoMindMap to suppress this behaviour. Use -MindMap <path>
# to generate only the mind map to a specific path.

# This function converts parsed pipeline structures (and optionally trace
# results) into a nested Markdown outline suitable for Markmap rendering.
# Each heading level maps to a depth in the mind map:
#   # Pipeline Name
#   ## Stage: Name
#   ### Job: Name
#   #### Step: Name
#   ##### Script: filename.ps1
#   ###### Function: FuncName
# Leaf annotations (commands, external calls) use bullet lists.
function ConvertTo-MindMapData {
    param(
        [array]$ParsedPipelines,
        [array]$TraceResults
    )

    # Build a Markmap-compatible tree structure directly as hashtables.
    # Each node: @{ content = "label"; children = @(...) }
    # This is serialised to JSON and passed straight to Markmap.create(),
    # bypassing the Transformer/markmap-lib dependency entirely.
    function New-Node { param([string]$Content) @{ content = $Content; children = @() } }

    $rootChildren = @()

    foreach ($pp in $ParsedPipelines) {
        $pipeline = $pp.Pipeline
        $fileName = $pp.FileName
        $name = if ($pipeline['name']) { $pipeline['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($fileName) }
        $pipelineNode = New-Node $name

        $stages = Get-Stages $pipeline
        $stageNum = 0
        foreach ($stage in $stages) {
            $stageNum++
            $stageLabel = "$stageNum. $($stage.Name)"
            $stageNode = New-Node $stageLabel

            foreach ($job in $stage.Jobs) {
                $jobLabel = $job.Name
                if ($job.Type -eq 'deployment') { $jobLabel += ' [deploy]' }
                if ($job.Environment) { $jobLabel += " ($($job.Environment))" }
                $jobNode = New-Node $jobLabel

                $stepNum = 0
                foreach ($step in $job.Steps) {
                    $stepNum++
                    $stepLabel = ($step.Name -replace '``', '')
                    if (-not $step.Enabled) { $stepLabel += ' [DISABLED]' }
                    $stepNode = New-Node "$stepNum. $stepLabel"

                    if ($TraceResults) {
                        $matchingTraces = @($TraceResults | Where-Object {
                            $_.Entry.Pipeline -eq $fileName -and $_.Entry.Step -eq $step.Name
                        })
                        foreach ($tr in $matchingTraces) {
                            $trace = $tr.Trace
                            $scriptNode = New-Node "Script: $($trace.FileName)"

                            if ($trace.Functions.Count -gt 0) {
                                $fnNode = New-Node "Functions ($($trace.Functions.Count))"
                                foreach ($fn in $trace.Functions) { $fnNode.children += New-Node $fn.Name }
                                $scriptNode.children += $fnNode
                            }

                            $topCmds = @($trace.Commands |
                                Where-Object { $_.Name -match '^(Stop|Start|Restart|Set|New|Remove|Copy|Move|Invoke|Install|Enable|Disable|Test)-' } |
                                Select-Object -First 8)
                            if ($topCmds.Count -gt 0) {
                                $cmdNode = New-Node 'Key Operations'
                                foreach ($c in $topCmds) { $cmdNode.children += New-Node $c.Name }
                                $scriptNode.children += $cmdNode
                            }

                            if ($trace.ExternalCalls.Count -gt 0) {
                                $extNode = New-Node 'External Systems'
                                foreach ($ext in $trace.ExternalCalls) { $extNode.children += New-Node $ext.Command }
                                $scriptNode.children += $extNode
                            }

                            $stepNode.children += $scriptNode
                        }
                    }

                    $jobNode.children += $stepNode
                }
                $stageNode.children += $jobNode
            }
            $pipelineNode.children += $stageNode
        }
        $rootChildren += $pipelineNode
    }

    if ($rootChildren.Count -eq 1) { return $rootChildren[0] }
    $root = New-Node 'Pipelines'
    $root.children = $rootChildren
    return $root
}

# This function generates a self-contained HTML file with an interactive Markmap
# mind map. The tree data is built as a JSON object in PowerShell and passed
# directly to Markmap.create() - bypassing markmap-lib/Transformer entirely.
# Only requires markmap-view and d3 from CDN. Each node can be clicked to show
# or hide its children, enabling drill-down from pipeline overview to individual
# function calls.
function ConvertTo-MindMapHtml {
    param(
        $TreeData,
        [string]$OutputPath,
        [string]$Title = 'Pipeline Mind Map'
    )

    # Convert the tree to JSON - this is the Markmap node structure
    $treeJson = $TreeData | ConvertTo-Json -Depth 20 -Compress

    $htmlTemplate = @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TITLE_PLACEHOLDER</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  html, body, #mindmap { width: 100%; height: 100%; }
  body {
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    background: #0d1117;
    color: #c9d1d9;
  }
  .toolbar {
    position: fixed; top: 0; left: 0; right: 0; z-index: 1000;
    background: #161b22; border-bottom: 1px solid #30363d;
    padding: 0.5rem 1rem; display: flex; align-items: center; gap: 1rem;
    flex-wrap: wrap;
  }
  .toolbar h1 { font-size: 1rem; color: #58a6ff; font-weight: 600; }
  .toolbar button {
    background: #21262d; color: #c9d1d9; border: 1px solid #30363d;
    padding: 0.35rem 0.75rem; border-radius: 4px; cursor: pointer;
    font-size: 0.85rem; font-family: inherit;
  }
  .toolbar button:hover { background: #30363d; border-color: #58a6ff; }
  .toolbar .sep { width: 1px; height: 1.2rem; background: #30363d; }
  .toolbar .hint { font-size: 0.8rem; color: #8b949e; margin-left: auto; }
  #mindmap { padding-top: 52px; width: 100%; height: calc(100% - 52px); }
</style>
</head>
<body>
<div class="toolbar">
  <h1>TITLE_PLACEHOLDER</h1>
  <div class="sep"></div>
  <button onclick="if(mm)mm.fit()">Fit View</button>
  <button onclick="expandAll()">Expand All</button>
  <button onclick="collapseToDepth(1)">Stages Only</button>
  <button onclick="collapseToDepth(2)">+ Jobs</button>
  <button onclick="collapseToDepth(3)">+ Steps</button>
  <button onclick="collapseToDepth(4)">+ Scripts</button>
  <div class="hint">Click any node to expand/collapse. Scroll to zoom. Drag to pan.</div>
</div>
<div id="err" style="color:#f44336;padding:1rem;font-family:monospace;font-size:0.85rem;position:fixed;bottom:0;left:0;right:0;z-index:999;background:#161b22;display:none;"></div>
<svg id="mindmap"></svg>

<script src="https://url.au.m.mimecastprotect.com/s/pfz3CD1vM2Fmj22rhRC2TjWOTh?domain=cdn.jsdelivr.net"></script>
<script src="https://url.au.m.mimecastprotect.com/s/l1NQCE8wN2FG1rrocxFoT7cot4?domain=cdn.jsdelivr.net"></script>

<script>
var root = TREEDATA_PLACEHOLDER;
var mm = null;
var errEl = document.getElementById('err');

function walkNodes(node, fn, depth) {
  depth = depth || 0;
  fn(node, depth);
  if (node.children) {
    for (var i = 0; i < node.children.length; i++) {
      walkNodes(node.children[i], fn, depth + 1);
    }
  }
}

function collapseToDepth(maxDepth) {
  walkNodes(root, function(node, depth) {
    node.payload = node.payload || {};
    node.payload.fold = (depth >= maxDepth) ? 1 : 0;
  });
  if (mm) { mm.setData(root); setTimeout(function(){ mm.fit(); }, 100); }
}

function expandAll() {
  walkNodes(root, function(node) {
    if (node.payload) node.payload.fold = 0;
  });
  if (mm) { mm.setData(root); setTimeout(function(){ mm.fit(); }, 100); }
}

try {
  collapseToDepth(1);
  var el = document.getElementById('mindmap');
  mm = markmap.Markmap.create(el, { maxWidth: 280 }, root);
  setTimeout(function() { mm.fit(); }, 500);
} catch(e) {
  errEl.style.display = 'block';
  errEl.textContent = 'Error: ' + e.message;
}
</script>
</body>
</html>
'@

    $htmlTemplate = $htmlTemplate -replace 'TITLE_PLACEHOLDER', [System.Security.SecurityElement]::Escape($Title)
    $htmlTemplate = $htmlTemplate -replace 'TREEDATA_PLACEHOLDER', $treeJson

    $dir = Split-Path $OutputPath -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Set-Content -Path $OutputPath -Value $htmlTemplate -Encoding UTF8 -NoNewline
}

# ══════════════════════════════════════════════════════════════════════════════
# MAIN EXECUTION BLOCK
# ══════════════════════════════════════════════════════════════════════════════
# The main block orchestrates the full pipeline:
#   1. If -Diff is specified, compare two files and exit (separate code path)
#   2. Resolve all YAML files from the provided -Path arguments (files, dirs, wildcards)
#   3. Parse each YAML file into a hashtable using ConvertFrom-Yaml
#   4. For each parsed pipeline, generate the requested output sections
#   5. If -EnvironmentMatrix is specified, generate the cross-pipeline matrix (once)
#   6. Write output to the requested destination(s): stdout, -SingleFile, -OutputDir, -Html

# Handle -Diff mode - this is a separate code path that compares exactly two files
if ($Diff) {
    if ($Diff.Count -ne 2) {
        Write-Error '-Diff requires exactly two YAML file paths.'
        exit 1
    }
    $diffOutput = Compare-Pipelines -PathA $Diff[0] -PathB $Diff[1]

    if ($Html) {
        ConvertTo-HtmlReport -MarkdownContent $diffOutput -OutputPath $Html
        Write-Host "HTML diff written to $Html" -ForegroundColor Green
    } elseif ($SingleFile) {
        Set-Content -Path $SingleFile -Value $diffOutput -Encoding UTF8
        Write-Host "Diff written to $SingleFile" -ForegroundColor Green
    } else {
        Write-Output $diffOutput
    }
    exit 0
}

# Resolve input paths to actual YAML files. Handles three input types:
#   - Directories: searches for *.yml and *.yaml files (non-recursive)
#   - Files: added directly
#   - Wildcards: resolved via Resolve-Path
$yamlFiles = @()
foreach ($p in $Path) {
    if (Test-Path $p -PathType Container) {
        $yamlFiles += @(Get-ChildItem -Path $p -Filter '*.yml' -File) + @(Get-ChildItem -Path $p -Filter '*.yaml' -File) | Sort-Object Name
    } elseif (Test-Path $p -PathType Leaf) {
        $yamlFiles += Get-Item $p
    } else {
        $resolved = Resolve-Path $p -ErrorAction SilentlyContinue
        if ($resolved) { $yamlFiles += $resolved | ForEach-Object { Get-Item $_.Path } }
        else { Write-Warning "'$p' not found, skipping." }
    }
}

if ($yamlFiles.Count -eq 0) {
    Write-Error 'No YAML files found.'
    exit 1
}

Write-Host "Processing $($yamlFiles.Count) file(s)..." -ForegroundColor Cyan

# Parse each YAML file into a hashtable. Invalid files are warned and skipped.
$parsedPipelines = @()
foreach ($file in $yamlFiles) {
    try {
        $content = Get-Content -Path $file.FullName -Raw -Encoding UTF8
        $pipeline = ConvertFrom-Yaml $content
        if ($pipeline -isnot [hashtable]) {
            Write-Warning "'$($file.Name)' is not a valid pipeline YAML, skipping."
            continue
        }
        $parsedPipelines += [PSCustomObject]@{ File = $file; Pipeline = $pipeline; FileName = $file.Name }
    } catch {
        Write-Warning "Error parsing '$($file.Name)': $_"
    }
}

# ── Stage 1: Script Discovery (-ScanScripts) ──
# If -ScanScripts is specified, scan all parsed pipelines for script references
# before proceeding with any other output generation. The manifest is written to
# disk and a console summary is displayed. If no other output features are
# requested, the script exits after scanning.
if ($ScanScripts) {
    if (-not $ScriptRoot) {
        Write-Error '-ScanScripts requires -ScriptRoot to be specified. Provide the base directory where pipeline scripts are located.'
        exit 1
    }
    if (-not (Test-Path $ScriptRoot -PathType Container)) {
        Write-Error "ScriptRoot directory does not exist: $ScriptRoot"
        exit 1
    }
    $ScriptRoot = (Resolve-Path $ScriptRoot).Path

    Write-Host 'Running Stage 1: Script Discovery Scan...' -ForegroundColor Cyan
    $allScanResults = @()
    foreach ($pp in $parsedPipelines) {
        $scanResults = Invoke-ScriptScan -Pipeline $pp.Pipeline -SourceFile $pp.FileName -ScriptRoot $ScriptRoot
        $allScanResults += $scanResults
    }

    $pipelineSourceDesc = ($parsedPipelines | ForEach-Object { $_.FileName }) -join ', '
    Export-ScriptManifest -Entries $allScanResults -OutputPath $ManifestPath `
                          -PipelineSource $pipelineSourceDesc -ScriptRoot $ScriptRoot

    # Determine whether any other output features were requested. If ScanScripts
    # is the only feature, exit cleanly after producing the manifest.
    $otherFeaturesRequested = $Diagram -or $DiagramOnly -or $Rollback -or $Checklist -or
                              $EnvironmentMatrix -or $EstimateDuration -or $Validate -or
                              $Html -or $MermaidDir -or $SingleFile -or $OutputDir
    if (-not $otherFeaturesRequested) {
        Write-Host 'Scan complete. No other output features requested - exiting.' -ForegroundColor Cyan
        exit 0
    }
    Write-Host 'Continuing with requested documentation output...' -ForegroundColor Cyan
    Write-Host ''
}

# ── Stage 2: Script Tracing (-TraceScripts) ──
# Reads the manifest, parses each RESOLVED PowerShell script via AST, generates
# nested diagrams and a trace report. Newly discovered sub-references are
# reported for iterative manifest updates.
$traceOutput = ''
if ($TraceScripts) {
    $manifestFile = if ($ManifestPath) { $ManifestPath } else { Join-Path $PWD 'script-manifest.json' }
    $manifestEntries = Import-ScriptManifest -ManifestPath $manifestFile
    if (-not $manifestEntries) {
        Write-Error "Cannot proceed with tracing - manifest load failed. Run -ScanScripts first."
        exit 1
    }

    # Filter to RESOLVED ps1/psm1 entries that are not marked 'skip'
    $traceableEntries = @($manifestEntries | Where-Object {
        $_.Status -eq 'RESOLVED' -and
        $_.FileType -in @('ps1', 'psm1') -and
        $_.TraceDepth -ne 'skip'
    })

    if ($traceableEntries.Count -eq 0) {
        Write-Warning 'No traceable scripts found in manifest (need RESOLVED .ps1/.psm1 entries with traceDepth != skip).'
    } else {
        Write-Host "Tracing $($traceableEntries.Count) script(s)..." -ForegroundColor Cyan

        # Deduplicate by resolved path to avoid parsing the same file multiple times
        $uniquePaths = @{}
        $traceResults = @()
        foreach ($entry in $traceableEntries) {
            $path = $entry.ResolvedPath
            if (-not $uniquePaths.ContainsKey($path)) {
                Write-Host "  Parsing: $($entry.Reference)" -ForegroundColor Gray
                $trace = Invoke-ScriptTrace -ScriptPath $path -TraceDepth $entry.TraceDepth
                $uniquePaths[$path] = $trace
            }
            $traceResults += [PSCustomObject]@{
                Entry = $entry
                Trace = $uniquePaths[$path]
            }
        }

        # Generate the trace report markdown
        $traceOutput = ConvertTo-TraceReport -TraceResults $traceResults -ManifestEntries $manifestEntries

        # Export .mmd files for traced scripts if -MermaidDir is specified
        if ($MermaidDir) {
            Write-Host "Exporting script diagrams to $MermaidDir..." -ForegroundColor Cyan
            Export-ScriptMermaid -TraceResults $traceResults -OutputDir $MermaidDir
        }

        # Report newly discovered references
        $newRefCount = 0
        foreach ($tr in $traceResults) {
            foreach ($sub in $tr.Trace.SubReferences) {
                $alreadyKnown = $manifestEntries | Where-Object {
                    $_.Reference -eq $sub.Reference -or $_.ResolvedPath -like "*$($sub.Reference)*"
                }
                if (-not $alreadyKnown) { $newRefCount++ }
            }
        }
        if ($newRefCount -gt 0) {
            Write-Host ""
            Write-Host "  Discovered $newRefCount new script/module reference(s) not in the manifest." -ForegroundColor Yellow
            Write-Host "  Re-run -ScanScripts to include them, or add them manually to the manifest." -ForegroundColor Yellow
            Write-Host ""
        }

        Write-Host "Trace complete. $($traceResults.Count) script(s) analysed." -ForegroundColor Green
    }

    # If TraceScripts is the only feature, output the trace report and exit
    $otherFeaturesRequested = $Diagram -or $DiagramOnly -or $Rollback -or $Checklist -or
                              $EnvironmentMatrix -or $EstimateDuration -or $Validate -or
                              (-not $TraceScripts -and ($SingleFile -or $OutputDir))
    if (-not $otherFeaturesRequested -and -not $Html -and -not $SingleFile -and -not $OutputDir) {
        if ($traceOutput) { Write-Output $traceOutput }
        exit 0
    }
}

# ── Inline Script Tracing (-TraceInline) ──
# Traces all inline PowerShell blocks directly from the YAML - no manifest or
# -ScriptRoot required. Results feed into the same trace report and mind map
# as -TraceScripts. Can be combined with -TraceScripts (external file results
# are merged with inline results).
$inlineTraceResults = @()
if ($TraceInline) {
    Write-Host 'Tracing inline PowerShell blocks...' -ForegroundColor Cyan
    $inlineTraceResults = Invoke-InlineTracing -ParsedPipelines $parsedPipelines

    if ($inlineTraceResults.Count -eq 0) {
        Write-Host '  No inline PowerShell blocks with traceable content found.' -ForegroundColor Yellow
    } else {
        Write-Host "  Traced $($inlineTraceResults.Count) inline script block(s)." -ForegroundColor Green
    }

    # Merge inline results into traceOutput (which may already contain -TraceScripts results)
    $allTraceResults = @()
    if (Get-Variable -Name traceResults -ErrorAction SilentlyContinue) { $allTraceResults += $traceResults }
    $allTraceResults += $inlineTraceResults

    if ($allTraceResults.Count -gt 0) {
        $manifestEntries = if (Get-Variable -Name manifestEntries -ErrorAction SilentlyContinue) { $manifestEntries } else { @() }
        $traceOutput = ConvertTo-TraceReport -TraceResults $allTraceResults -ManifestEntries $manifestEntries

        if ($MermaidDir) {
            Export-ScriptMermaid -TraceResults $allTraceResults -OutputDir $MermaidDir
        }
    }

    # If TraceInline is the only feature, output and exit
    $otherFeaturesRequested = $Diagram -or $DiagramOnly -or $Rollback -or $Checklist -or
                              $EnvironmentMatrix -or $EstimateDuration -or $Validate
    if (-not $otherFeaturesRequested -and -not $Html -and -not $SingleFile -and -not $OutputDir -and -not $TraceScripts -and -not $MindMap -and -not $DrawIO) {
        if ($traceOutput) { Write-Output $traceOutput }
        exit 0
    }
}

# Generate output for each pipeline by calling the requested feature functions.
# Each feature's output is concatenated into a single string per pipeline.
$allOutput = @()
foreach ($pp in $parsedPipelines) {
    $output = ''

    if (-not $DiagramOnly) {
        $output += ConvertTo-PipelineMarkdown -Pipeline $pp.Pipeline -SourceFile $pp.FileName
    }
    if ($Diagram -or $DiagramOnly) {
        $output += ConvertTo-PipelineDiagram -Pipeline $pp.Pipeline -SourceFile $pp.FileName
    }
    if ($Rollback) {
        $output += ConvertTo-RollbackPlan -Pipeline $pp.Pipeline -SourceFile $pp.FileName
    }
    if ($Checklist) {
        $output += ConvertTo-Checklist -Pipeline $pp.Pipeline -SourceFile $pp.FileName
    }
    if ($EstimateDuration) {
        $output += ConvertTo-DurationEstimate -Pipeline $pp.Pipeline -SourceFile $pp.FileName
    }
    if ($Validate) {
        $output += Invoke-PipelineValidation -Pipeline $pp.Pipeline -SourceFile $pp.FileName
    }
    if ($MermaidDir) {
        Export-PipelineMermaid -Pipeline $pp.Pipeline -SourceFile $pp.FileName -OutputDir $MermaidDir
    }
    if ($DrawIO) {
        $drawTraceData = @()
        if ($mindMapTraceData.Count -gt 0) { $drawTraceData = $mindMapTraceData }
        Export-DrawIO -Pipeline $pp.Pipeline -SourceFile $pp.FileName -OutputDir $DrawIO -TraceResults $drawTraceData
    }

    $allOutput += [PSCustomObject]@{ File = $pp.File; Markdown = $output }
}

# Environment matrix is generated once across ALL pipelines (not per-pipeline)
$matrixOutput = ''
if ($EnvironmentMatrix) {
    $matrixOutput = ConvertTo-EnvironmentMatrix -ParsedPipelines $parsedPipelines
}

# Combine all pipeline outputs and append matrix if present, then write to
# the requested destination(s). Multiple outputs can be generated simultaneously
# (e.g., -SingleFile and -Html together). If no output switch is specified,
# results go to stdout.
$combined = ($allOutput | ForEach-Object { $_.Markdown }) -join "`n`n"
if ($matrixOutput) { $combined += "`n`n$matrixOutput" }
if ($traceOutput) { $combined += "`n`n$traceOutput" }

# ── Mind Map Generation ──
# Generates an interactive Markmap mind map. Three trigger modes:
#   1. -MindMap <path>   : Explicit path, always generates
#   2. -Html <path>      : Auto-generates companion mind map (unless -NoMindMap)
#   3. Neither           : No mind map generated
# Trace results are included in the mind map if -TraceScripts was run.
# Collect all trace results (external + inline) for the mind map
$mindMapTraceData = @()
if (Get-Variable -Name traceResults -ErrorAction SilentlyContinue) { $mindMapTraceData += $traceResults }
if ($inlineTraceResults.Count -gt 0) { $mindMapTraceData += $inlineTraceResults }

$generateMindMap = $false
$mindMapOutputPath = ''

if ($MindMap) {
    $generateMindMap = $true
    $mindMapOutputPath = $MindMap
} elseif ($Html -and -not $NoMindMap) {
    $generateMindMap = $true
    $htmlDir = Split-Path $Html -Parent
    $htmlBase = [System.IO.Path]::GetFileNameWithoutExtension($Html)
    $mindMapOutputPath = if ($htmlDir) { Join-Path $htmlDir "${htmlBase}-mindmap.html" } else { "${htmlBase}-mindmap.html" }
}

if ($generateMindMap -and $parsedPipelines.Count -gt 0) {
    $treeData = ConvertTo-MindMapData -ParsedPipelines $parsedPipelines -TraceResults $mindMapTraceData
    $pipelineName = if ($parsedPipelines.Count -eq 1) {
        $p = $parsedPipelines[0].Pipeline
        if ($p['name']) { $p['name'] } else { [System.IO.Path]::GetFileNameWithoutExtension($parsedPipelines[0].FileName) }
    } else { "Pipeline Documentation ($($parsedPipelines.Count) pipelines)" }
    ConvertTo-MindMapHtml -TreeData $treeData -OutputPath $mindMapOutputPath -Title $pipelineName
    Write-Host "Mind map written to $mindMapOutputPath" -ForegroundColor Green
}

if ($Html) {
    $dir = Split-Path $Html -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    ConvertTo-HtmlReport -MarkdownContent $combined -OutputPath $Html
    Write-Host "HTML report written to $Html" -ForegroundColor Green
}

if ($SingleFile) {
    $dir = Split-Path $SingleFile -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Set-Content -Path $SingleFile -Value $combined -Encoding UTF8
    Write-Host "Written to $SingleFile" -ForegroundColor Green
} elseif ($OutputDir) {
    if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }
    foreach ($item in $allOutput) {
        $outPath = Join-Path $OutputDir "$($item.File.BaseName).md"
        Set-Content -Path $outPath -Value $item.Markdown -Encoding UTF8
        Write-Host "  -> $outPath" -ForegroundColor Green
    }
    if ($matrixOutput) {
        $matrixPath = Join-Path $OutputDir "_environment-matrix.md"
        Set-Content -Path $matrixPath -Value $matrixOutput -Encoding UTF8
        Write-Host "  -> $matrixPath" -ForegroundColor Green
    }
} elseif (-not $Html) {
    Write-Output $combined
}

Write-Host "Done. $($allOutput.Count) pipeline(s) documented." -ForegroundColor Cyan

