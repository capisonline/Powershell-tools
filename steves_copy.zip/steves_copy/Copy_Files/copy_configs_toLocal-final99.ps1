﻿<#
.SYNOPSIS
    Collects active VisPR service configuration files and IIS configuration
    from OLD and NEW servers defined in a CSV mapping file.

.DESCRIPTION
    This script connects to servers listed in a CSV file (headers: OLD_Server, NEW_Server)
    and collects configuration artifacts required for environment comparison and merge.

    It performs the following actions per server:

    1) Windows Services (Name LIKE 'VisPR%')
       - Queries services whose names start with "VisPR"
       - Determines the executable path from the service PathName
       - Copies the corresponding EXE.config file from the same directory
       - Reuses discovered service paths to identify Vision roots such as:
            D:\vision\VisPR
            D:\vision\VisPR_PHQVT
            D:\vision\VisPR_BNL
       - Copies root-level Vision settings and ini files from those discovered roots

    2) IIS Configuration
       - Copies:
            C:\Windows\System32\inetsrv\config\applicationHost.config
       - Parses IIS site definitions
       - Extracts physicalPath values
       - Copies:
            - Root web.config for each IIS site
            - All *.json files in each IIS site root
            - (Optional) All nested web.config files if -RecurseWebConfigs is specified

    Output is written to the following structure:

        <DestinationRoot>\
            OLD\
                <ServerName>\D$\...
                <ServerName>\C$\...
            NEW\
                <ServerName>\D$\...
                <ServerName>\C$\...

    Full original drive structure is preserved to allow deterministic redeployment.

.PARAMETER CsvPath
    Path to CSV file containing:
        OLD_Server,NEW_Server

.PARAMETER DestinationRoot
    Root directory where collected configuration files will be stored.

.PARAMETER EnvironmentToken
    Optional filter (e.g. "VT" or "PR").
    Only servers containing this token in their hostname will be processed.

.PARAMETER RecurseWebConfigs
    If specified, all web.config files under each IIS site root will be copied.
    If not specified, only the root web.config of each site will be copied.

.REQUIREMENTS
    - Run from PowerShell ISE or elevated PowerShell session
    - Administrative access to \\SERVER\C$ and \\SERVER\D$
    - Remote service query access (Win32_Service via CIM/WMI)

.EXAMPLE
    .\copy_configs_toLocal-final.ps1 `
        -CsvPath 'C:\temp\QCAD\PR\Configs\Merging\PR_Server_List_OLD-NEW.csv' `
        -DestinationRoot 'C:\temp\QCAD\PR\Configs\Merging' `
        -RecurseWebConfigs

.NOTES
    This script performs read-only collection.
    No configuration changes are made to any server.

#>

param(
  [Parameter(Mandatory=$true)] [string]$CsvPath,           # headers: OLD_Server,NEW_Server
  [Parameter(Mandatory=$true)] [string]$DestinationRoot,   # e.g. C:\CollectedConfigs
  [string]$EnvironmentToken = "",                          # optional filter, e.g. VT / PR
  [switch]$RecurseWebConfigs                               # optional: copy all web.config under each IIS site root
)

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
New-Item -ItemType Directory -Path $DestinationRoot -Force | Out-Null

$logPath    = Join-Path $DestinationRoot "Collect_$ts.log"
$reportPath = Join-Path $DestinationRoot "Collect_$ts.csv"
"Side,Server,Type,Source,Destination,Status,Notes" | Out-File $reportPath -Encoding UTF8

function Log([string]$msg) {
  $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
  $line | Tee-Object -FilePath $logPath -Append | Out-Null
}

function EnsureDir([string]$p) {
  if (-not (Test-Path -LiteralPath $p)) {
    New-Item -ItemType Directory -Path $p -Force | Out-Null
  }
}

function LocalPathToUNC([string]$server, [string]$localPath) {
  # D:\x\y -> \\server\D$\x\y
  $drive = $localPath.Substring(0,1)
  $rest  = $localPath.Substring(2)
  return "\\$server\$drive`$$rest"
}

function UNCToDestPath([string]$destSideRoot, [string]$server, [string]$uncPath) {
  # \\server\D$\x\y -> <destSideRoot>\<server>\D$\x\y
  if ($uncPath -match "^\\\\$([Regex]::Escape($server))\\([A-Z])\`$\\") {
    $drive = $Matches[1] + "$"
    $relative = $uncPath -replace "^\\\\$([Regex]::Escape($server))\\([A-Z])\`$\\", ""
    return Join-Path $destSideRoot (Join-Path $server (Join-Path $drive $relative))
  }
  elseif ($uncPath -match "^\\\\([^\\]+)\\([^\\]+)\\(.*)$") {
    # UNC physicalPath -> store under <server>\UNC\<otherserver>\<share>\...
    $otherServer = $Matches[1]
    $share       = $Matches[2]
    $rest        = $Matches[3]
    return Join-Path $destSideRoot (Join-Path $server (Join-Path "UNC" (Join-Path $otherServer (Join-Path $share $rest))))
  }
  else {
    return Join-Path $destSideRoot (Join-Path $server ("MISC\" + ($uncPath -replace "[\\:]", "_")))
  }
}

function CopyOne([string]$side, [string]$server, [string]$type, [string]$sourceUNC, [string]$destSideRoot, [string]$notes="") {
  try {
    $destPath = UNCToDestPath -destSideRoot $destSideRoot -server $server -uncPath $sourceUNC
    EnsureDir (Split-Path $destPath -Parent)
    Copy-Item -LiteralPath $sourceUNC -Destination $destPath -Force -ErrorAction Stop
    "$side,$server,$type,""$sourceUNC"",""$destPath"",COPIED,""$notes""" | Out-File $reportPath -Append -Encoding UTF8
    return $true
  }
  catch {
    Log "ERROR: Copy failed ($side/$type): $sourceUNC :: $($_.Exception.Message)"
    "$side,$server,$type,""$sourceUNC"","""",ERROR,""Copy failed: $notes""" | Out-File $reportPath -Append -Encoding UTF8
    return $false
  }
}

function Resolve-IISPhysicalPath([string]$path) {
  $p = $path.Trim()
  $p = $p -replace "%SystemDrive%", "C:"
  return $p
}

function Parse-ServiceExePath([string]$pathName) {
  # Examples:
  #  "D:\vision\VisPR\Services\Fortek.Services.Telephony.exe"
  #  "\"D:\vision\...\SomeSvc.exe\" -arg1 -arg2"
  #  D:\vision\...\SomeSvc.exe -arg

  if (-not $pathName) { return $null }

  $p = $pathName.Trim()

  if ($p.StartsWith('"')) {
    $secondQuote = $p.IndexOf('"', 1)
    if ($secondQuote -gt 1) {
      return $p.Substring(1, $secondQuote - 1)
    }
  }

  $m = [regex]::Match($p, '(?i)\.exe')
  if ($m.Success) {
    return $p.Substring(0, $m.Index + 4).Trim()
  }

  return $null
}

function Get-VisionRootFromExePath([string]$exePath) {
  if (-not $exePath) { return $null }

  # Match:
  # D:\vision\VisPR\...
  # D:\vision\VisPR_PHQ\...
  # D:\vision\VisPR\...
  # D:\vision\VisPR_BNL\...
  $m = [regex]::Match($exePath, '^(?i)([A-Z]:\\vision\\Vis[A-Z0-9]+(?:_[A-Z0-9]+)?)\\')
  if ($m.Success) {
    return $m.Groups[1].Value
  }

  return $null
}

function Get-VisionRootCandidateFiles([string]$visionRoot) {
  if (-not $visionRoot) { return @() }

  # Do not use Join-Path here, because $visionRoot is a path discovered
  # from a remote server service and may reference D:\ or E:\ that does not
  # exist on the machine running this script.
  $leaf = [System.IO.Path]::GetFileName($visionRoot.TrimEnd('\'))

  $candidates = @(
    "$visionRoot\$leaf.settings"
    "$visionRoot\$leaf.ini"
    "$visionRoot\Vision_$leaf.settings"
    "$visionRoot\Vision_$leaf.ini"
  )

  return $candidates | Sort-Object -Unique
}

function Collect-FromServer([string]$side, [string]$server) {
  $destSideRoot = Join-Path $DestinationRoot $side
  EnsureDir $destSideRoot

  Log "---- $side :: $server ----"

  if (-not (Test-Path -LiteralPath "\\$server\C$")) {
    Log "ERROR: Cannot access \\$server\C$"
    "$side,$server,ACCESS,""\\$server\C$"","""",ERROR,""No admin share access""" | Out-File $reportPath -Append -Encoding UTF8
    return
  }

  # Track discovered Vision roots from service paths
  $visionRoots = New-Object 'System.Collections.Generic.HashSet[string]'

  # -------- 1) SERVICE-BASED CONFIG COLLECTION --------
  try {
    $services = Get-CimInstance -ComputerName $server -ClassName Win32_Service -Filter "Name LIKE 'VisVT%'" -ErrorAction Stop

    foreach ($svc in $services) {
      $exe = Parse-ServiceExePath $svc.PathName
      if (-not $exe) {
        "$side,$server,SERVICE_CONFIG,""$($svc.Name)"","""",SKIP,""Could not parse PathName""" | Out-File $reportPath -Append -Encoding UTF8
        continue
      }

      # Record discovered Vision root if present
      $visionRoot = Get-VisionRootFromExePath $exe
      if ($visionRoot) {
        [void]$visionRoots.Add($visionRoot)
      }

      # Copy the service EXE.config
      $cfg = "$exe.config"
      $cfgUNC = LocalPathToUNC $server $cfg

      if (Test-Path -LiteralPath $cfgUNC) {
        CopyOne $side $server "SERVICE_CONFIG" $cfgUNC $destSideRoot "Service=$($svc.Name)" | Out-Null
      }
      else {
        "$side,$server,SERVICE_CONFIG,""$cfgUNC"","""",SKIP,""Config not found for service=$($svc.Name)""" | Out-File $reportPath -Append -Encoding UTF8
      }
    }
  }
  catch {
    Log "WARN: Could not query Win32_Service on $server (VisVT*). Will still collect IIS config. :: $($_.Exception.Message)"
    "$side,$server,SERVICE_QUERY,""Win32_Service VisVT*"","""",ERROR,""Service query failed""" | Out-File $reportPath -Append -Encoding UTF8
  }

  # -------- 2) VISION ROOT FILES DISCOVERED FROM SERVICE PATHS --------
  if ($visionRoots.Count -gt 0) {
    foreach ($vr in $visionRoots) {
      $candidateFiles = Get-VisionRootCandidateFiles -visionRoot $vr

      foreach ($localFile in $candidateFiles) {
        $fileUNC = LocalPathToUNC $server $localFile
        if (Test-Path -LiteralPath $fileUNC) {
          CopyOne $side $server "VISION_ROOT_FILE" $fileUNC $destSideRoot "DiscoveredFrom=$vr" | Out-Null
        }
        else {
          "$side,$server,VISION_ROOT_FILE,""$fileUNC"","""",SKIP,""Not found under discovered root $vr""" | Out-File $reportPath -Append -Encoding UTF8
        }
      }
    }
  }
  else {
    "$side,$server,VISION_ROOT_FILE,""VisionRootDiscovery"","""",SKIP,""No Vision roots discovered from VisVT service paths""" | Out-File $reportPath -Append -Encoding UTF8
  }

  # -------- 3) IIS: applicationHost.config + web.config + *.json discovery --------
  $iisLocal = "C:\Windows\System32\inetsrv\config\applicationHost.config"
  $iisUNC   = LocalPathToUNC $server $iisLocal

  if (Test-Path -LiteralPath $iisUNC) {
    $copiedOk = CopyOne $side $server "IIS_CONFIG" $iisUNC $destSideRoot
    if ($copiedOk) {
      $copiedPath = UNCToDestPath -destSideRoot $destSideRoot -server $server -uncPath $iisUNC

      try {
        [xml]$appHost = Get-Content -LiteralPath $copiedPath -ErrorAction Stop

        $vdirs = $appHost.configuration.'system.applicationHost'.sites.site.application.virtualDirectory |
                 Where-Object { $_.physicalPath } |
                 ForEach-Object { $_.physicalPath } |
                 Sort-Object -Unique

        foreach ($p in $vdirs) {
          $resolved = Resolve-IISPhysicalPath $p

          if ($resolved -match "^\\\\") {
            $rootUNC = $resolved
          }
          else {
            if ($resolved.Length -ge 3 -and $resolved[1] -eq ":") {
              $rootUNC = LocalPathToUNC $server $resolved
            }
            else {
              "$side,$server,WEB_CONFIG,""$p"","""",SKIP,""Unrecognized physicalPath format""" | Out-File $reportPath -Append -Encoding UTF8
              continue
            }
          }

          # Root web.config
          $webUNC = Join-Path $rootUNC "web.config"
          if (Test-Path -LiteralPath $webUNC) {
            CopyOne $side $server "WEB_CONFIG" $webUNC $destSideRoot "IISRoot=$p" | Out-Null
          }
          else {
            "$side,$server,WEB_CONFIG,""$webUNC"","""",SKIP,""web.config not found (IISRoot=$p)""" | Out-File $reportPath -Append -Encoding UTF8
          }

          # Root-level JSON config files
          try {
            Get-ChildItem -Path $rootUNC -File -Filter "*.json" -ErrorAction Stop |
              ForEach-Object {
                CopyOne $side $server "WEB_JSON_CONFIG" $_.FullName $destSideRoot "IISRoot=$p" | Out-Null
              }
          }
          catch {
            Log "WARN: Failed searching $rootUNC for *.json :: $($_.Exception.Message)"
          }

          # Optional recurse for nested web.config
          if ($RecurseWebConfigs -and (Test-Path -LiteralPath $rootUNC)) {
            try {
              Get-ChildItem -Path $rootUNC -Recurse -File -Filter "web.config" -ErrorAction Stop |
                ForEach-Object {
                  CopyOne $side $server "WEB_CONFIG" $_.FullName $destSideRoot "IISRoot=$p" | Out-Null
                }
            }
            catch {
              Log "WARN: Recurse web.config failed under $rootUNC :: $($_.Exception.Message)"
            }
          }
        }
      }
      catch {
        Log "ERROR: Failed to parse copied applicationHost.config for $server :: $($_.Exception.Message)"
        "$side,$server,IIS_PARSE,""$copiedPath"","""",ERROR,""Parse failed""" | Out-File $reportPath -Append -Encoding UTF8
      }
    }
  }
  else {
    "$side,$server,IIS_CONFIG,""$iisUNC"","""",SKIP,""applicationHost.config not found (IIS not installed?)""" | Out-File $reportPath -Append -Encoding UTF8
  }
}

# ---------- Run ----------
$map = Import-Csv -Path $CsvPath
if (-not $map) {
  throw "CSV is empty."
}
if (-not ($map[0].PSObject.Properties.Name -contains "OLD_Server" -and $map[0].PSObject.Properties.Name -contains "NEW_Server")) {
  throw "CSV must have headers: OLD_Server, NEW_Server"
}

$oldServers = $map | ForEach-Object { $_.OLD_Server } | Where-Object { $_ } | ForEach-Object { $_.Trim() } | Sort-Object -Unique
$newServers = $map | ForEach-Object { $_.NEW_Server } | Where-Object { $_ } | ForEach-Object { $_.Trim() } | Sort-Object -Unique

if ($EnvironmentToken -ne "") {
  $oldServers = $oldServers | Where-Object { $_ -match [Regex]::Escape($EnvironmentToken) }
  $newServers = $newServers | Where-Object { $_ -match [Regex]::Escape($EnvironmentToken) }
}

Log "Starting collection. OLD=$($oldServers.Count) NEW=$($newServers.Count) Dest=$DestinationRoot EnvFilter='$EnvironmentToken' RecurseWebConfigs=$RecurseWebConfigs"

foreach ($s in $oldServers) {
  Collect-FromServer -side "OLD" -server $s
}

foreach ($s in $newServers) {
  Collect-FromServer -side "NEW" -server $s
}

Log "Done. Report=$reportPath Log=$logPath"
Write-Host "DONE. Report: $reportPath"
Write-Host "      Log:    $logPath"