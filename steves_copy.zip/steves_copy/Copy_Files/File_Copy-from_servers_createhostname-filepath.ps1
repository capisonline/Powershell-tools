﻿<# 
.SYNOPSIS
    This PowerShell script automates the process of copying specific files from a list of remote Windows 2012 servers to a local machine while preserving the folder structure.

.DESCRIPTION

    Search and Filter Files: Recursively searches a specified directory on each remote server for files matching given extensions (e.g., *.config, *.settings, *.ini).
    Preserve Directory Structure: Preserves the directory structure of the found files, replicating it under a top-level folder named after the server hostname.
    Copy Files Locally: Copies the matched files from the remote servers to the local output directory, ensuring only the specified file types are copied.

#>

# Define variables
$serversList = "C:\temp\QCAD\PR\Discovery\telemetry_capture\PR_Telemetry_ServerList.txt"
$outputDir = "C:\temp\QCAD\PR\Discovery\telemetry_capture\01-8-25"
$searchDir = "E:\PR_Discovery\Logs"
$extensions = @("*.*")

# Create output directory if it doesn't exist
if (-Not (Test-Path -Path $outputDir)) {
    New-Item -ItemType Directory -Path $outputDir
}

# Read the list of servers
$servers = Get-Content -Path $serversList

foreach ($server in $servers) {
    try {
        # Get the list of files with the specified extensions
        foreach ($extension in $extensions) {
            $files = Invoke-Command -ComputerName $server -ScriptBlock {
                param ($dir, $ext)
                Get-ChildItem -Path $dir -Recurse -Filter $ext
            } -ArgumentList $searchDir, $extension

            foreach ($file in $files) {
                # Construct the destination path
                $relativePath = $file.FullName.Substring($searchDir.Length + 1)  # Remove the search directory part
                $destinationPath = Join-Path -Path $outputDir -ChildPath "$server\$relativePath"
                
                # Create the destination directory if it doesn't exist
                $destinationDir = Split-Path -Path $destinationPath -Parent
                if (-Not (Test-Path -Path $destinationDir)) {
                    New-Item -ItemType Directory -Path $destinationDir -Force
                }
                
                # Copy the file to the local machine using network path
                $networkPath = "\\$server\$($searchDir.Replace(':', '$'))\$($relativePath)"
                Copy-Item -Path $networkPath -Destination $destinationPath -Force
            }
        }
    } catch {
        Write-Error "Failed to process server ${server}: $_"
    }
}
