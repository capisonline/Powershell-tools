﻿<#
.SYNOPSIS
    Collects active VISPR service configuration files and IIS configuration
    from OLD and NEW servers defined in a CSV mapping file.

.DESCRIPTION
    This script connects to servers listed in a CSV file (headers: OLD_Server, NEW_Server)
    and collects configuration artifacts required for environment comparison and merge.

    It performs the following actions per server:

    1) Windows Services (Name LIKE 'VISPR%')
       - Queries services whose names start with "VISPR"
       - Determines the executable path from the service PathName
       - Copies the corresponding EXE.config file from the same directory
       - Reuses discovered service paths to identify Vision roots such as:
            D:\Vision\VISPR
            D:\Vision\VISPR_PHQ
            D:\Vision\VISPR_BNL
       - Enumerates and copies any root-level *.ini and *.settings files
         that actually exist under those discovered Vision roots

    2) Disk Discovery
       - Scans D:\Vision and E:\Vision
       - Finds any folders named VISPR*
       - Enumerates and copies any root-level *.ini and *.settings files
         that actually exist under those roots

    3) IIS Configuration
       - Copies:
            C:\Windows\System32\inetsrv\config\applicationHost.config
       - Parses IIS site definitions
       - Extracts physicalPath values
       - Copies:
            - Root web.config for each IIS site
            - All *.json files in each IIS site root
            - (Optional) All nested web.config files if -RecurseWebConfigs is specified

    Output is written to the following structure:

        <DestinationRoot>\
            OLD\
                <ServerName>\D$\...
                <ServerName>\C$\...
            NEW\
                <ServerName>\D$\...
                <ServerName>\C$\...

    Full original drive structure is preserved to allow deterministic redeployment.

.PARAMETER CsvPath
    Path to CSV file containing:
        OLD_Server,NEW_Server

.PARAMETER DestinationRoot
    Root directory where collected configuration files will be stored.

.PARAMETER EnvironmentToken
    Optional filter (e.g. "PR" or "PR").
    Only servers containing this token in their hostname will be processed.

.PARAMETER RecurseWebConfigs
    If specified, all web.config files under each IIS site root will be copied.
    If not specified, only the root web.config of each site will be copied.

.REQUIREMENTS
    - Run from PowerShell ISE or elevated PowerShell session
    - Administrative access to \\SERVER\C$ and remote admin shares for app drives
    - Remote service query access (Win32_Service via CIM/WMI)

.EXAMPLE
    .\copy_configs_toLocal_PR.ps1 `
        -CsvPath 'C:\temp\QCAD\PR\Configs\Merging\PR_Server_List_OLD-NEW.csv' `
        -DestinationRoot 'C:\temp\QCAD\PR\Configs\Merging' `
        -RecurseWebConfigs

.NOTES
    This script performs read-only collection.
    No configuration changes are made to any server.
#>

param(
  [Parameter(Mandatory=$true)] [string]$CsvPath,
  [Parameter(Mandatory=$true)] [string]$DestinationRoot,
  [string]$EnvironmentToken = "",
  [switch]$RecurseWebConfigs
)

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
New-Item -ItemType Directory -Path $DestinationRoot -Force | Out-Null

$logPath    = Join-Path $DestinationRoot "Collect_$ts.log"
$reportPath = Join-Path $DestinationRoot "Collect_$ts.csv"
"Side,Server,Type,Source,Destination,Status,Notes" | Out-File $reportPath -Encoding UTF8

function Log {
  param(
    [Parameter(Mandatory=$true)] [string]$Message,
    [ValidateSet('INFO','GOOD','WARN','ERROR','STEP','SKIP')] [string]$Level = 'INFO'
  )

  $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
  $line = "$timestamp [$Level] $Message"

  $line | Out-File -FilePath $logPath -Append -Encoding UTF8

  switch ($Level) {
    'GOOD'  { Write-Host $line -ForegroundColor Green }
    'WARN'  { Write-Host $line -ForegroundColor Yellow }
    'ERROR' { Write-Host $line -ForegroundColor Red }
    'STEP'  { Write-Host $line -ForegroundColor Cyan }
    'SKIP'  { Write-Host $line -ForegroundColor DarkYellow }
    default { Write-Host $line -ForegroundColor Gray }
  }
}

function EnsureDir([string]$p) {
  if (-not (Test-Path -LiteralPath $p)) {
    New-Item -ItemType Directory -Path $p -Force | Out-Null
  }
}

function LocalPathToUNC([string]$server, [string]$localPath) {
  if ([string]::IsNullOrWhiteSpace($localPath)) {
    throw "LocalPathToUNC received an empty path."
  }

  if ($localPath.Length -lt 3 -or $localPath[1] -ne ':') {
    throw "LocalPathToUNC expected a drive-based local path, got: $localPath"
  }

  $drive = $localPath.Substring(0,1)
  $rest  = $localPath.Substring(2)
  return "\\$server\$drive`$$rest"
}

function UNCToDestPath([string]$destSideRoot, [string]$server, [string]$uncPath) {
  if ($uncPath -match "^\\\\$([Regex]::Escape($server))\\([A-Z])\`$\\") {
    $drive = $Matches[1] + "$"
    $relative = $uncPath -replace "^\\\\$([Regex]::Escape($server))\\([A-Z])\`$\\", ""
    return Join-Path $destSideRoot (Join-Path $server (Join-Path $drive $relative))
  }
  elseif ($uncPath -match "^\\\\([^\\]+)\\([^\\]+)\\(.*)$") {
    $otherServer = $Matches[1]
    $share       = $Matches[2]
    $rest        = $Matches[3]
    return Join-Path $destSideRoot (Join-Path $server (Join-Path "UNC" (Join-Path $otherServer (Join-Path $share $rest))))
  }
  else {
    return Join-Path $destSideRoot (Join-Path $server ("MISC\" + ($uncPath -replace "[\\:]", "_")))
  }
}

function CopyOne([string]$side, [string]$server, [string]$type, [string]$sourceUNC, [string]$destSideRoot, [string]$notes="") {
  try {
    $destPath = UNCToDestPath -destSideRoot $destSideRoot -server $server -uncPath $sourceUNC
    EnsureDir (Split-Path $destPath -Parent)
    Copy-Item -LiteralPath $sourceUNC -Destination $destPath -Force -ErrorAction Stop
    "$side,$server,$type,""$sourceUNC"",""$destPath"",COPIED,""$notes""" | Out-File $reportPath -Append -Encoding UTF8
    Log "$side/$server [$type] COPIED :: $sourceUNC" 'GOOD'
    return $true
  }
  catch {
    Log "$side/$server [$type] COPY FAILED :: $sourceUNC :: $($_.Exception.Message)" 'ERROR'
    "$side,$server,$type,""$sourceUNC"","""",ERROR,""Copy failed: $notes""" | Out-File $reportPath -Append -Encoding UTF8
    return $false
  }
}

function Resolve-IISPhysicalPath([string]$path) {
  $p = $path.Trim()
  $p = $p -replace "%SystemDrive%", "C:"
  return $p
}

function Parse-ServiceExePath([string]$pathName) {
  if (-not $pathName) { return $null }

  $p = $pathName.Trim()

  if ($p.StartsWith('"')) {
    $secondQuote = $p.IndexOf('"', 1)
    if ($secondQuote -gt 1) {
      return $p.Substring(1, $secondQuote - 1)
    }
  }

  $m = [regex]::Match($p, '(?i)\.exe')
  if ($m.Success) {
    return $p.Substring(0, $m.Index + 4).Trim()
  }

  return $null
}

function Get-VisionRootFromExePath([string]$exePath) {
  if (-not $exePath) { return $null }

  $m = [regex]::Match($exePath, '^(?i)([A-Z]:\\Vision\\Vis[A-Z0-9_]+)\\')
  if ($m.Success) {
    return $m.Groups[1].Value
  }

  return $null
}

function Get-VisionRootsFromDisk([string]$server) {
  $roots = @()

  foreach ($drive in @("D","E")) {
    $baseLocal = "$drive`:\Vision"

    try {
      $baseUNC = LocalPathToUNC $server $baseLocal

      if (-not (Test-Path -LiteralPath $baseUNC)) {
        continue
      }

      $dirs = Get-ChildItem -LiteralPath $baseUNC -Directory -ErrorAction Stop |
        Where-Object { $_.Name -match '^VISPR' } |
        Select-Object -ExpandProperty Name

      foreach ($d in $dirs) {
        $roots += "$drive`:\Vision\$d"
      }
    }
    catch {
      Log "Failed scanning $baseLocal on $server :: $($_.Exception.Message)" 'WARN'
    }
  }

  return $roots | Sort-Object -Unique
}

function Get-VisionRootExtraFiles([string]$server, [string]$visionRoot) {
  if ([string]::IsNullOrWhiteSpace($visionRoot)) { return @() }

  $results = @()

  try {
    $rootUNC = LocalPathToUNC $server $visionRoot

    if (-not (Test-Path -LiteralPath $rootUNC)) {
      Log "Vision root UNC not accessible: $rootUNC" 'WARN'
      return @()
    }

    $extraFiles = Get-ChildItem -LiteralPath $rootUNC -File -ErrorAction Stop |
      Where-Object { $_.Extension -in @('.ini', '.settings') } |
      Select-Object -ExpandProperty FullName

    foreach ($f in $extraFiles) {
      if ($f -match "^\\\\$([Regex]::Escape($server))\\([A-Z])\`$(\\.*)$") {
        $drive = $Matches[1]
        $rest  = $Matches[2]
        $results += "${drive}:$rest"
      }
      else {
        Log "Skipping extra root file with unexpected UNC format: $f" 'WARN'
      }
    }
  }
  catch {
    Log "Failed enumerating root-level ini/settings files under $visionRoot on $server :: $($_.Exception.Message)" 'WARN'
  }

  return $results | Sort-Object -Unique
}

function Collect-FromServer([string]$side, [string]$server) {
  $destSideRoot = Join-Path $DestinationRoot $side
  EnsureDir $destSideRoot

  Log "---- START $side :: $server ----" 'STEP'

  if (-not (Test-Path -LiteralPath "\\$server\C$")) {
    Log "Cannot access \\$server\C$" 'ERROR'
    "$side,$server,ACCESS,""\\$server\C$"","""",ERROR,""No admin share access""" | Out-File $reportPath -Append -Encoding UTF8
    return
  }

  Log "Admin share access OK on $server" 'GOOD'

  $visionRoots = New-Object 'System.Collections.Generic.HashSet[string]'

  # -------- 1) SERVICE-BASED CONFIG COLLECTION --------
  Log "Querying VISPR services on $server" 'STEP'
  try {
    $services = Get-CimInstance -ComputerName $server -ClassName Win32_Service -Filter "Name LIKE 'VISPR%'" -ErrorAction Stop

    if (-not $services) {
      Log "No VISPR services returned from $server" 'SKIP'
    }
    else {
      Log "Found $($services.Count) VISPR services on $server" 'GOOD'
    }

    foreach ($svc in $services) {
      Log "Processing service $($svc.Name)" 'INFO'

      $exe = Parse-ServiceExePath $svc.PathName
      if (-not $exe) {
        Log "Could not parse PathName for service $($svc.Name)" 'SKIP'
        "$side,$server,SERVICE_CONFIG,""$($svc.Name)"","""",SKIP,""Could not parse PathName""" | Out-File $reportPath -Append -Encoding UTF8
        continue
      }

      $visionRoot = Get-VisionRootFromExePath $exe
      if ($visionRoot) {
        if (-not $visionRoots.Contains($visionRoot)) {
          [void]$visionRoots.Add($visionRoot)
          Log "Discovered Vision root from service: $visionRoot" 'GOOD'
        }
      }
      else {
        Log "No Vision root matched from EXE path: $exe" 'SKIP'
      }

      $cfg = "$exe.config"
      try {
        $cfgUNC = LocalPathToUNC $server $cfg
      }
      catch {
        Log "Could not convert service config path to UNC for $($svc.Name) :: $($_.Exception.Message)" 'WARN'
        "$side,$server,SERVICE_CONFIG,""$cfg"","""",SKIP,""UNC conversion failed for service=$($svc.Name)""" | Out-File $reportPath -Append -Encoding UTF8
        continue
      }

      if (Test-Path -LiteralPath $cfgUNC) {
        CopyOne $side $server "SERVICE_CONFIG" $cfgUNC $destSideRoot "Service=$($svc.Name)" | Out-Null
      }
      else {
        Log "Path not accessible or file not found for service $($svc.Name): $cfgUNC" 'SKIP'
        "$side,$server,SERVICE_CONFIG,""$cfgUNC"","""",SKIP,""Config path not accessible or file not found for service=$($svc.Name)""" | Out-File $reportPath -Append -Encoding UTF8
      }
    }
  }
  catch {
    Log "Could not query Win32_Service on $server (VISPR*). Will still continue with disk and IIS collection. :: $($_.Exception.Message)" 'WARN'
    "$side,$server,SERVICE_QUERY,""Win32_Service VISPR*"","""",ERROR,""Service query failed""" | Out-File $reportPath -Append -Encoding UTF8
  }

  # -------- 2) DISK-BASED ROOT DISCOVERY --------
  $diskRoots = Get-VisionRootsFromDisk -server $server

  if ($diskRoots.Count -gt 0) {
    Log "Discovered $($diskRoots.Count) Vision root(s) from disk scan on $server" 'GOOD'
    foreach ($r in $diskRoots) {
      if (-not $visionRoots.Contains($r)) {
        [void]$visionRoots.Add($r)
        Log "Adding Vision root from disk: $r" 'INFO'
      }
    }
  }
  else {
    Log "No additional Vision roots found via disk scan on $server" 'SKIP'
  }

  # -------- 3) ROOT-LEVEL INI / SETTINGS UNDER EACH DISCOVERED ROOT --------
  if ($visionRoots.Count -gt 0) {
    Log "Processing $($visionRoots.Count) discovered Vision root(s) on $server" 'STEP'

    foreach ($vr in $visionRoots) {
      Log "Enumerating root-level ini/settings files under $vr" 'INFO'

      $rootFiles = Get-VisionRootExtraFiles -server $server -visionRoot $vr

      if (-not $rootFiles -or $rootFiles.Count -eq 0) {
        Log "No root-level ini/settings files found under $vr" 'SKIP'
        "$side,$server,VISION_ROOT_FILE,""$vr"","""",SKIP,""No root-level ini/settings files found""" | Out-File $reportPath -Append -Encoding UTF8
        continue
      }

      Log "Found $($rootFiles.Count) root-level ini/settings file(s) under $vr" 'GOOD'

      foreach ($localFile in $rootFiles) {
        try {
          $fileUNC = LocalPathToUNC $server $localFile
        }
        catch {
          Log "Could not convert root file to UNC: $localFile :: $($_.Exception.Message)" 'WARN'
          "$side,$server,VISION_ROOT_FILE,""$localFile"","""",SKIP,""UNC conversion failed under discovered root $vr""" | Out-File $reportPath -Append -Encoding UTF8
          continue
        }

        if (Test-Path -LiteralPath $fileUNC) {
          CopyOne $side $server "VISION_ROOT_FILE" $fileUNC $destSideRoot "DiscoveredFrom=$vr" | Out-Null
        }
        else {
          Log "Root file path not accessible or file not found: $fileUNC" 'SKIP'
          "$side,$server,VISION_ROOT_FILE,""$fileUNC"","""",SKIP,""Root file path not accessible or file not found under discovered root $vr""" | Out-File $reportPath -Append -Encoding UTF8
        }
      }
    }
  }
  else {
    Log "No Vision roots discovered from either services or disk on $server" 'SKIP'
    "$side,$server,VISION_ROOT_FILE,""VisionRootDiscovery"","""",SKIP,""No Vision roots discovered from either services or disk""" | Out-File $reportPath -Append -Encoding UTF8
  }

  # -------- 4) IIS: applicationHost.config + web.config + *.json discovery --------
  Log "Checking IIS configuration on $server" 'STEP'
  $iisLocal = "C:\Windows\System32\inetsrv\config\applicationHost.config"
  $iisUNC   = LocalPathToUNC $server $iisLocal

  if (Test-Path -LiteralPath $iisUNC) {
    $copiedOk = CopyOne $side $server "IIS_CONFIG" $iisUNC $destSideRoot
    if ($copiedOk) {
      $copiedPath = UNCToDestPath -destSideRoot $destSideRoot -server $server -uncPath $iisUNC

      try {
        [xml]$appHost = Get-Content -LiteralPath $copiedPath -ErrorAction Stop

        $vdirs = $appHost.configuration.'system.applicationHost'.sites.site.application.virtualDirectory |
                 Where-Object { $_.physicalPath } |
                 ForEach-Object { $_.physicalPath } |
                 Sort-Object -Unique

        Log "Found $($vdirs.Count) IIS physical path(s) on $server" 'GOOD'

        foreach ($p in $vdirs) {
          Log "Processing IIS root: $p" 'INFO'
          $resolved = Resolve-IISPhysicalPath $p

          if ($resolved -match "^\\\\") {
            $rootUNC = $resolved
          }
          else {
            if ($resolved.Length -ge 3 -and $resolved[1] -eq ":") {
              try {
                $rootUNC = LocalPathToUNC $server $resolved
              }
              catch {
                Log "Could not convert IIS root to UNC: $resolved :: $($_.Exception.Message)" 'WARN'
                "$side,$server,WEB_CONFIG,""$resolved"","""",SKIP,""UNC conversion failed for IIS root""" | Out-File $reportPath -Append -Encoding UTF8
                continue
              }
            }
            else {
              Log "Unrecognized IIS physicalPath format: $p" 'SKIP'
              "$side,$server,WEB_CONFIG,""$p"","""",SKIP,""Unrecognized physicalPath format""" | Out-File $reportPath -Append -Encoding UTF8
              continue
            }
          }

          $webUNC = Join-Path $rootUNC "web.config"
          if (Test-Path -LiteralPath $webUNC) {
            CopyOne $side $server "WEB_CONFIG" $webUNC $destSideRoot "IISRoot=$p" | Out-Null
          }
          else {
            Log "web.config not found under IIS root: $webUNC" 'SKIP'
            "$side,$server,WEB_CONFIG,""$webUNC"","""",SKIP,""web.config not found (IISRoot=$p)""" | Out-File $reportPath -Append -Encoding UTF8
          }

          try {
            $jsonFiles = Get-ChildItem -Path $rootUNC -File -Filter "*.json" -ErrorAction Stop
            if ($jsonFiles.Count -eq 0) {
              Log "No root-level JSON files under $rootUNC" 'SKIP'
            }

            foreach ($j in $jsonFiles) {
              CopyOne $side $server "WEB_JSON_CONFIG" $j.FullName $destSideRoot "IISRoot=$p" | Out-Null
            }
          }
          catch {
            Log "Failed searching $rootUNC for *.json :: $($_.Exception.Message)" 'WARN'
          }

          if ($RecurseWebConfigs -and (Test-Path -LiteralPath $rootUNC)) {
            try {
              $nestedWebConfigs = Get-ChildItem -Path $rootUNC -Recurse -File -Filter "web.config" -ErrorAction Stop
              foreach ($w in $nestedWebConfigs) {
                CopyOne $side $server "WEB_CONFIG" $w.FullName $destSideRoot "IISRoot=$p" | Out-Null
              }
            }
            catch {
              Log "Recurse web.config failed under $rootUNC :: $($_.Exception.Message)" 'WARN'
            }
          }
        }
      }
      catch {
        Log "Failed to parse copied applicationHost.config for $server :: $($_.Exception.Message)" 'ERROR'
        "$side,$server,IIS_PARSE,""$copiedPath"","""",ERROR,""Parse failed""" | Out-File $reportPath -Append -Encoding UTF8
      }
    }
  }
  else {
    Log "applicationHost.config not found on $server (IIS not installed?)" 'SKIP'
    "$side,$server,IIS_CONFIG,""$iisUNC"","""",SKIP,""applicationHost.config not found (IIS not installed?)""" | Out-File $reportPath -Append -Encoding UTF8
  }

  Log "---- END $side :: $server ----" 'STEP'
}

# ---------- Run ----------
$map = Import-Csv -Path $CsvPath
if (-not $map) {
  throw "CSV is empty."
}

if (-not ($map[0].PSObject.Properties.Name -contains "OLD_Server" -and $map[0].PSObject.Properties.Name -contains "NEW_Server")) {
  throw "CSV must have headers: OLD_Server, NEW_Server"
}

$oldServers = $map | ForEach-Object { $_.OLD_Server } | Where-Object { $_ } | ForEach-Object { $_.Trim() } | Sort-Object -Unique
$newServers = $map | ForEach-Object { $_.NEW_Server } | Where-Object { $_ } | ForEach-Object { $_.Trim() } | Sort-Object -Unique

if ($EnvironmentToken -ne "") {
  $oldServers = $oldServers | Where-Object { $_ -match [Regex]::Escape($EnvironmentToken) }
  $newServers = $newServers | Where-Object { $_ -match [Regex]::Escape($EnvironmentToken) }
}

Log "Starting collection. OLD=$($oldServers.Count) NEW=$($newServers.Count) Dest=$DestinationRoot EnvFilter='$EnvironmentToken' RecurseWebConfigs=$RecurseWebConfigs" 'STEP'

foreach ($s in $oldServers) {
  Collect-FromServer -side "OLD" -server $s
}

foreach ($s in $newServers) {
  Collect-FromServer -side "NEW" -server $s
}

Log "Done. Report=$reportPath Log=$logPath" 'GOOD'
Write-Host ""
Write-Host "DONE. Report: $reportPath" -ForegroundColor Green
Write-Host "      Log:    $logPath" -ForegroundColor Green