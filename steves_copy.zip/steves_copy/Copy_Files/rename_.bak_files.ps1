﻿<#
.SYNOPSIS
Promotes *.bak config files by archiving the current live file with a timestamp,
then renaming the .bak file to the live filename.

.DESCRIPTION
For each server in the input list, this script scans one or more root paths for *.bak files.
If a matching live file already exists, it is renamed to:
    <filename>.bak_yyyyMMdd_HHmmss
Then the *.bak file is renamed to the live filename.

Example:
    Vision_VisVT.settings          -> Vision_VisVT.settings.bak_20260410_101530
    Vision_VisVT.settings.bak      -> Vision_VisVT.settings

.NOTES
- Designed for UNC admin shares on remote servers
- Read the -WhatIf section below before live use

C:\temp\QCAD\VT\Configs\Merging
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ServerListPath,

    [string[]]$SearchRoots = @(
        'D$\Vision'
        #'E$\Vision'
    ),

    [string]$LogPath = "C:\temp\promote_bak_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv",

    [switch]$WhatIf
)

$timestamp = Get-Date -Format 'yyyyMMdd'

"Server,Action,Source,Destination,Status,Notes" | Out-File -FilePath $LogPath -Encoding utf8

function Write-Log {
    param(
        [string]$Server,
        [string]$Action,
        [string]$Source,
        [string]$Destination,
        [string]$Status,
        [string]$Notes
    )

    $line = '"{0}","{1}","{2}","{3}","{4}","{5}"' -f `
        $Server, $Action, $Source, $Destination, $Status, $Notes.Replace('"','""')

    $line | Out-File -FilePath $LogPath -Append -Encoding utf8
}

$servers = Get-Content -Path $ServerListPath | Where-Object { $_.Trim() } | ForEach-Object { $_.Trim() }

foreach ($server in $servers) {
    Write-Host "=== $server ===" -ForegroundColor Cyan

    foreach ($root in $SearchRoots) {
        $uncRoot = "\\$server\$root"

        if (-not (Test-Path -LiteralPath $uncRoot)) {
            Write-Host "SKIP root not accessible: $uncRoot" -ForegroundColor Yellow
            Write-Log -Server $server -Action "SCAN" -Source $uncRoot -Destination "" -Status "SKIP" -Notes "Root not accessible"
            continue
        }

        Write-Host "Scanning $uncRoot" -ForegroundColor Gray

        try {
            $bakFiles = Get-ChildItem -LiteralPath $uncRoot -Recurse -File -Filter "*.bak" -ErrorAction Stop
        }
        catch {
            Write-Host "ERROR scanning $uncRoot : $($_.Exception.Message)" -ForegroundColor Red
            Write-Log -Server $server -Action "SCAN" -Source $uncRoot -Destination "" -Status "ERROR" -Notes $_.Exception.Message
            continue
        }

        foreach ($bak in $bakFiles) {
            $bakPath = $bak.FullName
            $livePath = $bakPath -replace '\.bak$',''

            if ($livePath -eq $bakPath) {
                Write-Host "SKIP invalid bak pattern: $bakPath" -ForegroundColor Yellow
                Write-Log -Server $server -Action "PARSE" -Source $bakPath -Destination "" -Status "SKIP" -Notes "Could not derive live filename"
                continue
            }

            $archivePath = "$livePath.bak_$timestamp"

            try {
                if (Test-Path -LiteralPath $livePath) {
                    Write-Host "Archive live: $livePath -> $archivePath" -ForegroundColor Yellow
                    if (-not $WhatIf) {
                        Rename-Item -LiteralPath $livePath -NewName (Split-Path -Path $archivePath -Leaf) -ErrorAction Stop
                    }
                    Write-Log -Server $server -Action "ARCHIVE_LIVE" -Source $livePath -Destination $archivePath -Status "OK" -Notes "Existing live file archived"
                }
                else {
                    Write-Host "No live file exists for: $livePath" -ForegroundColor Gray
                    Write-Log -Server $server -Action "ARCHIVE_LIVE" -Source $livePath -Destination $archivePath -Status "SKIP" -Notes "No existing live file"
                }

                Write-Host "Promote bak: $bakPath -> $livePath" -ForegroundColor Green
                if (-not $WhatIf) {
                    Rename-Item -LiteralPath $bakPath -NewName (Split-Path -Path $livePath -Leaf) -ErrorAction Stop
                }
                Write-Log -Server $server -Action "PROMOTE_BAK" -Source $bakPath -Destination $livePath -Status "OK" -Notes "Bak promoted to live"
            }
            catch {
                Write-Host "ERROR processing $bakPath : $($_.Exception.Message)" -ForegroundColor Red
                Write-Log -Server $server -Action "PROMOTE_BAK" -Source $bakPath -Destination $livePath -Status "ERROR" -Notes $_.Exception.Message
            }
        }
    }
}

Write-Host ""
Write-Host "Done. Log: $LogPath" -ForegroundColor Green