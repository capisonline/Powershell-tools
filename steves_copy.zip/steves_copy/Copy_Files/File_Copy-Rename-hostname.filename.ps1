﻿# This connects to the listed servers and recursively searches the D:\Vision folder for anything 
# with the extension *.config
# it then copies the file to your output location and adds the hostname_ to the beginning of the file
# these files can then be worked on without impacting the source servers.

# Define the input file containing the list of server names and the output location 
$inputFile = "C:\temp\QCAD\PA\PA_OLD_New_Serverlist.txt"
$outputLocation = "C:\temp\QCAD\PA\QA\Config_Matching"

# Read the list of server names from the input file
$servers = Get-Content -Path $inputFile

# Function to copy config files from remote server
function Copy-ConfigFiles {
    param (
        [string]$server
    )

    # Define the remote path to search for config files
    $remotePath = "D:\Vision"

    # Establish a new PSSession to the remote server
    $session = New-PSSession -ComputerName $server

    # Command to find all app.exe.config files in the remote Vision directory
    $remoteCommand = {
        param ($remotePath)
        Get-ChildItem -Path $remotePath -Recurse -Filter *.config
    }

    # Execute the command on the remote server
    $configFiles = Invoke-Command -Session $session -ScriptBlock $remoteCommand -ArgumentList $remotePath

    # Copy each found config file to the local machine, renaming it with the hostname
    foreach ($file in $configFiles) {
        $localFileName = "$server" + "_" + $file.Name
        $localFilePath = Join-Path -Path $outputLocation -ChildPath $localFileName
        Copy-Item -Path $file.FullName -Destination $localFilePath -FromSession $session
    }

    # Remove the PSSession
    Remove-PSSession -Session $session
}

# Iterate over each server and copy the config files
foreach ($server in $servers) {
    Copy-ConfigFiles -server $server
}
