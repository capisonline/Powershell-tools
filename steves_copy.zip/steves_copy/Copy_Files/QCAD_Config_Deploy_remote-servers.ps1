﻿<#
.SYNOPSIS
Deploys QCAD config files from a local OLD/NEW folder structure to their target servers.

.DESCRIPTION
This script walks the local source tree under:
C:\temp\QCAD\VT\Configs\Merging

It derives the destination path directly from the folder structure, for example:

C:\temp\QCAD\VT\Configs\Merging\OLD\QPS-VAS-VT-05\D$\Vision\VisVT\Services\FortekCoreService\FortekCoreService.exe.config

becomes:

\\QPS-VAS-VT-05\D$\Vision\VisVT\Services\FortekCoreService\FortekCoreService.exe.config

Before overwriting a target file, the script creates a rollback backup:
- If no .bak exists, it creates: <filename>.bak
- If a .bak already exists, it creates: <filename>.yyyyMMdd_HHmmss.bak

The script does NOT restart any services.

It logs all actions to CSV and text log files.

.NOTES
Designed for controlled deployment of QCAD config files in mission-critical environments.
Run from an elevated PowerShell session with access to the target admin shares.
#>

# -----------------------------
# Configuration
# -----------------------------
$BasePath   = "C:\temp\QCAD\VT\Configs\Merging"
$LogRoot    = "C:\temp\QCAD\VT\Configs\Merging\Logs"
$TimeStamp  = Get-Date -Format "yyyyMMdd_HHmmss"
$CsvLogPath = Join-Path $LogRoot "ConfigDeploy_$TimeStamp.csv"
$TxtLogPath = Join-Path $LogRoot "ConfigDeploy_$TimeStamp.log"

# Set to $true for dry run only
$WhatIfMode = $false

# -----------------------------
# Initialisation
# -----------------------------
if (-not (Test-Path $BasePath)) {
    throw "Base path not found: $BasePath"
}

if (-not (Test-Path $LogRoot)) {
    New-Item -Path $LogRoot -ItemType Directory -Force | Out-Null
}

$CsvLog = New-Object System.Collections.Generic.List[Object]

function Write-Log {
    param(
        [string]$Level,
        [string]$Message
    )

    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Write-Host $line
    Add-Content -Path $TxtLogPath -Value $line
}

function Add-CsvLog {
    param(
        [string]$Status,
        [string]$SourceFile,
        [string]$TargetFile,
        [string]$BackupFile,
        [string]$Server,
        [string]$Mode,
        [string]$Message
    )

    $CsvLog.Add([pscustomobject]@{
        Timestamp  = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Status     = $Status
        Mode       = $Mode
        Server     = $Server
        SourceFile = $SourceFile
        TargetFile = $TargetFile
        BackupFile = $BackupFile
        Message    = $Message
    })
}

function Get-DeploymentTarget {
    param(
        [string]$FullSourcePath,
        [string]$RootPath
    )

    $relative = $FullSourcePath.Substring($RootPath.Length).TrimStart('\')
    $parts = $relative -split '\\'

    if ($parts.Count -lt 3) {
        throw "Path does not conform to expected structure: $FullSourcePath"
    }

    # Expected:
    # OLD|NEW \ ServerName \ D$ \ ...
    $tier       = $parts[0]
    $serverName = $parts[1]
    $sharePath  = ($parts[2..($parts.Count - 1)] -join '\')

    $targetPath = "\\$serverName\$sharePath"

    return [pscustomobject]@{
        Tier       = $tier
        ServerName = $serverName
        SharePath  = $sharePath
        TargetPath = $targetPath
    }
}

function Get-BackupPath {
    param(
        [string]$TargetFile
    )

    $defaultBak = "$TargetFile.bak"

    if (-not (Test-Path $defaultBak)) {
        return $defaultBak
    }

    $ts = Get-Date -Format "yyyyMMdd_HHmmss"
    return "$TargetFile.$ts.bak"
}

# -----------------------------
# Processing
# -----------------------------
Write-Log -Level "INFO" -Message "Starting config deployment scan from: $BasePath"
Write-Log -Level "INFO" -Message "WhatIfMode = $WhatIfMode"

$files = Get-ChildItem -Path $BasePath -Recurse -File | Where-Object {
    $_.FullName -notmatch '\\Logs\\'
}

if (-not $files) {
    Write-Log -Level "WARN" -Message "No files found under $BasePath"
}

foreach ($file in $files) {
    $backupPath = ""
    $targetPath = ""
    $serverName = ""

    try {
        $target = Get-DeploymentTarget -FullSourcePath $file.FullName -RootPath $BasePath
        $targetPath = $target.TargetPath
        $serverName = $target.ServerName

        Write-Log -Level "INFO" -Message "Processing source file: $($file.FullName)"
        Write-Log -Level "INFO" -Message "Derived target path: $targetPath"

        $targetDir = Split-Path $targetPath -Parent

        if (-not (Test-Path $targetDir)) {
            throw "Target directory not reachable: $targetDir"
        }

        if (-not (Test-Path $targetPath)) {
            throw "Target file does not exist: $targetPath"
        }

        $backupPath = Get-BackupPath -TargetFile $targetPath
        Write-Log -Level "INFO" -Message "Backup path: $backupPath"

        if ($WhatIfMode) {
            Write-Log -Level "INFO" -Message "DRY RUN: Would back up '$targetPath' to '$backupPath'"
            Write-Log -Level "INFO" -Message "DRY RUN: Would copy '$($file.FullName)' to '$targetPath'"

            Add-CsvLog -Status "DRYRUN" `
                       -SourceFile $file.FullName `
                       -TargetFile $targetPath `
                       -BackupFile $backupPath `
                       -Server $serverName `
                       -Mode "WhatIf" `
                       -Message "Would back up and deploy"
            continue
        }

        Copy-Item -Path $targetPath -Destination $backupPath -Force -ErrorAction Stop
        Write-Log -Level "INFO" -Message "Backup created: $backupPath"

        Copy-Item -Path $file.FullName -Destination $targetPath -Force -ErrorAction Stop
        Write-Log -Level "INFO" -Message "Deploy complete: $targetPath"

        Add-CsvLog -Status "SUCCESS" `
                   -SourceFile $file.FullName `
                   -TargetFile $targetPath `
                   -BackupFile $backupPath `
                   -Server $serverName `
                   -Mode "Deploy" `
                   -Message "Backup created and file deployed"
    }
    catch {
        $err = $_.Exception.Message
        Write-Log -Level "ERROR" -Message "Failed processing '$($file.FullName)' :: $err"

        Add-CsvLog -Status "FAILED" `
                   -SourceFile $file.FullName `
                   -TargetFile $targetPath `
                   -BackupFile $backupPath `
                   -Server $serverName `
                   -Mode $(if ($WhatIfMode) { "WhatIf" } else { "Deploy" }) `
                   -Message $err
    }
}

# -----------------------------
# Finalise logs
# -----------------------------
$CsvLog | Export-Csv -Path $CsvLogPath -NoTypeInformation -Encoding UTF8

Write-Log -Level "INFO" -Message "Completed deployment run"
Write-Log -Level "INFO" -Message "CSV log: $CsvLogPath"
Write-Log -Level "INFO" -Message "Text log: $TxtLogPath"