﻿
# Output Path: C:\temp\QCAD\VT\Merge\Merge_Discovery

$serverList = Get-Content "C:\temp\QCAD\VT\VT_Old_Servers.txt"
$outputRoot = "C:\temp\QCAD\VT\Merge\Merge_Discovery\old_servers"
$logFile = Join-Path $outputRoot "discovery_log.csv"

# Ensure output directory exists
New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
"Server,RemotePath,LocalPath,Status" | Out-File -FilePath $logFile -Encoding UTF8

foreach ($server in $serverList) {
    Write-Host "Processing $server..."

    $remoteFolders = @()

    # Always include D$\vision
    $visionPath = "\\$server\d$\vision"
    if (Test-Path $visionPath) {
        $remoteFolders += $visionPath
    }

    # Conditionally include D$\inetpub
    $inetpubPath = "\\$server\d$\inetpub"
    if (Test-Path $inetpubPath) {
        $remoteFolders += $inetpubPath
    }

    # Try to parse IIS config paths
    try {
        $configPath = "\\$server\c$\Windows\System32\inetsrv\config\applicationHost.config"
        if (Test-Path $configPath) {
            [xml]$iisConfig = Get-Content $configPath
            $iisPaths = $iisConfig.configuration.'system.applicationHost'.sites.site.application |
                ForEach-Object {
                    $_.virtualDirectory |
                        Where-Object { $_.path -eq "/" } |
                        ForEach-Object { $_.physicalPath }
                }
            foreach ($iisPath in $iisPaths) {
                $uncPath = $iisPath -replace ":", "$"
                $uncPath = "\\$server\$uncPath"
                if (Test-Path $uncPath) {
                    $remoteFolders += $uncPath
                }
            }
        }
    } catch {
        Write-Warning "Failed to parse IIS config on $server"
    }

    foreach ($remoteRoot in $remoteFolders) {
        try {
            $files = Get-ChildItem -Path $remoteRoot -Include *.config,*.ini,*.settings -Recurse -ErrorAction SilentlyContinue
            foreach ($file in $files) {
                $relative = $file.FullName -replace "^\\\\$server\\", ""
                $relative = $relative -replace ":", ""  # Remove colon from drive letter
                $localPath = Join-Path $outputRoot "$server\$relative"

                $localDir = Split-Path $localPath -Parent
                New-Item -ItemType Directory -Path $localDir -Force | Out-Null

                Copy-Item -Path $file.FullName -Destination $localPath -Force
                Add-Content $logFile "$server,$($file.FullName),$localPath,SUCCESS"
            }
        } catch {
            Add-Content $logFile "$server,$remoteRoot,,ERROR - $_"
        }
    }
} 
