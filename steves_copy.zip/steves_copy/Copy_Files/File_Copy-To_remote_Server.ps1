﻿# Read the list of servers from the text file 
$serverList = Get-Content "C:\temp\QCAD\PA\PA_NEW_Server_list.txt"

# Path to the SQL Server backup script that needs to be deployed
$sourceScriptPath = "C:\temp\QCAD\PA\LogOff\LogOff.lnk"

# Loop through each server and copy the script to a specific location
foreach ($server in $serverList) {
    $destinationPath = "\\$server\C$\Users\Public\Desktop"
    # Ensure the destination folder exists
    if (-Not (Test-Path "\\$server\E$\")) {
        New-Item -Path "\\$server\E$\" -ItemType Directory
    }
    # Copy the script to the destination
    Copy-Item -Path $sourceScriptPath -Destination $destinationPath -Force
    Write-Output "Script copied to $server"
}
