﻿<#
.SYNOPSIS
    Scan a list of servers for specific Windows Event Log entries (e.g. MPIO errors).

.DESCRIPTION
    - Reads server names from a text file (one per line).
    - Queries the System log on each server.
    - Filters by Source (e.g. 'mpio') and a list of Event IDs.
    - Optionally limits search to the last X days.
    - Outputs results to a CSV.

.NOTES
    Run from a machine/account that has rights to read remote event logs.
#>

param(
    # Text file with one server name per line
    [string]$ServerListFile = "C:\temp\servers.txt",

    # Output CSV
    [string]$OutputCsv      = "C:\temp\Mpio_Events_Report.csv",

    # Event log name (mpio events are in the System log)
    [string]$LogName        = "System",

    # Event source / provider (for mpio errors, this is 'mpio')
    [string]$Source         = "mpio",

    # Event IDs to search for (default: typical MPIO events 16 & 17, plus 46 for path removed)
    [int[]]$EventIds        = @(16, 17, 46),

    # How many days back to search
    [int]$DaysBack          = 7
)

# Ensure output folder exists
$folder = Split-Path $OutputCsv -Parent
if (-not (Test-Path $folder)) {
    New-Item -Path $folder -ItemType Directory | Out-Null
}

Write-Host "Reading servers from: $ServerListFile"
$servers = Get-Content -Path $ServerListFile | Where-Object { $_ -and -not $_.StartsWith("#") }

if (-not $servers) {
    Write-Error "No servers found in $ServerListFile"
    exit 1
}

$results = @()
$startTime = (Get-Date).AddDays(-$DaysBack)

Write-Host "Searching $LogName log for source '$Source', Event IDs: $($EventIds -join ', '), last $DaysBack day(s)..."
Write-Host ""

foreach ($server in $servers) {
    $server = $server.Trim()
    if (-not $server) { continue }

    Write-Host "Processing server: $server ..." -ForegroundColor Cyan

    try {
        $filter = @{
            LogName      = $LogName
            ProviderName = $Source
            Id           = $EventIds
            StartTime    = $startTime
        }

        $events = Get-WinEvent -ComputerName $server -FilterHashtable $filter -ErrorAction Stop

        foreach ($evt in $events) {
            $results += [pscustomobject]@{
                Server          = $server
                TimeCreated     = $evt.TimeCreated
                EventId         = $evt.Id
                Level           = $evt.LevelDisplayName
                Source          = $evt.ProviderName
                Message         = $evt.Message -replace "`r`n", " "  # flatten message
            }
        }
    }
    catch {
        # Capture connectivity / permission issues as a row as well
        Write-Warning "Failed to query $server : $($_.Exception.Message)"

        $results += [pscustomobject]@{
            Server          = $server
            TimeCreated     = $null
            EventId         = $null
            Level           = "Error"
            Source          = "$Source (scan)"
            Message         = "Failed to query server: $($_.Exception.Message)"
        }
    }
}

Write-Host ""
Write-Host "Found $($results.Count) matching events. Writing to $OutputCsv ..." -ForegroundColor Green

$results |
    Sort-Object Server, TimeCreated |
    Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8

Write-Host "Done."
