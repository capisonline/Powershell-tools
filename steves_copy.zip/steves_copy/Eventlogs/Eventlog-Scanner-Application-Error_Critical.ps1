﻿# Remember to change how many results you want returned. 
# This was set to 1 for testing. Lots can take a while.
# Define the input file with the list of servers 
$serverListFile = "C:\temp\QCAD\PA\PA_NEW_Server_list _logman_test.txt"

# Define the output directory where the CSV files will be saved
$outputDir = "C:\temp\QCAD\PA\Issues\eventlogs"

# Ensure the output directory exists
if (-not (Test-Path -Path $outputDir)) {
    New-Item -ItemType Directory -Path $outputDir
}

# Import the list of servers from the text file
$servers = Get-Content -Path $serverListFile

# Loop through each server in the list
foreach ($server in $servers) {
    Write-Host "Connecting to $server..."

    try {
        # Retrieve event logs from the Application log, filtering for Errors and Critical, and limit to 100 results
        $eventLogs = Get-WinEvent -ComputerName $server -LogName Application -ErrorAction Stop |
            Where-Object { $_.LevelDisplayName -eq "Error" -or $_.LevelDisplayName -eq "Critical" } |
            Select-Object -First 1

        # If any logs are retrieved, export them to a CSV file
        if ($eventLogs) {
            $outputFile = Join-Path -Path $outputDir -ChildPath "$server-ApplicationLogs.csv"

            $eventLogs | Select-Object TimeCreated, LevelDisplayName, Id, ProviderName, Message |
            Export-Csv -Path $outputFile -NoTypeInformation

            Write-Host "Event logs saved to $outputFile"
        } else {
            Write-Host "No Error or Warning logs found on $server"
        }
    } catch {
        Write-Warning "Failed to connect to $server or retrieve logs. Error: $_"
    }
}

Write-Host "Script completed."
