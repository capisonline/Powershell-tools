﻿<#
.SYNOPSIS
  Collects Windows Resource-Exhaustion Resolver events (ID 1014) from Win2019 servers.

.EXAMPLE
  .\Get-RERLandscape.ps1 -ComputerName POLVCADVASVT03, POLVCADVASVT04 -DaysBack 90 -OutCsv .\rer_landscape.csv

.PARAMETER ComputerName
  One or more server names (NetBIOS or FQDN). Defaults to the local computer.

.PARAMETER DaysBack
  How far back to search. Default: 30 days.

.PARAMETER Credential
  Optional credential for remote queries. If omitted, uses current credentials.

.PARAMETER OutCsv
  Optional path to write a consolidated CSV of results.

.NOTES
  - Requires network/WMI/WinRM access to targets and permission to read event logs.
  - Channel: Microsoft-Windows-Resource-Exhaustion-Resolver/Operational
#>

[CmdletBinding()]
param(
  [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
  [string[]]$ComputerName = $env:COMPUTERNAME,

  [int]$DaysBack = 30,

  [System.Management.Automation.PSCredential]$Credential,

  [string]$OutCsv
)

begin {
  $startTime = (Get-Date).AddDays(-[math]::Abs($DaysBack))
  $channel   = 'Microsoft-Windows-Resource-Exhaustion-Resolver/Operational'
  $eventId   = 1014

  $results = New-Object System.Collections.Generic.List[object]
}

process {
  foreach ($cn in $ComputerName) {
    Write-Verbose "Querying $cn …"

    # Build an efficient Get-WinEvent filter
    $filter = @{ LogName = $channel; Id = $eventId; StartTime = $startTime }

    try {
      $events = if ($Credential) {
        Get-WinEvent -ComputerName $cn -FilterHashtable $filter -ErrorAction Stop
      } else {
        Get-WinEvent -ComputerName $cn -FilterHashtable $filter -ErrorAction Stop
      }

      foreach ($evt in $events) {
        # Parse the XML to extract fields from DroppedLeakDiagnosisEventInfo
        try {
          $xml = [xml]$evt.ToXml()

          # Namespaces
          $ns = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
          $ns.AddNamespace('e', 'http://schemas.microsoft.com/win/2004/08/events/event')
          $ns.AddNamespace('r', 'http://www.microsoft.com/Windows/Resource/Exhaustion/Resolver/Event')

          $sysTime     = $xml.SelectSingleNode('/e:Event/e:System/e:TimeCreated', $ns).GetAttribute('SystemTime')
          $recordId    = $xml.SelectSingleNode('/e:Event/e:System/e:EventRecordID', $ns).'#text'
          $activityId  = $xml.SelectSingleNode('/e:Event/e:System/e:Correlation', $ns).GetAttribute('ActivityID')

          $imgNode     = $xml.SelectSingleNode('/e:Event/e:UserData/r:DroppedLeakDiagnosisEventInfo/r:ProcessImageName', $ns)
          $pidNode     = $xml.SelectSingleNode('/e:Event/e:UserData/r:DroppedLeakDiagnosisEventInfo/r:ProcessId', $ns)
          $pctNode     = $xml.SelectSingleNode('/e:Event/e:UserData/r:DroppedLeakDiagnosisEventInfo/r:ProcessCreationTime', $ns)
          $codeNode    = $xml.SelectSingleNode('/e:Event/e:UserData/r:DroppedLeakDiagnosisEventInfo/r:DropReasonCode', $ns)

          $obj = [pscustomobject]@{
            Computer                 = $cn
            EventRecordID            = [long]$recordId
            EventTimeUTC             = [datetime]$sysTime
            EventTimeLocal           = ([datetime]$sysTime).ToLocalTime()
            ActivityID               = $activityId
            ProcessImageName         = $imgNode.'#text'
            ProcessId                = [int]$pidNode.'#text'
            ProcessCreationTimeUTC   = if ($pctNode) { [datetime]$pctNode.'#text' } else { $null }
            ProcessCreationTimeLocal = if ($pctNode) { ([datetime]$pctNode.'#text').ToLocalTime() } else { $null }
            DropReasonCode           = if ($codeNode) { [int]$codeNode.'#text' } else { $null }
            Channel                  = $channel
            EventID                  = $eventId
          }

          $results.Add($obj) | Out-Null
        }
        catch {
          Write-Warning "[$cn] Failed to parse event XML (RecordID $($evt.RecordId)): $($_.Exception.Message)"
        }
      }

      if (-not $events) {
        Write-Verbose "[$cn] No matching events found."
      }
    }
    catch {
      Write-Warning "[$cn] Query failed: $($_.Exception.Message)"
    }
  }
}

end {
  if ($results.Count -gt 0) {
    $sorted = $results | Sort-Object Computer, EventTimeUTC

    # Emit to pipeline
    $sorted

    if ($OutCsv) {
      try {
        $sorted | Export-Csv -Path $OutCsv -NoTypeInformation -Encoding UTF8
        Write-Host "Exported $($sorted.Count) rows to: $OutCsv" -ForegroundColor Green
      } catch {
        Write-Warning "Failed to write CSV: $($_.Exception.Message)"
      }
    }
  }
  else {
    Write-Host "No Resource-Exhaustion Resolver events (ID 1014) found within the last $DaysBack days for the given hosts." -ForegroundColor Yellow
  }
}
