﻿<#
.SYNOPSIS
Collects SHA-256 hash values and metadata for all files under a specified folder
on each target host, saving results to $hostname__Hashed_Files.csv.

.DESCRIPTION
Connects to a list of remote machines and enumerates all files under the configured
root path. For each file, computes a SHA-256 hash and records optional metadata
(name, extension, version, timestamps). The inventory is exported locally as
"<Hostname>_Hashed_Files.csv". This inventory can be used to establish a baseline
manifest or to capture the deployed state of each host for later comparison.

.OUTPUTS
CSV files saved locally, one per host, containing at minimum:
- FullName
- HashSHA256
Optional columns (may be null): Name, Extension, FileVersion, ProductVersion,
CreationTime, LastWriteTime.

.EXAMPLE
Run once to generate a baseline manifest from a golden build:
    .\Collect-FileHashes.ps1
Use the resulting CSV as the baseline in Compare-AgainstBaseline.ps1
#>


# ==========================
# HARD-CODED SETTINGS
# ==========================
$ServersFile   = "C:\temp\QCAD\PS\PS_Old_servers.txt"       # one hostname per line
$RemoteRoot    = "D:\vision\visPS\Services"              # folder to scan on the remote
$LocalOutDir   = "C:\temp\QCAD\PS\Issues\File_Hashes"               # where CSVs are saved locally
$LogFile       = Join-Path $LocalOutDir "collection_log_$(Get-Date -Format yyyyMMdd_HHmmss).txt"

# ==========================
# PREP
# ==========================
New-Item -ItemType Directory -Path $LocalOutDir -Force | Out-Null
$servers = Get-Content -Path $ServersFile | Where-Object { $_ -and $_.Trim() -ne "" }

# helper: write both to console and log
function Write-Log {
  param([string]$msg)
  $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
  $line | Tee-Object -FilePath $LogFile -Append
}

Write-Log "Starting hash collection. Remote root: $RemoteRoot"

foreach ($server in $servers) {
  $hostName = $server.Trim()
  $csvPath  = Join-Path $LocalOutDir ("{0}_Hashed_Files.csv" -f $hostName)
  Write-Log "[$hostName] Starting…"

  try {
    $data = Invoke-Command -ComputerName $hostName -ErrorAction Stop -ScriptBlock {
      param($Path)
      # Enumerate & hash on the remote to avoid copying files
      if (-not (Test-Path -LiteralPath $Path)) {
        throw "Path not found: $Path"
      }

      # Use -ErrorAction to skip files we can't access
      Get-ChildItem -Path $Path -Recurse -File -ErrorAction SilentlyContinue |
        ForEach-Object {
          $fi = $_
          $hash = $null
          try {
            $hash = (Get-FileHash -Algorithm SHA256 -Path $fi.FullName -ErrorAction Stop).Hash
          } catch {
            $hash = $null
          }

          [pscustomobject]@{
            FullName       = $fi.FullName
            Name           = $fi.Name
            Extension      = $fi.Extension
            FileVersion    = $fi.VersionInfo.FileVersion
            ProductVersion = $fi.VersionInfo.ProductVersion
            CreationTime   = $fi.CreationTime
            LastWriteTime  = $fi.LastWriteTime
            HashSHA256     = $hash
          }
        }
    } -ArgumentList $RemoteRoot

    if ($null -eq $data -or $data.Count -eq 0) {
      Write-Log "[$hostName] No files returned. (Empty directory or access denied?)"
    } else {
      $data | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
      Write-Log "[$hostName] Wrote $($data.Count) rows to $csvPath"
    }
  }
  catch {
    Write-Log "[$hostName] ERROR: $($_.Exception.Message)"
  }
}

Write-Log "Completed hash collection."
