<#
Purpose: Diagnose iDRAC Redfish connectivity from this host (DNS, 443, TLS, Auth, Proxy).
Compat: Windows PowerShell 5.1
#>

param(
  [Parameter(Mandatory=$true)][string]$IdracHost,
  [Parameter(Mandatory=$true)][string]$IdracUser,
  [Parameter(Mandatory=$true)][string]$IdracPass,
  [int]$TimeoutSec = 20,
  [switch]$SkipCertCheck = $true
)

# TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Proxy bypass
[System.Net.WebRequest]::DefaultWebProxy = New-Object System.Net.WebProxy

# Optional cert bypass
if ($SkipCertCheck) {
  Add-Type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
  public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem) { return true; }
}
"@
  [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
}

$report = [System.Collections.Generic.List[pscustomobject]]::new()
function step($name, [scriptblock]$code){
  try{
    $sw=[Diagnostics.Stopwatch]::StartNew(); & $code; $sw.Stop()
    $report.Add([pscustomobject]@{ Step=$name; Result='OK'; Ms=[int]$sw.Elapsed.TotalMilliseconds; Detail='' })
  } catch {
    $report.Add([pscustomobject]@{ Step=$name; Result='FAIL'; Ms=0; Detail=$_.Exception.Message })
  }
}

$baseUri = "https://$IdracHost/redfish/v1"
$pair = "{0}:{1}" -f $IdracUser,$IdracPass
$auth = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))

step 'DNS resolve' { Resolve-DnsName -Name $IdracHost -ErrorAction Stop | Out-Null }
step 'TCP 443'     { Test-NetConnection -ComputerName $IdracHost -Port 443 -InformationLevel Detailed -ErrorAction Stop | Out-Null }
step 'GET /redfish/v1 (no auth)' {
  Invoke-RestMethod -Uri $baseUri -Headers @{} -Method Get -TimeoutSec $TimeoutSec | Out-Null
}
step 'GET /redfish/v1 (basic auth)' {
  Invoke-RestMethod -Uri $baseUri -Headers @{Authorization=$auth} -Method Get -TimeoutSec $TimeoutSec | Out-Null
}
step 'GET /Systems/System.Embedded.1 (basic auth)' {
  Invoke-RestMethod -Uri ($baseUri + '/Systems/System.Embedded.1') -Headers @{Authorization=$auth} -Method Get -TimeoutSec $TimeoutSec | Out-Null
}
step 'GET /Chassis/System.Embedded.1/Thermal (basic auth)' {
  Invoke-RestMethod -Uri ($baseUri + '/Chassis/System.Embedded.1/Thermal') -Headers @{Authorization=$auth} -Method Get -TimeoutSec $TimeoutSec | Out-Null
}

$report | Format-Table -AutoSize
