﻿<#
QCAD PR Oracle RAC - iDRAC Redfish Sensor Poller (hosts from list)

- Input file: base hostnames (e.g. POLPCADORAPR01)
- Script targets: <hostname>-i.qldpol automatically
- Writes one CSV per iDRAC host
#>

# -----------------------------
# Hardcoded inputs / outputs
# -----------------------------
$HostListPath     = "C:\temp\QCAD\PR\Hardware_Testing\iDrac\idrac_hosts.txt"
$OutputDir        = "C:\temp\QCAD\PR\Hardware_Testing\iDrac\iDRAC_Sensors\16-01-2026"
$IntervalSeconds  = 10
$DurationMinutes  = 600

# Append this to each hostname from the input file
$IdracSuffix      = "-i.qldpol"

$IdracUser        = "root"

# Sensor URIs
$sensorUris = @(
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardPwrConsumption",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardCPUUsage",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardMEMUsage",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardSYSUsage",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardIOUsage",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardInletTemp",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/CPU1Temp",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/Temperature.DIMM_MAX"
)

# -----------------------------
# Prompt once for password (secure)
# -----------------------------
$IdracPassSecure = Read-Host "Enter iDRAC ROOT password" -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($IdracPassSecure)
try { $IdracPass = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }

# -----------------------------
# Prep / validation
# -----------------------------
if (-not (Test-Path $HostListPath)) { throw "Host list file not found: $HostListPath" }
if (-not (Test-Path $OutputDir)) { New-Item -Path $OutputDir -ItemType Directory -Force | Out-Null }

# Read base hosts
$baseHosts = Get-Content -Path $HostListPath -ErrorAction Stop |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ -and -not $_.StartsWith("#") -and -not $_.StartsWith(";") } |
    Select-Object -Unique

if (-not $baseHosts -or $baseHosts.Count -eq 0) { throw "No valid hosts found in $HostListPath" }

# Build iDRAC targets
$targets = foreach ($h in $baseHosts) {
    if ($h -match '\.') { $h } else { "$h$IdracSuffix" }
}
$targets = $targets | Select-Object -Unique

Write-Host "Base hosts loaded ($($baseHosts.Count)) from: $HostListPath"
Write-Host "iDRAC targets ($($targets.Count)) using suffix: $IdracSuffix"
Write-Host "Using iDRAC user: $IdracUser"
Write-Host "Interval: $IntervalSeconds sec | Duration: $DurationMinutes min"
Write-Host "Output: $OutputDir`n"

# -----------------------------
# Run in parallel jobs
# -----------------------------
$jobs = foreach ($IdracFqdn in $targets) {
    Start-Job -Name "Poll_$IdracFqdn" -ArgumentList @(
        $IdracFqdn, $IdracUser, $IdracPass, $sensorUris, $IntervalSeconds, $DurationMinutes, $OutputDir
    ) -ScriptBlock {
        param($IdracFqdn,$User,$Pass,$Uris,$Interval,$DurationMin,$OutDir)

        # TLS + ignore certs
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
        try { [System.Net.ServicePointManager]::Expect100Continue = $false } catch {}
        try {
            [System.Net.ServicePointManager]::ServerCertificateValidationCallback =
                [System.Net.Security.RemoteCertificateValidationCallback]{ $true }
        } catch {}

        function Invoke-HttpRaw {
            param(
                [Parameter(Mandatory)][string]$Uri,
                [Parameter(Mandatory)][string]$Method,
                [hashtable]$Headers,
                [string]$BodyJson,
                [int]$TimeoutSec = 30,
                [switch]$NoKeepAlive
            )

            $req = [System.Net.HttpWebRequest]::Create($Uri)
            $req.Method = $Method
            $req.Accept = "application/json"
            $req.ContentType = "application/json"
            $req.Timeout = $TimeoutSec * 1000
            $req.ReadWriteTimeout = $TimeoutSec * 1000
            $req.Proxy = $null
            if ($NoKeepAlive) { $req.KeepAlive = $false }

            if ($Headers) {
                foreach ($k in $Headers.Keys) { $req.Headers[$k] = $Headers[$k] }
            }

            if ($BodyJson) {
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($BodyJson)
                $req.ContentLength = $bytes.Length
                $stream = $req.GetRequestStream()
                $stream.Write($bytes, 0, $bytes.Length)
                $stream.Close()
            }

            try {
                $resp = $req.GetResponse()
            } catch [System.Net.WebException] {
                if ($_.Exception.Response) {
                    $r = $_.Exception.Response
                    $status = [int]$r.StatusCode
                    $reader = New-Object System.IO.StreamReader($r.GetResponseStream())
                    $body = $reader.ReadToEnd()
                    $reader.Close()
                    throw "HTTP ${status}: $body"
                }
                throw $_.Exception.Message
            }

            $obj = [pscustomobject]@{
                StatusCode = [int]$resp.StatusCode
                Headers    = $resp.Headers
                BodyText   = $null
            }

            $sr = New-Object System.IO.StreamReader($resp.GetResponseStream())
            $obj.BodyText = $sr.ReadToEnd()
            $sr.Close()
            $resp.Close()

            return $obj
        }

        function Invoke-HttpJson {
            param(
                [Parameter(Mandatory)][string]$Uri,
                [Parameter(Mandatory)][string]$Method,
                [hashtable]$Headers,
                [string]$BodyJson,
                [int]$TimeoutSec = 30,
                [switch]$NoKeepAlive
            )

            $raw = Invoke-HttpRaw -Uri $Uri -Method $Method -Headers $Headers -BodyJson $BodyJson -TimeoutSec $TimeoutSec -NoKeepAlive:$NoKeepAlive
            if ([string]::IsNullOrWhiteSpace($raw.BodyText)) { return $null }
            return ($raw.BodyText | ConvertFrom-Json)
        }

        # FIX: DO NOT use param name 'Host' (conflicts with read-only $Host)
        function Test-IdracConnectivity {
            param([string]$TargetHost,[int]$Port=443,[int]$TimeoutMs=3000)
            try {
                $client = New-Object System.Net.Sockets.TcpClient
                $iar = $client.BeginConnect($TargetHost, $Port, $null, $null)
                $ok = $iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false)
                if (-not $ok) { $client.Close(); return $false }
                $client.EndConnect($iar) | Out-Null
                $client.Close()
                return $true
            } catch { return $false }
        }

        function New-RedfishSession {
            param([string]$BaseUri,[string]$User,[string]$Pass)
            $uri  = "$BaseUri/redfish/v1/SessionService/Sessions"
            $body = @{ UserName=$User; Password=$Pass } | ConvertTo-Json

            $raw = Invoke-HttpRaw -Uri $uri -Method "POST" -Headers $null -BodyJson $body -TimeoutSec 30 -NoKeepAlive
            $token    = $raw.Headers["X-Auth-Token"]
            $location = $raw.Headers["Location"]
            if (-not $token -or -not $location) { throw "Failed to create Redfish session (missing token/location)." }

            [pscustomobject]@{
                Token    = $token
                Location = if ($location -like "http*") { $location } else { "$BaseUri$location" }
            }
        }

        function Remove-RedfishSession {
            param([string]$SessionLocation,[string]$Token)
            try { Invoke-HttpJson -Uri $SessionLocation -Method "DELETE" -Headers @{ "X-Auth-Token" = $Token } -NoKeepAlive | Out-Null } catch {}
        }

        function Read-Sensor {
            param([string]$BaseUri,[string]$Token,[string]$SensorUri)
            $full = "$BaseUri$SensorUri"
            Invoke-HttpJson -Uri $full -Method "GET" -Headers @{ "X-Auth-Token" = $Token } -NoKeepAlive
        }

        $base  = "https://$IdracFqdn"
        $stamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
        $csv   = Join-Path $OutDir "$($IdracFqdn)_Sensors_$stamp.csv"

        "Timestamp,IdracHost,SensorUri,SensorId,Name,Reading,Units,Health,State" |
            Out-File -FilePath $csv -Encoding utf8 -Force

        # FIXED CALL SITE: -TargetHost (not -Host)
        if (-not (Test-IdracConnectivity -TargetHost $IdracFqdn -Port 443 -TimeoutMs 3000)) {
            $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
            "$ts,$IdracFqdn,""PRECHECK"",ERROR,""TCP 443 unreachable (DNS/firewall/routing)"",,,," |
                Out-File -FilePath $csv -Append -Encoding utf8
            throw "TCP 443 unreachable for $IdracFqdn"
        }

        $session = $null
        try {
            $maxTries = 5
            for ($t=1; $t -le $maxTries; $t++) {
                try { $session = New-RedfishSession -BaseUri $base -User $User -Pass $Pass; break }
                catch {
                    if ($t -eq $maxTries) { throw }
                    Start-Sleep -Seconds (3 * $t)
                }
            }

            $end = (Get-Date).AddMinutes($DurationMin)

            while ((Get-Date) -lt $end) {
                foreach ($u in $Uris) {
                    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
                    try {
                        $s = Read-Sensor -BaseUri $base -Token $session.Token -SensorUri $u
                        $safeName = (($s.Name) -replace '"','""')
                        $line = @(
                            $ts,
                            $IdracFqdn,
                            """$u""",
                            $s.Id,
                            """$safeName""",
                            $s.Reading,
                            $s.ReadingUnits,
                            $s.Status.Health,
                            $s.Status.State
                        ) -join ","
                        $line | Out-File -FilePath $csv -Append -Encoding utf8
                    }
                    catch {
                        $err = (($_.Exception.Message) -replace '"','""')
                        "$ts,$IdracFqdn,""$u"",ERROR,""GET failed: $err"",,,," |
                            Out-File -FilePath $csv -Append -Encoding utf8
                    }
                }
                Start-Sleep -Seconds $Interval
            }
        }
        finally {
            if ($session) { Remove-RedfishSession -SessionLocation $session.Location -Token $session.Token }
        }

        "Completed polling for $IdracFqdn. CSV: $csv"
    }
}

$jobs | Wait-Job | ForEach-Object {
    Write-Host "`n==== $($_.Name) [$($_.State)] ===="
    try { Receive-Job $_ -ErrorAction Stop | Write-Host }
    catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red }
}

$jobs | Remove-Job -Force
