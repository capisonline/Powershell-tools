﻿# -----------------------------
# Hardcoded inputs / outputs
# -----------------------------
$HostListPath     = "C:\temp\QCAD\PR\Hardware_Testing\iDrac\idrac_hosts.txt"
$OutputDir        = "C:\temp\QCAD\PR\Hardware_Testing\iDrac\iDRAC_Sensors\16-1-2026"
$IntervalSeconds  = 10
$DurationMinutes  = 4
$IdracUser        = "root"

# Prompt once for password (secure)
$IdracPassSecure = Read-Host "Enter iDRAC ROOT password" -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($IdracPassSecure)
try { $IdracPass = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }

# Sensor URIs (from your /Sensors collection)
$sensorUris = @(
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardPwrConsumption",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardCPUUsage",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardMEMUsage",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardSYSUsage",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardIOUsage",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/SystemBoardInletTemp",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/CPU1Temp",
    "/redfish/v1/Chassis/System.Embedded.1/Sensors/Temperature.DIMM_MAX"
)

# -----------------------------
# Prep
# -----------------------------
if (-not (Test-Path $HostListPath)) { throw "Host list file not found: $HostListPath" }
if (-not (Test-Path $OutputDir)) { New-Item -Path $OutputDir -ItemType Directory -Force | Out-Null }

$idracHosts = Get-Content -Path $HostListPath -ErrorAction Stop |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ -and -not $_.StartsWith("#") -and -not $_.StartsWith(";") } |
    Select-Object -Unique

if (-not $idracHosts -or $idracHosts.Count -eq 0) { throw "No valid hosts found in $HostListPath" }

Write-Host "Hosts loaded ($($idracHosts.Count)) from: $HostListPath"
Write-Host "Using iDRAC user: $IdracUser"
Write-Host "Interval: $IntervalSeconds sec | Duration: $DurationMinutes min"
Write-Host "Output: $OutputDir`n"

# -----------------------------
# Jobs
# -----------------------------
$jobs = foreach ($h in $idracHosts) {
    Start-Job -Name "Poll_$h" -ArgumentList @(
        $h, $IdracUser, $IdracPass, $sensorUris, $IntervalSeconds, $DurationMinutes, $OutputDir
    ) -ScriptBlock {
        param($idracHost,$user,$pass,$uris,$interval,$durationMin,$outDir)

        # TLS + ignore certs (job process)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
        try { [System.Net.ServicePointManager]::Expect100Continue = $false } catch {}
        try {
            [System.Net.ServicePointManager]::ServerCertificateValidationCallback =
                [System.Net.Security.RemoteCertificateValidationCallback]{ $true }
        } catch {}

        function Invoke-HttpJson {
            param(
                [Parameter(Mandatory)][string]$Uri,
                [Parameter(Mandatory)][string]$Method,
                [hashtable]$Headers,
                [string]$BodyJson,
                [int]$TimeoutSec = 30,
                [switch]$NoKeepAlive
            )

            $req = [System.Net.HttpWebRequest]::Create($Uri)
            $req.Method = $Method
            $req.Accept = "application/json"
            $req.ContentType = "application/json"
            $req.Timeout = $TimeoutSec * 1000
            $req.ReadWriteTimeout = $TimeoutSec * 1000
            $req.Proxy = $null

            if ($NoKeepAlive) {
                $req.KeepAlive = $false
            }

            if ($Headers) {
                foreach ($k in $Headers.Keys) {
                    # add non-restricted headers
                    $req.Headers[$k] = $Headers[$k]
                }
            }

            if ($BodyJson) {
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($BodyJson)
                $req.ContentLength = $bytes.Length
                $stream = $req.GetRequestStream()
                $stream.Write($bytes, 0, $bytes.Length)
                $stream.Close()
            }

            try {
                $resp = $req.GetResponse()
            } catch [System.Net.WebException] {
                # bubble up response body/status for debugging
                if ($_.Exception.Response) {
                    $r = $_.Exception.Response
                    $status = [int]$r.StatusCode
                    $reader = New-Object System.IO.StreamReader($r.GetResponseStream())
                    $body = $reader.ReadToEnd()
                    $reader.Close()
                    throw "HTTP ${status}: $body"
                }
                throw $_.Exception.Message
            }

            $sr = New-Object System.IO.StreamReader($resp.GetResponseStream())
            $text = $sr.ReadToEnd()
            $sr.Close()
            $resp.Close()

            if ([string]::IsNullOrWhiteSpace($text)) { return $null }
            return ($text | ConvertFrom-Json)
        }

        function New-RedfishSession {
            param([string]$BaseUri,[string]$User,[string]$Pass)

            $uri  = "$BaseUri/redfish/v1/SessionService/Sessions"
            $body = @{ UserName=$User; Password=$Pass } | ConvertTo-Json

            # Create session via Invoke-WebRequest (easy header capture)
            $resp = Invoke-WebRequest -Method Post -Uri $uri -Body $body -ContentType "application/json" -UseBasicParsing -TimeoutSec 30
            $token    = $resp.Headers["X-Auth-Token"]
            $location = $resp.Headers["Location"]

            if (-not $token -or -not $location) { throw "Failed to create Redfish session (missing token/location)." }

            [pscustomobject]@{
                Token    = $token
                Location = if ($location -like "http*") { $location } else { "$BaseUri$location" }
            }
        }

        function Remove-RedfishSession {
            param([string]$SessionLocation,[string]$Token)
            try {
                # Use HttpWebRequest so we can set KeepAlive=$false
                Invoke-HttpJson -Uri $SessionLocation -Method "DELETE" -Headers @{ "X-Auth-Token" = $Token } -NoKeepAlive | Out-Null
            } catch {}
        }

        function Read-Sensor {
            param([string]$BaseUri,[string]$Token,[string]$SensorUri)

            $full = "$BaseUri$SensorUri"
            Invoke-HttpJson -Uri $full -Method "GET" -Headers @{ "X-Auth-Token" = $Token } -NoKeepAlive
        }

        function Read-SensorWithRetry {
            param([string]$BaseUri,[ref]$SessionRef,[string]$User,[string]$Pass,[string]$SensorUri)

            $attempts = 3
            for ($i=1; $i -le $attempts; $i++) {
                try {
                    return Read-Sensor -BaseUri $BaseUri -Token $SessionRef.Value.Token -SensorUri $SensorUri
                } catch {
                    $msg = $_.Exception.Message
                    # Recreate session on common transient failures incl. 503 or connection drops
                    if ($i -lt $attempts) {
                        try {
                            if ($SessionRef.Value) {
                                Remove-RedfishSession -SessionLocation $SessionRef.Value.Location -Token $SessionRef.Value.Token
                            }
                        } catch {}
                        Start-Sleep -Seconds (2 * $i)  # simple backoff
                        $SessionRef.Value = New-RedfishSession -BaseUri $BaseUri -User $User -Pass $Pass
                        continue
                    }
                    throw $msg
                }
            }
        }

        $base  = "https://$idracHost"
        $stamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
        $csv   = Join-Path $outDir "$($idracHost)_Sensors_$stamp.csv"

        "Timestamp,IdracHost,SensorUri,SensorId,Name,Reading,Units,Health,State" |
            Out-File -FilePath $csv -Encoding utf8 -Force

        $session = $null
        $sessionRef = [ref]$session

        try {
            $session = New-RedfishSession -BaseUri $base -User $user -Pass $pass
            $end = (Get-Date).AddMinutes($durationMin)

            while ((Get-Date) -lt $end) {
                foreach ($u in $uris) {
                    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
                    try {
                        $s = Read-SensorWithRetry -BaseUri $base -SessionRef $sessionRef -User $user -Pass $pass -SensorUri $u

                        $safeName = (($s.Name) -replace '"','""')
                        $line = @(
                            $ts,
                            $idracHost,
                            """$u""",
                            $s.Id,
                            """$safeName""",
                            $s.Reading,
                            $s.ReadingUnits,
                            $s.Status.Health,
                            $s.Status.State
                        ) -join ","

                        $line | Out-File -FilePath $csv -Append -Encoding utf8
                    }
                    catch {
                        $err = ($_.Exception.Message -replace '"','""')
                        "$ts,$idracHost,""$u"",ERROR,""GET failed: $err"",,,," |
                            Out-File -FilePath $csv -Append -Encoding utf8
                    }
                }

                Start-Sleep -Seconds $interval
            }
        }
        finally {
            if ($session) { Remove-RedfishSession -SessionLocation $session.Location -Token $session.Token }
        }

        "Completed polling for $idracHost. CSV: $csv"
    }
}

$jobs | Wait-Job | ForEach-Object { Receive-Job $_ } | Write-Host
$jobs | Remove-Job -Force
