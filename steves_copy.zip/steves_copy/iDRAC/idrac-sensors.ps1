<#
Purpose: Query iDRAC Redfish for CPU/Memory health and temperature sensors (inlet/exhaust, CPU, DIMM where available).
Compat: Windows PowerShell 5.1 (no -Authentication / -SkipCertificateCheck on Invoke-RestMethod).
#>

param(
  [string]$IdracHost = "idrac-hostname-or-ip",
  [string]$IdracUser = "root",
  [string]$IdracPass = "REDACTED",
  [int]$IntervalSeconds = 0,        # 0 = single snapshot; >0 = poll
  [int]$DurationSeconds = 0,        # if polling, stop after this many seconds (0 = run once)
  [switch]$SkipCertCheck = $true    # ignore self-signed iDRAC certs (default on)
)

# Load common helpers from the same folder as this script
. "$PSScriptRoot\_qcad.common.ps1"

# Force TLS 1.2 (older defaults may be TLS 1.0)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Optionally relax cert validation for self-signed iDRACs
if ($SkipCertCheck) {
  Add-Type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
  public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem) { return true; }
}
"@
  [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
}

$run = New-RunFolder "idrac-sensors-$IdracHost"
$summaryCsv = Join-Path $run "summary.csv"
$tempsCsv   = Join-Path $run "temperatures.csv"

if(!(Test-Path $summaryCsv)){"Timestamp,OverallHealth,CPUHealth,MemoryHealth,AvgInletC,AvgExhaustC,AvgCpuC,AvgDimmC" | Out-File $summaryCsv}
if(!(Test-Path $tempsCsv)){"Timestamp,Type,Name,ReadingC,UpperCritical,UpperFatal,LowerCritical,LowerFatal,Status" | Out-File $tempsCsv}

$baseUri = "https://$IdracHost/redfish/v1"
$secPass = ConvertTo-SecureString $IdracPass -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential($IdracUser,$secPass)

function Get-Redfish($path){
  Invoke-RestMethod -Uri ($baseUri + $path) -Credential $cred -Method Get -TimeoutSec 15
}

function Write-Temps($thrObj){
  $ts = (Get-Date).ToString($TimeFormat)
  foreach($t in ($thrObj.Temperatures | Where-Object { $_.ReadingCelsius -ne $null })) {
    $type = if($t.Name -match '(CPU|Processor)'){ 'CPU' } elseif($t.Name -match '(DIMM|MEM)' ){ 'DIMM' } elseif($t.Name -match '(Inlet)' ){ 'Inlet' } elseif($t.Name -match '(Exhaust)' ){ 'Exhaust' } else { 'Other' }
    "$ts,$type,$($t.Name),$($t.ReadingCelsius),$($t.UpperThresholdCritical),$($t.UpperThresholdFatal),$($t.LowerThresholdCritical),$($t.LowerThresholdFatal),$($t.Status.Health)" | Add-Content $tempsCsv
  }
}

function Snapshot(){
  try{
    $sys = Get-Redfish '/Systems/System.Embedded.1'
    $thr = Get-Redfish '/Chassis/System.Embedded.1/Thermal'
  } catch {
    Write-Warning "Redfish query failed: $($_.Exception.Message)"
    return
  }

  # Summary line
  $overall = $sys.Status.Health
  $cpuH    = $sys.Processors.Status.Health
  $memH    = $sys.Memory.Status.Health

  $inlet   = $thr.Temperatures | Where-Object { $_.Name -match 'Inlet' } | Select-Object -ExpandProperty ReadingCelsius -ErrorAction SilentlyContinue
  $exhaust = $thr.Temperatures | Where-Object { $_.Name -match 'Exhaust' } | Select-Object -ExpandProperty ReadingCelsius -ErrorAction SilentlyContinue
  $cpuT    = $thr.Temperatures | Where-Object { $_.Name -match '(CPU|Processor)' } | Select-Object -ExpandProperty ReadingCelsius -ErrorAction SilentlyContinue
  $dimmT   = $thr.Temperatures | Where-Object { $_.Name -match '(DIMM|MEM)' } | Select-Object -ExpandProperty ReadingCelsius -ErrorAction SilentlyContinue

  $avg = {
    param($arr)
    if($arr -and $arr.Count -gt 0){ [Math]::Round(($arr | Measure-Object -Average).Average,2) } else { "" }
  }

  $ts = (Get-Date).ToString($TimeFormat)
  "$ts,$overall,$cpuH,$memH,$(& $avg $inlet),$(& $avg $exhaust),$(& $avg $cpuT),$(& $avg $dimmT)" | Add-Content $summaryCsv

  # Detailed temps
  Write-Temps $thr
}

if($IntervalSeconds -le 0){
  Snapshot
  Write-Host "Snapshot complete. Output in: $run" -ForegroundColor Green
}else{
  $end = if($DurationSeconds -gt 0){ (Get-Date).AddSeconds($DurationSeconds) } else { $null }
  while($true){
    Snapshot
    if($end -and (Get-Date) -ge $end){ break }
    Start-Sleep -Seconds $IntervalSeconds
  }
  Write-Host "Polling complete. Output in: $run" -ForegroundColor Green
}
