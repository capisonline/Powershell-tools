<#
Purpose: Advanced iDRAC Redfish sensor collector
- Auto-discovers Systems/Chassis IDs
- Collects Thermal temperatures + Redfish Sensors (temperature-type)
- Attempts to map DIMM/Memory temps via Sensors.RelatedItem
- Adds Power readings (Watts) and PSU redundancy/health
Compat: Windows PowerShell 5.1
#>

param(
  [Parameter(Mandatory=$true)][string]$IdracHost,
  [Parameter(Mandatory=$true)][string]$IdracUser,
  [Parameter(Mandatory=$true)][string]$IdracPass,
  [int]$IntervalSeconds = 2,
  [int]$DurationSeconds = 120,
  [int]$TimeoutSec = 30,
  [switch]$SkipCertCheck = $true
)

. "$PSScriptRoot\_qcad.common.ps1"

# TLS & proxy
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[System.Net.WebRequest]::DefaultWebProxy = New-Object System.Net.WebProxy

# Optional cert bypass
if ($SkipCertCheck) {
  Add-Type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
  public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem) { return true; }
}
"@
  [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
}

$run = New-RunFolder "idrac-sensors-adv-$IdracHost"
$summaryCsv = Join-Path $run "summary.csv"
$tempsCsv   = Join-Path $run "temperatures.csv"
$powerCsv   = Join-Path $run "power.csv"
$notesTxt   = Join-Path $run "notes.txt"

if(!(Test-Path $summaryCsv)){"Timestamp,OverallHealth,CPUHealth,MemoryHealth,AvgInletC,AvgExhaustC,AvgCpuC,AvgDimmC,PowerWatts,PSURedundancy,PSUAnyCritical" | Out-File $summaryCsv}
if(!(Test-Path $tempsCsv)){"Timestamp,Source,Type,Name,Reading,Units,UpperCritical,UpperFatal,LowerCritical,LowerFatal,Status,Path" | Out-File $tempsCsv}
if(!(Test-Path $powerCsv)){"Timestamp,ReadingWatts,MinWatts,MaxWatts,AverageWatts" | Out-File $powerCsv}

$base = "https://$IdracHost/redfish/v1"
$auth = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $IdracUser,$IdracPass)))

function GetJson($uri){
  Invoke-RestMethod -Uri $uri -Headers @{Authorization=$auth} -Method Get -TimeoutSec $TimeoutSec
}

# Discover Systems & Chassis IDs
try {
  $root = GetJson $base
  $systemsCol = GetJson ("https://$IdracHost" + $root.Systems.'@odata.id')
  $sysId = $systemsCol.Members[0].'@odata.id'
  $chassisCol = GetJson ("https://$IdracHost" + $root.Chassis.'@odata.id')
  $chId = $chassisCol.Members[0].'@odata.id'
  Add-Content $notesTxt "Discovered System: $sysId"
  Add-Content $notesTxt "Discovered Chassis: $chId"
} catch {
  Add-Content $notesTxt "Discovery failed: $($_.Exception.Message)"
  throw
}

function Snapshot(){
  $ts = (Get-Date).ToString($TimeFormat)
  try{
    $sys = GetJson ("https://$IdracHost$sysId")
    $thr = GetJson ("https://$IdracHost$chId/Thermal")
  } catch {
    Write-Warning "Thermal/Sys query failed: $($_.Exception.Message)"
    return
  }

  # Power/PSU
  $watts = $null; $min=$null; $max=$null; $avg=$null; $psuRed=''; $psuCrit = $false
  try{
    $pwr = GetJson ("https://$IdracHost$chId/Power")
    if($pwr.PowerControl){
      $pc = $pwr.PowerControl | Select-Object -First 1
      $watts = $pc.PowerConsumedWatts
      $min   = $pc.PowerMetrics.MinConsumedWatts
      $max   = $pc.PowerMetrics.MaxConsumedWatts
      $avg   = $pc.PowerMetrics.AverageConsumedWatts
    }
    if($pwr.PowerSupplies){
      $psuRed = ($pwr.PowerSupplies | Select-Object -First 1).RedundancyStatus
      $psuCrit = ($pwr.PowerSupplies | Where-Object {$_.Status.Health -eq 'Critical'}).Count -gt 0
    }
    "$ts,$watts,$min,$max,$avg" | Add-Content $powerCsv
  } catch {
    Write-Warning "Power query failed: $($_.Exception.Message)"
  }

  # Summary
  $overall = $sys.Status.Health
  $cpuH    = $sys.Processors.Status.Health
  $memH    = $sys.Memory.Status.Health

  $inletR  = $thr.Temperatures | Where-Object { $_.Name -match 'Inlet' } | Select-Object -ExpandProperty ReadingCelsius -ErrorAction SilentlyContinue
  $exhR    = $thr.Temperatures | Where-Object { $_.Name -match 'Exhaust' } | Select-Object -ExpandProperty ReadingCelsius -ErrorAction SilentlyContinue
  $cpuR    = $thr.Temperatures | Where-Object { $_.Name -match '(CPU|Processor)' } | Select-Object -ExpandProperty ReadingCelsius -ErrorAction SilentlyContinue
  $dimmR   = $thr.Temperatures | Where-Object { $_.Name -match '(DIMM|MEM)' } | Select-Object -ExpandProperty ReadingCelsius -ErrorAction SilentlyContinue

  function avg([object]$arr){ if($arr -and $arr.Count -gt 0){ [Math]::Round(($arr | Measure-Object -Average).Average,2) } else { "" } }

  "$ts,$overall,$cpuH,$memH,$(avg $inletR),$(avg $exhR),$(avg $cpuR),$(avg $dimmR),$watts,$psuRed,$psuCrit" | Add-Content $summaryCsv

  # Detailed Thermal temps
  foreach($t in ($thr.Temperatures | Where-Object { $_.ReadingCelsius -ne $null })) {
    $type = if($t.Name -match '(CPU|Processor)'){ 'CPU' } elseif($t.Name -match '(DIMM|MEM)'){ 'DIMM' } elseif($t.Name -match '(Inlet)'){ 'Inlet' } elseif($t.Name -match '(Exhaust)'){ 'Exhaust' } else { 'Other' }
    "$ts,Thermal,$type,$($t.Name),$($t.ReadingCelsius),C,$($t.UpperThresholdCritical),$($t.UpperThresholdFatal),$($t.LowerThresholdCritical),$($t.LowerThresholdFatal),$($t.Status.Health),$chId/Thermal" | Add-Content $tempsCsv
  }

  # Redfish Sensors collection: try to find Memory-related temp sensors
  try{
    $sensors = GetJson ("https://$IdracHost$chId/Sensors")
    foreach($m in $sensors.Members){
      $s = GetJson ("https://$IdracHost" + $m.'@odata.id')
      if($s.ReadingType -and ($s.ReadingType -match 'Temperature') -and $s.Reading){
        # If RelatedItem points to Memory, mark as DIMM
        $stype = 'Other'
        if($s.RelatedItem){
          foreach($ri in $s.RelatedItem){
            $rid = $ri.'@odata.id'
            if($rid -like "/redfish/v1/Systems/*/Memory/*"){ $stype = 'DIMM' }
            if($rid -like "/redfish/v1/Systems/*/Processors/*"){ $stype = 'CPU' }
          }
        }
        $name = $s.Name; if(-not $name){ $name = $s.Id }
        "$ts,Sensors,$stype,$name,$($s.Reading),$($s.ReadingUnits),$($s.UpperThresholdCritical),$($s.UpperThresholdFatal),$($s.LowerThresholdCritical),$($s.LowerThresholdFatal),$($s.Status.Health),$($m.'@odata.id')" | Add-Content $tempsCsv
      }
    }
  } catch {
    Write-Host "Sensors collection not available: $($_.Exception.Message)"
  }
}

$end = (Get-Date).AddSeconds($DurationSeconds)
while((Get-Date) -lt $end){
  Snapshot
  Start-Sleep -Seconds $IntervalSeconds
}
Write-Host "Advanced sensor polling complete. Output in: $run" -ForegroundColor Green
