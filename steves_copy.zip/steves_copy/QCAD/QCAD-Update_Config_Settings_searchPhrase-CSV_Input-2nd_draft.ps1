﻿<# 
.SYNOPSIS
This script reads a list of servers from a specified text file and recursively searches for configuration files 
(e.g., *.config, *.settings, *.csv) in a specified folder on each server. It searches for multiple incorrect settings 
within these files and replaces them with the correct settings. The script creates a backup of each modified file 
with a timestamp in the filename and logs the details of the updated files into a log file.

.DESCRIPTION
- Reads the list of servers from a text file.
- Reads the mappings of old values to new values from a CSV file.
- Connects to each server and recursively searches for configuration files in a specified folder.
- Creates a backup of each file with a timestamp before making any changes.
- Replaces multiple incorrect settings with their corresponding correct settings.
- Logs the details of the updated files (server, file path, backup file path, and timestamp) into a log file.
- Logs detailed output to a log file for debugging purposes.

.PARAMETER serversListPath
The path to the text file containing the list of servers.

.PARAMETER folderToSearch
The folder path on each server to search for configuration files.

.PARAMETER mappingsCsvPath
The path to the CSV file containing the mappings of old values to new values.

.PARAMETER fileExtensions
An array of file patterns to search for (e.g., *.config, *.settings, *.csv).

.PARAMETER logFilePath
The path to the log file where detailed output will be saved.

.EXAMPLE
.\Update-ConfigFiles.ps1 -serversListPath "C:\path\to\servers.txt" -folderToSearch "C$\path\to\search" -mappingsCsvPath "C:\path\to\mappings.csv" -logFilePath "C:\path\to\log.txt"
#>

# Define the path to the servers list and the folder to search
$serversListPath = "C:\path\to\servers.txt"
$folderToSearch = "C$\path\to\search" # Adjust this to match the shared folder path on the server

# Define the path to the mappings CSV file
$mappingsCsvPath = "C:\path\to\mappings.csv"

# Define the file extensions to search for
$fileExtensions = @("*.config", "*.settings", "*.csv") # Add more patterns if needed

# Get the current timestamp
$timestamp = Get-Date -Format "yyyyMMddHHmmss"

# Define the path for the log file
$logFilePath = "C:\path\to\log_$timestamp.txt"

# Create an ArrayList to store the updated files information
$updatedFiles = New-Object System.Collections.ArrayList

# Read the mappings from the CSV file
$mappings = Import-Csv -Path $mappingsCsvPath

# Function to update the configuration files on a server
function Update-ConfigFiles {
    param (
        [string]$server,
        [string]$folder,
        [array]$mappings,
        [string]$timestamp,
        [string[]]$fileExtensions
    )

    foreach ($fileExtension in $fileExtensions) {
        # Recursively get all files with the specified extension in the folder
        $files = Get-ChildItem -Path "\\$server\$folder" -Filter $fileExtension -Recurse -ErrorAction SilentlyContinue

        foreach ($file in $files) {
            try {
                "Processing file: $($file.FullName) on server: $server" | Tee-Object -FilePath $logFilePath -Append
                # Read the content of the file
                $content = Get-Content -Path $file.FullName -Raw
                $updated = $false

                # Iterate through the mappings
                foreach ($mapping in $mappings) {
                    $oldValue = $mapping.OldValue
                    $newValue = $mapping.NewValue

                    # Check if the file contains the old value and replace it
                    if ($content -match [regex]::Escape($oldValue)) {
                        "Found old value: $oldValue in file: $($file.FullName). Replacing with: $newValue" | Tee-Object -FilePath $logFilePath -Append
                        $content = $content -replace [regex]::Escape($oldValue), $newValue
                        $updated = $true
                    }
                }

                if ($updated) {
                    # Create a backup of the file with a timestamp
                    $backupFileName = "$($file.FullName).$timestamp.backup"
                    Copy-Item -Path $file.FullName -Destination $backupFileName

                    # Write the updated content back to the file
                    Set-Content -Path $file.FullName -Value $content

                    "Updated file: $($file.FullName) and created backup: $backupFileName" | Tee-Object -FilePath $logFilePath -Append

                    # Add the updated file information to the ArrayList
                    $fileUpdateInfo = [PSCustomObject]@{
                        Server = $server
                        FilePath = $file.FullName
                        BackupFilePath = $backupFileName
                        Timestamp = $timestamp
                    }
                    $updatedFiles.Add($fileUpdateInfo) | Out-Null

                    "Added to updatedFiles array: $($fileUpdateInfo | Out-String)" | Tee-Object -FilePath $logFilePath -Append
                }
            } catch {
                "Error processing file: $($file.FullName) on server: $server. Error: $_" | Tee-Object -FilePath $logFilePath -Append
            }
        }
    }
}

# Read the list of servers
$servers = Get-Content -Path $serversListPath

foreach ($server in $servers) {
    "Processing server: $server" | Tee-Object -FilePath $logFilePath -Append
    Update-ConfigFiles -server $server -folder $folderToSearch -mappings $mappings -timestamp $timestamp -fileExtensions $fileExtensions
}
