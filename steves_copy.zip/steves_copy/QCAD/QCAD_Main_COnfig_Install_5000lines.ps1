# Variables
#DV
$PasswordListId = 14
$apiKey = "bd62e3935784afcd35497e6b2fc3a8b9"

#PR
$PasswordListId = 17
$apiKey = "c9b48a25f6373edbd923c457368aef9a"

Function Get-ServerType{
	<#
    .SYNOPSIS
    Consolidates important server specific values passed in from the environment map
    .DESCRIPTION
    Returns a hashtable for the current server that includes the server type, IP address, 
	Site Code (if FB VAS) and Number Cruncher prefix
	.PARAMETER environmentMap
	The environment map in the form of an Xml
	.PARAMETER thisServer
	The name of the current server as a string
    #>

	[cmdletbinding()]
	param(
		[xml]
		$environmentMap,
		[string]
		$thisServer
		)

	[hashtable]$Return = @{} 
	$serverNodes = $environmentMap.SelectNodes("//Servers")

	foreach ($server in $serverNodes.ChildNodes){
    	if ($server.HostName -eq $thisServer){
		    $Return.Name = $server.Name
		    $Return.IpAddress = $server.IpAddress
		    
            if ($server.SiteCode){
			    $Return.SiteCode = $server.SiteCode
			    $Return.NCPrefix = $server.NCPrefix
			}

            return $Return #review whether return is required
		}
	}
}

Function Calculate-Ports{
	<#
    .SYNOPSIS
    Calucates and returns the appropriate system ports based on the system name
    .DESCRIPTION
    Calucates and returns the appropriate system ports based on the system name
	.PARAMETER systemName
	The name of the system that has been designated
	.PARAMETER basePort
	The base port of the system that has been designated
    #>

	[cmdletbinding()]
	param(
		[string]$systemName, 
		[int]$basePort
		)

    $num = 0
    $length = $systemName.Length
    $systemName = $systemName.ToLower()

    for ($i = 0; $i -lt $length; $i++){
        $c = [byte][char]$systemName[$i]
        $num += $c    
    }

    $num + $basePort
}

## VISION CORE SERVICES

function update-QPRIMEInMAConfig{

    <#
    .SYNOPSIS
    Looks up the QPRIME environment and calls the Update-MAConfigFile function
    
    .DESCRIPTION
    Executes the Update-MAConfigFile function using PowerShell v1.0

	#>

    [cmdletbinding()]
    param
    (
        [string]$environmentName = $Env:EnvName,
		[string]$version = "master"
    )

    [xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
    $thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # Environment Name
    $environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
    $adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    # Get QPRIME AIP connection string
    $QPrimeEnv = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.QPrimeTarget
	
	$QPRIMEAIPConn = "$QPrimeEnv.$adDomain"
    write-host "QPRIME target: $QPRIMEAIPConn"

    $cmd = "C:\windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
	$script = "E:\Vision\UpdateQPrimeMAConfig.ps1"

    Start-Process $cmd "$script $QPRIMEAIPConn $environmentName" -wait
}

Function Update-VisionIni{
	<#
    .SYNOPSIS
    Creates the vision_visXX.ini file from scratch
    .DESCRIPTION
    Creates the vision_visXX.ini file from scratch from the system name and the current server
	#>

    [cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
		[switch]$check,
        [switch]$fallBack
	)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($fallBack)
    {
        # FB VAS
        if ($check)
        {
            $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "_" + $siteCode 

            if (!(Test-Path $tempPath))
            {
                mkdir -Path $tempPath
            }

            $targetConfig = $tempPath + "\Vision_Vis" + $environmentName + "_" + $siteCode + ".ini"

        }else
        {
	        $targetConfig = "d:\Vision\Vis" + $environmentName + "_" + $siteCode + "\Vision_Vis" + $environmentName + "_" + $siteCode + ".ini"
        }

    }else
    {
        if ($check)
        {
            $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName
            Write-Verbose $tempPath

            if (!(Test-Path $tempPath))
            {
                mkdir -Path $tempPath
            }

            $targetConfig = $tempPath + "\Vision_Vis" + $environmentName + ".ini"

        }else
        {
	        $targetConfig = "d:\Vision\Vis" + $environmentName + "\Vision_Vis" + $environmentName + ".ini"
        }
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	$fileContent = @("[New Version]
<!-- The New Version path should be set to the following which is the location from which VAS servers -->
<!-- and clients download new versions of software from.  This should be on the primary VAS and shared  -->")

	$fileContent += "Path=\\" + $adDomain + "\appdata\" + $environmentName + "\QCAD\New Version$"

	$fileContent += @("
[Manager]
<!-- The Manager path should be set to the following which is the location in which various database files -->
<!-- are located and required access to by the manager client  -->")

	$fileContent += "Path=\\" + $adDomain + "\appdata\" + $environmentName + "\QCAD\System_Vis$environmentName$"

	$fileContent += @("
[Position]
<!-- Server Name -->")

	$fileContent += "SID=" + $thisServer

	Out-File -FilePath $targetConfig -InputObject $fileContent
}

Function Update-VisionSettings{
	<#
    .SYNOPSIS
    Creates Vision_VisXX.settings file from the environment map and versioned config file
    .DESCRIPTION
    Creates Vision_VisXX.settings file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check,
        [switch]$fallBack
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Vision_Vis.settings" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    $siteCodeString = ""

    if ($fallBack)
    {
        $siteCodeString = "_" + $siteCode
    }else{
        $siteCodeString = ""
    }
        
    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + $siteCodeString

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Vision_Vis" + $environmentName + $siteCodeString + ".settings"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + $siteCodeString + "\Vision_Vis" + $environmentName + $siteCodeString + ".settings"
    }

	# Get Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	##COMMMON
	
	$oraVisionReaderPW = Get-EncStoredPassword -passwordName "ORA_VISION_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
    $oraVisionReaderUN = Get-StoredUsername -passwordName "ORA_VISION_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionWriterPW = Get-EncStoredPassword -passwordName "ORA_VISION_WRITER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
    $oraVisionWriterUN = Get-StoredUsername -passwordName "ORA_VISION_WRITER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionEventPW = Get-EncStoredPassword -passwordName "ORA_VISION_EVENT" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
    $oraVisionEventUN = Get-StoredUsername -passwordName "ORA_VISION_EVENT" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionServerReaderPW = Get-EncStoredPassword -passwordName "ORA_VISION_Server_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
    $oraVisionServerReaderUN = Get-StoredUsername -passwordName "ORA_VISION_Server_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$visionMBPW = Get-StoredPassword -passwordName "VisionMB" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
    $visionMBUN = Get-StoredUsername -passwordName "VisionMB" -environment $environmentName -listId $PasswordListId -apiKey $apiKey

	# SQLServerConnectionServerDatabase
	$targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='SQLServerConnectionServerDatabase']")
	$targetConfigNode.SetAttribute("value", "Vis" + $environmentName + $siteCodeString + "_VisionServer")

	# OracleConnectionDataSource
	$targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='OracleConnectionDataSource']")
	$targetConfigNode.SetAttribute("value", $environmentName + "CAD")

    # OracleConnectionUser
	$targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='OracleConnectionUser']")
	$targetConfigNode.SetAttribute("value", $oraVisionReaderUN)

	# OracleConnectionPassword
	$targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='OracleConnectionPassword']")
	$targetConfigNode.SetAttribute("value", $oraVisionReaderPW)

	# WebServiceURL
	if ($thisServerType.Name -eq "VCS")
	{
		$targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='WebServiceURL']")
		$targetConfigNode.SetAttribute("value", "http://" + $environmentName.ToLower() + "cad-vcsnlb." + $adDomain.ToLower() + "/Vis" + $environmentName + "_VisionWebServices/VisionDataReader.asmx")
	}else
	{
		$targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='WebServiceURL']")
		$targetConfigNode.SetAttribute("value", "http://" + $environmentName + "cad-vwsnlb." + $adDomain + "/Vis" + $environmentName + "_VisionWebServices/VisionDataReader.asmx")
	}

	# LogPath
	$targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='LogPath']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName + $siteCodeString + "\Logs")

	# VisionDatasource
	$targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='VisionDatasource']")
	$targetConfigNode.SetAttribute("value", $environmentName + "CAD")
	
	#####################################

    if ($thisServerType.Name -eq "VAS"){

        ## VisionDatabaseWriterService

        # DatabaseUserID
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionDatabaseWriterService']/add[@key='DatabaseUserID']")
	    $targetConfigNode.SetAttribute("value", $oraVisionWriterUN)

	    # DatabasePassword
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionDatabaseWriterService']/add[@key='DatabasePassword']")
	    $targetConfigNode.SetAttribute("value", $oraVisionWriterPW)

        ## VisionEventProcessorService

	    # OracleConnectionUser
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionEventProcessorService']/add[@key='OracleConnectionUser']")
	    $targetConfigNode.SetAttribute("value", $oraVisionEventUN) 

	    # OracleConnectionPassword
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionEventProcessorService']/add[@key='OracleConnectionPassword']")
	    $targetConfigNode.SetAttribute("value", $oraVisionEventPW) 

	    # Hosts.Count
	    $vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	    $vasCount = $vasNodes.Count

	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionEventProcessorService']/add[@key='Hosts.Count']")
	    $targetConfigNode.SetAttribute("value", $vasCount)

	    # Hosts.#
	    $VasOrder = @()
	    foreach ($node in $vasNodes){
		    if ($node.Hostname -eq $thisServer){
		    $VasOrder += @($node.IpAddress)
		    }
	    }
	    foreach ($node in $vasNodes){
		    if ($node.Hostname -ne $thisServer){
		    $VasOrder += @($node.IpAddress)
		    }
	    }
	    $vasCount = 0
	    foreach ($node in $VasOrder){
		    $vasCount++
		    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionEventProcessorService']")
		    $h = $targetConfigXml.CreateElement("add")
		    $h.SetAttribute("key", "Hosts.Host" + $vasCount)
		    $h.SetAttribute("value", $node)
		    $targetConfigNode.AppendChild($h)
	    }

        ## VisionMessageBrokerService

	    # SMTP_Username
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionMessageBrokerService']/add[@key='SMTP_Username']")
	    $targetConfigNode.SetAttribute("value", $adDomain + "\" + $visionMBUN)

	    # SMTP_Password
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionMessageBrokerService']/add[@key='SMTP_Password']")
	    $targetConfigNode.SetAttribute("value", $visionMBPW)

	    # OracleConnectionPassword
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionMessageBrokerService']/add[@key='OracleConnectionPassword']")
	    $targetConfigNode.SetAttribute("value", $oraVisionServerReaderPW)

	    # Hosts.Count
	    $vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	    $vasCount = $vasNodes.Count
	
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionMessageBrokerService']/add[@key='Hosts.Count']")
	    $targetConfigNode.SetAttribute("value", $vasCount)

	    # Hosts.#
	    $VasOrder = @()
	    foreach ($node in $vasNodes){
		    if ($node.Hostname -eq $thisServer){
		    $VasOrder += @($node.IpAddress)
		    }
	    }
	    foreach ($node in $vasNodes){
		    if ($node.Hostname -ne $thisServer){
		    $VasOrder += @($node.IpAddress)
		    }
	    }
	    $vasCount = 0
	    foreach ($node in $VasOrder){
		    $vasCount++
		    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionMessageBrokerService']")
		    $h = $targetConfigXml.CreateElement("add")
		    $h.SetAttribute("key", "Hosts.Host" + $vasCount)
		    $h.SetAttribute("value", $node)
		    $targetConfigNode.AppendChild($h)
	    }

        ## VisionNumberCruncherService
        # Hosts.Count
	    $vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	    $vasCount = $vasNodes.Count

	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionNumberCruncherService']/add[@key='Hosts.Count']")
	    $targetConfigNode.SetAttribute("value", $vasCount)

	    # Hosts.#
	    $VasOrder = @()
	    foreach ($node in $vasNodes){
		    if ($node.Hostname -eq $thisServer){
		    $VasOrder += @($node.IpAddress)
		    }
	    }
	    foreach ($node in $vasNodes){
		    if ($node.Hostname -ne $thisServer){
		    $VasOrder += @($node.IpAddress)
		    }
	    }
	    $vasCount = 0
	    foreach ($node in $VasOrder){
		    $vasCount++
		    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionNumberCruncherService']")
		    $h = $targetConfigXml.CreateElement("add")
		    $h.SetAttribute("key", "Hosts.Host" + $vasCount)
		    $h.SetAttribute("value", $node)
		    $targetConfigNode.AppendChild($h)
	    }
        $targetConfigNodes = $targetConfigXml.SelectNodes("//VISION")
    
        $targetConfigNodes | % {
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientConnectionManager']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientService-VCS']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientService-VAS']")
            $child_node.SetAttribute("Name", "VisionClientService") | Out-Null
        }

        ## VisionServerConnectionManager
        $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionServerConnectionManager']/add[@key='SmartPollEnabled']")
        $targetConfigNode.SetAttribute("value","True")

        ## VisionClientService

	    # ClientSettings.DataReaderService
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionClientService']/add[@key='ClientSettings.DataReaderService']")
	    $targetConfigNode.SetAttribute("value", "http://" + $environmentName + "cad-vwsnlb." + $adDomain + "/Vis" + $environmentName + "_VisionWebServices/VisionDataReader.asmx")
 
	    # ClientSettings.GazetteerService
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionClientService']/add[@key='ClientSettings.GazetteerService']")
	    $targetConfigNode.SetAttribute("value", "http://" + $environmentName + "cad-vwsnlb." + $adDomain + "/Vis" + $environmentName + "_VisionWebServices/VisionGazetteerService.asmx")

    } elseif ($thisServerType.Name -eq "CCM"){

        ## Common
        # SQLServerConnectionServerDatabase
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='SQLServerConnectionServerDatabase']")
	    $targetConfigNode.SetAttribute("value", "Vis" + $environmentName + "_" + $thisServerType.SiteCode + "_VisionServer")

        # WebServiceURL
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='Common']/add[@key='WebServiceURL']")
	    $targetConfigNode.SetAttribute("value", "http://" + $environmentName + "cad-vwsnlb." + $adDomain + "/Vis" + $environmentName + "_VisionWebServices/VisionDataReader.asmx")
        
        $ccmNodes = $sourceConfigXml.SelectNodes("//CCM")
	    $thisServerIndex = $ccmNodes.HostName.IndexOf($thisServer)
    
        $targetConfigNodes = $targetConfigXml.SelectNodes("//VISION")

        $targetConfigNodes | % {
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionDatabaseWriterService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionMessageBrokerService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionEventProcessorService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientService-VAS']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientService-VCS']")
            $_.RemoveChild($child_node) | Out-Null
        }
    
        if ($fallBack){
            # FB VAS
            write-debug "FB VAS"

            ## VisionNumberCruncherService
		    $ccmNodes = $sourceConfigXml.SelectNodes("//CCM")
            $thisNode = $ccmNodes | Where-Object {$_.HostName -eq $thisServer}
            $NCPrefix = $thisNode.NCPrefix
            write-debug "NCPrefix: $NCPrefix"
		    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionNumberCruncherService']/add[@key='NumberPrefix']")
		    $targetConfigNode.SetAttribute("value",$NCPrefix)

            ## VisionServerConnectionManager
            $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionServerConnectionManager']/add[@key='SmartPollEnabled']")
            $targetConfigNode.SetAttribute("value","False")

            $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionServerConnectionManager']")
            $h = $targetConfigXml.CreateElement("add")
            $h.SetAttribute("key","StartUpInFallback")
            $h.SetAttribute("value","False")
            $targetConfigNode.appendChild($h)

            $targetConfigNodes | % {
                $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientConnectionManager']")
                $_.RemoveChild($child_node) | Out-Null

                $child_node = $_.SelectSingleNode("//Application[@Name='VisionDataReaderService']/add[@key='ExcludeTables']")
                $child_node.SetAttribute("value", "GI,LAST_INCIDENT_NUMBER")

                $child_node = $_.SelectSingleNode("//Application[@Name='VisionNumberCruncherService']/add[@key='Hosts.Count']")
                $child_node.SetAttribute("value", "1")

                $child_node = $_.SelectSingleNode("//Application[@Name='VisionNumberCruncherService']")
                $h = $targetConfigXml.CreateElement("add")
		        $h.SetAttribute("key", "Hosts.Host1")
		        $h.SetAttribute("value", "127.0.0.1")
		        $child_node.AppendChild($h)
            }

        }else {
        # CCM - non FB
            write-debug "CCM"
            $targetConfigNodes | % {
                $child_node = $_.SelectSingleNode("//Application[@Name='VisionDataReaderService']")
                $_.RemoveChild($child_node) | Out-Null
                $child_node = $_.SelectSingleNode("//Application[@Name='VisionDbReaderService_Server']")
                $_.RemoveChild($child_node) | Out-Null
                $child_node = $_.SelectSingleNode("//Application[@Name='VisionNumberCruncherService']")
                $_.RemoveChild($child_node) | Out-Null
                $child_node = $_.SelectSingleNode("//Application[@Name='VisionServerConnectionManager']")
                $_.RemoveChild($child_node) | Out-Null
            }
        }
    } elseif ($thisServerType.Name -eq "VMG"){
        $targetConfigNodes = $targetConfigXml.SelectNodes("//VISION")
    
        $targetConfigNodes | % {
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientConnectionManager']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionDatabaseWriterService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionDataReaderService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionDbReaderService_Server']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionEventProcessorService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionMessageBrokerService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionNumberCruncherService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionServerConnectionManager']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientService-VAS']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientService-VCS']")
            $_.RemoveChild($child_node) | Out-Null
        }
    } elseif ($thisServerType.Name -eq "VCS"){
        $targetConfigNodes = $targetConfigXml.SelectNodes("//VISION")
    
        $targetConfigNodes | % {
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientConnectionManager']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionDatabaseWriterService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionDataReaderService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionDbReaderService_Server']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionEventProcessorService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionMessageBrokerService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionNumberCruncherService']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionServerConnectionManager']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientService-VAS']")
            $_.RemoveChild($child_node) | Out-Null
            $child_node = $_.SelectSingleNode("//Application[@Name='VisionClientService-VCS']")
            $child_node.SetAttribute("Name", "VisionClientService") | Out-Null
        }
        
        ## VisionClientService

	    # ClientSettings.DataReaderService
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionClientService']/add[@key='ClientSettings.DataReaderService']")
	    $targetConfigNode.SetAttribute("value", "http://" + $environmentName.ToLower() + "cad-vcsnlb." + $adDomain.ToLower() + "/Vis" + $environmentName + "_VisionWebServices/VisionDataReader.asmx")
 
	    # ClientSettings.GazetteerService
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionClientService']/add[@key='ClientSettings.GazetteerServices.1']")
	    $targetConfigNode.SetAttribute("value", "http://" + $environmentName.ToLower() + "cad-vcsnlb." + $adDomain.ToLower() + "/Vis" + $environmentName + "_VisionWebServices/VisionGazetteerService.asmx")
    }

    ## COMMON VisionClientService Settings
    $vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	$vasCount = $vasNodes.Count

    if ($thisServerType.Name -eq "VCS" -or $thisServerType.Name -eq "VAS"){	
	    # ClientSettings.MapPath
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionClientService']/add[@key='ClientSettings.MapPath']")
	    $targetConfigNode.SetAttribute("value", "http://" + $environmentName.ToLower() + "cad-vcsnlb." + $adDomain.ToLower() + "/WMS/GetMap.ashx")

	    # ClientSettings.NewVersionFolder
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionClientService']/add[@key='ClientSettings.NewVersionFolder']")
	    $targetConfigNode.SetAttribute("value", "\\" + $adDomain + "\appdata\" + $environmentName + "\QCAD\New Version$")

        # Hosts.Count
	    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionClientService']/add[@key='Hosts.Count']")
	    $targetConfigNode.SetAttribute("value", $vasCount)
    }

    if ($thisServerType.Name -eq "VAS"){	
	    # Hosts.#
	    $VasOrder = @()
	    foreach ($node in $vasNodes){
		    if ($node.Hostname -eq $thisServer){
		    $VasOrder += @($node.IpAddress)
		    }
	    }
	    foreach ($node in $vasNodes){
		    if ($node.Hostname -ne $thisServer){
		    $VasOrder += @($node.IpAddress)
		    }
	    }
	    $vasCount = 0
	    foreach ($node in $VasOrder){
		    $vasCount++
		    $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionClientService']")
		    $h = $targetConfigXml.CreateElement("add")
		    $h.SetAttribute("key", "Hosts.Host" + $vasCount)
		    $h.SetAttribute("value", $node + ":Vis" + $environmentName)
		    $targetConfigNode.AppendChild($h)
	    }
    }elseif ($thisServerType.Name -eq "VCS")
    {
        # Hosts.#
	    $VCSNode = $sourceConfigXml.SelectNodes("//VCS") | Where-Object {$_.HostName -eq $thisServer}
        write-host $VCSNode.VasOrder.List
        $vasCount = 0
        foreach ($node in $VCSNode.VasOrder.List){
            $vasCount++
            $targetConfigNode = $targetConfigXml.SelectNodes("//Application[@Name='VisionClientService']")
		    $h = $targetConfigXml.CreateElement("add")
		    $h.SetAttribute("key", "Hosts.Host" + $vasCount)
		    $h.SetAttribute("value", $vasNodes[$node - 1].IpAddress + ":Vis" + $environmentName)
		    $targetConfigNode.AppendChild($h)
	    }
    }

	$targetConfigXml.Save($targetConfig)
}

Function Update-FortekCoreService{
	<#
    .SYNOPSIS
    Creates FortekCoreService.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates FortekCoreService.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "FortekCoreService.exe.config" -version $version).objects.object.'#text'

    # Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    $thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + $siteCodeString + "\Services\FortekCoreService"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\FortekCoreService.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + $siteCodeString + "\Services\FortekCoreService\FortekCoreService.exe.config"
    }

	# Connection Strings
	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings")
	
	$h = $targetConfigXml.CreateElement("add")
	$h.SetAttribute("name", "Fortek.Services.VisionServer.My.MySettings.ServerConfigConnStr")
	$h.SetAttribute("connectionString", "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};User ID=admin")
	$targetConfigNode.AppendChild($h)

	$h = $targetConfigXml.CreateElement("add")
	$h.SetAttribute("name", "Fortek.Services.VisionServer.My.MySettings.LocalSQLConnStr")
	$h.SetAttribute("connectionString", "Data Source=.\SqlExpress;Initial Catalog=Vis" + $environmentName +$siteCodeString+ "_VisionServer;Integrated Security=True;MultipleActiveResultSets=True")
	$targetConfigNode.AppendChild($h)

	$h = $targetConfigXml.CreateElement("add")
	$h.SetAttribute("name", "Fortek.Services.VisionServer.My.MySettings.RemoteSQLConnStr")
	$h.SetAttribute("connectionString", "Data Source=" + $thisServer + ",2001;Initial Catalog=Vis" + $environmentName +$siteCodeString+ "_VisionServer;Integrated Security=True;MultipleActiveResultSets=True")
	$targetConfigNode.AppendChild($h)

	$h = $targetConfigXml.CreateElement("add")
	$h.SetAttribute("name", "Fortek.Services.VisionServer.My.MySettings.AccessConnStr")
	$h.SetAttribute("connectionString", "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};")
	$targetConfigNode.AppendChild($h)

	$h = $targetConfigXml.CreateElement("add")
	$h.SetAttribute("name", "Fortek.Services.VisionServer.My.MySettings.PacketManagerConnection")
	$h.SetAttribute("connectionString", "Data Source=.\SqlExpress;Initial Catalog=Vis" + $environmentName +$siteCodeString+ "_VisionPacketManager;Integrated Security=True;MultipleActiveResultSets=True")
	$h.SetAttribute("providerName", "System.Data.SqlClient")
	$targetConfigNode.AppendChild($h)

	$h = $targetConfigXml.CreateElement("add")
	$h.SetAttribute("name", "Fortek.Services.VisionServer.My.MySettings.PacketManager_RemoteConnection")
	$h.SetAttribute("connectionString", "Data Source=" + $thisServer + ",2001;Initial Catalog=Vis" + $environmentName +$siteCodeString+ "_VisionPacketManager;Integrated Security=True;MultipleActiveResultSets=True")
	$h.SetAttribute("providerName", "System.Data.SqlClient")
	$targetConfigNode.AppendChild($h)

	$h = $targetConfigXml.CreateElement("add")
	$h.SetAttribute("name", "Fortek.Services.VisionServer.My.MySettings.PacketManager_2005")
	$h.SetAttribute("connectionString", "Data Source=.\SqlExpress;Initial Catalog=Vis" + $environmentName+$siteCodeString + "_VisionPacketManager;Integrated Security=True;MultipleActiveResultSets=True")
	$h.SetAttribute("providerName", "System.Data.SqlClient")
	$targetConfigNode.AppendChild($h)

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='System']")
	
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName + $siteCodeString
	$targetConfigNode.AppendChild($h)

	# Array of VAS Hosts
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='Hosts']/value/ArrayOfString")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	
	# For VAS servers, add itself first
    if ($thisServerType.Name -eq "VAS")
    {	    
        $thisServerNode = $vasNodes | Where-Object {$_.HostName -eq $thisServer}
        $h = $targetConfigXml.CreateElement("string")
	    $h.InnerText = $thisServerNode.IpAddress
	    $targetConfigNode.AppendChild($h)
    }
	
	foreach ($node in $vasNodes){
        if ($node.HostName -ne $thisServer)
        {
		    $h = $targetConfigXml.CreateElement("string")
		    $h.InnerText = $node.IpAddress
		    $targetConfigNode.AppendChild($h)
        }
	}

    # For FB VAS servers, add itself to the available VAS servers last
    if($thisServerType.Name -eq "CCM"){
        $node = $sourceConfigXml.SelectNodes("//CCM")| Where-Object {$_.HostName -eq $thisServer}
        $h = $targetConfigXml.CreateElement("string")
		$h.InnerText = $node.IpAddress
		$targetConfigNode.AppendChild($h)
    }

	# Web Service URL
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='WebServiceUrl']")
	
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "http://" + $environmentName + "cad-vwsnlb." + $adDomain + "/Vis" + $environmentName + "_VisionWebServices_Server/VisionDataReader.asmx" 
	$targetConfigNode.AppendChild($h)

	# DB Reader Service URL
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='Fortek_Vision_Server_VisionDbReaderService_VisionDataReader']")
	
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "http://" + $environmentName + "cad-vwsnlb." + $adDomain + "/Vis" + $environmentName + "_VisionWebServices_Server/VisionDataReader.asmx" 
	$targetConfigNode.AppendChild($h)

	# Web Reference DB Reader Service URL
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='Fortek_Vision_Server_WebReference_VisionDataReader']")
	
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "http://" + $environmentName + "cad-vwsnlb." + $adDomain + "/Vis" + $environmentName + "_VisionWebServices_Server/VisionDataReader.asmx" 
	$targetConfigNode.AppendChild($h)

	# RestartManagerBasePort - update value for FB VAS only
    if($thisServerType.Name -eq "CCM"){

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='RestartManagerBasePort']/value")
        
        $systemName = "Vis" + $environmentName
        $mainSystemBaseport = 13000

        $mainSystemPort = Calculate-Ports -systemName $systemName -basePort $mainSystemBaseport
        write-host "mainSystemPort: $mainSystemPort"

        $fallbackPort =  Calculate-Ports -systemName ($systemName + $siteCodeString) -basePort $mainSystemBaseport
        write-host "fallbackPort: $fallbackPort"

        $RestartManagerBasePort = $mainSystemBaseport - ($fallbackPort - $mainSystemPort)
        write-host "RestartManagerBasePort: $RestartManagerBasePort"

        $targetConfigNode.innerText = $RestartManagerBasePort   
    }

	# Server SID
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='SID']")
	
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = $thisServer
	$targetConfigNode.AppendChild($h)

	# New Version Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='NewVersionDirectory']")
	
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "\\" + $adDomain + "\appdata\" + $environmentName + "\QCAD\New Version$"
	$targetConfigNode.AppendChild($h)

	# Generic Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='LogPath']")
	
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName +$siteCodeString + "\Logs\"
	$targetConfigNode.AppendChild($h)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName +$siteCodeString + "\Logs\FCS Trace\FCS_VisionServer.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='BulkCopy']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName +$siteCodeString + "\Logs\FCS Trace\FCS_BulkCopy.log")

	$targetConfigXml.Save($targetConfig)
}

Function Update-VisionDataService{
	<#
    .SYNOPSIS
    Creates VisionDataService.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates VisionDataService.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "VisionDataService.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName +$siteCodeString+ "\Services\DataService"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\VisionDataService.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName +$siteCodeString+ "\Services\DataService\VisionDataService.exe.config"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='System']")
	$targetConfigNode.SetAttribute("value", "Vis" + $environmentName+$siteCodeString)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName+$siteCodeString + "\System_Vis" + $environmentName +$siteCodeString+"\Logs\DataReaderService.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-IntegrityCheckerService{
	<#
    .SYNOPSIS
    Creates IntegrityCheckerService.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates IntegrityCheckerService.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "IntegrityCheckerService.exe.config" -version $version).objects.object.'#text'

    $thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }
    
    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName +$siteCodeString + "\Services\IntegrityChecker"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\IntegrityCheckerService.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + $siteCodeString + "\Services\IntegrityChecker\IntegrityCheckerService.exe.config"
    }

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='System']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName + $siteCodeString
	$targetConfigNode.AppendChild($h)

	# Web Service URL
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='WebServiceURL']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "http://" + $environmentName + "cad-vwsnlb." + $adDomain + "/Vis" + $environmentName + "_VisionWebServices_Server/VisionDataReader.asmx" 
	$targetConfigNode.AppendChild($h)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString+ "\System_Vis" + $environmentName + $siteCodeString + "\Logs\IntegrityChecker.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-NumberCruncherService{
	<#
    .SYNOPSIS
    Creates NumberCruncherService.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates NumberCruncherService.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "NumberCruncherService.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName +$siteCodeString+ "\Services\NumberCruncher"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\NumberCruncherService.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName +$siteCodeString+ "\Services\NumberCruncher\NumberCruncherService.exe.config"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='System']")
	$targetConfigNode.SetAttribute("value", "Vis" + $environmentName+$siteCodeString)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName +$siteCodeString+ "\System_Vis" + $environmentName +$siteCodeString+ "\Logs\NumberCruncher.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.LogSockets.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName +$siteCodeString+ "\System_Vis" + $environmentName +$siteCodeString+ "\Logs\NumberCruncher.Fortek.Net.LogSockets.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.Rx.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName +$siteCodeString+ "\System_Vis" + $environmentName +$siteCodeString+ "\Logs\NumberCruncher.Fortek.Net.Rx.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.Tx.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName +$siteCodeString+"\System_Vis" + $environmentName +$siteCodeString+ "\Logs\NumberCruncher.Fortek.Net.Tx.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VSCMService{
	<#
    .SYNOPSIS
    Creates VisionServerConnectionManager.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates VisionServerConnectionManager.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "VisionServerConnectionManager.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName +$siteCodeString+ "\Services\VSCM"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\VisionServerConnectionManager.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + $siteCodeString + "\Services\VSCM\VisionServerConnectionManager.exe.config"
    }

	# Base Ports
	$syncBasePort, $fallbackSyncPort, $mainSystemPort = 0

	if ($thisServerType.Name -eq "CCM"){
		$ccmNodes = $sourceConfigXml.SelectNodes("//CCM")
		$systemName = "Vis" + $environmentName + $siteCodeString
		$thisServerIndex = $ccmNodes.HostName.IndexOf($thisServer)
		$thisSiteCode = $ccmNodes.SiteCode[$thisServerIndex]
		$mainSystemBaseport = 12500
		$mainSystemPort = Calculate-Ports -systemName $systemName -basePort $mainSystemBaseport
		$fallbackPort = (Calculate-Ports -systemName ($systemName + "_" + $thisSiteCode) -basePort $mainSystemBaseport) - $mainSystemPort
		$fallbackSyncPort = $mainSystemBaseport - $fallbackPort
		$syncBasePort = $fallbackSyncPort + 6000

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='FallbackEnabled']/value")
        $targetConfigNode.InnerText = "True"

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='FallbackConnectionString']/value")
        $targetConfigNode.InnerText = "Server=.\SQLExpress;Database=Vis" + $environmentName + $siteCodeString + "_VisionFallbackManager;Trusted_Connection=Yes;"

	} else {
		$syncBasePort = 18500
		$fallbackSyncPort = 12500
	}

	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='SyncBasePort']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = $syncBasePort
	$targetConfigNode.AppendChild($h)

	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='FallbackSyncPort']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = $fallbackSyncPort
	$targetConfigNode.AppendChild($h)

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='System']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName + $siteCodeString
	$targetConfigNode.AppendChild($h)

	# Sync Connection
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='SyncConnection']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Server=.\SQLEXPRESS;Database=Vis" + $environmentName + $siteCodeString + "_VisionPacketManager;Trusted_Connection=Yes;"
	$targetConfigNode.AppendChild($h)

	# Array of Sync Hosts
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='SyncHosts']/value/ArrayOfHost")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")

	foreach ($node in $vasNodes){
		$h = $targetConfigXml.CreateElement("Host")
		$targetConfigNode.AppendChild($h)

		$i = $h.AppendChild($targetConfigXml.CreateElement("Address"))
		$i.InnerText = $node.IpAddress
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("PacketManagerDatabaseName"))
		$i.InnerText = "Vis" + $environmentName + "_VisionPacketManager"
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("LinkedServerName"))
		$i.InnerText = $node.HostName
		$h.AppendChild($i)
	}

	if ($thisServerType.Name -eq "CCM"){
		$ccmNodes = $sourceConfigXml.SelectNodes("//CCM")
		$thisServerIndex = $ccmNodes.HostName.IndexOf($thisServer)
		$thisSiteCode = $ccmNodes.SiteCode[$thisServerIndex]

		$h = $targetConfigXml.CreateElement("Host")
		$targetConfigNode.AppendChild($h)

		$i = $h.AppendChild($targetConfigXml.CreateElement("Address"))
		$i.InnerText = $ccmNodes.IpAddress[$thisServerIndex]
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("PacketManagerDatabaseName"))
		$i.InnerText = "Vis" + $environmentName + $siteCodeString + "_VisionPacketManager"
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("LinkedServerName"))
		$i.InnerText = $thisServer
		$h.AppendChild($i)
	}

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='PacketManager']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName + $siteCodeString + "\Logs\ServicesCore_VSCM_PacketManager.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='VSCM']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName + $siteCodeString + "\Logs\VSCM.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='FallbackManager']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName + $siteCodeString + "\Logs\ServicesCore_VSCM_FallbackManager.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='VSCM.UserStats.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName + $siteCodeString + "\Logs\VSCM_UserStats.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='VSCM.UnroutablePackets.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName + $siteCodeString + "\Logs\VSCM_UnroutablePackets.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='VSCM.ReplotStats.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + $siteCodeString + "\System_Vis" + $environmentName + $siteCodeString + "\Logs\VSCM_ReplotStats.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-ArbitratorService{
	<#
    .SYNOPSIS
    Creates Fortek.Services.Arbitrator.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates Fortek.Services.Arbitrator.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Fortek.Services.Arbitrator.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\Arbitrator"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Fortek.Services.Arbitrator.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\Arbitrator\Fortek.Services.Arbitrator.exe.config"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")

	# Split brain configs
    $targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='Required']/value")
    $thisNode = $vasNodes | Where-Object {$_.HostName -eq $thisServer}
    $targetConfigNode.Item(0).InnerText = $thisNode.Required

    $targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='Addresses']/value/ArrayOfString")
    $AddressNodes = $thisNode.RequiredAddress
    foreach ($item in $AddressNodes.Address)
    {
        $h = $targetConfigXml.CreateElement("string")
        $h.InnerText = $item
        $targetConfigNode.AppendChild($h)
    }

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='SystemName']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName
	$targetConfigNode.AppendChild($h)

	# Array of VAS Hosts
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='VSCM']/value/ArrayOfString")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")

	foreach ($node in $vasNodes){
		$h = $targetConfigXml.CreateElement("string")
		$h.InnerText = $node.IpAddress
		$targetConfigNode.AppendChild($h)
	}

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\Arbitrator.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-EventProcessorService{
	<#
    .SYNOPSIS
    Creates EventProcessorService.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates EventProcessorService.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "EventProcessorService.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\EventProcessor"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\EventProcessorService.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\EventProcessor\EventProcessorService.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='System']")
	$targetConfigNode.SetAttribute("value", "Vis" + $environmentName)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\EventProcessor.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-ExternalClientGatewayService{
	<#
    .SYNOPSIS
    Creates Fortek.Services.ExternalClientGateway.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates Fortek.Services.ExternalClientGateway.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Fortek.Services.ExternalClientGateway.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ExternalClientGateway"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Fortek.Services.ExternalClientGateway.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\ExternalClientGateway\Fortek.Services.ExternalClientGateway.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='CADSystemName']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName
	$targetConfigNode.AppendChild($h)

	# Array of VAS Hosts
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='CADHosts']/value/ArrayOfString")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")

	$VasOrder = @()
	foreach ($node in $vasNodes){
		if ($node.Hostname -eq $thisServer){
		$VasOrder += @($node.IpAddress)
		} 
	}
	foreach ($node in $vasNodes){
		if ($node.Hostname -ne $thisServer){
		$VasOrder += @($node.IpAddress)
		}
	}

	foreach ($node in $VasOrder){
		$h = $targetConfigXml.CreateElement("string")
		$h.InnerText = $node
		$targetConfigNode.AppendChild($h)
	}

	if ($thisServerType.Name -eq "VAS"){
        $targetConfigNode = $targetConfigXml.SelectNodes("//applicationSettings")
        $child_node = $targetConfigNode.selectSingleNode("//Fortek.Net.My.MySettings")
        $targetConfigNode.RemoveChild($child_node)
    }elseif($thisServerType.Name -eq "VMG"){
		$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='SecondsUntilTimeOut']/value")
		$targetConfigNode.InnerText = "300"
		$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='BroadcastAVL']/value")
		$targetConfigNode.InnerText = "True"
		$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='EnhancedDebugLogging']/value")
		$targetConfigNode.InnerText = "True"
		$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='SendFullAddress']/value")
		$targetConfigNode.InnerText = "True"
		$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='ReplotChunkSize']/value")
		$targetConfigNode.InnerText = "300"
		$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='FinalisationNarrativeKey']/value")
        $targetConfigNode.InnerText = "8"
		$targetConfigNode = $targetConfigXml.SelectSingleNode("//appender[@name='Fortek.Net.Rx.Appender']/param[@name='MaximumFileSize']")
		$targetConfigNode.SetAttribute("value", "100MB")
		$targetConfigNode = $targetConfigXml.SelectSingleNode("//appender[@name='Fortek.Net.Tx.Appender']/param[@name='MaximumFileSize']")
		$targetConfigNode.SetAttribute("value", "100MB")
	}

	# Web Service URL
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='Fortek_ExternalClientGateway_DataReader_VisionDataReader']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "http://" + $environmentName + "cad-vwsnlb." + $adDomain + "/Vis" + $environmentName + "_VisionWebServices/VisionDataReader.asmx" 
	$targetConfigNode.AppendChild($h)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ServiceVas_ExternalClientGateway.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.LogSockets.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\Sockets\ExternalClientGateway.Fortek.Net.LogSockets.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.Rx.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\Sockets\ExternalClientGateway.Fortek.Net.Rx.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.Tx.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\Sockets\ExternalClientGateway.Fortek.Net.Tx.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-MessageBrokerService{
	<#
    .SYNOPSIS
    Creates MessageBrokerService.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates MessageBrokerService.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "MessageBrokerService.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\MessageBroker"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\MessageBrokerService.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\MessageBroker\MessageBrokerService.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='System']")
	$targetConfigNode.SetAttribute("value", "Vis" + $environmentName)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ServiceVas_MessageBroker.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-SMSGWService{
	<#
    .SYNOPSIS
    Creates SMSGW.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates SMSGW.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "SMSGW.exe.config" -version $version).objects.object.'#text'


    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\SMSGW"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\SMSGW.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\SMSGW\SMSGW.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='System']")
	$targetConfigNode.SetAttribute("value", "Vis" + $environmentName)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\SMSGW.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-GD92GWService{
	<#
    .SYNOPSIS
    Creates GD92GW.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates GD92GW.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "GD92GW.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\SMSGW"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\GD92GW.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\SMSGW\GD92GW.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='System']")
	$targetConfigNode.SetAttribute("value", "Vis" + $environmentName)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VASServices_Gd92Gateway.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VdwService{
	<#
    .SYNOPSIS
    Creates VDW.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates VDW.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)
	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "VDW.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\VDW"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\VDW.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\VDW\VDW.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='SystemName']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName
	$targetConfigNode.AppendChild($h)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ServiceVas_VisionDatabaseWriter.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Failed_Packet_Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ServiceVas_VisionDatabaseWriter.FailedPackets.dat")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.LogSockets.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ServiceVas_VisionDatabaseWriter.FortekNet.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.Rx.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ServiceVas_VisionDatabaseWriter.FortekNetRx.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.Tx.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ServiceVas_VisionDatabaseWriter.FortekNetTx.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VisionTelstraCNIService{
	<#
    .SYNOPSIS
    Creates VISION Telstra CLI Service.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates VISION Telstra CLI Service.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "VISION Telstra CLI Service.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\VisionTelstraCNIService"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\VISION Telstra CLI Service.exe.config"

    }else
    {
    	$targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\VisionTelstraCNIService\VISION Telstra CLI Service.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='VISIONSystemName']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName
	$targetConfigNode.AppendChild($h)

	# Array of VAS Hosts
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='VISIONHosts']/value/ArrayOfString")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")

	$VasOrder = @()
	foreach ($node in $vasNodes){
		if ($node.Hostname -eq $thisServer){
		$VasOrder += @($node.IpAddress)
		}
	}
	foreach ($node in $vasNodes){
		if ($node.Hostname -ne $thisServer){
			$VasOrder += @($node.IpAddress)
		}
	}

	foreach ($node in $VasOrder){
		$h = $targetConfigXml.CreateElement("string")
		$h.InnerText = $node
		$targetConfigNode.AppendChild($h)
	}

	#Existing Array of AMLQueryURLS
	#$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='AMLQueryURLs']/value/ArrayOfString")
	#$amlNodes = $sourceConfigXml.SelectNodes("//AML")
	#$h = $targetConfigXml.CreateElement("string")
	#$h.InnerText = $amlNodes.PrimaryNode
	#$targetConfigNode.AppendChild($h)
	
	#Check if Secondary Node Exists and writes if it does
	#$secondaryExists = $amlNodes.SecondaryNode
	#if ($secondaryExists -ne $null)
	#{$h = $targetConfigXml.CreateElement("string")
	#	$h.InnerText = $amlNodes.SecondaryNode
	#	$targetConfigNode.AppendChild($h)
	#}

	#Array of AMLQueryURLS
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='AMLQueryURLs']/value/ArrayOfString")
    $amlNodes = $sourceConfigXml.SelectNodes("//AML")
    #If server is VT/PR 06/08
    if ($thisServer -eq "qps-vas-vt-06" -or $thisServer -eq "qps-vas-vt-08" -or $thisServer -eq "qps-vas-pr-06" -or $thisServer -eq "qps-vas-pr-08")
    	{
			$h = $targetConfigXml.CreateElement("string")
    		$h.InnerText = $amlNodes.PrimaryNode
    		$targetConfigNode.AppendChild($h)
		}
    #If server is VT/PR 05/07
    elseif ($thisServer -eq "qps-vas-vt-05" -or $thisServer -eq "qps-vas-vt-07" -or $thisServer -eq "qps-vas-pr-05" -or $thisServer -eq "qps-vas-pr-07")
    	{
			$h = $targetConfigXml.CreateElement("string")
    		$h.InnerText = $amlNodes.SecondaryNode
    		$targetConfigNode.AppendChild($h)
    	}
    #For all other env vas servers
    else
		{
			$h = $targetConfigXml.CreateElement("string")
			$h.InnerText = $amlNodes.PrimaryNode
			$targetConfigNode.AppendChild($h)
		}

	#if VT or PR - get password and enable certificate validation - otherwise disable certificate validation
	if ($environmentName -eq "PR" -or $environmentName -eq "VT")
	{$CNICertPW  = Get-StoredPassword -passwordName "CNI_CERT" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='CertificatePW']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = $CNICertPW
	$targetConfigNode.AppendChild($h)		
	
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='DisableCertificateValidation']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "False"
	$targetConfigNode.AppendChild($h)	}
	Else
	{$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='DisableCertificateValidation']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "True"
	$targetConfigNode.AppendChild($h)
	
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='CertificatePW']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Placeholder"
	$targetConfigNode.AppendChild($h)
	}	
	
	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ServiceVas_CNI.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)

	#replace environment variable in certificate name
	(Get-Content $targetConfig -Raw).Replace('${EnvironmentName}',$environmentName) | 
	Set-Content $targetConfig 
}

## AML Web Service
Function Update-AMLWebService{
	<#
    .SYNOPSIS
    Creates AML_Web.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates AML_Web.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master", 
		[Parameter(Mandatory=$false)]
        [ValidateSet('server','admin','_server','_admin')]
		[string]$service = "",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "AML_Web.config" -version $version).objects.object.'#text'
	
	$targetConfig = "d:\InetPub\wwwroot\Vis" + $environmentName + "_AMLService\web.config"
	$targetConfigXml.Save($targetConfig)
	#replace variable with EnvironmentName
	(Get-Content $targetConfig -Raw).Replace('${EnvironmentName}',$environmentName) | 
	Set-Content $targetConfig 	
}

## AML JSON
Function Update-AMLJSON{
	<#
    .SYNOPSIS
    Creates AML_appsettings.json file from the environment map and versioned config file
    .DESCRIPTION
    Creates AML_appsettings.json file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master", 
		[Parameter(Mandatory=$false)]
        [ValidateSet('server','admin','_server','_admin')]
		[string]$service = "",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	$targetConfigXml = (Get-ServiceConfig -configName "AML_appsettings.json" -version $version).objects.object.'#text'
	write-host $targetConfigXml
	$targetConfig = "d:\InetPub\wwwroot\Vis" + $environmentName + "_AMLService\appsettings.json"
	New-Item -ItemType "file" -Path $targetConfig -Force
	Set-Content -Path $targetConfig -Value $targetConfigXml
	 
	
	(Get-Content $targetConfig -Raw).Replace('${EnvironmentName}',$environmentName) | 
	Set-Content $targetConfig 
	
	# Array of VAS Hosts
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")

	#Create list of VAS in quotes separated by comma for JSON format
	foreach ($node in $vasNodes){
	$VasList = $VasList + [char]34 + $node.IpAddress + [char]34 + [char]44
	}
	$vasList = $VasList.Substring(0,$VasList.Length-1)
	
	(Get-Content $targetConfig -Raw).Replace('${VASList}',$VasList) | 
	Set-Content $targetConfig 	
}

Function Update-VisionClientService{
	<#
    .SYNOPSIS
    Creates VisionClientService.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates VisionClientService.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "VisionClientService.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\VCS"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\VisionClientService.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\VCS\VisionClientService.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='System']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName
	$targetConfigNode.AppendChild($h)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='ALL']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis$environmentName\System_Vis$environmentName\Logs\VCS Trace\VisionClientService.log")
    
    if ($thisServerType.Name -eq "VCS"){
		$targetConfigNode = $targetConfigXml.SelectNodes("//sectionGroup")
		$h = $targetConfigXml.CreateElement("section")
		$h.SetAttribute("name", "Fortek.Remoting.My.MySettings")
		$h.SetAttribute("type", "System.Configuration.ClientSettingsSection, System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
		$h.SetAttribute("requirePermission", "false")
		$targetConfigNode.AppendChild($h)

	# Active Load Balancing changes
		$targetConfigNode = $targetConfigXml.SelectNodes("//VisionClientService.My.MySettings")
		$h = $targetConfigXml.CreateElement("setting")
		$h.SetAttribute("name", "LoadBalancingGroup")
		$h.SetAttribute("serializeAs", "Xml")
		$targetConfigNode.AppendChild($h)

		$i = $targetConfigXml.CreateElement("value")
		$h.AppendChild($i)

		$j = $targetConfigXml.CreateElement("ArrayOfString")
		$j.SetAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
		$j.SetAttribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema")
		$i.AppendChild($j)

		$vcsNodes = $sourceConfigXml.SelectNodes("//VCS")
		$thisServerIndex = $vcsNodes.HostName.IndexOf($thisServer)
		$arrayLength = $vcsNodes.Count
        
		for ($i = 0; $i -le ($arrayLength - $thisServerIndex -1); $i++){
			$k = $targetConfigXml.CreateElement("string")
			$k.InnerText = $vcsNodes[$i + $thisServerIndex].HostName
			$j.AppendChild($k)
		}
        
        if ($thisServerIndex -gt 0){		
            for ($i = 0; $i -le ($thisServerIndex - 1); $i++){
                $k = $targetConfigXml.CreateElement("string")
			    $k.InnerText = $vcsNodes[$i].HostName
			    $j.AppendChild($k)
		    }
        }

        $targetConfigNode = $targetConfigXml.SelectNodes("//VisionClientService.My.MySettings")
		$h = $targetConfigXml.CreateElement("setting")
		$h.SetAttribute("name", "VisionClientService_DataReader_VisionDataReader")
		$h.SetAttribute("serializeAs", "String")
		$targetConfigNode.AppendChild($h)

		$i = $targetConfigXml.CreateElement("value")
		$i.InnerText = "http://" + $environmentName.ToLower() + "cad-vcsnlb." + $adDomain.ToLower() + "/Vis" + $environmentName + "_VisionWebServices/visiondatareader.asmx"
		$h.AppendChild($i)

		$targetConfigNode = $targetConfigXml.SelectNodes("//applicationSettings")
		$h = $targetConfigXml.CreateElement("VisionLib.My.MySettings")
		$targetConfigNode.AppendChild($h)

		$i = $targetConfigXml.CreateElement("setting")
		$i.SetAttribute("name", "LogSockets")
		$i.SetAttribute("serializeAs", "String")
		$h.AppendChild($i)

		$j = $targetConfigXml.CreateElement("value")
		$j.InnerText = "True"
		$i.AppendChild($j)

		$h = $targetConfigXml.CreateElement("Fortek.Remoting.My.MySettings")
		$targetConfigNode.AppendChild($h)

		$i = $targetConfigXml.CreateElement("setting")
		$i.SetAttribute("name", "CompressionThreshold")
		$i.SetAttribute("serializeAs", "String")
		$h.AppendChild($i)

		$j = $targetConfigXml.CreateElement("value")
		$j.InnerText = "500"
		$i.AppendChild($j)

		$targetConfigNode = $targetConfigXml.SelectNodes("//channel[@ref='tcp']")
		$h = $targetConfigXml.CreateElement("clientProviders")
		$targetConfigNode.AppendChild($h)

		$i = $targetConfigXml.CreateElement("formatter")
		$i.SetAttribute("ref", "binary")
		$i.SetAttribute("typeFilterLevel", "Full")
		$h.AppendChild($i)

		$i = $targetConfigXml.CreateElement("provider")
		$i.SetAttribute("type", "System.Runtime.Remoting.Channels.BinaryServerFormatterSinkProvider, System.Runtime.Remoting")
		$h.AppendChild($i)

		$i = $targetConfigXml.CreateElement("provider")
		$i.SetAttribute("type", "MessagingLib.EncryptionClientSinkProvider, MessagingLib")
		$h.AppendChild($i)

		$i = $targetConfigXml.CreateElement("provider")
		$i.SetAttribute("type", "MessagingLib.CompressionClientSinkProvider, MessagingLib")
		$h.AppendChild($i)

		$targetConfigNode = $targetConfigXml.SelectNodes("//configuration")
		$i = $targetConfigXml.CreateElement("appSettings")
		$targetConfigNode.AppendChild($i)

		$j = $targetConfigXml.CreateElement("add")
		$j.SetAttribute("key", "System")
		$j.SetAttribute("value", "Vis" + $environmentName)
		$i.AppendChild($j)

		$j = $targetConfigXml.CreateElement("add")
		$j.SetAttribute("key", "ApplicationName")
		$j.SetAttribute("value", "VisionClientService")
		$i.AppendChild($j)

		$j = $targetConfigXml.CreateElement("add")
		$j.SetAttribute("key", "ClientSettingsProvider.ServiceUri")
		$j.SetAttribute("value", "")
		$i.AppendChild($j)
	}

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

## VWS Server Services
Function Update-VisionWebService{
	<#
    .SYNOPSIS
    Creates VWS_Web.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates VWS_Web.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master", 
		[Parameter(Mandatory=$false)]
        [ValidateSet('server','admin','_server','_admin')]
		[string]$service = "",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "VWS_Web.config" -version $version).objects.object.'#text'
	
	if ($service -eq "server" -or $service -eq "admin"){
		$service = "_" + $service
	}

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "_VisionWebServices$service"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\web.config"

    }else
    {
	    $targetConfig = "d:\InetPub\wwwroot\Vis" + $environmentName + "_VisionWebServices$service\web.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Passwords
	$oraVisionReaderPW = Get-StoredPassword -passwordName "ORA_VISION_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionReaderUN = Get-StoredUsername -passwordName "ORA_VISION_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionServerReaderPW  = Get-StoredPassword -passwordName "ORA_VISION_Server_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionServerReaderUN  = Get-StoredUsername -passwordName "ORA_VISION_Server_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionGazReaderPW  = Get-StoredPassword -passwordName "ORA_VISION_GAZREADER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionGazReaderUN  = Get-StoredUsername -passwordName "ORA_VISION_GAZREADER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionAdminPW  = Get-StoredPassword -passwordName "ORA_VISION_ADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionAdminUN  = Get-StoredUsername -passwordName "ORA_VISION_ADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey

	# appSettings
	$targetConfigNode = $targetConfigXml.SelectNodes("//appSettings/add[@key='VisionDataSource']")
	$targetConfigNode.SetAttribute("value", $environmentName + "CAD")


	if ($service -eq "_server"){
		$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='VisionDatabaseUser']")
		$targetConfigNode.SetAttribute("value", $oraVisionServerReaderUN)

		$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='VisionDatabasePassword']")
		$targetConfigNode.SetAttribute("value", $oraVisionServerReaderPW)
	} else {
		$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='VisionDatabaseUser']")
		$targetConfigNode.SetAttribute("value", $oraVisionReaderUN)

		$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='VisionDatabasePassword']")
		$targetConfigNode.SetAttribute("value", $oraVisionReaderPW)
	}
	
	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='GazDataSource']")
	$targetConfigNode.SetAttribute("value", $environmentName + "CAD")

	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='GazDatabaseUser']")
	$targetConfigNode.SetAttribute("value", $oraVisionGazReaderUN)

	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='GazDatabasePassword']")
	$targetConfigNode.SetAttribute("value", $oraVisionGazReaderPW)

	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='AdminDatabaseUser']")
	$targetConfigNode.SetAttribute("value", $oraVisionAdminUN)

	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='AdminDatabasePassword']")
	$targetConfigNode.SetAttribute("value", $oraVisionAdminPW)

	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='LoggingConfigurationFile']")
	$targetConfigNode.SetAttribute("value", "d:\inetpub\wwwroot\Vis" + $environmentName + "_VisionWebServices" + $service + "\loggingconfig.xml")

	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='Logpath']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs")

	# Save Changes
	$targetConfigXml.Save($targetConfig)

	## LOGGING Config
    if ($check)
    {
        $targetConfig = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "_VisionWebServices$service\LoggingConfig.xml"
    }else
    {
	    $targetConfig = "d:\InetPub\wwwroot\Vis" + $environmentName + "_VisionWebServices$service\LoggingConfig.xml"
    }

    [xml]$targetConfigXml = (Get-ServiceConfig -configName "VWS_LoggingConfig.xml" -version $version).objects.object.'#text'

    $targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param") | Where-Object {$_.Name -eq 'File'}
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VisionWebServices$service.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='VisionGazetteerService.Appender']/param") | Where-Object {$_.Name -eq 'File'}
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VisionGazetteerService$service.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='VisionDataReaderService.Appender']/param") | Where-Object {$_.Name -eq 'File'}
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VisionDataReaderService$service.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='VisionAdministratorService.Appender']/param") | Where-Object {$_.Name -eq 'File'}
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VisionAdministratorService$service.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VisionMdtWebService{
	<#
    .SYNOPSIS
    Creates MDT_Web.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates MDT_Web.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)
		
	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

    ## Web.config
    [xml]$targetConfigXml = (Get-ServiceConfig -configName "MDT_Web.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "_VisionMdtWebServices"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\web.config"

    }else
    {
	    $targetConfig = "d:\InetPub\wwwroot\Vis" + $environmentName + "_VisionMdtWebServices\web.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Passwords
	$oraVisionReaderPW = Get-StoredPassword -passwordName "ORA_VISION_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionReaderUN = Get-StoredUsername -passwordName "ORA_VISION_READER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey

	# appSettings
	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='ConnectionString']")
	$targetConfigNode.SetAttribute("value", "Data Source=" + $environmentName + "CAD; User Id=" + $oraVisionReaderUN + "; Password=" + $oraVisionReaderPW + ";")


	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='DirectoryLoggingConfigurationFile']")
	$targetConfigNode.SetAttribute("value", "D:\inetpub\wwwroot\Vis" + $environmentName + "_VisionMdtWebServices\directoryloggingConfig.xml")

	$targetConfigNode = $targetConfigXml.SelectNodes("//add[@key='NarrativeLoggingConfigurationFile']")
	$targetConfigNode.SetAttribute("value", "D:\inetpub\wwwroot\Vis" + $environmentName + "_VisionMdtWebServices\narrativeloggingConfig.xml")

	# Save Changes
	$targetConfigXml.Save($targetConfig)

    ## directoryLoggingConfig
    [xml]$targetConfigXml = (Get-ServiceConfig -configName "MDT_directoryLoggingConfig.xml" -version $version).objects.object.'#text'
    
    if ($check)
    {
        $targetConfig = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "_VisionMdtWebServices\directoryLoggingConfig.xml"
    }else
    {
	    $targetConfig = "d:\InetPub\wwwroot\Vis" + $environmentName + "_VisionMdtWebServices\directoryLoggingConfig.xml"
    }

    $targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param") | Where-Object {$_.Name -eq 'File'}
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\MDTDirectoryWebService.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)

    ## narrativeLoggingConfig
    [xml]$targetConfigXml = (Get-ServiceConfig -configName "MDT_narrativeLoggingConfig.xml" -version $version).objects.object.'#text'
    
    if ($check)
    {
        $targetConfig = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "_VisionMdtWebServices\narrativeLoggingConfig.xml"
    }else
    {
	    $targetConfig = "d:\InetPub\wwwroot\Vis" + $environmentName + "_VisionMdtWebServices\narrativeLoggingConfig.xml"
    }

    $targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param") | Where-Object {$_.Name -eq 'File'}
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\MDTNarrativeWebService.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

## VIM Server Services

Function Update-VimArl{
	<#
    .SYNOPSIS
    Creates ARL.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates ARL.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "ARL.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ARL"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\ARL.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\ARL\ARL.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer
	
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain
	
	$oraVisionAdminPW  = Get-StoredPassword -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionAdminUN  = Get-StoredUsername -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$vimArlPW  = Get-StoredPassword -passwordName "VIM_ARL" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	
	# Connection String
	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='VIM']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source=" + $environmentName + "CAD;User ID=" + $oraVisionAdminUN + ";Password=" + $oraVisionAdminPW + ";Min Pool Size=6;")

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='ARLVIM']/file")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VIMArl.log")

	# ARL AAS NLB Host
	$aasNodes = $sourceConfigXml.SelectNodes("//AAS")
	$aasNlb = ""
	foreach ($node in $aasNodes){
			$aasNlb = $node.NLB
	}

	if ($aasNlb -eq ""){$aasNlb = "dummy"}

	$targetConfigNode = $targetConfigXml.SelectNodes("//client/endpoint[@name='ArlResourceServiceEndpoint']")
	$targetConfigNode.SetAttribute("address", "http://" + $aasNlb + "." + $adDomain + "/ArlResourceService/ResourceService.svc")

	# CAD Hosts
	$vimNodes = $sourceConfigXml.SelectNodes("//VIM")
	$thisServerIndex = $vimNodes.HostName.IndexOf($thisServer) + 1

	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	$count = 1
	foreach ($node in $vasNodes){
		$targetConfigNode = $targetConfigXml.SelectNodes("//CadServers")
		$h = $targetConfigXml.CreateElement("CadServer")
		$h.SetAttribute("index", $count)
		$h.SetAttribute("systemName", "Vis" + $environmentName)
		$h.SetAttribute("serverAddress", $node.IpAddress)
		$h.SetAttribute("userPosition", $node.HostName)
		$h.SetAttribute("userProfile", "Administrator")
		$h.SetAttribute("userId", "VIM" + $thisServerIndex + "ARL" + $count)
		$h.SetAttribute("userPassword", $vimArlPW)
		$targetConfigNode.AppendChild($h)
		$count++
	}

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VimAudit{
	<#
    .SYNOPSIS
    Creates Audit.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates Audit.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Audit.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\Audit"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Audit.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\Audit\Audit.exe.config"
    }
    
    $thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain
	
	$oraVisionAdminPW  = Get-StoredPassword -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionAdminUN  = Get-StoredUsername -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionReportPW  = Get-StoredPassword -passwordName "ORA_REPORTUSER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionReportUN  = Get-StoredUsername -passwordName "ORA_REPORTUSER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey

	# Connection Strings
	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='VIM']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source=" + $environmentName + "CAD;User ID=" + $oraVisionAdminUN + ";Password=" + $oraVisionAdminPW + ";Min Pool Size=6;Decr Pool Size=3;")

	$oraNodes = $sourceConfigXml.SelectNodes("//ORA")
	$repDataSource = ""
	foreach ($node in $oraNodes){
		$repDataSource = $node.ReportDataSource
	}

	#Report DB connection put back in as the service still requires it
	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='REPORT']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source=" + $repDataSource + ";User ID=" + $oraVisionReportUN + ";Password=" + $oraVisionReportPW + ";Min Pool Size=6;Decr Pool Size=3;")

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Audit']/file")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VIMAudit.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appSettings/add[@key='AuditLogFilePath']")
	$targetConfigNode.SetAttribute("value", "\\" + $ADDomain + "\appdata\" + $EnvironmentName + "\QCAD\VisionAudit$\")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VimOccurrence{
	<#
    .SYNOPSIS
    Creates Occurrence.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates Occurrence.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Occurrence.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\Occurrence"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Occurrence.exe.config"

    }else
    {
    	$targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\Occurrence\Occurrence.exe.config"
	}

    $thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# QPRIME Target
    $QprimeTarget = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.QPrimeTarget
	
	$oraVisionAdminPW  = Get-StoredPassword -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionAdminUN  = Get-StoredUsername -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$vimOccPW  = Get-StoredPassword -passwordName "VIM_Occurance" -environment $environmentName -listId $PasswordListId -apiKey $apiKey

	# Occurrence URL
    $targetConfigNode = $targetConfigXml.SelectNodes("//applicationSettings/Fortek.Vision.QPS.Occurrence.Properties.Settings/setting")
    #$targetConfigNode.Item(1) = 
    $h = $targetConfigXml.CreateElement("value")
    $h.InnerText = "http://$QprimeTarget.$adDomain/Interfaces/CADV3Service/CAD.svc"
    $targetConfigNode.AppendChild($h)
	
	# Connection String
	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='VIM']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source=" + $environmentName + "CAD;User ID=" + $oraVisionAdminUN + ";Password=" + $oraVisionAdminPW + ";Min Pool Size=6;Decr Pool Size=3;")

	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='VCLCACHE']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source=.\SQLEXPRESS;Initial Catalog=Vis" + $environmentName + "_VCLCACHE;Persist Security Info=True;Integrated Security=True")

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='OccurrenceVIM']/file")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VIMOccurrence.log")

	# CAD Hosts
	$vimNodes = $sourceConfigXml.SelectNodes("//VIM")
	$thisServerIndex = $vimNodes.HostName.IndexOf($thisServer) + 1

	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	$count = 1
	foreach ($node in $vasNodes){
		$targetConfigNode = $targetConfigXml.SelectNodes("//CadServers")
		$h = $targetConfigXml.CreateElement("CadServer")
		$h.SetAttribute("index", $count)
		$h.SetAttribute("systemName", "Vis" + $environmentName)
		$h.SetAttribute("serverAddress", $node.IpAddress)
		$h.SetAttribute("userPosition", $node.HostName)
		$h.SetAttribute("userProfile", "Administrator")
		$h.SetAttribute("userId", "VIM" + $thisServerIndex + "OCC" + $count)
		$h.SetAttribute("userPassword", $vimOccPW)
		$targetConfigNode.AppendChild($h)
		$count++
	}

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VimOfficerDetail{
	<#
    .SYNOPSIS
    Creates OfficerDetail.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates OfficerDetail.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "OfficerDetail.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\OfficerDetail"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\OfficerDetail.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\OfficerDetail\OfficerDetail.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain
	
	$oraVisionAdminPW  = Get-StoredPassword -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionAdminUN  = Get-StoredUsername -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$vimOdPW  = Get-StoredPassword -passwordName "VIM_OfficerDetail" -environment $environmentName -listId $PasswordListId -apiKey $apiKey

	# Connection String
	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='VIM']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source=" + $environmentName + "CAD;User ID=" + $oraVisionAdminUN + ";Password=" + $oraVisionAdminPW + ";Min Pool Size=6;Decr Pool Size=3;")

	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='VCLCACHE']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source=.\SQLEXPRESS;Initial Catalog=Vis" + $environmentName + "_VCLCACHE;Persist Security Info=True;Integrated Security=True")

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='OfficerDetail']/file")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VIMOfficerDetail.log")

	# CAD Hosts
	$vimNodes = $sourceConfigXml.SelectNodes("//VIM")
	$thisServerIndex = $vimNodes.HostName.IndexOf($thisServer) + 1

	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	$count = 1
	foreach ($node in $vasNodes){
		$targetConfigNode = $targetConfigXml.SelectNodes("//CadServers")
		$h = $targetConfigXml.CreateElement("CadServer")
		$h.SetAttribute("index", $count)
		$h.SetAttribute("systemName", "Vis" + $environmentName)
		$h.SetAttribute("serverAddress", $node.IpAddress)
		$h.SetAttribute("userPosition", $node.HostName)
		$h.SetAttribute("userProfile", "Administrator")
		$h.SetAttribute("userId", "VIM" + $thisServerIndex + "OD" + $count)
		$h.SetAttribute("userPassword", $vimOdPW)
		$targetConfigNode.AppendChild($h)
		$count++
	}

	$targetConfigNode = $targetConfigXml.SelectNodes("//appSettings/add[@key='OfficerDetailFilePath']")
	$targetConfigNode.SetAttribute("value", "\\" + $adDomain + "\appdata\" + $environmentName + "\QCAD\OfficerDetails$\")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appSettings/add[@key='VasSqlSvrCxnString']")
	$targetConfigNode.SetAttribute("value", "Data Source={0},2001;Initial Catalog=Vis" + $environmentName + "_VisionServer;Persist Security Info=True;Integrated Security=True")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VimPoliceLink{
	<#
    .SYNOPSIS
    Creates PoliceLink_VIM.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates PoliceLink_VIM.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "PoliceLink_VIM.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\PoliceLinkVIM"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\PoliceLink_VIM.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\PoliceLinkVIM\PoliceLink_VIM.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain
	$crmTarget = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.CRMTarget
	
	$oraVisionAdminPW  = Get-StoredPassword -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionAdminUN  = Get-StoredUsername -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$vimPlPW  = Get-StoredPassword -passwordName "VIM_PoliceLink" -environment $environmentName -listId $PasswordListId -apiKey $apiKey

	# Connection String
	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='VIM']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source=" + $environmentName + "CAD;User ID=" + $oraVisionAdminUN + ";Password=" + $oraVisionAdminPW + ";Min Pool Size=6;Decr Pool Size=3;")

	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='VASDB']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source={0}\SQLEXPRESS;Initial Catalog=Vis" + $environmentName + "_VisionServer;Persist Security Info=True;Integrated Security=True;MultipleActiveResultSets=True")

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='PoliceLinkVIM']/file")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VIMPoliceLink.log")

	# CAD Hosts
	$vimNodes = $sourceConfigXml.SelectNodes("//VIM")
	$thisServerIndex = $vimNodes.HostName.IndexOf($thisServer) + 1

	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	$count = 1
	foreach ($node in $vasNodes){
		$targetConfigNode = $targetConfigXml.SelectNodes("//CadServers")
		$h = $targetConfigXml.CreateElement("CadServer")
		$h.SetAttribute("index", $count)
		$h.SetAttribute("systemName", "Vis" + $environmentName)
		$h.SetAttribute("serverAddress", $node.IpAddress)
		$h.SetAttribute("userPosition", $node.HostName)
		$h.SetAttribute("userProfile", "Administrator")
		$h.SetAttribute("userId", "VIM" + $thisServerIndex + "PLK" + $count)
		$h.SetAttribute("userPassword", $vimPlPW)
		$targetConfigNode.AppendChild($h)
		$count++
	}

    $targetConfigNode = $targetConfigXml.SelectNodes("//appSettings/add[@key='ServiceName']")
    $targetConfigNode.SetAttribute("value","Vis"+$environmentName+"_PolicelinkVIM")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appSettings/add[@key='VasAccessCxnString']")
	$targetConfigNode.SetAttribute("value", "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\\" + $adDomain + "\appdata\" + $environmentName + "\QCAD\New Version$\Server\Config\cmsserverconfig.mdb;Mode=share deny write;")

	#$targetConfigNode = $targetConfigXml.SelectNodes("//client/endpoint[@name='QPSCADWebServiceBinding']")
	#$targetConfigNode.SetAttribute("address", "http://" + $crmTarget + "." + $adDomain + "/GTConnect/StatelessSoapAcceptor/?gtxInitialProcess=QPSCAD.Integration.WebServices.QPSCADWebService")
	# Save Changes
	$targetConfigXml.Save($targetConfig)

	$CRM = $crmTarget + "." + $adDomain
	(Get-Content $targetConfig -Raw).Replace('${CRMTarget}',$CRM) | 	
    Set-Content $targetConfig
}

Function Update-VimPoliceLinkWeb{
	<#
    .SYNOPSIS
    Creates NumberCruncherService.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates NumberCruncherService.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "PoliceLinkWeb_Web.config" -version $version).objects.object.'#text'
	
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\PoliceLinkWeb"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\web.config"

    }else
    {
	    $targetConfig = "D:\vision\Vis" + $environmentName + "\Services\PoliceLinkWeb\web.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Passwords
	$oraVisionAdminPW  = Get-StoredPassword -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionAdminUN  = Get-StoredUsername -passwordName "ORA_VIMADMIN" -environment $environmentName -listId $PasswordListId -apiKey $apiKey

	# Logging
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='PoliceLink']/file")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VIMPolicelink_Web.log")

	# appSettings
	$targetConfigNode = $targetConfigXml.SelectNodes("//connectionStrings/add[@name='VIM']")
	$targetConfigNode.SetAttribute("connectionString", "Data Source=" + $environmentName + "CAD; User Id=" + $oraVisionAdminUN + "; Password=" + $oraVisionAdminPW + ";Min Pool Size=6;Decr Pool Size=3;")


	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

## VCS Server SERVICES

Function Update-CccmService{
	<#
    .SYNOPSIS
    Creates Fortek.Services.CCCM.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates Fortek.Services.CCCM.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Fortek.Services.CCCM.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\CCCM"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Fortek.Services.CCCM.exe.config"

    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\CCCM\Fortek.Services.CCCM.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='SystemName']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName
	$targetConfigNode.AppendChild($h)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\CCCM\CCCM.log")
	
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.LogSockets.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\CCCM\CCCM.LogSockets.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.Rx.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\CCCM\CCCM.Rx.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.Tx.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\CCCM\CCCM.Tx.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VcsWms{
	<#
    .SYNOPSIS
    Creates web.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates web.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "VCS_WMS_Web.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Wms"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Web.config"
    }else
    {
	    $targetConfig = "D:\InetPub\wwwroot\Wms\Web.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer
			
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain
	
	# VCS WMS 
	$targetConfigNode = $targetConfigXml.SelectSingleNode("//appSettings/add[@key='configFile']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\GIS\LCAD_Map_Vis.xml")

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//appSettings/add[@key='MapInfo.Engine.Session.Workspace']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\GIS\LCAD_Map_Vis.mws")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VcsMapMws{
	<#
    .SYNOPSIS
    Creates LCAD_Map_Vis.mws file from the environment map and versioned config file
    .DESCRIPTION
    Creates LCAD_Map_Vis.mws file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "LCAD_Map_Vis.mws" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Gis"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\LCAD_Map_Vis.mws"
    }else
    {
	    $targetConfig = "E:\Vision\Vis" + $environmentName + "\Gis\LCAD_Map_Vis.mws"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer
			
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain
	
	$ns = new-object Xml.XmlNamespaceManager $targetConfigXml.NameTable
    $ns.AddNamespace("ns", $targetConfigXml.WorkSpace.xmlns)
    $ns.AddNamespace("mxp", "http://www.mapinfo.com/mxp")
    $ns.AddNamespace("gml", "http://www.opengis.net/gml")
	
	# Workspace Locations
	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id4']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\FEATURES\MANMADE\ISLAND_FEATURES.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id7']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\FEATURES\MANMADE\Bay_Features.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id10']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\FEATURES\MANMADE\PARK.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id12']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\FEATURES\MANMADE\Towns.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id15']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\ES\POLICE_DIVISIONS_LINE.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id18']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\ES\POLICE_PATROL_GROUPS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id22']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\ES\POLICE_REGIONS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id26']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\RAIL\RAIL_STN.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id28']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\AIR\Airstrip_Footprint.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id31']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\QLD\SUBURB_LINE.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id36']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\RAIL\RAILWAYS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id39']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\AUSTRALIA\AUST_HWY.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id42']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\MAJOR_RD.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id49']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\MAIN_RD.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id58']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\MINOR_RD.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id63']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\RURAL_MINOR_ROADS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id70']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\TUNNELS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id75']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\BIKEWAY.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id78']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\HYDROLOGY\DAM_CATCHMENT.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id81']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\HYDROLOGY\WATER_BODY.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id84']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\LANDUSE\NATIONAL_PARK_STATE_FOREST.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id88']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\LANDUSE\LAND_PARCELS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id92']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\QLD\SUBURB.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id95']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\QLD\LOCAL_GOVERNMENT_AREA.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id99']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\AUSTRALIA\AUSTRALIA.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//ns:TABFileDataSourceDefinition[@id='id102']", $ns)
	$targetConfigNode.FileName = "E:\Vision\Vis" + $environmentName + "\GIS\AUSTRALIA\BACKGROUND.TAB"

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VcsMapXml{
	<#
    .SYNOPSIS
    Creates LCAD_Map_Vis.xml file from the environment map and versioned config file
    .DESCRIPTION
    Creates LCAD_Map_Vis.xml file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "LCAD_Map_Vis.xml" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Gis"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\LCAD_Map_Vis.xml"
    }else
    {
	    $targetConfig = "E:\Vision\Vis" + $environmentName + "\Gis\LCAD_Map_Vis.xml"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer
			
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	$ns = new-object Xml.XmlNamespaceManager $targetConfigXml.NameTable
    $ns.AddNamespace("mxp-wms", "http://www.mapinfo.com/mxp/wms")
    $ns.AddNamespace("mxp", "http://www.mapinfo.com/mxp")
	
	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp-wms:OnlineResource", $ns)
	$targetConfigNode.InnerText = "http://" +$thisServer + "." + $adDomain + "/WMS/GetMap.ashx"
	
	# Workspace Locations
	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id1']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\AIR\Airstrip_Footprint.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id2']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\AUSTRALIA\AUSTRALIA.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id3']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\AUSTRALIA\AUST_HWY.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id4']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\AUSTRALIA\BACKGROUND.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id5']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\FEATURES\MANMADE\Bay_Features.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id6']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\BIKEWAY.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id7']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\HYDROLOGY\DAM_CATCHMENT.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id8']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\FEATURES\MANMADE\ISLAND_FEATURES.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id9']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\LANDUSE\LAND_PARCELS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id10']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\QLD\LOCAL_GOVERNMENT_AREA.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id11']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\MAIN_RD.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id12']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\MAJOR_RD.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id13']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\MINOR_RD.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id14']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\LANDUSE\NATIONAL_PARK_STATE_FOREST.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id15']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\FEATURES\MANMADE\PARK.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id16']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\ES\POLICE_DIVISIONS_LINE.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id17']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\ES\POLICE_PATROL_GROUPS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id18']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\ES\POLICE_REGIONS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id19']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\RAIL\RAILWAYS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id20']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\RAIL\RAIL_STN.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id21']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\RURAL_MINOR_ROADS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id22']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\QLD\SUBURB.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id23']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\ADMINBDY\QLD\SUBURB_LINE.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id24']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\FEATURES\MANMADE\TOWNS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id25']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\TRANSPORT\ROAD\TUNNELS.TAB"

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//mxp:TABFileDataSourceDefinition[@id='id26']/mxp:FileName", $ns)
	$targetConfigNode.InnerText = "E:\Vision\Vis" + $environmentName + "\GIS\HYDROLOGY\WATER_BODY.TAB"

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

## CCM Server SERVICES

Function Update-CcmService{
	<#
    .SYNOPSIS
    Creates VisionClientConnectionManagerService.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates VisionClientConnectionManagerService.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "VisionClientConnectionManagerService.exe.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\VCCM"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\VisionClientConnectionManagerService.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\VCCM\VisionClientConnectionManagerService.exe.config"
    }

	$thisServer = $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='System']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName
	$targetConfigNode.AppendChild($h)

	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
    $ccmNode = $sourceConfigXml.SelectNodes("//CCM")| Where-Object {$_.HostName -eq $thisServer}
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='Hosts']/value/ArrayOfString")

	foreach ($item in $ccmNode.VasOrder.List){
        $item
        [int]$index = $item - 1
        $h = $targetConfigXml.CreateElement("string")
		$h.InnerText = $vasNodes[$index].IpAddress
        write-host "element: " $h.InnerText
		$targetConfigNode.AppendChild($h)
	}

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\VCCM.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

## APL Server SERVICES

Function Update-AplParser{
	<#
    .SYNOPSIS
    Creates AplParser.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates AplParser.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Fortek.Services.APLParser.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\APLParser"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Fortek.Services.APLParser.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\APLParser\Fortek.Services.APLParser.exe.config"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\APLParser\APLParser.log")

	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='CADSystemName']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName
	$targetConfigNode.AppendChild($h)

	# Array of VAS Hosts
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='CADHosts']/value/ArrayOfString")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")

	foreach ($node in $vasNodes){
		$h = $targetConfigXml.CreateElement("string")
		$h.InnerText = $node.IpAddress
		$targetConfigNode.AppendChild($h)
	}

	# UDP IP
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='UdpIp']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = $thisServerType.IpAddress
	$targetConfigNode.AppendChild($h)

	# Array of MLS Gateways
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='MlsGateways']/value/ArrayOfString")
	$aplNodes = $sourceConfigXml.SelectNodes("//APL")

	foreach ($node in $aplNodes){
		if ($node.HostName -eq $thisServer){ ## If condition only while HADR of APL servers is not configured
			$h = $targetConfigXml.CreateElement("string")
			$h.InnerText = "http://" + $node.HostName + "." + $adDomain + "/Vis" + $environmentName + "_MlsGateway/MlsGateway.asmx"
			$targetConfigNode.AppendChild($h)
		}
	}

	foreach ($node in $aplNodes){
		if ($node.HostName -ne $thisServer){ ## If condition only while HADR of APL servers is not configured
			$h = $targetConfigXml.CreateElement("string")
			$h.InnerText = "http://" + $node.HostName + "." + $adDomain + "/Vis" + $environmentName + "_MlsGateway/MlsGateway.asmx"
			$targetConfigNode.AppendChild($h)
		}
	}

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-AvlUpdater{
	<#
    .SYNOPSIS
    Creates AvlUpdater.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates AvlUpdater.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Fortek.Services.AVLUpdaterService.exe.config" -version $version).objects.object.'#text'
  
    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\AVLUpdater"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Fortek.Services.AVLUpdaterService.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\AVLUpdater\Fortek.Services.AVLUpdaterService.exe.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain
	
	$oraVisionAVLWriterPW  = Get-StoredPassword -passwordName "ORA_VISION_AVLWRITER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	$oraVisionAVLWriterUN  = Get-StoredUsername -passwordName "ORA_VISION_AVLWRITER" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
	
	# System Name
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='SystemName']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Vis" + $environmentName
	$targetConfigNode.AppendChild($h)

	# Connection Strings
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='ConnectionString']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "Data Source=" + $environmentName + "CAD;User ID=" + $oraVisionAVLWriterUN + ";Password=" + $oraVisionAVLWriterPW + ";Min Pool Size=6;Decr Pool Size=3;"
	$targetConfigNode.AppendChild($h)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\AVLUpdater\AvlUpdater.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='FailedPackets.Appender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\AVLUpdater\AvlUpdater.FailedPackets.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-MlsGateway{
	<#
    .SYNOPSIS
    Creates web.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates web.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "APL_MLS_Web.config" -version $version).objects.object.'#text'

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "_MlsGateway"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Web.config"
    }else
    {
	    $targetConfig = "D:\InetPub\wwwroot\Vis" + $environmentName + "_MlsGateway\Web.config"
    }

	$thisServer = $thisServer
	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer
			
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain
	
	# MLS Gateway
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='MlsUserName']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "ARL-MLS-" + $environmentName
	$targetConfigNode.AppendChild($h)

	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='MlsUser']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "ARL-MLS-" + $environmentName
	$targetConfigNode.AppendChild($h)

	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='MotoLocatorService_MLSWebService_MLSWebServicesInterface']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "http://" + $environmentName + "CAD-AASNLB." + $adDomain + "/ArlLocationForwardService/MlsWebServices.asmx"
	$targetConfigNode.AppendChild($h)

	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='AuthorisedEndPoints']/value/ArrayOfString")
	$h = $targetConfigXml.CreateElement("string")
	$h.InnerText = $thisServer + ",6543"
	$targetConfigNode.AppendChild($h)

	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='OwnUrl']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "http://" + $thisServer + "." + $adDomain + "/Vis${EnvironmentName}_MlsGateway/MlsGateway.asmx"
	$targetConfigNode.AppendChild($h)

	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='Fortek_WebServices_MlsGateway_UNS_3_0_MLSWebServicesInterface']")
	$h = $targetConfigXml.CreateElement("value")
	$h.InnerText = "http://" + $thisServer + "." + $adDomain + "/Vis${EnvironmentName}_MlsGateway/MlsGateway.asmx"
	$targetConfigNode.AppendChild($h)

	# Log Directory
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='RollingLogFileAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\MlsGateway.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

## ICEMS

Function Update-IcemsMessenger{
	<#
    .SYNOPSIS
    Creates CF.Services.ICEMS.Messenger.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates CF.Services.ICEMS.Messenger.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "CF.Services.ICEMS.Messenger.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ICEMS6Messenger"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\CF.Services.ICEMS.Messenger.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\ICEMS6Messenger\CF.Services.ICEMS.Messenger.exe.config"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# Log Directories
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='MainAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Messenger\ICEMS.MessengerService.log")
	
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='Fortek.Net.LogSockets']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Messenger\ICEMS.MessengerService.LogSockets.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='ListenerAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Messenger\ICEMS.MessengerService.Listener.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='POLAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Messenger\ICEMS_Messenger_POL-Q.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='AMBAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Messenger\ICEMS_Messenger_AMB-Q.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='FIREAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Messenger\ICEMS_Messenger_FIRE-Q.log")

	#$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='SESAppender']/param[@name='File']")
	#$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Messenger\ICEMS_Messenger_SES.log")

	#$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='DTMRAppender']/param[@name='File']")
	#$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Messenger\ICEMS_Messenger_DTMR-Q.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-IcemsProcessor{
	<#
    .SYNOPSIS
    Creates CF.Services.ICEMS.Processor.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates CF.Services.ICEMS.Processor.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "CF.Services.ICEMS.Processor.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ICEMS6Processor"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\CF.Services.ICEMS.Processor.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\ICEMS6Processor\CF.Services.ICEMS.Processor.exe.config"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# Log Directories
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='MainAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Processor\ICEMS.ProcessorService.log")
	
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='VisionAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Processor\VisionClient.log")
	
	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='POLAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Processor\ICEMS_Processor_POL-Q.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='AMBAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Processor\ICEMS_Processor_AMB-Q.log")

	$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='FIREAppender']/param[@name='File']")
	$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Processor\ICEMS_Processor_FIRE-Q.log")

	#$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='SESAppender']/param[@name='File']")
	#$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Processor\ICEMS_Processor_SES.log")

	#$targetConfigNode = $targetConfigXml.SelectNodes("//appender[@name='DTMRAppender']/param[@name='File']")
	#$targetConfigNode.SetAttribute("value", "E:\Vision\Vis" + $environmentName + "\System_Vis" + $environmentName + "\Logs\ICEMS\Processor\ICEMS_Processor_DTMR.log")

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-IcemsLocalAgency{
	<#
    .SYNOPSIS
    Creates ICEMS LocalAgency.xml file from the environment map and versioned config file
    .DESCRIPTION
    Creates ICEMS LocalAgency.xml file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
	.PARAMETER type
	Requires either Processor or Messenger. This parameter is mandatory and validates the value
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
		
		[Parameter(Mandatory=$true)]
		[ValidateSet("Processor", "Messenger")]
		[string]$type,
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "ICEMS_LocalAgency.xml" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ICEMS6"+ $type+ "\Configuration\"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\LocalAgency.xml"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Services\ICEMS6" + $type + "\Configuration\LocalAgency.xml"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# Configuration
	$targetConfigNode = $targetConfigXml.SelectSingleNode("//PrimaryIPAddress")
	$targetConfigNode.InnerText = $thisServerType.IpAddress
	
	if ($type -eq "Messenger"){
		$targetConfigNode = $targetConfigXml.SelectSingleNode("//PrimaryTCPPort")
		$icemsServer = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ICEMS.ICEMSServers.Server |Where-Object { $_.HostName -eq $thisServer}
		$targetConfigNode.InnerText = $icemsServer.LocalPort
	}

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-IcemsQueues{
	<#
    .SYNOPSIS
    Creates ICEMS Queues.xml file from the environment map and versioned config file
    .DESCRIPTION
    Creates ICEMS Queues.xml file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "ICEMS_Queues.xml" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ICEMS6Messenger\Configuration"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetMessengerConfig = $tempPath + "\Queues.xml"
    }else
    {
	    $targetMessengerConfig = "d:\Vision\Vis" + $environmentName + "\Services\ICEMS6Messenger\Configuration\Queues.xml"
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ICEMS6Processor\Configuration"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetProcessorConfig = $tempPath + "\Queues.xml"

    }else
    {
        $targetProcessorConfig = "d:\Vision\Vis" + $environmentName + "\Services\ICEMS6Processor\Configuration\Queues.xml"
    }
    
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    $rabbitVisionPW = Get-EncStoredPassword -passwordName "Rabbit_Vision" -environment $environmentName -listId $PasswordListId -apiKey $apiKey
    $rabbitVisionUN = Get-StoredUsername -passwordName "Rabbit_Vision" -environment $environmentName -listId $PasswordListId -apiKey $apiKey

    $icemsServers = $sourceConfigXml.SelectNodes("//ICEMS/ICEMSServers/Server")
    $isIcems = 0
    foreach ($server in $icemsServers.HostName){
        if ($server -eq $thisServer){ $isIcems++ }
    }

	if ($isIcems -eq 1){
		# Configuration
        $targetConfigNode = $targetConfigXml.SelectNodes("//Hosts")
        foreach ($item in $targetConfigNode){
		    foreach ($server in $icemsServers.HostName){
                if ($server -eq $thisServer){
                    $h = $targetConfigXml.CreateElement("string")
                    $h.InnerText = $server
                    $item.AppendChild($h)
                }
            }
            foreach ($server in $icemsServers.HostName){
                if ($server -ne $thisServer){
                    $h = $targetConfigXml.CreateElement("string")
                    $h.InnerText = $server
                    $item.AppendChild($h)
                }
            }
        }

		$targetConfigNode = $targetConfigXml.SelectNodes("//Account")
        foreach ($item in $targetConfigNode){
		    $item.InnerText = $rabbitVisionUN
        }
	
		$targetConfigNode = $targetConfigXml.SelectNodes("//Password")
        foreach ($item in $targetConfigNode){
		    $item.InnerText = $rabbitVisionPW
        }

		# Save Changes
		$targetConfigXml.Save($targetMessengerConfig)
        $targetConfigXml.Save($targetProcessorConfig)
	}
}

Function Update-IcemsVision{
	<#
    .SYNOPSIS
    Creates ICEMS Vision.xml file from the environment map and versioned config file
    .DESCRIPTION
    Creates ICEMS Vision.xml file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "ICEMS_Vision.xml" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ICEMS6Messenger\Configuration"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetMessengerConfig = $tempPath + "\Vision.xml"
    }else
    {
	    $targetMessengerConfig = "d:\Vision\Vis" + $environmentName + "\Services\ICEMS6Messenger\Configuration\Vision.xml"
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ICEMS6Processor\Configuration"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetProcessorConfig = $tempPath + "\Vision.xml"
    }else
    {
        $targetProcessorConfig = "d:\Vision\Vis" + $environmentName + "\Services\ICEMS6Processor\Configuration\Vision.xml"
    }
    
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    $icemsServers = $sourceConfigXml.SelectNodes("//ICEMS/ICEMSServers/Server")
    $isIcems = 0
    $priority = 0

    foreach ($server in $icemsServers){
        write-verbose $server.HostName
        $priority++
        if ($server.HostName -eq $thisServer){
            $isIcems++
            write-verbose "ICEMS server $priority"
            break
         }
    }

	if ($isIcems -eq 1){
		# Configuration
        $targetConfigNode = $targetConfigXml.SelectSingleNode("//SystemName")
        $targetConfigNode.InnerText = "Vis" + $environmentName
        
        $targetConfigNode = $targetConfigXml.SelectSingleNode("//Hosts")
        $vasServers = $sourceConfigXml.SelectNodes("//VAS")

        $thisNode = $vasServers | Where-Object {$_.HostName -eq $thisServer}
        $h = $targetConfigXml.CreateElement("string")
        $h.InnerText = $thisNode.IpAddress
        $targetConfigNode.AppendChild($h)

        foreach ($server in $vasServers){
            if ($server.HostName -ne $thisServer){
                $h = $targetConfigXml.CreateElement("string")
                $h.InnerText = $server.IpAddress
                $targetConfigNode.AppendChild($h)
            }
        }

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//Priority")
        #$targetConfigNode.InnerText.value = $priority
        $targetConfigNode.InnerText = $priority
        Write-Verbose "targetConfigNode.InnerText:"
        write-verbose $targetConfigNode.InnerText
		
        $targetConfigNode = $targetConfigXml.SelectSingleNode("//IncidentCreationStatus")
        $targetConfigNode.InnerText = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ICEMS.IncCreateStatus

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//DefaultRecipient")
        $targetConfigNode.InnerText = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ICEMS.DefaultRecipient

		# Save Changes
		$targetConfigXml.Save($targetMessengerConfig)
        $targetConfigXml.Save($targetProcessorConfig)
	}
}

Function Update-IcemsRemoteAgency{
	<#
    .SYNOPSIS
    Creates ICEMS Remote Agency xml file from the environment map and versioned config file
    .DESCRIPTION
    Creates ICEMS Remote Agency xml file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
	.PARAMETER agency
	The appropriate agency being configured
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",

		[Parameter(Mandatory=$true)]
		[string]$agency,
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "RemoteAgencies.xml" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ICEMS6Messenger\Configuration\RemoteAgencies"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetMessengerConfig = $tempPath + "\$agency.xml"
    }else
    {
	    $targetMessengerConfig = "d:\Vision\Vis" + $environmentName + "\Services\ICEMS6Messenger\Configuration\RemoteAgencies\" + $agency + ".xml"
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Services\ICEMS6Processor\Configuration\RemoteAgencies"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetProcessorConfig = $tempPath + "\$agency.xml"
    }else
    {
        $targetProcessorConfig = "d:\Vision\Vis" + $environmentName + "\Services\ICEMS6Processor\Configuration\RemoteAgencies\" + $agency + ".xml"
    }
    
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    $icemsServers = $sourceConfigXml.SelectNodes("//ICEMS/ICEMSServers/Server")
    $isIcems = 0
    foreach ($server in $icemsServers.HostName){
        if ($server -eq $thisServer){ $isIcems++ }
    }

	if ($isIcems -eq 1){
		# Configuration
        $sourceConfigNode = $sourceConfigXml.SelectSingleNode("//Agency[@Name='" + $agency + "']")

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//AgencyName")
        $targetConfigNode.InnerText = $sourceConfigNode.Name

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//AgencyFullName")
        $targetConfigNode.InnerText = $sourceConfigNode.AgencyFullName

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//NodeIdentifier")
        $targetConfigNode.InnerText = $sourceConfigNode.NodeIdentifier

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//UseIPAddress")
        $targetConfigNode.InnerText = $sourceConfigNode.UseIPAddress

        $targetConfigNode = $targetConfigXml.SelectSingleNode("//PrimaryIPAddress")
        $targetConfigNode.InnerText = $sourceConfigNode.PrimaryIPAddress
        
        $targetConfigNode = $targetConfigXml.SelectSingleNode("//PrimaryTCPPort")
        $targetConfigNode.InnerText = $sourceConfigNode.PrimaryTCPPort

		if ($sourceConfigNode.SecondaryIPAddress)
		{
			$targetConfigNode = $targetConfigXml.SelectSingleNode("//SecondaryIPAddress")
			$targetConfigNode.InnerText = $sourceConfigNode.SecondaryIPAddress

			$targetConfigNode = $targetConfigXml.SelectSingleNode("//SecondaryTCPPort")
			$targetConfigNode.InnerText = $sourceConfigNode.SecondaryTCPPort
		}else
        {
            $remoteAgencyConfig = $targetConfigXml.SelectSingleNode("//RemoteAgencyConfiguration")
            
            $targetConfigNode = $targetConfigXml.SelectSingleNode("//SecondaryIPAddress")
            $remoteAgencyConfig.RemoveChild($targetConfigNode)

            $targetConfigNode = $targetConfigXml.SelectSingleNode("//SecondaryTCPPort")
            $remoteAgencyConfig.RemoveChild($targetConfigNode)
        }

		# Save Changes
		$targetConfigXml.Save($targetMessengerConfig)
        $targetConfigXml.Save($targetProcessorConfig)
	}
}

## Utilities

Function Update-CniTester{
	<#
    .SYNOPSIS
    Creates CNITester.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates CNITester.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "CNITester.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Utilities\CNITester"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\CNITester.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Utilities\CNITester\CNITester.exe.config"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# Add Master VAS Hostname
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='CADServerHostIPList_Data']/value/ArrayOfString")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	$h = $targetConfigXml.CreateElement("string")
	$h.InnerText = $vasNodes[0].HostName
	$targetConfigNode.AppendChild($h)

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-AplParserMonitor{
	<#
    .SYNOPSIS
    Creates Fortek.Applications.APLParserMonitor.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates Fortek.Applications.APLParserMonitor.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Fortek.Applications.APLParserMonitor.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Utilities\APLParserMonitor"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Fortek.Applications.APLParserMonitor.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Utilities\APLParserMonitor\Fortek.Applications.APLParserMonitor.exe.config"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-CccmViewer{
	<#
    .SYNOPSIS
    Creates Fortek.Applications.CCCMViewer.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates Fortek.Applications.CCCMViewer.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Fortek.Applications.CCCMViewer.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Utilities\CCCMViewer"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Fortek.Applications.CCCMViewer.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Utilities\CCCMViewer\Fortek.Applications.CCCMViewer.exe.config"
    }

	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-CccmSimulator{
	<#
    .SYNOPSIS
    Creates Fortek.Simulators.CCCM.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates Fortek.Simulators.CCCM.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "Fortek.Simulators.CCCM.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + "\Utilities\CCCMSimulator"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\Fortek.Simulators.CCCM.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + "\Utilities\CCCMSimulator\Fortek.Simulators.CCCM.exe.config"
    }
    
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# Configuration

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='SystemName']/value")
    $targetConfigNode.InnerText = "Vis" + $environmentName

	$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='Hosts']/value/ArrayOfString")

    $VCSNodes = $sourceConfigXml.SelectNodes("//VCS")
    $thisServerIndex = $VCSNodes.HostName.IndexOf($thisServer)

    # Add bottom half of VCS servers starting with itself
    for ($i = $thisServerIndex;$i -lt $VCSNodes.Count; $i++)
    {
        $h = $targetConfigXml.CreateElement("string")
        $h.InnerText =  $VCSNodes.HostName[$i] + ":Vis" + $environmentName + ":0:1"
	    $targetConfigNode.AppendChild($h)
    }

    # Add top half of VCS servers
    for ($i = 0;$i -lt $thisServerIndex; $i++)
    {
        $h = $targetConfigXml.CreateElement("string")
        $h.InnerText =  $VCSNodes.HostName[$i] + ":Vis" + $environmentName + ":0:1"
	    $targetConfigNode.AppendChild($h)
    }

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-FortekServiceMonitor{
	<#
    .SYNOPSIS
    Creates FortekServiceMonitor.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates FortekServiceMonitor.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "FortekServiceMonitor.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

	# FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName +$siteCodeString+ "\Utilities\FortekCoreServiceMonitor"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\FortekServiceMonitor.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName +$siteCodeString+ "\Utilities\FortekCoreServiceMonitor\FortekServiceMonitor.exe.config"
    }
	
	# Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

	# Configuration
				
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='VisionServers']/value/ArrayOfString")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	foreach ($node in $vasNodes){
		$h = $targetConfigXml.CreateElement("string")
		$h.InnerText = $node.IpAddress + "(50002)"
		$targetConfigNode.AppendChild($h)
	}
	$ccmNodes = $sourceConfigXml.SelectNodes("//CCM")
	foreach ($node in $ccmNodes){
		if ($node.NCPrefix){
			$h = $targetConfigXml.CreateElement("string")
			$h.InnerText = $node.IpAddress + "(50002)"
			$targetConfigNode.AppendChild($h)
		}
	}

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-CoreVAS-FortekServiceMonitor{
	<#
    .SYNOPSIS
    Creates FortekServiceMonitor.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates FortekServiceMonitor.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "FortekServiceMonitor.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + $siteCodeString+"\Utilities\CoreVAS-FortekCoreServiceMonitor"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\FortekServiceMonitor.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName +$siteCodeString+ "\Utilities\CoreVAS-FortekCoreServiceMonitor\FortekServiceMonitor.exe.config"
    }

	# Configuration
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='VisionServers']/value/ArrayOfString")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	foreach ($node in $vasNodes){
		$h = $targetConfigXml.CreateElement("string")
		$h.InnerText = $node.IpAddress + "(50002)"
		$targetConfigNode.AppendChild($h)
	}
	
	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-FBVAS-FortekServiceMonitor{
	<#
    .SYNOPSIS
    Creates FortekServiceMonitor.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates FortekServiceMonitor.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "FortekServiceMonitor.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + $siteCodeString+"\Utilities\FBVAS-FortekCoreServiceMonitor"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\FortekServiceMonitor.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName +$siteCodeString+ "\Utilities\FBVAS-FortekCoreServiceMonitor\FortekServiceMonitor.exe.config"
    }

	# Configuration
	$targetConfigNode = $targetConfigXml.SelectNodes("//setting[@name='VisionServers']/value/ArrayOfString")
	$ccmNodes = $sourceConfigXml.SelectNodes("//CCM")
	foreach ($node in $ccmNodes){
		if ($node.NCPrefix){
			$h = $targetConfigXml.CreateElement("string")
			$h.InnerText = $node.IpAddress + "(50002)"
			$targetConfigNode.AppendChild($h)
		}
	}

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-PacketManagerViewer{
	<#
    .SYNOPSIS
    Creates PacketManagerViewer.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates PacketManagerViewer.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "PacketManagerViewer.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + $siteCodeString+"\Utilities\PacketManagerViewer"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\PacketManagerViewer.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + $siteCodeString+"\Utilities\PacketManagerViewer\PacketManagerViewer.exe.config"
    
    }

	# Configuration
	$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='SyncHosts']/value/ArrayOfHost")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	
	foreach ($node in $vasNodes){
		$h = $targetConfigXml.CreateElement("Host")
		$targetConfigNode.AppendChild($h)

		$i = $h.AppendChild($targetConfigXml.CreateElement("Address"))
		$i.InnerText = $node.HostName
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("PacketManagerDatabaseName"))
		$i.InnerText = "Vis" + $environmentName + "_VisionPacketManager"
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("VisionServerDatabaseName"))
		$i.InnerText = "Vis" + $environmentName + "_VisionServer"
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("ConnectionString"))
		$i.InnerText = "Server=" + $node.HostName + "\SqlExpress,2001;Database={0};Trusted_Connection=Yes;MultipleActiveResultSets=true;"
		$h.AppendChild($i)
	}
	$ccmNodes = $sourceConfigXml.SelectNodes("//CCM")
	foreach ($node in $ccmNodes){
		if ($node.NCPrefix){
			$h = $targetConfigXml.CreateElement("Host")
			$targetConfigNode.AppendChild($h)

			$i = $h.AppendChild($targetConfigXml.CreateElement("Address"))
			$i.InnerText = $node.HostName
			$h.AppendChild($i)

			$i = $h.AppendChild($targetConfigXml.CreateElement("PacketManagerDatabaseName"))
			$i.InnerText = "Vis" + $environmentName + "_" + $node.SiteCode + "_VisionPacketManager"
			$h.AppendChild($i)

			$i = $h.AppendChild($targetConfigXml.CreateElement("VisionServerDatabaseName"))
			$i.InnerText = "Vis" + $environmentName + "_" + $node.SiteCode + "_VisionServer"
			$h.AppendChild($i)

			$i = $h.AppendChild($targetConfigXml.CreateElement("ConnectionString"))
			$i.InnerText = "Server=" + $node.HostName + "\SqlExpress,2001;Database={0};Trusted_Connection=Yes;MultipleActiveResultSets=true;"
			$h.AppendChild($i)
		}
	}

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-CC-PacketManagerViewer{
	<#
    .SYNOPSIS
    Creates PacketManagerViewer.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates PacketManagerViewer.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "CC-PacketManagerViewer.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName + $siteCodeString+"\Utilities\CC-PacketManagerViewer"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\PacketManagerViewer.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName + $siteCodeString+"\Utilities\CC-PacketManagerViewer\PacketManagerViewer.exe.config"
    
    }

	# Configuration
	$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='SyncHosts']/value/ArrayOfHost")
	$vasNodes = $sourceConfigXml.SelectNodes("//VAS")
	
	foreach ($node in $vasNodes){
		$h = $targetConfigXml.CreateElement("Host")
		$targetConfigNode.AppendChild($h)

		$i = $h.AppendChild($targetConfigXml.CreateElement("Address"))
		$i.InnerText = $node.HostName
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("PacketManagerDatabaseName"))
		$i.InnerText = "Vis" + $environmentName + "_VisionPacketManager"
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("VisionServerDatabaseName"))
		$i.InnerText = "Vis" + $environmentName + "_VisionServer"
		$h.AppendChild($i)

		$i = $h.AppendChild($targetConfigXml.CreateElement("ConnectionString"))
		$i.InnerText = "Server=" + $node.HostName + "\SqlExpress,2001;Database={0};Trusted_Connection=Yes;MultipleActiveResultSets=true;"
		$h.AppendChild($i)
	}
	$ccmNodes = $sourceConfigXml.SelectNodes("//CCM")
	foreach ($node in $ccmNodes){
		if ($node.NCPrefix){
			$h = $targetConfigXml.CreateElement("Host")
			$targetConfigNode.AppendChild($h)

			$i = $h.AppendChild($targetConfigXml.CreateElement("Address"))
			$i.InnerText = $node.HostName
			$h.AppendChild($i)

			$i = $h.AppendChild($targetConfigXml.CreateElement("PacketManagerDatabaseName"))
			$i.InnerText = "Vis" + $environmentName + "_" + $node.SiteCode + "_VisionPacketManager"
			$h.AppendChild($i)

			$i = $h.AppendChild($targetConfigXml.CreateElement("VisionServerDatabaseName"))
			$i.InnerText = "Vis" + $environmentName + "_" + $node.SiteCode + "_VisionServer"
			$h.AppendChild($i)

			$i = $h.AppendChild($targetConfigXml.CreateElement("ConnectionString"))
			$i.InnerText = "Server=" + $node.HostName + "\SqlExpress,2001;Database={0};Trusted_Connection=Yes;MultipleActiveResultSets=true;"
			$h.AppendChild($i)
		}
	}

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Function Update-VscmMonitor{
	<#
    .SYNOPSIS
    Creates VSCM Monitor.exe.config file from the environment map and versioned config file
    .DESCRIPTION
    Creates VSCM Monitor.exe.config file from the environment map and versioned config file
	.LINK
	http://tfs.sdg.dvds.devpol:8080/tfs/psba/BuildAndDeploy/_git/Deployment.QCAD?path=%2F&version=GBmaster
	.PARAMETER version
	The appropriate branch of the config files in TFS Git. Defaults to 'Master'
    #>

	[cmdletbinding()]
	param(
        [string]$thisServer = $env:COMPUTERNAME,
        [string]$environmentName = $Env:EnvName,
        [string]$siteCode = $Env:SiteCode,
		[string]$version = "master",
        [switch]$check
		)

	[xml]$sourceConfigXml = (Get-EnvironmentConfig($environmentName)).objects.object.'#text'
	[xml]$targetConfigXml = (Get-ServiceConfig -configName "VSCM Monitor.exe.config" -version $version).objects.object.'#text'

	$thisServerType = Get-ServerType -environmentMap $sourceConfigXml -thisServer $thisServer

    # Environment Name
	$environmentName = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.EnvName
	$adDomain = $sourceConfigXml.'QCAD.Variable.Inputs'.Environment.ADDomain

    # FB VAS
    $siteCodeString = ""
    if($thisServerType.Name -eq "CCM"){
        $siteCodeString = "_" + $siteCode
    }

    if ($check)
    {
        $tempPath = "d:\temp\config\$version\$environmentName\$thisServer\Vision\Vis" + $environmentName +$siteCodeString+ "\Utilities\VSCMMonitor"

        if (!(Test-Path $tempPath))
        {
            mkdir -Path $tempPath
        }

        $targetConfig = $tempPath + "\VSCM Monitor.exe.config"
    }else
    {
	    $targetConfig = "d:\Vision\Vis" + $environmentName +$siteCodeString+ "\Utilities\VSCMMonitor\VSCM Monitor.exe.config"
    }

	# Configuration
	$targetConfigNode = $targetConfigXml.SelectSingleNode("//setting[@name='System']/value")
	$targetConfigNode.InnerText = "Vis" + $environmentName

	# Save Changes
	$targetConfigXml.Save($targetConfig)
}

Export-ModuleMember -Function '*'