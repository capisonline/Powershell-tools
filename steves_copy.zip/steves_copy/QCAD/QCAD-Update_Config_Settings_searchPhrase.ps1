﻿<# 
.SYNOPSIS
This script reads a list of servers from a specified text file and recursively searches for configuration files 
(e.g., *.config, *.settings) in a specified folder on each server. It searches for a specific incorrect setting 
within these files and replaces it with the correct setting. The script creates a backup of each modified file 
with a timestamp in the filename and logs the details of the updated files into a CSV file.

.DESCRIPTION
- Reads the list of servers from a text file.
- Connects to each server and recursively searches for configuration files in a specified folder.
- Creates a backup of each file with a timestamp before making any changes.
- Replaces the incorrect setting with the correct setting.
- Logs the details of the updated files (server, file path, backup file path, and timestamp) into a CSV file.

.PARAMETER serversListPath
The path to the text file containing the list of servers.

.PARAMETER folderToSearch
The folder path on each server to search for configuration files.

.PARAMETER searchPhrase
The incorrect setting phrase to search for in the configuration files.

.PARAMETER replacementText
The correct setting phrase to replace the incorrect setting.

.PARAMETER fileExtensions
An array of file patterns to search for (e.g., *.config, *.settings).

.PARAMETER csvFilePath
The path to the CSV file where the details of the updated files will be saved.

Run this within the ISE for ease of reading / updating
Rogers.Steven(CC) <Rogers.Steven2@police.qld.gov.au>
#>

# Define the path to the servers list and the folder to search
$serversListPath = "C:\temp\QCAD\TP\Issues\Server_list.txt"
$folderToSearch = "D$\Vision" # Adjust this to match the shared folder path on the server

# Define the phrase to search for and the replacement text
$searchPhrase = "TPcad-vwsnlb.PRDS.QLDPOL"
$replacementText = "TPcad-vws01.PRDS.QLDPOL"

# Define the file extensions to search for
$fileExtensions = @("*.config", "*.settings") # Add more filename patterns if needed

# Get the current timestamp
$timestamp = Get-Date -Format "yyyyMMddHHmmss"

# Name the CSV file to save the updated files information
$csvFilePath = "C:\temp\QCAD\TP\Issues\UpdatedFiles_$timestamp.csv"

# Create an array to store the updated files information
$updatedFiles = @()

# Function to update the configuration files on a server
function Update-ConfigFiles {
    param (
        [string]$server,
        [string]$folder,
        [string]$searchPhrase,
        [string]$replacementText,
        [string]$timestamp,
        [string[]]$fileExtensions
    )

    foreach ($fileExtension in $fileExtensions) {
        # Recursively get all files with the specified extension in the folder
        $files = Get-ChildItem -Path "\\$server\$folder" -Filter $fileExtension -Recurse -ErrorAction SilentlyContinue

        foreach ($file in $files) {
            try {
                # Read the content of the file
                $content = Get-Content -Path $file.FullName -Raw

                # Check if the file contains the search phrase
                if ($content -match $searchPhrase) {
                    # Create a backup of the file with a timestamp
                    $backupFileName = "$($file.FullName).$timestamp.backup"
                    Copy-Item -Path $file.FullName -Destination $backupFileName

                    # Replace the incorrect setting with the correct one
                    $updatedContent = $content -replace $searchPhrase, $replacementText

                    # Write the updated content back to the file
                    Set-Content -Path $file.FullName -Value $updatedContent

                    Write-Output "Updated file: $($file.FullName) and created backup: $backupFileName"

                    # Add the updated file information to the array
                    $updatedFiles += [PSCustomObject]@{
                        Server = $server
                        FilePath = $file.FullName
                        BackupFilePath = $backupFileName
                        Timestamp = $timestamp
                    }
                }
            } catch {
                Write-Output "Error processing file: $($file.FullName) on server: $server. Error: $_"
            }
        }
    }
}

# Read the list of servers
$servers = Get-Content -Path $serversListPath

foreach ($server in $servers) {
    Write-Output "Processing server: $server"
    Update-ConfigFiles -server $server -folder $folderToSearch -searchPhrase $searchPhrase -replacementText $replacementText -timestamp $timestamp -fileExtensions $fileExtensions
}

# Save the updated files information to the CSV file
$updatedFiles | Export-Csv -Path $csvFilePath -NoTypeInformation

Write-Output "Updated files information saved to: $csvFilePath"
