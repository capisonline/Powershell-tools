﻿<#
    PowerShell script to copy a local script to each server listed in a text file and create a scheduled task
    Script copied to server and being ran requires repeating logic
#>
$taskName = "QCAD_Telemetry_Capture"
$taskDescription = "Runs a discovery script every 4 minutes."
$localScriptPath = "C:\temp\scripts\QCAD\PR_Discovery\Collect-QCAD-Telemetry-Enhanced.ps1"
$remoteScriptDirectory = "C$\Temp"  # Directory on the remote server
$remoteScriptPath = "\\$server\$remoteScriptDirectory\Collect-QCAD-Telemetry-Enhanced.ps1" # Full path for script execution
$serversList = "C:\temp\QCAD\PR\Discovery\telemetry_capture\PR_Telemetry_ServerList.txt"
# PowerShell script to execute a script once, start immediately upon creation, and stop after 5 days 


# Read the list of servers
$servers = Get-Content -Path $serversList

# Loop through each server and set up the task
foreach ($server in $servers) {
    # Construct the UNC path for copying the script
    $copyToPath = "\\$server\$remoteScriptDirectory\Collect-QCAD-Telemetry-Enhanced.ps1" # Correctly setting the copy destination

    # Try to copy the script to the remote server, handle potential errors
    try {
        Copy-Item -Path $localScriptPath -Destination $copyToPath -Force -ErrorAction Stop
    } catch {
        Write-Error "Failed to copy to ${$server} $_"
        continue # Skip further commands and proceed with the next server
    }

    # Define the action to run the PowerShell script on the remote server
    $action = New-ScheduledTaskAction -Execute "Powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$copyToPath`""

    # Get the current time and calculate the end time X days from now
    $startTime = Get-Date
    $endTime = $startTime.AddDays(2)

    # Define the trigger to run immediately and end after X days
    # Script being run requires repeating logic if not defined here:
    $trigger = New-ScheduledTaskTrigger -Once -At $startTime
    $trigger.EndBoundary = $endTime.ToString("yyyy-MM-dd'T'HH:mm:ss")

    # Define the principal under which the task should run (System account)
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount

    # Use Invoke-Command to register and start the task on the remote server
    $scriptBlock = {
        Param ($taskName, $taskDescription, $action, $trigger, $principal)
        $task = Register-ScheduledTask -TaskName $taskName -Description $taskDescription -Action $action -Trigger $trigger -Principal $principal
        Start-ScheduledTask -TaskName $taskName
    }

    try {
        Invoke-Command -ComputerName $server -ScriptBlock $scriptBlock -ArgumentList $taskName, $taskDescription, $action, $trigger, $principal -ErrorAction Stop
        Write-Output "Scheduled Task '$taskName' created and started successfully on $server, set to stop after 2 days."
    } catch {
        Write-Error "Failed to create or start task on ${$server} $_"
    }
}
