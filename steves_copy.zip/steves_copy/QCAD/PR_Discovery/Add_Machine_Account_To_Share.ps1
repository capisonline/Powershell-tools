﻿# === CONFIG ===
$folderPath = "D:\PR_Discovery\captures"
$domain = "prds.qldpol"  
$servers = @(
'QPS-AAS-PR-02',
'QPS-AAS-PR-01',
'QPS-APL-PR-01',
'QPS-APL-PR-02',
'QPS-GDP-PR-02',
'QPS-GGS-PR-01',
'QPS-GGS-PR-02',
'QPS-VAS-PR-05',
'QPS-VAS-PR-07',
'QPS-VAS-PR-06',
'QPS-VAS-PR-08',
'QPS-VCS-PR-01',
'QPS-VCS-PR-06',
'QPS-VCS-PR-02',
'QPS-VCS-PR-07',
'QPS-VCS-PR-03',
'QPS-VCS-PR-08',
'QPS-VCS-PR-04',
'QPS-VCS-PR-09',
'QPS-VCS-PR-05',
'QPS-VCS-PR-10',
'QPS-VIM-PR-05',
'QPS-VIM-PR-07',
'QPS-VIM-PR-06',
'QPS-VIM-PR-08',
'QPS-VMG-PR-01',
'QPS-VMG-PR-02',
'QPS-VWS-PR-09',
'QPS-VWS-PR-13',
'QPS-VWS-PR-10',
'QPS-VWS-PR-14',
'QPS-VWS-PR-11',
'QPS-VWS-PR-15',
'QPS-VWS-PR-12',
'QPS-VWS-PR-16',
'PHQ-CCM-PR-04',
'PHQ-CCM-PR-05',
'BNL-CCM-PR-03',
'BNL-CCM-PR-04',
'CNS-CCM-PR-03',
'CNS-CCM-PR-04',
'RKH-CCM-PR-03',
'RKH-CCM-PR-04',
'QPS-ORA-PR-09',
'QPS-ORA-PR-10',
'MYD-CCM-PR-03',
'MYD-CCM-PR-04',
'QPS-ORA-PR-11',
'QPS-ORA-PR-12',
'TNV-CCM-PR-03',
'TNV-CCM-PR-04',
'TWB-CCM-PR-03',
'TWB-CCM-PR-04'

)

# Ensure folder exists
if (-not (Test-Path $folderPath)) {
    New-Item -Path $folderPath -ItemType Directory -Force
}

# Convert to FileSecurity object
$acl = Get-Acl $folderPath

foreach ($server in $servers) {
    $machineAccount = "$domain\$server`$"
    Write-Host "Adding permissions for $machineAccount..."

    $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
        $machineAccount, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow"
    )

    $acl.SetAccessRule($accessRule)
}

# Apply permissions
Set-Acl -Path $folderPath -AclObject $acl
Write-Host "NTFS permissions applied."

