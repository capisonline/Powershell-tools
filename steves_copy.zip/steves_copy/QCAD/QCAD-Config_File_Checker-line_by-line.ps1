﻿# Define paths for input and output files 
$ServerMappingCsv = "C:\temp\QCAD\PA\QA\Config_Matching\input_results.csv"
$OldConfigsRoot = "C:\temp\QCAD\PA\QA\Config_Matching\Old_Configs"
$NewConfigsRoot = "C:\temp\QCAD\PA\QA\Config_Matching\New_Configs"
$OutputDirectory = "C:\temp\QCAD\PA\QA\Config_Matching"

# Function to compare files line by line and generate differences
function Compare-Files {
    param (
        [string]$OldFilePath,
        [string]$NewFilePath
    )

    $oldFileLines = Get-Content -Path $OldFilePath
    $newFileLines = Get-Content -Path $NewFilePath

    $differences = @()
    $maxLines = [Math]::Max($oldFileLines.Count, $newFileLines.Count)

    for ($i = 0; $i -lt $maxLines; $i++) {
        $oldLine = if ($i -lt $oldFileLines.Count) { $oldFileLines[$i] } else { "" }
        $newLine = if ($i -lt $newFileLines.Count) { $newFileLines[$i] } else { "" }

        if ($oldLine -ne $newLine) {
            $differences += [PSCustomObject]@{
                LineNumber = $i + 1
                OldLine = $oldLine
                NewLine = $newLine
            }
        }
    }

    return $differences
}

# Main processing
Import-Csv -Path $ServerMappingCsv | ForEach-Object {
    $oldServer = $_.OldServer
    $newServer = $_.NewServer

    $oldConfigFile = Join-Path -Path $OldConfigsRoot -ChildPath "$($oldServer)_app.config"
    $newConfigFile = Join-Path -Path $NewConfigsRoot -ChildPath "$($newServer)_app.config"

    if ((Test-Path -Path $oldConfigFile) -and (Test-Path -Path $newConfigFile)) {
        try {
            $differences = Compare-Files -OldFilePath $oldConfigFile -NewFilePath $newConfigFile

            if ($differences.Count -gt 0) {
                $outputCsvPath = Join-Path -Path $OutputDirectory -ChildPath "$($oldServer)_$($newServer)_differences.csv"
                $differences | Export-Csv -Path $outputCsvPath -NoTypeInformation
            }
        } catch {
            Write-Host "Error processing $oldConfigFile and ${newConfigFile}: $($_.Exception.Message)"
        }
    } else {
        Write-Host "Config files not found for $oldServer or $newServer"
    }
}

Write-Host "Comparison complete. Check $OutputDirectory for results."
