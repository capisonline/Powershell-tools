﻿##AH:UseTextMode


{
    Log-Debug Starting QCAD services;

    # Start VAS Master services
    foreach $server in @ServersInRoleAndEnvironment(QCAD VAS Master, $EnvironmentName)
    {
        for server $server
        {
            Log-Debug $server;

            try
            {
                if $DC_Outage == $DC || $DC_Outage == Both
                {
                    Log-Debug $server at $DC;

                    Start-Service Vis${EnvironmentName}_VSCM;

                    Start-Service Vis${EnvironmentName}_NumberCruncher;

                    Start-Service Vis${EnvironmentName}_DataService_Svr;

                    Start-Service Vis${EnvironmentName}_FortekCoreService;

                    Start-Service Vis${EnvironmentName}_IntegrityChecker;

                    if $ActiveAML != 0
                    {
                        Start-Service Vis${EnvironmentName}_CNI;
                    }

                    Start-Service Vis${EnvironmentName}_EventProcessor;

                    Start-Service Vis${EnvironmentName}_ExternalClientGateway;

                    Start-Service Vis${EnvironmentName}_MessageBroker;

                    #Start-Service Vis${EnvironmentName}_SMSGateway;

                    Start-Service Vis${EnvironmentName}_VCS;

                    Start-Service Vis${EnvironmentName}_VDW;

                    Start-Service Vis${EnvironmentName}_Arbitrator;

                    if $ICEMS != 0
                    {
                        Start-Service RabbitMQ;

                        Start-Service Vis${EnvironmentName}_ICEMS_Messenger;

                        Start-Service Vis${EnvironmentName}_ICEMS_Processor;
                    }
                }
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Issue starting services,
                    Description: There is an issue staring services on $server. Please investigate and rectify.,
                    AssignedTo: $ExecutionUser
                );
            }
        }
    }

    # Start VAS services
    foreach $server in @ServersInRoleAndEnvironment(QCAD VAS, $EnvironmentName)
    {
        for server $server
        {
            try
            {
                Log-Debug $server;

                if $DC_Outage == $DC || $DC_Outage == Both
                {
                    Log-Debug $server at $DC;

                    Start-Service Vis${EnvironmentName}_VSCM;

                    Start-Service Vis${EnvironmentName}_NumberCruncher;

                    Start-Service Vis${EnvironmentName}_DataService_Svr;

                    Start-Service Vis${EnvironmentName}_FortekCoreService;

                    Start-Service Vis${EnvironmentName}_IntegrityChecker;

                    if $ActiveAML != 0
                    {
                        Start-Service Vis${EnvironmentName}_CNI;
                    }

                    Start-Service Vis${EnvironmentName}_EventProcessor;

                    Start-Service Vis${EnvironmentName}_ExternalClientGateway;

                    Start-Service Vis${EnvironmentName}_MessageBroker;

                    #Start-Service Vis${EnvironmentName}_SMSGateway;

                    Start-Service Vis${EnvironmentName}_VCS;

                    Start-Service Vis${EnvironmentName}_VDW;

                    Start-Service Vis${EnvironmentName}_Arbitrator;

                    if $ICEMS != 0
                    {
                        Start-Service RabbitMQ;

                        Start-Service Vis${EnvironmentName}_ICEMS_Messenger;

                        Start-Service Vis${EnvironmentName}_ICEMS_Processor;
                    }
                }
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Issue starting services,
                    Description: There is an issue staring services on $server. Please investigate and rectify.,
                    AssignedTo: $ExecutionUser
                );
            }
        }
    }

    # Start FB VAS services
    if $FB_Mode == 0
    {
        foreach $server in @ServersInRoleAndEnvironment(QCAD FB VAS, $EnvironmentName)
        {
            for server $server
            {
                try
                {
                    Log-Debug $server;

                    Start-Service Vis${EnvironmentName}_VCCM;

                    Start-Service VIS${EnvironmentName}_${SiteCode}_VSCM;

                    Start-Service VIS${EnvironmentName}_${SiteCode}_NumberCruncher;

                    Start-Service VIS${EnvironmentName}_${SiteCode}_DataService_Svr;

                    Start-Service VIS${EnvironmentName}_${SiteCode}_IntegrityChecker;

                    Start-Service VIS${EnvironmentName}_${SiteCode}_FortekCoreService;
                }
                catch
                {
                    Perform-ManualOperation
                    (
                        Name: Issue starting services,
                        Description: There is an issue staring services on $server. Please investigate and rectify.,
                        AssignedTo: $ExecutionUser
                    );
                }
            }
        }
    }

    # Start all VWS services
    foreach $server in @ServersInRoleAndEnvironment(QCAD VWS, $EnvironmentName)
    {
        for server $server
        {
            try
            {
                IIS::Start-AppPool DefaultAppPool;

                IIS::Start-AppPool Vis${EnvironmentName}_VWS;

                IIS::Start-AppPool Vis${EnvironmentName}_VWS_Admin;

                IIS::Start-AppPool Vis${EnvironmentName}_VWS_Server;

                IIS::Start-AppPool VISIONWebService;
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Unable to Start App Pools,
                    Description: Start App Pools manually,
                    AssignedTo: $ExecutionUser
                );
            }

            try
            {
                IIS::Start-Site Default Web Site;
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Unable to Start Default Web Site,
                    Description: Start Default Web Site manually,
                    AssignedTo: $ExecutionUser
                );
            }

            try
            {
                PSCall QCAD::Confirm-IIS;
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Website Serving Error,
                    Description: Issues serving web pages on $server. Please investigate.,
                    AssignedTo: $ExecutionUser
                );
            }
        }
    }

    # Start all VCS services
    foreach $server in @ServersInRoleAndEnvironment(QCAD VCS, $EnvironmentName)
    {
        for server $server
        {
            try
            {
                Log-Debug $server;

                if $DC_Outage == $DC || $DC_Outage == Both
                {
                    Log-Debug $server at $DC;

                    Start-Service Vis${EnvironmentName}_CCCM;

                    Start-Service Vis${EnvironmentName}_VCS;
                }
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Issue starting services,
                    Description: There is an issue staring services on $server. Please investigate and rectify.,
                    AssignedTo: $ExecutionUser
                );
            }

            try
            {
                IIS::Start-AppPool DefaultAppPool;

                IIS::Start-AppPool Vis${EnvironmentName}_VWS;

                IIS::Start-AppPool Vis${EnvironmentName}_VWS_Admin;

                IIS::Start-AppPool Vis${EnvironmentName}_VWS_Server;

                IIS::Start-AppPool VISIONWebService;

                IIS::Start-AppPool MapXtremeAppPool;
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Unable to Start App Pools,
                    Description: Start App Pools manually,
                    AssignedTo: $ExecutionUser
                );
            }

            try
            {
                IIS::Start-Site Default Web Site;
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Unable to Start Default Web Site,
                    Description: Start Default Web Site manually,
                    AssignedTo: $ExecutionUser
                );
            }

            try
            {
                PSCall QCAD::Confirm-IIS;
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Website Serving Error,
                    Description: Issues serving web pages on $server. Please investigate.,
                    AssignedTo: $ExecutionUser
                );
            }
        }
    }

    # Start all CCM services if not in FB mode
    if $FB_Mode == 0
    {
        foreach $server in @ServersInRoleAndEnvironment(QCAD CCM, $EnvironmentName)
        {
            for server $server
            {
                try
                {
                    Log-Debug $server;

                    Start-Service Vis${EnvironmentName}_VCCM;
                }
                catch
                {
                    Perform-ManualOperation
                    (
                        Name: Issue starting services,
                        Description: There is an issue staring services on $server. Please investigate and rectify.,
                        AssignedTo: $ExecutionUser
                    );
                }
            }
        }
    }

    # Start all APL services
    foreach $server in @ServersInRoleAndEnvironment(QCAD APL, $EnvironmentName)
    {
        for server $server
        {
            try
            {
                Log-Debug $server;

                if $DC_Outage == $DC || $DC_Outage == Both
                {
                    Log-Debug $server at $DC;

                    if $PrimaryAPL == 1
                    {
                        Start-Service Vis${EnvironmentName}_APLParser;

                        Start-Service Vis${EnvironmentName}_AVLUpdater;
                    }
                }
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Issue starting services,
                    Description: There is an issue staring services on $server. Please investigate and rectify.,
                    AssignedTo: $ExecutionUser
                );
            }
        }
    }

    # Start all VIM services
    foreach $server in @ServersInRoleAndEnvironment(QCAD VIM, $EnvironmentName)
    {
        for server $server
        {
            try
            {
                Log-Debug $server;

                if $DC_Outage == $DC || $DC_Outage == Both
                {
                    Log-Debug $server at $DC;

                    Start-Service Vis${EnvironmentName}_ARL;

                    Start-Service Vis${EnvironmentName}_Audit;

                    Start-Service Vis${EnvironmentName}_Occurrence;

                    Start-service Vis${EnvironmentName}_OfficerDetail;

                    Start-service Vis${EnvironmentName}_PoliceLinkVIM;
                }
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Issue starting services,
                    Description: There is an issue staring services on $server. Please investigate and rectify.,
                    AssignedTo: $ExecutionUser
                );
            }

            try
            {
                IIS::Start-AppPool Vis${EnvironmentName}_PoliceLinkWeb_AppPool;
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Issue stopping app pool,
                    Description: There is an issue stopping app pool on $server. Please investigate and rectify.,
                    AssignedTo: $ExecutionUser
                );
            }
        }
    }

    # Start all VMG services
    foreach $server in @ServersInRoleAndEnvironment(QCAD VMG, $EnvironmentName)
    {
        for server $server
        {
            try
            {
                Log-Debug $server;

                if $DC_Outage == $DC || $DC_Outage == Both
                {
                    Log-Debug $server at $DC;

                    Start-Service Vis${EnvironmentName}_ExternalClientGateway;
                }
            }
            catch
            {
                Perform-ManualOperation
                (
                    Name: Issue starting services,
                    Description: There is an issue staring services on $server. Please investigate and rectify.,
                    AssignedTo: $ExecutionUser
                );
            }
        }
    }
}
