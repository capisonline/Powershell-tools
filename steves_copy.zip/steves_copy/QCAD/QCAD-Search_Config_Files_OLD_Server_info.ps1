﻿<# 
.SYNOPSIS
This script reads a list of servers from a specified text file and searches for specific content within .config, .settings, and .ini files in specified folders on each server. 
It records the filenames if the search content is found.

.DESCRIPTION
- Reads the list of servers from a text file.
- Reads the list of search content from a CSV file.
- Connects to each server and recursively searches for all files in specified folders.
- Searches for specific content within these files based on the list from the CSV file.
- Saves the filenames that contain the searched content to an output file.

.PARAMETER serversListPath
The path to the text file containing the list of servers.

.PARAMETER foldersToSearch
An array of folder paths on each server to search for files.

.PARAMETER searchCsvPath
The path to the CSV file containing the list of search content.

.PARAMETER outputFilePath
The path to the output file where the filenames containing the searched content will be saved.

.Execution EXAMPLE
Open the script in PowerShell ISE and run it directly.
#>

# Define the parameters as variables within the script
$serversListPath = "C:\temp\script_testing\Server_List.txt"
$foldersToSearch = @("C$\temp\QCAD\VT\Configs")
$searchCsvPath = "C:\temp\QCAD\PA\Configs\SearchContent.csv"

# Get the current timestamp
$timestamp = Get-Date -Format "yyyy-MM-dd-HH-mm"

# Define the path for the output file
$outputFilePath = "C:\temp\QCAD\PA\Configs\NLBoutput_$timestamp.txt"

# Define the file types to search
$fileTypes = @("*.config", "*.ini", "*.settings")

# Read the search content from the CSV file
$searchContentList = Import-Csv -Path $searchCsvPath

# Check if searchContentList is empty
if ($searchContentList.Count -eq 0) {
    Write-Error "No search terms found in the CSV file."
    exit
}

# Function to search for specific content in all files on a server
function Search-AllFiles {
    param (
        [string]$server,
        [array]$folders,
        [array]$fileTypes,
        [array]$searchContentList,
        [string]$outputFilePath
    )

    foreach ($folder in $folders) {
        foreach ($fileType in $fileTypes) {
            # Recursively get all files of the specified type in the folder
            $searchMessage = "Searching for $fileType files in $folder on server $server..."
            Write-Host $searchMessage
            $searchMessage | Out-File -FilePath $outputFilePath -Append -Encoding utf8
            $files = Get-ChildItem -Path "\\$server\$folder" -Filter $fileType -File -Recurse -ErrorAction SilentlyContinue
            foreach ($file in $files) {
                try {
                    $processingMessage = "Processing file: $($file.FullName) on server: $server"
                    Write-Host $processingMessage
                    $processingMessage | Out-File -FilePath $outputFilePath -Append -Encoding utf8

                    # Read the content of the file
                    $fileContent = Get-Content -Path $file.FullName -ErrorAction SilentlyContinue -Raw

                    # Check if the file contains any of the search content
                    foreach ($searchContent in $searchContentList) {
                        if ($fileContent -match [regex]::Escape($searchContent.SearchTerm)) {
                            # Record the filename if search content is found
                            $foundMessage = "Found search content: $($searchContent.SearchTerm) in file: \\$server\$($file.FullName)"
                            Write-Host $foundMessage
                            $foundMessage | Out-File -FilePath $outputFilePath -Append -Encoding utf8
                            break
                        }
                    }
                } catch {
                    $errorMessage = "Error processing file: $($file.FullName) on server: $server. Error: $($_.Exception.Message)"
                    Write-Host $errorMessage
                    $errorMessage | Out-File -FilePath $outputFilePath -Append -Encoding utf8
                }
            }
        }
    }
}

# Read the list of servers
$servers = Get-Content -Path $serversListPath

foreach ($server in $servers) {
    $processingServerMessage = "Processing server: $server"
    Write-Host $processingServerMessage
    $processingServerMessage | Out-File -FilePath $outputFilePath -Append -Encoding utf8
    Search-AllFiles -server $server -folders $foldersToSearch -fileTypes $fileTypes -searchContentList $searchContentList -outputFilePath $outputFilePath
}

$completionMessage = "Script execution completed."
Write-Host $completionMessage
$completionMessage | Out-File -FilePath $outputFilePath -Append -Encoding utf8
