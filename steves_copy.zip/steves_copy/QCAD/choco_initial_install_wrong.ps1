# Variables
$QcadSource = "http://dmproget.prds.qldpol/nuget/QCAD-2023-12B/"
$listId = 17
$apiKey = "c9b48a25f6373edbd923c457368aef9a"
$Start = Get-Date
$qcadversion = "2023-12B"

# Set Environment Variables
$lifeCycle = (Get-ItemProperty "HKLM:\SOFTWARE\PSBA\BuildVariables").Lifecycle
[Environment]::SetEnvironmentVariable("EnvName", $lifeCycle, "Machine")
$EnvName = $lifeCycle
$Env:EnvName = $EnvName

# Update Chocolatey repository details
[xml]$XmlDocument = Get-Content -Path "C:\ProgramData\chocolatey\config\chocolatey.config"
$targetNode = $XmlDocument.SelectNodes("//sources")
$newNode = $XmlDocument.CreateElement("source")
$newNode.SetAttribute("id", "PSBAPreReqs")
$newNode.SetAttribute("value", "https://dmproget.prds.qldpol/nuget/Prerequisites/")
$newNode.SetAttribute("disabled", "false")
$newNode.SetAttribute("bypassProxy", "true")
$newNode.SetAttribute("selfService", "false")
$newNode.SetAttribute("adminOnly", "false")
$newNode.SetAttribute("priority", "0")
$targetNode.AppendChild($newNode)
$XmlDocument.Save("C:\ProgramData\chocolatey\config\chocolatey.config")

# choco install Oracle.Client.19c.x64 --source http://dmproget.prds.qldpol/nuget/Prerequisites/ -y
# Removed by rogers.steven2@police.qld.gov.au
# choco install dotnet4.7.2 --source http://dmproget.prds.qldpol/nuget/Prerequisites/ -y
choco install MapXtreme --version 8.1.0 --source http://dmproget.prds.qldpol/nuget/Prerequisites/ -y

<# 
This section removed by rogers.steven2@police.qld.gov.au.
Removed as covered by TIG: QCAD Tech Refresh 2023 - TIG - BA Environment.docx pg 64
https://qldpolice.sharepoint.com/:f:/r/sites/QPS-O365-FDS-ICTDI-SolutionArchitecture/Shared%20Documents/PSA%20Systems%20-%20QPS/QCAD/2022%20Tech%20Refresh/2023%20Detailed%20Design?csf=1&web=1&e=g75AcI

Install IIS
choco install NetFx4Extended-ASPNET45 --source windowsfeatures
choco install IIS-WebServerRole --source windowsfeatures
choco install IIS-WebServer --source windowsfeatures
choco install IIS-CommonHttpFeatures --source windowsfeatures
choco install IIS-Security --source windowsfeatures
choco install IIS-RequestFiltering --source windowsfeatures
choco install IIS-StaticContent --source windowsfeatures
choco install IIS-DefaultDocument --source windowsfeatures
choco install IIS-DirectoryBrowsing --source windowsfeatures
choco install IIS-HttpErrors --source windowsfeatures
choco install IIS-HttpRedirect --source windowsfeatures
choco install IIS-ApplicationDevelopment --source windowsfeatures
choco install IIS-NetFxExtensibility --source windowsfeatures
choco install IIS-NetFxExtensibility45 --source windowsfeatures
choco install IIS-ISAPIExtensions --source windowsfeatures
choco install IIS-ISAPIFilter --source windowsfeatures
choco install IIS-ASPNET45 --source windowsfeatures
choco install IIS-ASPNET --source windowsfeatures
choco install IIS-ASP --source windowsfeatures
choco install IIS-HealthAndDiagnostics --source windowsfeatures
choco install IIS-HttpLogging --source windowsfeatures
choco install IIS-LoggingLibraries --source windowsfeatures
choco install IIS-RequestMonitor --source windowsfeatures
choco install IIS-BasicAuthentication --source windowsfeatures
choco install IIS-WindowsAuthentication --source windowsfeatures
choco install IIS-DigestAuthentication --source windowsfeatures
choco install IIS-ClientCertificateMappingAuthentication --source windowsfeatures
choco install IIS-IISCertificateMappingAuthentication --source windowsfeatures
choco install IIS-URLAuthorization --source windowsfeatures
choco install IIS-IPSecurity --source windowsfeatures
choco install IIS-Performance --source windowsfeatures
choco install IIS-HttpCompressionStatic --source windowsfeatures
choco install IIS-HttpCompressionDynamic --source windowsfeatures
choco install IIS-WebServerManagementTools --source windowsfeatures
choco install IIS-ManagementConsole --source windowsfeatures
choco install IIS-ManagementScriptingTools --source windowsfeatures
choco install WCF-HTTP-Activation45 --source windowsfeatures
choco install WCF-TCP-Activation45 --source windowsfeatures
choco install WCF-Pipe-Activation45 --source windowsfeatures
choco install Application-Server --source windowsfeatures
choco install ASP-NET-Framework --source windowsfeatures
choco install Application-Server-WebServer-Support --source windowsfeatures
choco install Application-Server-TCP-Port-Sharing --source windowsfeatures
choco install Application-Server-WAS-Support --source windowsfeatures
choco install Application-Server-TCP-Activation --source windowsfeatures
choco install Application-Server-Pipe-Activation --source windowsfeatures
choco install WCF-HTTP-Activation --source windowsfeatures
choco install WCF-NonHTTP-Activation --source windowsfeatures
choco install File-Services --source windowsfeatures
choco install CoreFileServer --source windowsfeatures

#>

choco install QCAD.Utilities.Web.Config.Key.Generator  --source $QcadSource -y

choco install Password.API.PSM --source http://dmproget.prds.qldpol/nuget/Prerequisites/ -y
choco install TFS.API.PSM --source http://dmproget.prds.qldpol/nuget/Prerequisites/ -y
choco install QCAD.Config.PSM --source $QcadSource -y
choco install QCAD.PreReq.PSM --source http://dmproget.prds.qldpol/nuget/Prerequisites/ -y

Import-Module password_api_psm
Import-Module tfs_api_psm
Import-Module qcad_config_psm
Import-Module qcad_prereq_psm

Update-NetworkSettings

Update-DateAndTimeFormat

#comment this out for PR deployment - copy TNS names from existing server as below generated TNS names is different to existing ones
#Update-TnsNames

# Service Install
choco install QCAD.Vision.Client.Service --source $QcadSource -y

choco install QCAD.Fortek.Services.CCCM.Service --source $QcadSource -y

choco install QCAD.Web.Web.Services --source $QcadSource -y

choco install QCAD.Web.Web.Services.Admin --source $QcadSource -y

choco install QCAD.Web.Web.Services.Server --source $QcadSource -y

choco install QCAD.Web.MDT.Web.Services --source $QcadSource -y

choco install QCAD.Mapping.SDM.Presentation --source $QcadSource -y

#UTILIES

choco install QCAD.Utilities.Fortek.Simulators.CCCM --version 1.0.0 --source $QcadSource -y

choco install QCAD.Utilities.Fortek.Simulators.CCCM.Viewer --version 4.13.42.47297 --source $QcadSource -y


#Create System_VisXX Folder
$VisionEnvPath= "D:\Vision\Vis" + $EnvName + "\"
$SystemPath= "System_Vis" + $EnvName
New-Item -Path $VisionEnvPath -Name $SystemPath -ItemType "directory"

#Create WMS folder
New-Item -Path "D:\InetPub\wwwroot" -name "wms" -ItemType "directory"


# Configs

Update-VisionSettings -version $qcadversion

Update-VisionClientService -version $qcadversion

Update-CccmService -version $qcadversion

Update-CccmViewer -version $qcadversion

Update-CccmSimulator -version $qcadversion

Update-VisionWebService -version $qcadversion

Update-VisionWebService -service server -version $qcadversion

Update-VisionWebService -service admin -version $qcadversion

Update-VisionMdtWebService -version $qcadversion

Update-VcsWms -version $qcadversion

Update-VcsMapMws -version $qcadversion

Update-VcsMapXml -version $qcadversion

#create Performance Counter Category for VCS Service
$ccdTypeName = 'System.Diagnostics.CounterCreationData'
$CounterCollection = New-Object System.Diagnostics.CounterCreationDataCollection
$perfCounterCategoryName = "Vis" + $EnvName + "Vision Client Service"
[System.Diagnostics.PerformanceCounterCategory]::Create($perfCounterCategoryName, $perfCounterVersion, [Diagnostics.PerformanceCounterCategoryType]::SingleInstance, $CounterCollection); 


# Windows Services

Update-VisionServices -serviceExecutable Fortek.Services.CCCM -serviceFolder CCCM -serviceName CCCM

Update-VisionServices -serviceExecutable VisionClientService -serviceFolder VCS -serviceName VCS

## Web Services

##Default AppPool
Create-ApplicationPool
Create-ApplicationPool -PoolName "VISIONWebService"

## WMS/MapXtreme
Create-ApplicationPool -PoolName MapXtremeAppPool -Enable32BitAppOnWin64 false -Pipeline Integrated -IdentityType ApplicationPoolIdentity

Convert-VirtualDirectoryToApplication -VDName WMS -VDPath D:\InetPub\wwwroot\WMS -AppPool MapXtremeAppPool

## VWS
$ServiceUN  = (Get-StoredUsername -passwordName "VisionWS" -environment $EnvName -listId $listId -apiKey $apiKey)[0]
$ServicePW  = (Get-StoredPassword -passwordName "VisionWS" -environment $EnvName -listId $listId -apiKey $apiKey)[0]

Create-ApplicationPool -PoolName Vis${EnvName}_VWS -Enable32BitAppOnWin64 false -IdentityType SpecificUser -User $ServiceUN -Password $ServicePW

Convert-VirtualDirectoryToApplication -VDName Vis${EnvName}_VisionWebServices -VDPath D:\InetPub\wwwroot\Vis${EnvName}_VisionWebServices -AppPool Vis${EnvName}_VWS
##

## VWS_Admin
$ServiceUN  = Get-StoredUsername -passwordName "VisionWS_Admin" -environment $EnvName -listId $listId -apiKey $apiKey
$ServicePW  = Get-StoredPassword -passwordName "VisionWS_Admin" -environment $EnvName -listId $listId -apiKey $apiKey

Create-ApplicationPool -PoolName Vis${EnvName}_VWS_Admin -Enable32BitAppOnWin64 false -IdentityType SpecificUser -User $ServiceUN -Password $ServicePW

Convert-VirtualDirectoryToApplication -VDName Vis${EnvName}_VisionWebServices_Admin -VDPath D:\InetPub\wwwroot\Vis${EnvName}_VisionWebServices_Admin -AppPool Vis${EnvName}_VWS_Admin
##

## VWS_Server
$ServiceUN  = Get-StoredUsername -passwordName "VisionWS_Server" -environment $EnvName -listId $listId -apiKey $apiKey
$ServicePW  = Get-StoredPassword -passwordName "VisionWS_Server" -environment $EnvName -listId $listId -apiKey $apiKey

Create-ApplicationPool -PoolName Vis${EnvName}_VWS_Server -Enable32BitAppOnWin64 false -IdentityType SpecificUser -User $ServiceUN -Password $ServicePW

Convert-VirtualDirectoryToApplication -VDName Vis${EnvName}_VisionWebServices_Server -VDPath D:\InetPub\wwwroot\Vis${EnvName}_VisionWebServices_Server -AppPool Vis${EnvName}_VWS_Server
##

## MDT
Convert-VirtualDirectoryToApplication -VDName Vis${EnvName}_VisionMdtWebServices -VDPath D:\InetPub\wwwroot\Vis${EnvName}_VisionMdtWebServices -AppPool VISIONWebService
##

# Required Folders

Update-IisLogPath

# Total Time
$duration = New-TimeSpan -Start $Start
"Duration: " + $duration.Hours + ":" + $duration.Minutes + ":" + $duration.Seconds