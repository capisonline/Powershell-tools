﻿# doco https://learn.microsoft.com/en-us/iis/manage/provisioning-and-managing-iis/appcmdexe
# READ-ONLY inventory for ALL sites/apps
$ts   = Get-Date -Format 'yyyyMMdd-HHmm'
$out  = "D:\Temp\IIS-$env:COMPUTERNAME-$ts"
$null = New-Item -ItemType Directory -Path $out -Force -ErrorAction SilentlyContinue

$inetsrv = "$env:windir\System32\inetsrv\appcmd.exe"
Import-Module WebAdministration

# Server-wide prereqs
& $inetsrv add backup "pre-inventory-$ts"         | Out-Null  # safe snapshot
& $inetsrv list config /section:isapiCgiRestriction > "$out\isapiCgiRestriction.txt"
Get-WindowsFeature * | Where-Object Installed | Sort DisplayName |
  Format-Table DisplayName,Name,InstallState > "$out\windowsfeatures.txt"

# Walk every site and every application
Get-Website | ForEach-Object {
  $site = $_.Name
  $siteDir = Join-Path $out ("site_" + ($site -replace '[\\/:*?"<>|]','_'))
  New-Item -ItemType Directory -Path $siteDir -Force | Out-Null

  # Include the site root ("/") as a location
  $locations = @("$site")

  # Add each application under the site (These are the vdirs for each app IE: /ArlMessagingService, /MSMQ, etc.)
  $locations += (Get-WebApplication -Site $site | ForEach-Object { "$site$($_.Path)" })

  foreach ($loc in $locations) {
    $safe = ($loc -replace '[\\/:*?"<>|\s]','_')

    # Effective handlers + auth at THIS location (this is what actually routes requests)
    & $inetsrv list config "$loc" /section:system.webServer/handlers > "$siteDir\${safe}_handlers.txt"
    Get-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' `
      -Location $loc -Filter 'system.webServer/security/authentication/*' -Name enabled `
      > "$siteDir\${safe}_auth.txt"

    # appSettings and common WCF client endpoints if defined here
    & $inetsrv list config "$loc" /section:appSettings > "$siteDir\${safe}_appSettings.txt" 2>$null
    & $inetsrv list config "$loc" /section:system.serviceModel/client > "$siteDir\${safe}_svcClient.txt" 2>$null

    # App pool + identity (matters for MSMQ ACLs, DB, file access)
    $siteName, $appPath = $loc.Split('/',2)
    $app = if ($appPath) { Get-WebApplication -Site $siteName | Where-Object { $_.Path -eq "/$appPath" } } else { $null }
    $pool = if ($app) { $app.applicationPool } else { (Get-Website $siteName).applicationPool }
    $poolObj = Get-Item "IIS:\AppPools\$pool"
    $poolObj | Select-Object Name,
      @{n='IdentityType';e={$_.processModel.identityType}},
      @{n='UserName';e={$_.processModel.userName}} |
      Format-List | Out-File "$siteDir\${safe}_apppool.txt"

    # Physical path + copy web.config (if present) for diffing
    $itemPath = "IIS:\Sites\$siteName" + ($(if ($appPath) {"/$appPath"} else {""}))
    $phys = (Get-Item $itemPath).physicalPath
    $phys | Out-File "$siteDir\${safe}_physicalPath.txt"
    $wc = Join-Path $phys 'web.config'
    if (Test-Path $wc) { Copy-Item $wc "$siteDir\${safe}_web.config" -Force }
  }
}

Write-Host "Inventory saved to: $out"
