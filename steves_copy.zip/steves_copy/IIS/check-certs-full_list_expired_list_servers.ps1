﻿# QCAD Environment Certificate Audit Script
# Scans certs across list of servers -> Updates single CSV -> Supports resume
# run against a list of server for a report. 

$serversFile = "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"
$outputFile = "C:\temp\QCAD\VT\IIS\Certs\QCAD_Fleet_Cert_Audit5456345.csv"
# Update to whatever number days you want
$warnDays = 60

# Load server list
if (!(Test-Path $serversFile)) {
    Write-Host " Server list file not found: $serversFile" -ForegroundColor Red
    return
}

$servers = Get-Content $serversFile | Where-Object { $_ -and $_ -notmatch "^#" }

# Load existing results if exist (for resume support)
if (Test-Path $outputFile) {
    $existing = Import-Csv $outputFile
} else {
    $existing = @()
}

foreach ($server in $servers) {

    # Check if already processed
    if ($existing.Server -contains $server) {
        Write-Host " Skipping $server (already processed)" -ForegroundColor Gray
        continue
    }

    Write-Host "`n==============================" -ForegroundColor Cyan
    Write-Host "Scanning $server" -ForegroundColor Cyan

    try {
        $certs = Invoke-Command -ComputerName $server -ScriptBlock {

            $warnDays = 60
            $results = @()

            $storesToScan = @(
                @{Location="LocalMachine"; Name="WebHosting"},
                @{Location="LocalMachine"; Name="My"},
                @{Location="LocalMachine"; Name="Root"},
                @{Location="LocalMachine"; Name="CA"},
                @{Location="LocalMachine"; Name="TrustedPeople"},
                @{Location="LocalMachine"; Name="TrustedPublisher"},
                @{Location="LocalMachine"; Name="AuthRoot"},
                @{Location="CurrentUser"; Name="My"}
            )

            foreach ($storeInfo in $storesToScan) {
                $location = $storeInfo.Location
                $name = $storeInfo.Name

                try {
                    $store = New-Object System.Security.Cryptography.X509Certificates.X509Store($name, $location)
                    $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)
                    $certs = $store.Certificates

                    foreach ($cert in $certs) {

                        $ekuOids = $cert.EnhancedKeyUsageList | ForEach-Object { $_.Oid.Value }
                        $expired = if ($cert.NotAfter -lt (Get-Date)) {"YES"} else {"NO"}
                        $daysLeft = ($cert.NotAfter - (Get-Date)).Days
                        $expiring = if ($daysLeft -le $warnDays -and $daysLeft -ge 0) {"YES"} elseif ($expired -eq "YES") {"YES"} else {"NO"}

                        $results += [PSCustomObject]@{
                            Server           = $env:COMPUTERNAME
                            StoreLocation    = "$location\$name"
                            Subject          = $cert.Subject
                            Issuer           = $cert.Issuer
                            Thumbprint       = $cert.Thumbprint
                            NotBefore        = $cert.NotBefore
                            NotAfter         = $cert.NotAfter
                            Expired          = $expired
                            DaysUntilExpiry  = $daysLeft
                            ExpiringSoon     = $expiring
                            PrivateKey       = if ($cert.HasPrivateKey) {"YES"} else {"NO"}
                            EKU_OIDs         = if ($ekuOids) { $ekuOids -join ";" } else { "None" }
                        }
                    }

                    $store.Close()
                } catch {}
            }

            return $results

        } -ErrorAction Stop

        # Append results to output
        $certs | Export-Csv -Path $outputFile -Append -NoTypeInformation

        Write-Host " Completed $server" -ForegroundColor Green

    } catch {
        Write-Host " ERROR connecting to $server" -ForegroundColor Red
        # Add failure entry
        [PSCustomObject]@{
            Server           = $server
            StoreLocation    = "ERROR"
            Subject          = "ERROR"
            Issuer           = ""
            Thumbprint       = ""
            NotBefore        = ""
            NotAfter         = ""
            Expired          = "ERROR"
            DaysUntilExpiry  = ""
            ExpiringSoon     = "ERROR"
            PrivateKey       = ""
            EKU_OIDs         = ""
        } | Export-Csv -Path $outputFile -Append -NoTypeInformation
    }
}

Write-Host "`n Fleet cert audit complete. Results saved to $outputFile" -ForegroundColor Green
