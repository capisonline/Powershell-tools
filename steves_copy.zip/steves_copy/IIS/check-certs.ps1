﻿$certSubject = "CN=cliservice-vt.police.qld.gov.au"

$serverCert = Get-ChildItem -Path "Cert:\LocalMachine\WebHosting" |
    Where-Object {
        $_.Subject -like "*$certSubject*" -and $_.HasPrivateKey -eq $true
    }

if (-not $serverCert) {
    Write-Host "❌ Server certificate '$certSubject' with private key NOT found in WebHosting store" -ForegroundColor Red
    return
}

Write-Host "`n✅ Found certificate:" -ForegroundColor Green
$serverCert | Format-List Subject, Issuer, NotBefore, NotAfter, Thumbprint

# Check EKU
$ekuOids = $serverCert.EnhancedKeyUsageList | ForEach-Object { $_.Oid.Value }
if ($ekuOids -contains "1.3.6.1.5.5.7.3.1") {
    Write-Host "✔️  EKU includes 'Server Authentication' (1.3.6.1.5.5.7.3.1)" -ForegroundColor Green
} else {
    Write-Host "❌ EKU does NOT include 'Server Authentication'!" -ForegroundColor Red
}

# Check expiry
if ($serverCert.NotAfter -lt (Get-Date)) {
    Write-Host "❌ Certificate has expired!" -ForegroundColor Red
} else {
    Write-Host "✔️  Certificate is valid (not expired)." -ForegroundColor Green
}
