﻿# Path to the text file containing the server names 
$serverListPath = "C:\temp\scripts\server_list.txt"

# Read the server names from the file
$servers = Get-Content -Path $serverListPath

# The CSV file path where the results will be saved
$csvFilePath = "C:\temp\QCAD\Shares\server_shares-final2.csv"

# Read the server names from the file
$servers = Get-Content -Path $serverListPath

# Create an empty array to hold the results
$results = @()

foreach ($server in $servers) {
    $smbShares = Get-SMBShare -CimSession $server

    foreach ($share in $smbShares) {
        $accessList = Get-SmbShareAccess -Name $share.Name -CimSession $server

        # For each access rule, add a custom object to the results array
        foreach ($access in $accessList) {
            $result = [PSCustomObject]@{
                Server = $server
                ShareName = $share.Name
                LocalPath = $share.Path # Include the local path of the share
                AccountName = $access.AccountName
                AccessRight = $access.AccessRight
            }
            $results += $result
        }
    }
}

# Export the results array to a CSV file
$results | Export-Csv -Path $csvFilePath -NoTypeInformation

Write-Host "Report generated at $csvFilePath"
