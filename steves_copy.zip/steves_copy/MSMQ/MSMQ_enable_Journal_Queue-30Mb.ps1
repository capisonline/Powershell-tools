﻿# Path to the CSV file containing the server names and queue names 
$serversQueueCSVPath = "C:\temp\QCAD\VT\MSMQ\Enable-journal-list-script_input.csv"

# Size limit for the journal in kilobytes (30MB = 30720KB (1024x30))
$journalSizeLimitKB = 30720

# Import the CSV file
$serversQueueList = Import-Csv -Path $serversQueueCSVPath

foreach ($entry in $serversQueueList) {
    $server = $entry.ServerName
    $queueName = $entry.QueueName

    try {
        Write-Output "Processing server: $server, Queue: $queueName"

        # Connect to the MSMQ queue on the remote server
        $queuePath = "MSMQ:\$server\$queueName"
        $queue = Get-WmiObject -Namespace "root\cimv2" -Class "MSMQ_MSMQQueueSetting" -ComputerName $server -Filter "PathName='$queueName'"

        if ($queue -ne $null) {
            # Enable journaling
            $queue.Journal = $true
            $queue.Update()

            # Set journal size limit
            $journalStorage = Get-WmiObject -Namespace "root\cimv2" -Class "MSMQ_MSMQSetting" -ComputerName $server
            $journalStorage.JournalQuota = $journalSizeLimitKB
            $journalStorage.Put()

            Write-Output "Enabled journaling on $queueName and set journal size limit to 30MB on $server."
        } else {
            Write-Output "Queue not found on ${server}: $queueName"
        }
    } catch {
        Write-Output "Failed to configure MSMQ on $server. Error: $_"
    }
}
