﻿# Define input and output variables 
$queueName = ".\private$\YourQueueName"
$journalQueueName = "$queueName;Journal"
$outputFile = "C:\path\to\output\JournalMessageDetails.csv"

try {
    # Load the System.Messaging assembly
    Add-Type -AssemblyName "System.Messaging"

    # Check if MSMQ service is running
    $msmqService = Get-Service -Name MSMQ -ErrorAction SilentlyContinue
    if ($null -eq $msmqService -or $msmqService.Status -ne 'Running') {
        throw "MSMQ service is not running. Please start the MSMQ service and try again."
    }

    # Create a MessageQueue object for the journal queue
    if ([System.Messaging.MessageQueue]::Exists($journalQueueName)) {
        $journalQueue = New-Object System.Messaging.MessageQueue $journalQueueName
    } else {
        throw "The journal queue '$journalQueueName' does not exist."
    }

    # Read all messages from the journal queue
    $messages = $journalQueue.GetAllMessages()
    if ($messages.Count -eq 0) {
        Write-Host "No messages found in the journal queue."
        exit
    }

    # Create a list to hold message details
    $messageDetailsList = @()

    foreach ($message in $messages) {
        # Get the message ID, date and time, and lookup ID
        $messageId = $message.Id
        $messageSentTime = $message.SentTime.ToString("yyyy-MM-dd HH:mm:ss")
        $messageLookupId = $message.LookupId

        # Create a custom object with the message details
        $messageDetails = [PSCustomObject]@{
            "Message ID" = $messageId
            "Sent Time" = $messageSentTime
            "Lookup ID" = $messageLookupId
        }

        # Add the message details to the list
        $messageDetailsList += $messageDetails
    }

    # Export the list to a CSV file
    $messageDetailsList | Export-Csv -Path $outputFile -NoTypeInformation

    Write-Host "Message details have been exported to $outputFile."
} catch {
    Write-Host "An error occurred: $_"
}
