﻿<# 
.SYNOPSIS
    This script retrieves MSMQ queue permissions from a list of servers and saves the information into a CSV file.

.DESCRIPTION
    The script performs the following actions:
    1. Reads a list of server names from a specified text file.
    2. Connects to each server and retrieves the MSMQ queue permissions.
    3. Saves the information into a CSV file, including server name, queue name, and permissions.

.PARAMETER ServerListPath
    The path to the text file containing the list of server names.

.PARAMETER OutputCsvPath
    The path to the output CSV file where the results will be saved.

.EXAMPLE
    .\GetMSMQQueuePermissions.ps1 -ServerListPath "C:\Path\To\ServerList.txt" -OutputCsvPath "C:\Path\To\Output.csv"
#>

param (
    [string]$ServerListPath,
    [string]$OutputCsvPath
)

# Import the list of servers
$servers = Get-Content -Path $ServerListPath

# Initialize an array to hold the results
$results = @()

# Function to retrieve MSMQ queue permissions on a remote server
function Get-MSMQQueuePermissions {
    param (
        [string]$serverName
    )

    try {
        Invoke-Command -ComputerName $serverName -ScriptBlock {
            param ($serverName)

            # Import the MSMQ module
            Import-Module -Name MSMQ

            # Initialize an array to hold the results
            $queuePermissions = @()

            # Get all public and private queues
            $queues = Get-MsmqQueue -Name * -QueueType All

            foreach ($queue in $queues) {
                $permissions = $queue.GetPermissions()
                foreach ($permission in $permissions) {
                    $queuePermissions += [PSCustomObject]@{
                        ServerName      = $serverName
                        QueueName       = $queue.QueueName
                        User            = $permission.User
                        AccessRights    = $permission.AccessRights
                        IsInherited     = $permission.IsInherited
                    }
                }
            }

            return $queuePermissions
        } -ArgumentList $serverName -Credential (Get-Credential) -ErrorAction Stop
    } catch {
        # Log the error
        Write-Error "Failed to retrieve MSMQ queue permissions for server ${serverName}: $_"
        return $null
    }
}

# Iterate through each server and get MSMQ queue permissions
foreach ($server in $servers) {
    $queuePermissions = Get-MSMQQueuePermissions -serverName $server
    if ($queuePermissions) {
        $results += $queuePermissions
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $OutputCsvPath -NoTypeInformation

Write-Output "Results exported to $OutputCsvPath"
