﻿# Path to the file containing the list of servers 
$serversList = "C:\temp\QCAD\VT\VT_Old_Servers.txt"

# Path to save the CSV file
$outputCsv = "C:\temp\QCAD\VT\MSMQ\VT_QCAD_MSMQ_Names-Perms.csv"

# Initialize CSV file
if (Test-Path $outputCsv) {
    Remove-Item $outputCsv
}

# Initialize CSV header
"ServerName,Queue,AccountName,Access,Right" | Out-File $outputCsv

# Import the list of servers
$servers = Get-Content $serversList

$allQueuePermissions = @()

foreach ($server in $servers) {
    try {
        $queuePermissions = Invoke-Command -ComputerName $server -ScriptBlock {
            Import-Module MSMQ
            $queues = Get-MsmqQueue -QueueType Private | Get-MsmqQueueACL
            $queuePermissions = @()

            foreach ($entry in $queues) {
                $queuePermissions += [PSCustomObject]@{
                    ServerName  = $env:COMPUTERNAME
                    Queue       = $entry.Queue
                    AccountName = $entry.AccountName
                    Access      = $entry.Access
                    Right       = $entry.Right
                }
            }

            return $queuePermissions
        } -ErrorAction Stop
        
        $allQueuePermissions += $queuePermissions

    } catch {
        Write-Host "Failed to retrieve queues from $server. Error: $_"
        $allQueuePermissions += [PSCustomObject]@{
            ServerName  = $server
            Queue       = "Error"
            AccountName = ""
            Access      = ""
            Right       = ""
        }
    }
}

# Export all collected queue permissions to CSV
$allQueuePermissions | Export-Csv -Path $outputCsv -NoTypeInformation

Write-Host "Queue names and permissions have been saved to $outputCsv"
