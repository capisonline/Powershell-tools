﻿# ========== User Variables ==========
$serverMapPath = "C:\temp\QCAD\VT\MSMQ\old_servers-new_servers.csv"
$oldPermissionsPath = "C:\temp\QCAD\VT\MSMQ\VT_Validate_MSMQ-against-new.csv"
$outputPath = "C:\temp\QCAD\VT\MSMQ\VT_PermissionCompare.csv"
# ====================================

# Load input data
$serverPairs = Import-Csv -Path $serverMapPath
$oldPermissions = Import-Csv -Path $oldPermissionsPath
$finalResults = @()

# Function to get MSMQ permissions from a remote server
function Get-MsmqPermissions {
    param([string]$ServerName)

    try {
        $queues = Get-MsmqQueue -ComputerName $ServerName -QueueType Private
        $allPerms = @()

        foreach ($queue in $queues) {
            $acls = Get-MsmqQueueAcl -Name $queue.QueueName -ComputerName $ServerName -ErrorAction Stop
            foreach ($acl in $acls) {
                $allPerms += [pscustomobject]@{
                    Queue       = $queue.QueueName
                    AccountName = $acl.AccountName
                    Access      = $acl.AccessControlType.ToString()
                    Right       = $acl.MsmqAccessRights.ToString()
                }
            }
        }

        return $allPerms
    }
    catch {
        Write-Warning "Failed to get MSMQ ACLs from ${ServerName}: $_"
        return @()
    }
}

# Main comparison logic
foreach ($pair in $serverPairs) {
    $oldServer = $pair.OLD_Server
    $newServer = $pair.NEW_Server

    Write-Host "`nComparing $oldServer --> $newServer..."

    # Get permissions from old export
    $oldPerms = $oldPermissions | Where-Object { $_.ServerName -eq $oldServer }

    # Get current permissions from new server
    $newPerms = Get-MsmqPermissions -ServerName $newServer

    foreach ($perm in $oldPerms) {
        $match = $newPerms | Where-Object {
            $_.Queue       -eq $perm.Queue       -and
            $_.AccountName -eq $perm.AccountName -and
            $_.Access      -eq $perm.Access      -and
            $_.Right       -eq $perm.Right
        }

        $finalResults += [pscustomobject]@{
            OLD_Server   = $oldServer
            NEW_Server   = $newServer
            Queue        = $perm.Queue
            AccountName  = $perm.AccountName
            Access       = $perm.Access
            Right        = $perm.Right
            ExistsOnNew  = if ($match) { $true } else { $false }
        }
    }
}

# Export results
$finalResults | Export-Csv -Path $outputPath -NoTypeInformation
Write-Host "`n Done. Results written to $outputPath"
