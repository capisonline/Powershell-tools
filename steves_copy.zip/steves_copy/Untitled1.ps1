﻿# Define the path to the folder containing the log files 
$logFolderPath = "C:\Path\To\Your\LogFiles"
$csvFilePath = "C:\Path\To\Your\output.csv"

# Function to scan a file for the word "ERROR"
function Scan-File {
    param (
        [string]$filePath
    )

    $results = @()
    try {
        # Open the file with shared read access
        $fileStream = [System.IO.File]::Open($filePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $streamReader = New-Object System.IO.StreamReader($fileStream)
        while ($line = $streamReader.ReadLine()) {
            if ($line -match "ERROR") {
                $dateTime = $line.Substring(0, 19)
                $results += [pscustomobject]@{
                    FileName = $filePath
                    DateTime = $dateTime
                    Status   = "ERROR"
                }
            }
        }
        $streamReader.Close()
        $fileStream.Close()
    } catch {
        $results += [pscustomobject]@{
            FileName = $filePath
            DateTime = ""
            Status   = "File Locked or Not Accessible"
        }
    }

    return $results
}

# Function to scan all log files in a folder
function Scan-Folder {
    param (
        [string]$folderPath
    )

    $allResults = @()
    $logFiles = Get-ChildItem -Path $folderPath -Filter *.log

    foreach ($logFile in $logFiles) {
        $fileResults = Scan-File -filePath $logFile.FullName
        $allResults += $fileResults
    }

    return $allResults
}

# Monitor the folder for changes
while ($true) {
    $scanResults = Scan-Folder -folderPath $logFolderPath

    # Update the CSV file with the scan results
    $scanResults | Export-Csv -Path $csvFilePath -NoTypeInformation -Force

    Start-Sleep -Seconds 5
}

