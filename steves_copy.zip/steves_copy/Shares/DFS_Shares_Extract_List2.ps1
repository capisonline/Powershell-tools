﻿$shares = @()
$DFSshares = Get-DfsnFolder -path '\\prds.qldpol\AppData\BA\QCAD\*' 
foreach($dfsshare in $DFSshares){
$shares += Get-DfsnFolderTarget -path $dfsshare.path | select path, targetpath, Referral Status}
$shares | export-csv C:\temp\QCAD\DFS\BA_dfsshares.csv