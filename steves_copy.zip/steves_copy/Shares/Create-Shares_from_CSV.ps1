﻿<#
Find and replace: '$' with ':'
Example Source CSV:
ColumnA         ColumnB             Column C        ColumnD                     ColumnE 
ServerName	    FolderPath	        ShareName	    FolderPermissions	        SharePermissions
EGLVCADAASPA01	D:\Share-testing4	Share-testing4	PRDS\907429:FullControl 	Everyone:Change;PRDS\%USERNAME%:Full

#>
# Define the path to the CSV file 
$csvFilePath = "C:\temp\QCAD\VT\Shared_Folders-NTFS_Perms\VT_Server_NTFS_Folders-perms.csv"

# Read the CSV file
$servers = Import-Csv $csvFilePath

foreach ($server in $servers) {
    $serverName = $server.ServerName
    $folderPath = $server.FolderPath
    $shareName = $server.ShareName
    $folderPermissions = $server.FolderPermissions
    $sharePermissions = $server.SharePermissions

    Invoke-Command -ComputerName $serverName -ScriptBlock {
        param($folderPath, $shareName, $folderPermissions, $sharePermissions)
        
        # Ensure the folder exists
        if (-not (Test-Path $folderPath)) {
            New-Item -Path $folderPath -ItemType Directory
        }

        # Create the share with temporary full access to "Everyone"
        $shareResult = New-SmbShare -Name $shareName -Path $folderPath -FullAccess "Everyone"
        if (-not $shareResult) {
            Write-Error "Failed to create share $shareName on $folderPath"
            return
        }

        # Set NTFS folder permissions
        $folderPermissions.Split(';') | ForEach-Object {
            if ($_ -ne "") {
                $permParts = $_.Split(':')
                if ($permParts.Count -eq 2) {
                    $user = $permParts[0]
                    $perm = $permParts[1]
                    $acl = Get-Acl $folderPath
                    $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($user, $perm, "ContainerInherit,ObjectInherit", "None", "Allow")
                    $acl.SetAccessRule($accessRule)
                    Set-Acl -Path $folderPath -AclObject $acl
                } else {
                    Write-Warning "Invalid folder permission format: $_"
                }
            }
        }

        # Set SMB share permissions
        $sharePermissions.Split(';') | ForEach-Object {
            if ($_ -ne "") {
                $permParts = $_.Split(':')
                if ($permParts.Count -eq 2) {
                    $user = $permParts[0]
                    $perm = $permParts[1]
                    $accessRight = switch ($perm) {
                        "Read" { "Read" }
                        "Change" { "Change" }
                        "Full" { "Full" }
                        default { Write-Warning "Unknown share permission level: $perm for user: $user"; return }
                    }
                    Grant-SmbShareAccess -Name $shareName -AccountName $user -AccessRight $accessRight -Force
                } else {
                    Write-Warning "Invalid share permission format: $_"
                }
            }
        }
    } -ArgumentList $folderPath, $shareName, $folderPermissions, $sharePermissions
}

Write-Host "Script execution completed."
