﻿$shares = @()
$DFSshares = Get-DfsnFolder -path '\\prds.qldpol\AppData\TP\*' 
foreach($dfsshare in $DFSshares){
$shares += Get-DfsnFolderTarget -path $dfsshare.path | select path, targetpath}
$shares | export-csv C:\temp\QCAD\TP\DFS\dfsshares.csv