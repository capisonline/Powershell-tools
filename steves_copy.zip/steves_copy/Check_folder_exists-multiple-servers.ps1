﻿Get-Content "C:\temp\QCAD\PA\PA_NEW_Server_list.txt" | ForEach-Object {
    [PSCustomObject]@{
        Computer_Name = $_
        Output        = Test-Path "\\$_\C$\Program Files\Microsoft Monitoring Agent\Agent"
    }
} | Export-Csv -Path C:\temp\QCAD\PA\Backups\PA_SCOM-check.csv -NoTypeInformation

