﻿# Define the path to the text file containing the list of roles and features 
$textFilePath = "C:\Path\To\Your\RolesAndFeatures.txt"

# Read the roles and features from the text file
$rolesAndFeatures = Get-Content -Path $textFilePath

# Install the roles and features
$result = Install-WindowsFeature -Name $rolesAndFeatures -IncludeAllSubFeature -Restart:$true

# Output the results of the installation
$result | Format-List

# Check if a restart is needed (if not already rebooted)
if ($result.RestartNeeded -eq "Yes") {
    # Optionally prompt for restart or perform it directly
    Restart-Computer
}
