﻿$serversFilePath = "C:\temp\scripts\server_list.txt"
$localOutDir     = "C:\temp\QCAD\VT\Issues\ARL-ECG\RolesNFeatures"

$servers = Get-Content -Path $serversFilePath
New-Item -Path $localOutDir -ItemType Directory -Force | Out-Null

foreach ($server in $servers) {
  try {
    $features = Invoke-Command -ComputerName $server -ErrorAction Stop -ScriptBlock {
      Get-WindowsFeature | Where-Object Installed
    }
    $destFile = Join-Path $localOutDir ("{0}_roles-features777.csv" -f $server)
    $features | Export-Csv -Path $destFile -NoTypeInformation
    Write-Host "Exported roles/features for $server -> $destFile"
  }
  catch {
    Write-Warning "${server}: $($_.Exception.Message)"
  }
}

Write-Host "Done."
