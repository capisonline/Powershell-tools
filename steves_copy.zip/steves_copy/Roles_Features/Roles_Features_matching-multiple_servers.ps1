﻿# Directory where the hostname files are stored, each containing the features required for that server 
$serverListDir = "C:\temp\QCAD\PR\Roles_Features\Input_Txt_Files"

# Output directory on your computer where the results will be saved
$localOutputDir = "C:\temp\QCAD\PR\Roles_Features\Input_Txt_Files\QA"

# Ensure the output directory exists
if (-not (Test-Path -Path $localOutputDir)) {
    New-Item -ItemType Directory -Path $localOutputDir
}

# Iterate over each file in the server list directory
Get-ChildItem -Path $serverListDir -File | ForEach-Object {
    $serverName = $_.BaseName # Assumes file name is the server hostname
    $featureFilePath = $_.FullName

    # Read the features from the file
    $featureList = Get-Content -Path $featureFilePath

    # Prepare an array to store result objects
    $resultArray = @()

    # Remote command block to check features
    $checkFeaturesScriptBlock = {
        param ($features)
        $features | ForEach-Object {
            $feature = $_.Trim()
            $result = Get-WindowsFeature -Name $feature
            if ($result) {
                [PSCustomObject]@{
                    Feature      = $feature
                    Installed    = $result.Installed
                    InstallState = $result.InstallState
                }
            } else {
                [PSCustomObject]@{
                    Feature      = $feature
                    Installed    = $false
                    InstallState = "Not Found"
                }
            }
        }
    }

    # Execute the feature check on the server and collect the results
    $resultArray += Invoke-Command -ComputerName $serverName -ScriptBlock $checkFeaturesScriptBlock -ArgumentList (,$featureList)

    # Define local output file path
    $localOutputFile = Join-Path -Path $localOutputDir -ChildPath "$serverName.csv"

    # Export the result array to a CSV file
    $resultArray | Export-Csv -Path $localOutputFile -NoTypeInformation

    Write-Host "Results for $serverName have been saved to $localOutputFile"
}

Write-Host "Feature check completed for all servers."
