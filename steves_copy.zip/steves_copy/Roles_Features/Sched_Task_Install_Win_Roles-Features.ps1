﻿
# Directory containing the text files 
$localDirectory = "C:\temp\QCAD\VT\Roles_Features"

# Path where the text files should be copied on the remote server
$remoteDirectory = "C$\temp"

# Command to run on the remote server to install roles/features
$installCommand = "Install-WindowsFeature -InputObject (Get-Content -Path $remoteDirectory\$file.Name)"

# Ensure the remote directory exists
Invoke-Command -ComputerName $hostname -ScriptBlock {
    Param($remoteDirectory)
    if (-not (Test-Path $remoteDirectory)) {
        New-Item -Path $remoteDirectory -ItemType Directory
    }
} -ArgumentList $remoteDirectory

# Process each text file
Get-ChildItem -Path $localDirectory -Filter "*.txt" | ForEach-Object {
    $file = $_
    $hostname = $_.BaseName  # Assuming the hostname is the filename without extension

    # Copy the file to the remote server
    Copy-Item -Path $file.FullName -Destination "\\$hostname\$remoteDirectory"

    # Create a scheduled task on the remote server to install the roles/features
    $action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-NoProfile -WindowStyle Hidden -Command `\"$installCommand`\""
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)  # Schedule to run 5 minutes from now
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

    # Connect to the remote server and create the task
    Invoke-Command -ComputerName $hostname -ScriptBlock {
        Param($action, $trigger, $settings)
        Register-ScheduledTask -TaskName "InstallRolesFeatures" -Action $action -Trigger $trigger -Settings $settings -Force -User "NT AUTHORITY\SYSTEM" -RunLevel Highest
    } -ArgumentList $action, $trigger, $settings
}
