# Directory where the hostname files are stored, each containing the features required for that server 
$serverListDir = "C:\temp\QCAD\VT\Roles_Features\New folder\"

# Output directory on your computer where the results will be saved
$localOutputDir = "C:\temp\QCAD\VT\Roles_Features\QA\final"

# Ensure the output directory exists
if (-not (Test-Path -Path $localOutputDir)) {
    New-Item -ItemType Directory -Path $localOutputDir
}

# Remote command block to check features
$checkFeaturesScriptBlock = {
    param ($features)
    $features.Trim() -split "`n" | ForEach-Object {
        $feature = $_.Trim()
        $result = Get-WindowsFeature -Name $feature

        if ($result) {
            [PSCustomObject]@{
                Feature      = $feature
                Installed    = $result.Installed
                InstallState = $result.InstallState
            }
        } else {
            [PSCustomObject]@{
                Feature      = $feature
                Installed    = $false
                InstallState = "Not Found"
            }
        }
    }
}

# Retrieve all server feature files
$serverFiles = Get-ChildItem -Path $serverListDir -File

# Process each server file in parallel
$serverFiles | ForEach-Object -Parallel {
    param ($file, $outputDir, $scriptBlock)
    $serverName = $file.BaseName
    $featureFilePath = $file.FullName
    $featureList = Get-Content -Path $featureFilePath -Raw

    # Execute the feature check on the server
    $resultArray = Invoke-Command -ComputerName $serverName -ScriptBlock $scriptBlock -ArgumentList $featureList

    # Define local output file path
    $localOutputFile = Join-Path -Path $outputDir -ChildPath "$serverName.csv"

    # Export the result array to a CSV file
    $resultArray | Export-Csv -Path $localOutputFile -NoTypeInformation

    Write-Host "Results for $serverName have been saved to $localOutputFile"
} -ArgumentList $localOutputDir, $checkFeaturesScriptBlock -ThrottleLimit 5

Write-Host "Feature check completed for all servers."
