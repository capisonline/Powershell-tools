﻿# Assuming the script is executed in the context where the hostname can determine the file name 
$hostname = $env:COMPUTERNAME
$filePath = "C:\temp\$hostname.txt"

# Install the Windows features listed in the file
Get-Content -Path $filePath | ForEach-Object {
    Install-WindowsFeature -Name $_ -Restart
}
