﻿<# 
Synopsis:
1. Before running this script, manually uninstall Oracle 19c using Chocolatey:
   choco uninstall Oracle.Client.19c.x86 -x
   The -x flag ensures that all associated files are forcefully uninstalled.
   
2. Reboot the system after running the choco uninstall command.

3. Run this script to:
   - Stop and delete Oracle services.
   - Remove Oracle-related registry keys.
   - Remove Oracle directories (including C:\Oracle, D:\Oracle, etc.).

4. Remove Oracle folder from the PATH environment variable
   - D:\oracle\product\19.0.0\client_1\bin;

#>

# Step 1: Stop and delete Oracle services
$oracleServices = Get-Service | Where-Object { $_.Name -like "Oracle*" }
foreach ($service in $oracleServices) {
    # Stop the service if it is running
    if ($service.Status -eq 'Running') {
        Stop-Service -Name $service.Name -Force
    }

    # Delete the service
    sc.exe delete $service.Name
}

# Step 2: Remove Oracle registry keys
$oracleRegistryKeys = @(
    "HKLM:\SOFTWARE\Oracle*",
    "HKLM:\SOFTWARE\Wow6432Node\Oracle*",
    "HKLM:\SYSTEM\CurrentControlSet\Services\Oracle*"
)

foreach ($key in $oracleRegistryKeys) {
    if (Test-Path $key) {
        Remove-Item -Path $key -Recurse -Force
    }
}

# Step 3: Remove Oracle-related directories
$oracleDirectories = @(
    "C:\Oracle",
    "C:\Program Files\Oracle",
    "C:\Program Files (x86)\Oracle",
    "D:\Oracle"
)

foreach ($dir in $oracleDirectories) {
    if (Test-Path $dir) {
        Remove-Item -Path $dir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
