﻿<#
.SYNOPSIS
    Runs tnsping for one or more aliases from a list of remote servers.

.DESCRIPTION
    - Reads a list of servers from a text file (one hostname per line).
    - For each server, remotely runs tnsping for each alias in $Aliases.
    - Attempts to locate tnsping.exe via configured Oracle bin paths,
      falling back to tnsping in the PATH.
    - Collects results (success/failure, exit code, and a short message).
    - Writes a CSV report you can attach to change records / runsheets.

    This script is read-only from an Oracle perspective; it does not change
    tnsnames.ora or any database state.

    REQUIREMENTS:
    - PowerShell remoting enabled and accessible (WinRM).
    - Appropriate admin/remote rights to the target servers.
    - Oracle client installed on each server with tnsping available.
#>

# ===========================
# CONFIGURATION
# ===========================

# 1. List of servers to test (one hostname per line)
$ServerListFile = "C:\temp\QCAD\PR\Oracle\ORacle_Service_Inputfile.txt"

# 2. Aliases to test from tnsnames.ora (typically the ones QCAD uses)
$Aliases = @(
    "PRCAD",
    "PRCADREP"
)

# 3. Possible Oracle bin paths on the remote servers.
#    The script will look for tnsping.exe in these paths, in order.
#    If none are found, it will fall back to tnsping in the PATH.
$OracleBinPaths = @(
    #"D:\oracle\product\19.0.0\client_1\bin",
    "D:\oracle\product\11.2.0\client_1\bin"
)

# 4. Where to save the report
$OutputFolder = "C:\temp\QCAD\PR\Oracle\Slow_TNSPIng"

# ===========================
# INITIALISATION
# ===========================

if (-not (Test-Path $ServerListFile)) {
    Write-Error "Server list file not found: $ServerListFile"
    return
}

if (-not (Test-Path $OutputFolder)) {
    New-Item -Path $OutputFolder -ItemType Directory -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$OutputCsv = Join-Path $OutputFolder ("tnsping_validation_{0}.csv" -f $timestamp)

Write-Host "Server list : $ServerListFile"
Write-Host "Aliases     : $($Aliases -join ', ')"
Write-Host "Output CSV  : $OutputCsv"
Write-Host ""

$allResults = @()
$servers = Get-Content -Path $ServerListFile | Where-Object { $_ -and $_.Trim() -ne "" }

# ===========================
# REMOTE SCRIPTBLOCK
# ===========================

$scriptBlock = {
    param(
        [string[]]$Aliases,
        [string[]]$OracleBinPaths
    )

    function Get-TnspingPath {
        param(
            [string[]]$OracleBinPaths
        )

        foreach ($binPath in $OracleBinPaths) {
            if ([string]::IsNullOrWhiteSpace($binPath)) { continue }

            $candidate = Join-Path $binPath "tnsping.exe"
            if (Test-Path $candidate) {
                return $candidate
            }
        }

        # Fallback: rely on PATH
        return "tnsping.exe"
    }

    $results = @()
    $tnspingExe = Get-TnspingPath -OracleBinPaths $OracleBinPaths

    # Check that tnsping is invocable
    $tnspingCommand = Get-Command $tnspingExe -ErrorAction SilentlyContinue
    if (-not $tnspingCommand) {
        foreach ($alias in $Aliases) {
            $results += [PSCustomObject]@{
                Server      = $env:COMPUTERNAME
                Alias       = $alias
                Success     = $false
                ExitCode    = $null
                Message     = "tnsping not found (checked OracleBinPaths and PATH)"
                TnspingPath = $tnspingExe
            }
        }
        return $results
    }

    foreach ($alias in $Aliases) {
        try {
            $output = & $tnspingExe $alias 1 2>&1
            $exitCode = $LASTEXITCODE
            $success = ($exitCode -eq 0)

            $summaryLine = ($output | Where-Object { $_ -and $_.Trim() -ne "" } | Select-Object -First 1)

            $results += [PSCustomObject]@{
                Server      = $env:COMPUTERNAME
                Alias       = $alias
                Success     = $success
                ExitCode    = $exitCode
                Message     = $summaryLine
                TnspingPath = $tnspingExe
            }
        }
        catch {
            $results += [PSCustomObject]@{
                Server      = $env:COMPUTERNAME
                Alias       = $alias
                Success     = $false
                ExitCode    = $null
                Message     = "Error running tnsping: $($_.Exception.Message)"
                TnspingPath = $tnspingExe
            }
        }
    }

    return $results
}

# ===========================
# MAIN LOOP
# ===========================

foreach ($server in $servers) {
    $server = $server.Trim()
    if (-not $server) { continue }

    Write-Host "Testing server: $server"

    try {
        $remoteResults = Invoke-Command -ComputerName $server `
                                        -ScriptBlock $scriptBlock `
                                        -ArgumentList ($Aliases, $OracleBinPaths) `
                                        -ErrorAction Stop

        $allResults += $remoteResults
    }
    catch {
        foreach ($alias in $Aliases) {
            $allResults += [PSCustomObject]@{
                Server      = $server
                Alias       = $alias
                Success     = $false
                ExitCode    = $null
                Message     = "Remoting error: $($_.Exception.Message)"
                TnspingPath = $null
            }
        }
        Write-Warning "Failed to run tnsping on ${server}: $($_.Exception.Message)"
    }
}

# ===========================
# OUTPUT
# ===========================

$allResults | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8

Write-Host ""
Write-Host "Summary by alias:"
$allResults |
    Group-Object Alias, Success |
    Sort-Object Name |
    ForEach-Object {
        $alias, $success = $_.Name -split ','
        Write-Host ("  Alias {0}, Success={1}: {2} result(s)" -f $alias, $success, $_.Count)
    }

Write-Host ""
Write-Host "Detailed tnsping report saved to:"
Write-Host "  $OutputCsv"
