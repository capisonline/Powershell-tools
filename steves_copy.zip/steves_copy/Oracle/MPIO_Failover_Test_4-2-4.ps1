﻿<#
<#
.SYNOPSIS
  Prove MPIO failover by forcing a controlled path-group reduction (e.g. 4 → 2 → 4)
  via disabling ONE QLogic FCoE HBA/function (PnP SCSIAdapter), while capturing PRE/DURING/POST path-count evidence.

.DESCRIPTION
  This script disables a specific Plug-and-Play (PnP) device representing one QLogic FCoE adapter function
  (e.g. PCI bus/device/function 195/0/2 or 195/0/3). Disabling this device removes the associated MPIO paths.
  The script captures mpclaim output before, during, and after the disable so we can prove the path count
  changes and returns to normal (e.g. 4 → 2 → 4).

  Service continuity is validated separately using an approved canary method.
  This script is only responsible for proving the Windows MPIO failover mechanism and path-count change.

.PARAMETER InstanceIdToDrop
  The PnP InstanceId of the QLogic FCoE SCSIAdapter to disable/enable.
  This value is environment/server specific and must be discovered on the server under test.

  How to discover InstanceIdToDrop (run on the target server as Administrator):

    # List QLogic FCoE adapters (SCSIAdapter class) and show the InstanceId to copy
    Get-PnpDevice -Class SCSIAdapter |
      Where-Object { $_.FriendlyName -match 'QLogic' -and $_.FriendlyName -match 'FCoE' } |
      Select-Object FriendlyName, Status, InstanceId |
      Format-List

    # Recommended: include PCI LocationInfo so you can distinguish Function 2 vs Function 3
    Get-PnpDevice -Class SCSIAdapter |
      Where-Object { $_.FriendlyName -match 'QLogic' -and $_.FriendlyName -match 'FCoE' } |
      ForEach-Object {
        $loc = (Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName 'DEVPKEY_Device_LocationInfo' -ErrorAction SilentlyContinue).Data
        [pscustomobject]@{
          FriendlyName = $_.FriendlyName
          Status       = $_.Status
          InstanceId   = $_.InstanceId
          LocationInfo = $loc
        }
      } | Format-List

  Example output (this host has two QLogic FCoE functions):
    FriendlyName : QLogic 25GE 2P QL41262HMKR CNA (FCoE)
    Status       : OK
    InstanceId   : QEBDRV\FCOE2&PCI_80801077&SUBSYS_000F1077&REV_02\5&1035A1D6&0&5005C300
    LocationInfo : PCI bus 195, device 0, function 2

    FriendlyName : QLogic 25GE 2P QL41262HMKR CNA (FCoE)
    Status       : OK
    InstanceId   : QEBDRV\FCOE2&PCI_80801077&SUBSYS_000F1077&REV_02\5&12CC0087&0&5005C300
    LocationInfo : PCI bus 195, device 0, function 3

  Selection guidance:
    - Drop only ONE function per test run (Function 2 OR Function 3), not both.
    - If baseline is 4 paths per MPIO disk, disabling one function should typically reduce to 2 paths.
    - Run the script twice (separate runs) if you need to validate both functions independently.

.PARAMETER WatchMpioDisk
  Which MPIO disk number to use for path-count extraction (e.g. 0).
  The script still records the full MPIO disk list, but uses the selected disk’s detailed output to compute PathCount.

.OUTPUTS
  A timestamped evidence folder under OutputRoot containing:
    01_PRE\mpclaim_s_d_list.txt
    01_PRE\mpclaim_s_d_<disk>.txt + PathCount
    02_DURING\mpclaim_s_d_<disk>.txt + PathCount
    03_POST\mpclaim_s_d_<disk>.txt + PathCount
    04_EVENTS\SystemEvents.txt
    ActionLog.txt
    RunSummary.txt (includes PASS/FAIL for ExpectedPrePost → ExpectedDuring → ExpectedPrePost)

.SAFETY
  VT / Pre-Prod ONLY. Run during a controlled window. The script re-enables the device in a finally block.
  Always confirm you have out-of-band access (iDRAC) before testing on physical hosts.

. Example:
  .\mpio_pathcount_evidence.ps1 `
  -WatchMpioDisk 0 `
  -InstanceIdToDrop 'QEBDRV\FCOE2&PCI_80801077&SUBSYS_000F1077&REV_02\5&12CC0087&0&5005C300' `
  -DisableSeconds 60 `
  -ExpectedPrePost 4 `
  -ExpectedDuring 2
#>

#>

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  [Parameter(Mandatory=$true)]
  [int]$WatchMpioDisk,

  [Parameter(Mandatory=$true)]
  [string]$InstanceIdToDrop,

  [int]$DisableSeconds = 60,

  [string]$OutputRoot = "D:\Hardware_Testing\MPIO_PathDrop",

  # Default expectation for a 4-path config when dropping one HBA/function
  [int]$ExpectedDuring = 2,
  [int]$ExpectedPrePost = 4
)

# -----------------------------
# Helpers
# -----------------------------
function Assert-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p  = New-Object Security.Principal.WindowsPrincipal($id)
  if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
    throw "Run in elevated PowerShell (Run as Administrator)."
  }
}

function Ensure-Dir([string]$p){
  New-Item -ItemType Directory -Path $p -Force | Out-Null
}

function Log([string]$msg){
  $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
  $line = "$ts :: $msg"
  $line | Out-File -FilePath $script:ActionLog -Append -Encoding utf8 -Force
  Write-Host $line
}

function Invoke-Mpclaim {
  param(
    [Parameter(Mandatory=$true)]
    [string[]]$MpclaimArgs
  )

  $exe = Join-Path $env:windir "System32\mpclaim.exe"
  if(-not (Test-Path $exe)){ throw "mpclaim.exe not found at $exe" }

  # Capture stdout + stderr deterministically.
  $out = & $exe @MpclaimArgs 2>&1

  # Important: mpclaim sometimes returns an array of lines already; normalize to string.
  ($out | Out-String -Width 400).TrimEnd()
}

function Get-PathCountFromDetail([string]$detailText){
  # Prefer the explicit header if present:
  # "MPIO Disk0: 04 Paths, Round Robin..."
  $m = [regex]::Match($detailText, 'MPIO\s+Disk\d+:\s+(\d+)\s+Paths', 'IgnoreCase')
  if($m.Success){ return [int]$m.Groups[1].Value }

  # Otherwise count Path ID lines: e.g. "0000000077050001 Active/Optimized ..."
  $pathLines = [regex]::Matches($detailText, '(?m)^\s*[0-9A-Fa-f]{16}\s+').Count
  if($pathLines -gt 0){ return $pathLines }

  return -1
}

function Capture-SystemEvents([string]$dir, [datetime]$start, [datetime]$end){
  Ensure-Dir $dir
  Log "EVENTS: $start -> $end"

  $out = Join-Path $dir "SystemEvents.txt"
  $providerRegex = 'MPIO|MSDSM|StorPort|Disk|Kernel-PnP|qefcoe|fcoe'

  try {
    $events =
      Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=$start; EndTime=$end} -ErrorAction SilentlyContinue |
      Where-Object { $_.ProviderName -match $providerRegex } |
      Select-Object TimeCreated,ProviderName,Id,LevelDisplayName,Message |
      Sort-Object TimeCreated

    if(-not $events){
      "No matching events found. Provider filter: $providerRegex`r`nWindow: $start -> $end" |
        Out-File -FilePath $out -Encoding utf8 -Force
    } else {
      $events | Format-List * | Out-File -FilePath $out -Encoding utf8 -Force
    }
  } catch {
    ("WARN: event capture failed: " + $_.Exception.Message) | Out-File -FilePath $out -Encoding utf8 -Force
  }
}

function Capture-State([string]$dir, [string]$label){
  Ensure-Dir $dir
  Log "CAPTURE: $label"

  # Target device snapshot (helps defend the test: what exactly did we disable?)
  try {
    Get-PnpDevice -InstanceId $InstanceIdToDrop -ErrorAction Stop |
      Format-List * |
      Out-File (Join-Path $dir "TargetDevice.txt") -Encoding utf8 -Force

    Get-PnpDeviceProperty -InstanceId $InstanceIdToDrop -KeyName 'DEVPKEY_Device_LocationInfo' -ErrorAction SilentlyContinue |
      Format-List * |
      Out-File (Join-Path $dir "TargetDevice_LocationInfo.txt") -Encoding utf8 -Force
  } catch {
    ("ERROR capturing PnP target: " + $_.Exception.Message) |
      Out-File (Join-Path $dir "TargetDevice_ERROR.txt") -Encoding utf8 -Force
  }

  # mpclaim list
  $listText = Invoke-Mpclaim -MpclaimArgs @('-s','-d')
  $listPath = Join-Path $dir "mpclaim_s_d_list.txt"
  $listText | Out-File -FilePath $listPath -Encoding utf8 -Force

  # mpclaim detail for watched disk
  $detailText = Invoke-Mpclaim -MpclaimArgs @('-s','-d',"$WatchMpioDisk")
  $detailPath = Join-Path $dir ("mpclaim_s_d_{0}.txt" -f $WatchMpioDisk)
  $detailText | Out-File -FilePath $detailPath -Encoding utf8 -Force

  # Extract path count
  $count = Get-PathCountFromDetail $detailText
  ("PathCount={0}" -f $count) | Out-File -FilePath (Join-Path $dir ("PathCount_Disk{0}.txt" -f $WatchMpioDisk)) -Encoding utf8 -Force

  return [pscustomobject]@{
    Label     = $label
    PathCount = $count
    Detail    = $detailPath
    List      = $listPath
  }
}

# -----------------------------
# MAIN
# -----------------------------
Assert-Admin

# Validate mpclaim exists
$mp = Join-Path $env:windir "System32\mpclaim.exe"
if(-not (Test-Path $mp)){
  throw "mpclaim.exe not found at $mp. Ensure MPIO feature/tools are installed."
}

# Validate target PnP device exists
$dev = Get-PnpDevice -InstanceId $InstanceIdToDrop -ErrorAction Stop
$loc = (Get-PnpDeviceProperty -InstanceId $InstanceIdToDrop -KeyName 'DEVPKEY_Device_LocationInfo' -ErrorAction SilentlyContinue).Data

Ensure-Dir $OutputRoot
$ts  = Get-Date -Format "yyyyMMdd_HHmmss"
$run = Join-Path $OutputRoot ("MPIO_PathCount_{0}_{1}_Disk{2}" -f $env:COMPUTERNAME, $ts, $WatchMpioDisk)
Ensure-Dir $run

$script:ActionLog = Join-Path $run "ActionLog.txt"
Log "Run folder: $run"
Log "WatchMpioDisk=$WatchMpioDisk | DisableSeconds=$DisableSeconds"
Log "Target: $($dev.FriendlyName) | $InstanceIdToDrop | $loc"
Log "Expectation: PRE/POST=$ExpectedPrePost, DURING=$ExpectedDuring"

$summaryPath = Join-Path $run "RunSummary.txt"
@(
  "Server:          $env:COMPUTERNAME"
  "Start:           $(Get-Date -Format o)"
  "Watch MPIO Disk: $WatchMpioDisk"
  "DisableSeconds:  $DisableSeconds"
  ""
  "PnP Target:"
  "  FriendlyName: $($dev.FriendlyName)"
  "  InstanceId:   $InstanceIdToDrop"
  "  LocationInfo: $loc"
  ""
  "Acceptance (MPIO only):"
  "  Expect PRE/POST PathCount = $ExpectedPrePost"
  "  Expect DURING  PathCount  = $ExpectedDuring"
  ""
  "Note:"
  "  Service continuity to be validated separately using approved canary method."
) | Out-File -FilePath $summaryPath -Encoding utf8 -Force

$evtStart = (Get-Date).AddMinutes(-2)

# PRE
$pre = Capture-State -dir (Join-Path $run "01_PRE") -label "PRE"

try {
  Log "DISABLING PnP device: $InstanceIdToDrop"
  if($PSCmdlet.ShouldProcess($InstanceIdToDrop, "Disable-PnpDevice")){
    Disable-PnpDevice -InstanceId $InstanceIdToDrop -Confirm:$false -ErrorAction Stop | Out-Null
  }

  Start-Sleep -Seconds 10

  # DURING
  $during = Capture-State -dir (Join-Path $run "02_DURING") -label "DURING"

  $hold = [Math]::Max(0, $DisableSeconds - 10)
  if($hold -gt 0){
    Log "Holding disabled for $hold seconds..."
    Start-Sleep -Seconds $hold
  }
}
finally {
  Log "ENABLING PnP device: $InstanceIdToDrop"
  try {
    if($PSCmdlet.ShouldProcess($InstanceIdToDrop, "Enable-PnpDevice")){
      Enable-PnpDevice -InstanceId $InstanceIdToDrop -Confirm:$false -ErrorAction Stop | Out-Null
    }
  } catch {
    Log "ERROR: Enable-PnpDevice failed: $($_.Exception.Message)"
  }

  Start-Sleep -Seconds 10

  # POST
  $post = Capture-State -dir (Join-Path $run "03_POST") -label "POST"
}

$evtEnd = (Get-Date).AddMinutes(2)
Capture-SystemEvents -dir (Join-Path $run "04_EVENTS") -start $evtStart -end $evtEnd

# Decide pass/fail (MPIO-only)
$mpioPass =
  ($pre.PathCount    -eq $ExpectedPrePost) -and
  ($during.PathCount -eq $ExpectedDuring) -and
  ($post.PathCount   -eq $ExpectedPrePost)

$decision = if($mpioPass){ "PASS" } else { "FAIL" }

Add-Content -Path $summaryPath -Encoding utf8 -Value ""
Add-Content -Path $summaryPath -Encoding utf8 -Value "Results:"
Add-Content -Path $summaryPath -Encoding utf8 -Value ("  PRE    PathCount = {0} ({1})" -f $pre.PathCount, $pre.Detail)
Add-Content -Path $summaryPath -Encoding utf8 -Value ("  DURING PathCount = {0} ({1})" -f $during.PathCount, $during.Detail)
Add-Content -Path $summaryPath -Encoding utf8 -Value ("  POST   PathCount = {0} ({1})" -f $post.PathCount, $post.Detail)
Add-Content -Path $summaryPath -Encoding utf8 -Value ""
Add-Content -Path $summaryPath -Encoding utf8 -Value ("MPIO Evidence Verdict: {0}" -f $decision)
Add-Content -Path $summaryPath -Encoding utf8 -Value "(If PathCount = -1, parsing failed; open the mpclaim_s_d_<disk>.txt files directly.)"

Log "DONE. MPIO Verdict: $decision"
Write-Host ""
Write-Host "Run folder: $run"
Write-Host "Summary:    $summaryPath"
