﻿<# 
.SYNOPSIS
    Deploy a new tnsnames.ora to a list of servers, backing up the existing file first.

.DESCRIPTION
    Reads a list of server names from a text file, connects via admin shares (e.g. \\SERVER\D$),
    backs up any existing tnsnames.ora with a timestamped .bak suffix, then copies a new
    local tnsnames.ora to each server.

    Run from an elevated PowerShell session / ISE with admin rights across the target servers.
#>

# ================= USER CONFIG =================

# Text file with one server name per line (no UNC, just hostnames)
$ServerListFile  = "C:\temp\QCAD\VT\Oracle\Oracle_VT_servers.txt"

# Local path to the new tnsnames.ora you want to deploy
$LocalTnsFile    = "C:\temp\QCAD\VT\Oracle\tnsnames.ora"

# Remote folder (via admin share) that contains tnsnames.ora on each server
# Adjust this to match your environment (D$\oracle\... if needed)
# $RemoteTnsFolder = "D$\oracle\product\19.0.0\client_1\network\admin"
$RemoteTnsFolder = "D$\oracle\product\11.2.0\client_1\network\admin"

# Log file on your machine
$LogFile         = "C:\temp\QCAD\VT\Oracle\Deploy-Tnsnames-final.log"

# =================================================

# Helper: write to console + log at the same time
function Write-Log {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$timestamp] [$Level] $Message"
    Write-Host $line
    $line | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

# Start of run
"========== Run started $(Get-Date -Format "yyyy-MM-dd HH:mm:ss") ==========" | Out-File $LogFile -Encoding UTF8

# Basic sanity checks
if (-not (Test-Path $ServerListFile)) {
    Write-Log "Server list file not found: $ServerListFile" "ERROR"
    return
}

if (-not (Test-Path $LocalTnsFile)) {
    Write-Log "Local tnsnames.ora not found: $LocalTnsFile" "ERROR"
    return
}

$Servers       = Get-Content $ServerListFile | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
$BackupStamp   = Get-Date -Format "yyyyMMdd_HHmmss"

foreach ($Server in $Servers) {
    $Server = $Server.Trim()
    if ([string]::IsNullOrWhiteSpace($Server)) { continue }

    $RemoteFolder = "\\$Server\$RemoteTnsFolder"
    $RemoteFile   = Join-Path $RemoteFolder "tnsnames.ora"

    Write-Log "[$Server] Processing. Remote folder: $RemoteFolder"

    if (-not (Test-Path $RemoteFolder)) {
        Write-Log "[$Server] Remote folder not reachable: $RemoteFolder" "ERROR"
        continue
    }

    try {
        # Backup existing tnsnames.ora if present
        if (Test-Path $RemoteFile) {
            $BackupFile = "$RemoteFile.$BackupStamp.bak"
            Copy-Item -Path $RemoteFile -Destination $BackupFile -ErrorAction Stop
            Write-Log "[$Server] Backed up existing tnsnames.ora to: $BackupFile"
        }
        else {
            Write-Log "[$Server] No existing tnsnames.ora to back up (file not found)"
        }

        # Deploy new tnsnames.ora
        Copy-Item -Path $LocalTnsFile -Destination $RemoteFile -Force -ErrorAction Stop
        Write-Log "[$Server] Deployed new tnsnames.ora to: $RemoteFile"
    }
    catch {
        Write-Log "[$Server] ERROR during copy: $($_.Exception.Message)" "ERROR"
        continue
    }
}

"========== Run finished $(Get-Date -Format "yyyy-MM-dd HH:mm:ss") ==========" | Out-File $LogFile -Append -Encoding UTF8
Write-Host "All done. Log written to $LogFile"
