﻿# -----------------------------
# SETTINGS (EDIT THESE)
# -----------------------------
$NicNames     = @("SLOT 1A Port 1", "SLOT 1A Port 2")  # <-- update if needed
$DownSeconds  = 12000
$UpSeconds    = 400

# -----------------------------
# OUTPUT + WORKER SCRIPT
# -----------------------------
$Root = "D:\Hardware_Testing\RAC_Failover"
New-Item -Path $Root -ItemType Directory -Force | Out-Null

$stamp   = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath = Join-Path $Root "NICFailover_$env:COMPUTERNAME`_$stamp.log"
$ps1Path = Join-Path $Root "NICFailover_$env:COMPUTERNAME`_$stamp.ps1"

$nicListLiteral = ($NicNames | ForEach-Object { '"' + $_.Replace('"','""') + '"' }) -join ","

@"
`$ErrorActionPreference = 'Stop'

function Log([string]`$m){
  `$ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
  "`$ts :: `$m" | Out-File -FilePath "$logPath" -Append -Encoding UTF8
}

function RunCmd([string]`$c){
  Log "RUN: `$c"
  cmd.exe /c `$c 2>&1 | ForEach-Object { Log "  `$($_)" }
}

`$NicNames    = @($nicListLiteral)
`$DownSeconds = $DownSeconds
`$UpSeconds   = $UpSeconds

Log "=== START ==="
Log ("NICs: " + (`$NicNames -join ", "))
RunCmd "mpclaim -s -d 0"

try {
  Log "Disabling NICs..."
  foreach(`$n in `$NicNames){
    Log "Disable-NetAdapter -Name '`$n'"
    Disable-NetAdapter -Name `$n -Confirm:`$false
  }

  Log "Sleeping (down) `$DownSeconds s..."
  Start-Sleep -Seconds `$DownSeconds
  RunCmd "mpclaim -s -d 0"
}
finally {
  Log "Re-enabling NICs (safety)..."
  foreach(`$n in `$NicNames){
    Log "Enable-NetAdapter -Name '`$n'"
    Enable-NetAdapter -Name `$n -Confirm:`$false -ErrorAction SilentlyContinue
  }
}

Log "Sleeping (up) `$UpSeconds s..."
Start-Sleep -Seconds `$UpSeconds
RunCmd "mpclaim -s -d 0"

Log "=== COMPLETE ==="
"@ | Set-Content -Path $ps1Path -Encoding UTF8

# -----------------------------
# CREATE + RUN TASK AS SYSTEM
# -----------------------------
$taskName = "QCAD_RAC_PublicNICFailover_$stamp"

# Ensure module available
Import-Module ScheduledTasks -ErrorAction Stop

$action  = New-ScheduledTaskAction -Execute "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" `
  -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$ps1Path`""

# Trigger a minute from now (but we’ll also Start-ScheduledTask immediately)
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)

# Run as SYSTEM with highest privileges
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
  -ExecutionTimeLimit (New-TimeSpan -Hours 1) -StartWhenAvailable

$task = New-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -Settings $settings

try {
  Register-ScheduledTask -TaskName $taskName -InputObject $task -Force | Out-Null
  Start-ScheduledTask -TaskName $taskName

  Write-Host "Created + started scheduled task: $taskName" -ForegroundColor Green
  Write-Host "Worker script: $ps1Path"
  Write-Host "Log file:      $logPath"
  Write-Host ""
  Write-Host "Check status:" -ForegroundColor Yellow
  Write-Host "  Get-ScheduledTask -TaskName $taskName | Get-ScheduledTaskInfo"
  Write-Host "Tail log:" -ForegroundColor Yellow
  Write-Host "  Get-Content -Path `"$logPath`" -Wait"
}
catch {
  Write-Host "FAILED to create/run scheduled task." -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  throw
}
