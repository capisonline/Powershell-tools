﻿<#
.SYNOPSIS
    QCAD Oracle RAC Canary – SQL*Plus poller using a fixed ARL_EVENT canary query, producing an auditable evidence pack per poll.
    This script just automates and repeats standard queries used to test QCAD can communicate with the Primary Oracle node via the SCAN address. 

.DESCRIPTION
    This script provides a repeatable “canary” test used to confirm that Oracle connectivity and basic data retrieval remain healthy
    throughout controlled hardware fault-injection and failover testing. It is intended to run continuously on a VIM server for the
    entire duration of Oracle RAC platform validation activities (NIC team events, MPIO/path events, RAC node failover, and DC/role-change
    validation windows as applicable).

    The canary is deliberately simple: it repeatedly connects, runs a known working query, and disconnects. This validates the database
    service path (client > SCAN/service > listener > database) without requiring application involvement. Note: QCAD application behaviour
    may differ (e.g., long-lived sessions, pooling, retry logic). If the canary remains healthy while the application misbehaves, treat that
    as a signal to investigate application connection handling rather than Oracle availability.

.PURPOSE / WHEN TO USE
    Use this canary during:
      - Baseline health confirmation (before injecting faults)
      - Live fault injection (NIC/MPIO/host events) to confirm continued service availability
      - Controlled RAC node failover windows to capture timing and node transition evidence
      - Inter-DC / Data Guard test windows (as approved) to observe connectivity impact and recovery timing
      - Monitoring validation (SCOM raise/clear) by correlating poll timestamps with alerts

.USAGE (OPERATOR WORKFLOW)
    1) Start this script BEFORE any hardware fault injection to establish a clean baseline (10–15 minutes recommended).
    2) Begin the planned fault-injection activity on the Primary Oracle cluster (or approved test target).
    3) Observe console status (OK/FAIL) during the test. On any FAIL:
         - capture the poll timestamp,
         - open the matching *_stdout.log for the first ORA-/SP2- line,
         - correlate with SCOM alert raise/clear times and the test action log.
    4) Continue polling through recovery so you capture both the failure and the clear/recovery behaviour.
    5) Retain the entire output folder as part of the evidence pack for the test window.

.CRITICAL DESIGN CHOICES
    1) Canary query executed VERBATIM:
       - The ARL_EVENT canary query is executed exactly as provided by QCAD.
       - No TO_DATE / TO_CHAR / NLS manipulation is applied.
       - This avoids environment-specific Oracle NLS date parsing issues and ensures the canary behaves exactly like the known-working
         manual SQL*Plus operator check.

    2) RAC node identity captured without V$ privileges:
       - Each poll captures the servicing RAC instance and physical node hostname using:
           sys_context('USERENV','INSTANCE_NAME') || ',' || sys_context('USERENV','SERVER_HOST')
         Example output:
           vtcad1,polpcadorapr01
       - This provides auditable node-level evidence for RAC failover timing without requiring SELECT on V$ views (avoids ORA-00942).

    3) Evidence-first approach:
       - The script does not attempt to interpret “business correctness”. It preserves raw outputs so they can be reviewed later and used in
         post-incident / post-test evidence packs, monitoring validation, and root-cause analysis.

.WHAT THIS SCRIPT VALIDATES
    When run during fault injection, this canary helps validate:
      - Connectivity: new sessions can be established to the target service on a repeatable interval.
      - Query execution: the canary query can execute successfully and return rows (or return zero rows without errors).
      - RAC behaviour: which instance/node serviced each poll (instance + hostname captured per poll in stdout and summary CSV).
      - Monitoring behaviour: ability to correlate failures and recoveries to SCOM alert raise/clear timing and health monitor pathways.
      - Recovery timing: bounded outage characteristics for the specific injected fault (when OK>FAIL>OK occurs).

.SUCCESS / FAILURE LOGIC
    - A poll is marked FAIL if:
        * SQL*Plus returns a non-zero exit code, OR
        * Captured output contains ORA-#### or SP2-#### errors.
    - Otherwise the poll is marked OK.

.OUTPUTS (EVIDENCE PACK)
    Per poll (one set each interval):
      1) *_results.csv
         - Spools the canary query output (comma-separated via "set colsep ,").
         - Raw proof of “query executed and returned output” at that poll time.

      2) *_stdout.log
         - Full SQL*Plus stdout/stderr for that poll, including:
             ---CANARY_RAC_NODE--- marker and the instance,host line
             ORA-/SP2- error details when present
         - Primary artifact for troubleshooting and correlation.

      3) *.sql
         - The exact SQL*Plus command file executed for that poll (reproducible/auditable).

    Per run (single index file):
      - Canary_Summary_<alias>_<timestamp>.csv
        Columns:
          PollTime, Target, Success, DurationMs, ExitCode,
          RacInstance, RacHost,
          StdoutLog, ResultsFile, SqlFile,
          ErrorSnippet (first ORA-/SP2- line)
        This is the quickest way to identify failure windows and link them to test actions and SCOM alerts.

.OPERATIONAL GUIDANCE
    - Use short polling (e.g. 10 seconds) during fault injection to capture raise/clear behaviour.
    - Keep the canary running through BOTH the injected fault and the recovery/clear window.
    - Store the output folder as part of the formal evidence pack for the change/test window.
    - Post-processing ideas (outside this script):
        * verify rows/timestamps continue to update across failover windows
        * calculate time-to-fail and time-to-recover per fault type
        * correlate poll timestamps to SCOM raise/clear and operator actions

.SECURITY NOTE
    This script may contain hardcoded credentials for controlled test execution.
    Remove credentials before sharing outside the approved operational team, and store any credentialed variant in a restricted location.

.PREREQUISITES
    - Oracle client installed (sqlplus.exe available)
    - Working TNS configuration for the target alias (TNS_ADMIN set if required)
    - Network connectivity to the Oracle service endpoints

.PARAMETER NOTES (via variables in this script)
    - $TnsAlias: Oracle TNS alias to target (e.g. PRDSCAN / POLSCAN / VTCAD)
    - $CanaryQuery: Fixed ARL_EVENT canary query (verbatim)
    - $IntervalSeconds / $DurationMinutes: Poll frequency and total run duration
    - $OutDir: Evidence output directory

.AUTHOR
    Rogers.Steven2@police.qld.gov.au
#>


# -----------------------------
# SETTINGS
# -----------------------------
$TnsAlias        = "vtcad"
$SqlPlusPath     = "sqlplus.exe"   # or full path to sqlplus.exe
$OutDir          = "D:\temp\Steve\Oracle_Hardware_Failtesting\16-01-2025"
$IntervalSeconds = 5
$DurationMinutes = 600

# QUERY (verbatim) –just update the date!                                                             update the date!
$CanaryQuery = "select event_datetime, callsign, callsign_status from ARL_EVENT where event_datetime > '01/01/2026' order by event_datetime desc;"

# Optional: set TNS_ADMIN explicitly if required on this host
$TnsAdmin = $null

# -----------------------------
# HARDCODED CREDS (REMOVE BEFORE SHARING)
# -----------------------------
$OracleUser = "VIMADMIN"
$OraclePass = "V1madm1nVT13"

# -----------------------------
# PREP
# -----------------------------
New-Item -Path $OutDir -ItemType Directory -Force | Out-Null
if ($TnsAdmin) { $env:TNS_ADMIN = $TnsAdmin }

try { $null = & $SqlPlusPath -V 2>$null } 
catch { throw "sqlplus not found. Set `$SqlPlusPath to the full path (e.g. D:\oracle\product\...\bin\sqlplus.exe)." }

$runStamp   = Get-Date -Format "yyyyMMdd_HHmmss"
$summaryCsv = Join-Path $OutDir ("Canary_Summary_{0}_{1}.csv" -f $TnsAlias, $runStamp)
"PollTime,Target,Success,DurationMs,ExitCode,RacInstance,RacHost,StdoutLog,ResultsFile,SqlFile,ErrorSnippet" |
  Out-File -FilePath $summaryCsv -Encoding utf8 -Force

# grab ORA-* & SP2* errors - if any reported review at these links:
# SP2*: https://docs.oracle.com/en/database/oracle/oracle-database/19/sqpug/SQL-Plus-error-messages.html#GUID-26D886EC-9FA3-4CFE-A017-1C913B7A7065 
# ORA-*: https://docs.oracle.com/en/error-help/db/ora-index.html
function Get-ErrorSnippet {
    param([string]$Text)
    $m1 = [regex]::Match($Text, "ORA-\d+:[^\r\n]+")
    if ($m1.Success) { return ($m1.Value -replace '"','""') }
    $m2 = [regex]::Match($Text, "SP2-\d+:[^\r\n]+")
    if ($m2.Success) { return ($m2.Value -replace '"','""') }
    return ""
}

function New-CanarySqlText {
    param(
        [string]$ResultsFilePath,
        [string]$Query
    )

    # Force query to ONE line + ensure semicolon
    $q = ($Query -replace "`r?`n"," ").Trim()
    if (-not $q.EndsWith(";")) { $q = $q + ";" }

@"
set echo off
set termout on
set feedback off
set verify off
set trimspool on
set linesize 4000
set tab off

prompt ---CANARY_POLL_START---
select systimestamp from dual;

prompt ---CANARY_RAC_NODE---
set heading off
set pagesize 0
select sys_context('USERENV','INSTANCE_NAME')||','||sys_context('USERENV','SERVER_HOST') from dual;
set heading on
set pagesize 5000

prompt ---CANARY_QUERY---
set colsep ,
spool "$ResultsFilePath"
$q
spool off

prompt ---CANARY_POLL_END---
exit;
"@
}

function Parse-RacNodeFromOutput {
    param([string]$Text)

    $racInstanceName = ""
    $racHostName     = ""

    $lines = $Text -split "(`r`n|`n|`r)"
    for ($i=0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match "---CANARY_RAC_NODE---") {
            for ($j=$i+1; $j -lt [Math]::Min($i+20, $lines.Count); $j++) {
                $l = $lines[$j].Trim()
                if (-not $l) { continue }
                if ($l -match "SYS_CONTEXT") { continue }
                if ($l -match "^-{3,}") { continue }

                # Expect: instance,host
                if ($l -match ",") {
                    $parts = $l.Split(",",2)
                    $racInstanceName = $parts[0].Trim()
                    $racHostName     = $parts[1].Trim()
                    break
                }
            }
            break
        }
    }

    return [pscustomobject]@{
        InstanceName = $racInstanceName
        HostName     = $racHostName
    }
}

Write-Host "Starting SQL*Plus canary -> $TnsAlias" -ForegroundColor Cyan
Write-Host "Interval: $IntervalSeconds sec | Duration: $DurationMinutes min"
Write-Host "OutDir: $OutDir"
Write-Host "Summary: $summaryCsv`n"

$endTime = (Get-Date).AddMinutes($DurationMinutes)

while ((Get-Date) -lt $endTime) {

    $pollTime = Get-Date
    $stamp    = $pollTime.ToString("yyyyMMdd_HHmmss_fff")

    $sqlFile     = Join-Path $OutDir ("Canary_{0}_{1}.sql" -f $TnsAlias, $stamp)
    $stdoutLog   = Join-Path $OutDir ("Canary_{0}_{1}_stdout.log" -f $TnsAlias, $stamp)
    $resultsFile = Join-Path $OutDir ("Canary_{0}_{1}_results.csv" -f $TnsAlias, $stamp)

    $sqlText = New-CanarySqlText -ResultsFilePath $resultsFile -Query $CanaryQuery
    $sqlText | Out-File -FilePath $sqlFile -Encoding ascii -Force

    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    $exitCode    = 0
    $success     = $true
    $errSnippet  = ""
    $racInstance = ""
    $racHost     = ""

    try {
        # Keep creds out of command-line args: use stdin + /nolog
        $stdin = @"
connect $OracleUser/$OraclePass@$TnsAlias
@$sqlFile
"@

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $SqlPlusPath
        $psi.Arguments = "-s /nolog"
        $psi.RedirectStandardInput  = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow  = $true
        if ($TnsAdmin) { $psi.EnvironmentVariables["TNS_ADMIN"] = $TnsAdmin }

        $p = New-Object System.Diagnostics.Process
        $p.StartInfo = $psi
        [void]$p.Start()

        $p.StandardInput.WriteLine($stdin)
        $p.StandardInput.Close()

        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()

        $p.WaitForExit()
        $exitCode = $p.ExitCode
        $sw.Stop()

        $combined = $stdout + "`r`n" + $stderr
        $combined | Out-File -FilePath $stdoutLog -Encoding utf8 -Force

        # Parse RAC node identity from SYS_CONTEXT output
        $rac = Parse-RacNodeFromOutput -Text $combined
        $racInstance = $rac.InstanceName
        $racHost     = $rac.HostName

        # Determine success/failure
        if ($exitCode -ne 0 -or $combined -match "ORA-\d+" -or $combined -match "SP2-\d+") {
            $success = $false
        }

        $errSnippet = Get-ErrorSnippet -Text $combined
        if (-not $errSnippet -and -not $success) {
            $errSnippet = ("ExitCode={0}" -f $exitCode) -replace '"','""'
        }
    }
    catch {
        $sw.Stop()
        $success = $false
        $exitCode = -1
        $errSnippet = (($_.Exception.Message) -replace '"','""')
        "ERROR: $($_.Exception.Message)" | Out-File -FilePath $stdoutLog -Encoding utf8 -Force
    }

    $durationMs = [math]::Round($sw.Elapsed.TotalMilliseconds,0)

    $successText = "No"
    $statusText  = "FAIL"
    $color       = "Red"
    if ($success) { $successText = "Yes"; $statusText = "OK"; $color = "Green" }

    $csvLine = '{0},{1},{2},{3},{4},{5},{6},"{7}","{8}","{9}","{10}"' -f `
        $pollTime.ToString("yyyy-MM-dd HH:mm:ss.fff"), `
        $TnsAlias, `
        $successText, `
        $durationMs, `
        $exitCode, `
        $racInstance, `
        $racHost, `
        $stdoutLog, `
        $resultsFile, `
        $sqlFile, `
        $errSnippet

    $csvLine | Out-File -FilePath $summaryCsv -Append -Encoding utf8

    Write-Host ("[{0}] {1} ({2} ms) | {3}@{4} -> {5}" -f `
        $pollTime.ToString("HH:mm:ss.fff"), $statusText, $durationMs, $racInstance, $racHost, $resultsFile) `
        -ForegroundColor $color

    Start-Sleep -Seconds $IntervalSeconds
}

Write-Host ("`nCompleted. Summary CSV: {0}" -f $summaryCsv) -ForegroundColor Cyan
