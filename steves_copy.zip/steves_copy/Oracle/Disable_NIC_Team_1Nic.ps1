﻿<#
.SYNOPSIS
    QCAD PROD Oracle Hardware Testing - P2-3 NIC Team Member Fail Test (single link)

.DESCRIPTION
    Time-boxed disable/re-enable of ONE LBFO team member (SwitchIndependent/Dynamic), with evidence logging.
    Designed to continue executing even if the operator is disconnected (e.g., RDP drop) by launching a child
    PowerShell process that performs the test independently of the ISE session.

    Evidence captured:
      - Pre/during/post: Get-NetLbfoTeam / Get-NetLbfoTeamMember / Get-NetLbfoTeamNic
      - System event log slice around the test window (Nlbfo/NDIS/Net providers)
      - Action log with timestamps
      - Revert attempts on exit (best effort)

.QUICK START
    1) Edit ONLY the variables in the "EDIT THESE" block.
    2) Run from PowerShell ISE "as Administrator".
    3) Script creates an evidence folder and writes logs there.
    4) It will disable the chosen team member for the specified duration, then re-enable it.

.NOTES
    - Do NOT use variable name $host (PowerShell automatic read-only variable collision).
    - Uses LBFO cmdlets (Get/Disable/Enable-NetLbfoTeamMember) available on Windows Server with LBFO.
#>

# -----------------------------
# EDIT THESE (5 variables)
# -----------------------------
$EvidenceRoot        = "C:\temp\QCAD\PR\Hardware_Testing\Evidence\NIC"
$TeamNameToTest      = "Public Network"   # "Public Network" or "Private Network"
$MemberNameToDisable = "SLOT 1A Port 2"   # EXACT member name from Get-NetLbfoTeamMember
$DisableSeconds      = 60                 # Time-box: how long to keep it disabled
$PostWaitSeconds     = 30                 # Wait after re-enable to capture recovery

# -----------------------------
# Optional: safety rails
# -----------------------------
$RequireAdmin        = $true
$AlsoCaptureNetIP    = $true   # capture IP config of team NICs
$AlsoCaptureRoutes   = $true   # capture routes
$EventLogMinutesBack = 10       # capture System events from X minutes before start until X minutes after end

# -----------------------------
# Internal - do not edit
# -----------------------------
$serverName = $env:COMPUTERNAME
$runStamp   = Get-Date -Format "yyyyMMdd_HHmmss"
$runDir     = Join-Path $EvidenceRoot ("{0}_{1}_{2}" -f $serverName, ($TeamNameToTest -replace '[\\/:*?"<>| ]','_'), $runStamp)
New-Item -Path $runDir -ItemType Directory -Force | Out-Null

$actionLog  = Join-Path $runDir "ActionLog.txt"
$preDir     = Join-Path $runDir "01_Pre"
$midDir     = Join-Path $runDir "02_During"
$postDir    = Join-Path $runDir "03_Post"
$evtDir     = Join-Path $runDir "04_EventLogs"
New-Item $preDir,$midDir,$postDir,$evtDir -ItemType Directory -Force | Out-Null

function Write-Action {
    param([string]$Message)
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
    $line = "$ts :: $Message"
    $line | Out-File -FilePath $actionLog -Append -Encoding utf8
    Write-Host $line
}

function Assert-Admin {
    $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
               ).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
    if (-not $isAdmin) { throw "Must run as Administrator." }
}

function Capture-State {
    param(
        [string]$PhaseDir,
        [string]$PhaseName
    )

    Write-Action "Capturing state: $PhaseName"

    # Teams
    Get-NetLbfoTeam | Format-List * | Out-File (Join-Path $PhaseDir "NetLbfoTeam.txt") -Encoding utf8
    Get-NetLbfoTeamMember | Sort-Object Team,Name | Format-List * | Out-File (Join-Path $PhaseDir "NetLbfoTeamMember.txt") -Encoding utf8
    Get-NetLbfoTeamNic | Sort-Object Team,Name | Format-List * | Out-File (Join-Path $PhaseDir "NetLbfoTeamNic.txt") -Encoding utf8

    if ($AlsoCaptureNetIP) {
        ipconfig /all | Out-File (Join-Path $PhaseDir "ipconfig_all.txt") -Encoding utf8
        Get-NetIPConfiguration | Format-List * | Out-File (Join-Path $PhaseDir "NetIPConfiguration.txt") -Encoding utf8
    }

    if ($AlsoCaptureRoutes) {
        route print | Out-File (Join-Path $PhaseDir "route_print.txt") -Encoding utf8
        Get-NetRoute | Sort-Object -Property DestinationPrefix | Format-Table -AutoSize |
            Out-File (Join-Path $PhaseDir "NetRoute.txt") -Encoding utf8
    }
}

function Capture-SystemEvents {
    param(
        [datetime]$StartTime,
        [datetime]$EndTime
    )

    Write-Action "Capturing System events: $StartTime -> $EndTime"

    $out = Join-Path $evtDir "SystemEvents.txt"

    # Filter to likely relevant providers
    $providers = @("Microsoft-Windows-Nlbfo","Microsoft-Windows-NDIS","Microsoft-Windows-NetworkProfile","Microsoft-Windows-TCPIP","e1iexpress","bnxtnd","ixgbe","qfle3","qevbda","Netwtw","Microsoft-Windows-Kernel-PnP")

    $events = Get-WinEvent -FilterHashtable @{
        LogName   = "System"
        StartTime = $StartTime
        EndTime   = $EndTime
    } -ErrorAction SilentlyContinue

    $events |
      Where-Object { $providers -contains $_.ProviderName -or $_.ProviderName -match "Nlbfo|NDIS|Net|TCPIP" } |
      Select-Object TimeCreated,ProviderName,Id,LevelDisplayName,Message |
      Format-List * |
      Out-File -FilePath $out -Encoding utf8
}

# -----------------------------
# Worker script content (runs in a separate PowerShell process)
# -----------------------------
$workerPath = Join-Path $runDir "Worker_NIC_Test.ps1"

$workerContent = @"
`$ErrorActionPreference = 'Stop'

function Write-Action([string]`$Message,[string]`$LogPath) {
    `$ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff')
    "`$ts :: `$Message" | Out-File -FilePath `$LogPath -Append -Encoding utf8
}

function Capture-State([string]`$PhaseDir,[string]`$PhaseName,[string]`$LogPath,[bool]`$CapIP,[bool]`$CapRoutes) {
    Write-Action "Capturing state: `$PhaseName" `$LogPath

    Get-NetLbfoTeam | Format-List * | Out-File (Join-Path `$PhaseDir 'NetLbfoTeam.txt') -Encoding utf8
    Get-NetLbfoTeamMember | Sort-Object Team,Name | Format-List * | Out-File (Join-Path `$PhaseDir 'NetLbfoTeamMember.txt') -Encoding utf8
    Get-NetLbfoTeamNic | Sort-Object Team,Name | Format-List * | Out-File (Join-Path `$PhaseDir 'NetLbfoTeamNic.txt') -Encoding utf8

    if (`$CapIP) {
        ipconfig /all | Out-File (Join-Path `$PhaseDir 'ipconfig_all.txt') -Encoding utf8
        Get-NetIPConfiguration | Format-List * | Out-File (Join-Path `$PhaseDir 'NetIPConfiguration.txt') -Encoding utf8
    }

    if (`$CapRoutes) {
        route print | Out-File (Join-Path `$PhaseDir 'route_print.txt') -Encoding utf8
        Get-NetRoute | Sort-Object DestinationPrefix | Format-Table -AutoSize | Out-File (Join-Path `$PhaseDir 'NetRoute.txt') -Encoding utf8
    }
}

# Inputs injected from parent
`$RunDir              = '$runDir'
`$ActionLog           = '$actionLog'
`$PreDir              = '$preDir'
`$MidDir              = '$midDir'
`$PostDir             = '$postDir'
`$EvtDir              = '$evtDir'
`$TeamNameToTest      = '$TeamNameToTest'
`$MemberNameToDisable = '$MemberNameToDisable'
`$DisableSeconds      = $DisableSeconds
`$PostWaitSeconds     = $PostWaitSeconds
`$CapIP               = $($AlsoCaptureNetIP.ToString().ToLower())
`$CapRoutes           = $($AlsoCaptureRoutes.ToString().ToLower())
`$EventLogMinutesBack = $EventLogMinutesBack

`$testStart = Get-Date
Write-Action "WORKER START: Team=`$TeamNameToTest | Member=`$MemberNameToDisable | DisableSeconds=`$DisableSeconds" `$ActionLog

# Validate team exists
`$team = Get-NetLbfoTeam -Name `$TeamNameToTest -ErrorAction Stop
Write-Action "Team status: Name=`$(`$team.Name) Status=`$(`$team.Status) Mode=`$(`$team.TeamingMode) LB=`$(`$team.LoadBalancingAlgorithm)" `$ActionLog

# Validate member exists in team
`$member = Get-NetLbfoTeamMember -Team `$TeamNameToTest | Where-Object { `$_.Name -eq `$MemberNameToDisable }
if (-not `$member) { throw "Member '`$MemberNameToDisable' not found in team '`$TeamNameToTest'." }

# Capture PRE state
Capture-State `$PreDir 'PRE' `$ActionLog `$CapIP `$CapRoutes

# Best-effort revert on any exit
`$reverted = `$false
try {
    Write-Action "DISABLING team member: `$MemberNameToDisable (Team=`$TeamNameToTest)" `$ActionLog
    Disable-NetLbfoTeamMember -Name `$MemberNameToDisable -Team `$TeamNameToTest -Confirm:`$false -ErrorAction Stop

    Write-Action "Sleeping for disable window: `$DisableSeconds seconds" `$ActionLog
    Start-Sleep -Seconds `$DisableSeconds

    # Capture DURING state
    Capture-State `$MidDir 'DURING (member disabled)' `$ActionLog `$CapIP `$CapRoutes
}
finally {
    try {
        Write-Action "RE-ENABLING team member: `$MemberNameToDisable (Team=`$TeamNameToTest)" `$ActionLog
        Enable-NetLbfoTeamMember -Name `$MemberNameToDisable -Team `$TeamNameToTest -Confirm:`$false -ErrorAction Stop
        `$reverted = `$true
        Write-Action "Re-enable command issued OK." `$ActionLog
    } catch {
        Write-Action ("FAILED to re-enable member: " + `$_.Exception.Message) `$ActionLog
    }
}

Write-Action "Post-wait for recovery: `$PostWaitSeconds seconds" `$ActionLog
Start-Sleep -Seconds `$PostWaitSeconds

# Capture POST state
Capture-State `$PostDir 'POST (member re-enabled)' `$ActionLog `$CapIP `$CapRoutes

`$testEnd = Get-Date

# Capture System events around window
`$evtStart = `$testStart.AddMinutes(-1 * `$EventLogMinutesBack)
`$evtEnd   = `$testEnd.AddMinutes(`$EventLogMinutesBack)

Write-Action "Capturing System events: `$evtStart -> `$evtEnd" `$ActionLog

`$providers = @('Microsoft-Windows-Nlbfo','Microsoft-Windows-NDIS','Microsoft-Windows-NetworkProfile','Microsoft-Windows-TCPIP','Microsoft-Windows-Kernel-PnP')
`$events = Get-WinEvent -FilterHashtable @{ LogName='System'; StartTime=`$evtStart; EndTime=`$evtEnd } -ErrorAction SilentlyContinue
`$events |
  Where-Object { `$providers -contains `$_.ProviderName -or `$_.ProviderName -match 'Nlbfo|NDIS|Net|TCPIP' } |
  Select-Object TimeCreated,ProviderName,Id,LevelDisplayName,Message |
  Format-List * |
  Out-File -FilePath (Join-Path `$EvtDir 'SystemEvents.txt') -Encoding utf8

Write-Action "WORKER END: reverted=`$reverted" `$ActionLog
"@

$workerContent | Out-File -FilePath $workerPath -Encoding utf8 -Force

# -----------------------------
# Parent execution
# -----------------------------
try {
    if ($RequireAdmin) { Assert-Admin }

    Write-Action "Run folder: $runDir"
    Write-Action "Preparing worker script: $workerPath"
    Write-Action "Target: Team='$TeamNameToTest' | Member='$MemberNameToDisable' | DisableSeconds=$DisableSeconds | PostWaitSeconds=$PostWaitSeconds"

    # Quick sanity log of current state in parent too
    Capture-State -PhaseDir $preDir -PhaseName "PRE (parent snapshot)"

    # Launch worker in separate process so it continues if ISE/RDP drops
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
    $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$workerPath`""
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow  = $true

    Write-Action "Launching worker process (independent of ISE session)..."
    $p = [System.Diagnostics.Process]::Start($psi)

    Write-Action "Worker PID: $($p.Id)"
    Write-Action "NOTE: You can disconnect; worker continues. Evidence will be written to: $runDir"
    Write-Action "Monitoring: tail the ActionLog.txt in another window if needed."

    # Optional: wait and show completion status in ISE if we stay connected
    $p.WaitForExit()
    Write-Action "Worker exited with code: $($p.ExitCode)"
    Write-Action "Completed. Review evidence folder: $runDir"
}
catch {
    Write-Action ("FATAL: " + $_.Exception.Message)
    throw
}
