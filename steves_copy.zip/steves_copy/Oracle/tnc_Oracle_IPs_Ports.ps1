﻿<#
.SYNOPSIS
  Test-NetConnection from a list of source servers to a list of targets (IP/host + port).

.INPUTS
  Servers file: one hostname per line
  Targets file: one target per line in any of these formats:
    10.1.2.3:1521
    10.1.2.3,1521
    10.1.2.3 1521
    oracle-scan.my.domain:1521
  Blank lines and lines starting with # are ignored.

.OUTPUTS
  CSV with one row per (SourceServer, Target, Port)
  Log file for progress/errors

.NOTES
  Requires WinRM/Invoke-Command access from where you run this to each source server.

  .\tnc_Oracle_IPs_Ports.ps1 -ServerListPath C:\temp\QCAD\VT\Oracle\Oracle_VT_servers.txt -TargetListPath C:\temp\QCAD\VT\Oracle\Oracle_IP_List-ports.txt

  t
#>
<#
Test-NetConnection from a list of source servers to a list of targets (IP/host + port).
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$ServerListPath,

    [Parameter(Mandatory=$true)]
    [string]$TargetListPath,

    [string]$OutDir = "C:\temp\QCAD\NetTests",

    [int]$TimeoutSeconds = 5,

    [switch]$PromptForCredential
)

# -------------------- Setup --------------------
$null = New-Item -ItemType Directory -Path $OutDir -Force

$stamp   = Get-Date -Format "yyyyMMdd_HHmmss"
$csvPath = Join-Path $OutDir "TNC_Results_$stamp.csv"
$logPath = Join-Path $OutDir "TNC_Run_$stamp.log"

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )
    $line = "{0} [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Write-Host $line
    $line | Out-File -FilePath $logPath -Append -Encoding UTF8 -ErrorAction SilentlyContinue
}

function Get-CleanLines {
    param([string]$Path)
    Get-Content -Path $Path -ErrorAction Stop |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and -not $_.StartsWith("#") }
}

function Parse-TargetLine {
    param([string]$Line)

    # Accept: host:port OR host,port OR host port
    $m = [regex]::Match($Line, '^(?<thost>[^,\s:]+)\s*([,:]|\s)\s*(?<tport>\d{1,5})$')
    if (-not $m.Success) { return $null }

    $targetHost = $m.Groups["thost"].Value.Trim()
    $port       = [int]$m.Groups["tport"].Value

    if ($port -lt 1 -or $port -gt 65535) { return $null }

    [pscustomobject]@{
        TargetHost = $targetHost
        Port       = $port
        Raw        = $Line
    }
}

# -------------------- Read inputs --------------------
if (-not (Test-Path $ServerListPath)) { throw "Server list not found: $ServerListPath" }
if (-not (Test-Path $TargetListPath)) { throw "Target list not found: $TargetListPath" }

$servers = Get-CleanLines -Path $ServerListPath
if (-not $servers -or $servers.Count -eq 0) { throw "No servers found in $ServerListPath" }

$targets = foreach ($line in (Get-CleanLines -Path $TargetListPath)) {
    $t = Parse-TargetLine -Line $line
    if ($null -eq $t) {
        Write-Log "Skipping invalid target line: '$line' (expected host:port, host,port, or 'host port')" "WARN"
        continue
    }
    $t
}
if (-not $targets -or $targets.Count -eq 0) { throw "No valid targets found in $TargetListPath" }

$cred = $null
if ($PromptForCredential) {
    $cred = Get-Credential -Message "Enter an account that can PS-Remote (WinRM) to the source servers"
}

Write-Log "Servers: $($servers.Count) | Targets: $($targets.Count) | Total tests: $($servers.Count * $targets.Count)"
Write-Log "CSV will be written to: $csvPath"
Write-Log "Log will be written to: $logPath"

# -------------------- Remote test block --------------------
$remoteScript = {
    param(
        [string]$TargetHost,
        [int]$TargetPort
    )

    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"

    try {
        $r = Test-NetConnection -ComputerName $TargetHost -Port $TargetPort -InformationLevel Detailed -WarningAction SilentlyContinue

        $remoteAddr = $null
        try { $remoteAddr = $r.RemoteAddress } catch {}

        [pscustomobject]@{
            Timestamp               = $ts
            SourceServer            = $env:COMPUTERNAME
            TargetHost              = $TargetHost
            TargetPort              = $TargetPort
            RemoteAddress           = $remoteAddr
            NameResolutionSucceeded = $r.NameResolutionSucceeded
            PingSucceeded           = $r.PingSucceeded
            TcpTestSucceeded        = $r.TcpTestSucceeded
            PingReplyDetailsMs      = $r.PingReplyDetails.RoundtripTime
            Error                   = $null
        }
    }
    catch {
        [pscustomobject]@{
            Timestamp               = $ts
            SourceServer            = $env:COMPUTERNAME
            TargetHost              = $TargetHost
            TargetPort              = $TargetPort
            RemoteAddress           = $null
            NameResolutionSucceeded = $null
            PingSucceeded           = $null
            TcpTestSucceeded        = $false
            PingReplyDetailsMs      = $null
            Error                   = $_.Exception.Message
        }
    }
}

# -------------------- Execute --------------------
$results = New-Object System.Collections.Generic.List[object]
$total = $servers.Count * $targets.Count
$idx = 0

foreach ($s in $servers) {

    # WinRM check
    try {
        if ($cred) { Test-WSMan -ComputerName $s -Credential $cred -ErrorAction Stop | Out-Null }
        else       { Test-WSMan -ComputerName $s -ErrorAction Stop | Out-Null }
    }
    catch {
        Write-Log "WinRM not reachable on '$s' from this machine. Skipping server. Error: $($_.Exception.Message)" "ERROR"
        foreach ($t in $targets) {
            $idx++
            $results.Add([pscustomobject]@{
                Timestamp               = (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff")
                SourceServer            = $s
                TargetHost              = $t.TargetHost
                TargetPort              = $t.Port
                RemoteAddress           = $null
                NameResolutionSucceeded = $null
                PingSucceeded           = $null
                TcpTestSucceeded        = $false
                PingReplyDetailsMs      = $null
                Error                   = "WinRM not reachable from runner"
            })
        }
        continue
    }

    foreach ($t in $targets) {
        $idx++
        Write-Progress -Activity "Testing connectivity (TNC)" -Status "$idx / $total" -PercentComplete ([int](($idx / $total) * 100))

        try {
            $invokeParams = @{
                ComputerName = $s
                ScriptBlock  = $remoteScript
                ArgumentList = @($t.TargetHost, $t.Port)
                ErrorAction  = "Stop"
            }
            if ($cred) { $invokeParams.Credential = $cred }

            $row = Invoke-Command @invokeParams
            foreach ($r in $row) { $results.Add($r) }

            if ($row.TcpTestSucceeded -eq $true) {
                Write-Log "OK    $s -> $($t.TargetHost):$($t.Port)"
            } else {
                $err = $row.Error
                if (-not $err) { $err = "TCP failed" }
                Write-Log "FAIL  $s -> $($t.TargetHost):$($t.Port) :: $err" "WARN"
            }
        }
        catch {
            Write-Log "ERROR $s -> $($t.TargetHost):$($t.Port) :: $($_.Exception.Message)" "ERROR"
            $results.Add([pscustomobject]@{
                Timestamp               = (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff")
                SourceServer            = $s
                TargetHost              = $t.TargetHost
                TargetPort              = $t.Port
                RemoteAddress           = $null
                NameResolutionSucceeded = $null
                PingSucceeded           = $null
                TcpTestSucceeded        = $false
                PingReplyDetailsMs      = $null
                Error                   = $_.Exception.Message
            })
        }
    }
}

# -------------------- Save --------------------
$results |
    Sort-Object SourceServer, TargetHost, TargetPort |
    Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

Write-Progress -Activity "Testing connectivity (TNC)" -Completed
Write-Log "Done. Wrote $($results.Count) rows to $csvPath"
Write-Log "Log: $logPath"
