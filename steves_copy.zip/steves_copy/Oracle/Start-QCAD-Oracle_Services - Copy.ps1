﻿<#
.SYNOPSIS
    Starts QCAD/Vision services for Oracle backend cutover recovery,
    matching the services stopped by the STOP script:
    - VDW, EventProcessor, MessageBroker, IntegrityChecker on VAS/CCM
    - All VIM services (incl. PoliceLinkWeb app pool)
    - Vision Web services on VWS and VCS
    - AVLUpdater on APL

    NOTE: Does NOT manage FortekCoreService (FCS) or its dependents.
          Use the dedicated FCS restart script for that.
#>

[CmdletBinding()]
param(
    [string]$ServerListPath = "C:\temp\QCAD\VT\Oracle\Oracle_VT_servers.txt",
    [string]$LogRoot        = "C:\temp\QCAD\VT\Oracle\VT_REPOINTS\"
)

# -----------------------------
# Setup logging
# -----------------------------
if (-not (Test-Path $LogRoot)) {
    New-Item -ItemType Directory -Path $LogRoot -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath   = Join-Path $LogRoot "QCAD_OracleCutover_Start_$timestamp.log"

Start-Transcript -Path $logPath -Force

Write-Host "QCAD Oracle Cutover START script starting..." -ForegroundColor Cyan
Write-Host "Server list : $ServerListPath" -ForegroundColor Cyan
Write-Host "Log file    : $logPath" -ForegroundColor Cyan

if (-not (Test-Path $ServerListPath)) {
    Write-Host "Server list file not found: $ServerListPath" -ForegroundColor Red
    Stop-Transcript
    return
}

$servers = Get-Content -Path $ServerListPath | Where-Object { $_ -and $_.Trim() -ne "" }

if (-not $servers) {
    Write-Host "No servers found in $ServerListPath" -ForegroundColor Red
    Stop-Transcript
    return
}

# -----------------------------
# Helper functions
# -----------------------------

function Start-RemoteService {
    param(
        [Parameter(Mandatory)][string]$Server,
        [Parameter(Mandatory)][string]$ServiceName
    )

    Write-Host "[$Server] Starting service '$ServiceName'..." -ForegroundColor Yellow
    try {
        $result = Invoke-Command -ComputerName $Server -ScriptBlock {
            param($svcName)
            try {
                $svc = Get-Service -Name $svcName -ErrorAction Stop
                if ($svc.Status -ne 'Running') {
                    Start-Service -Name $svcName -ErrorAction Stop
                    return "OK"
                } else {
                    return "ALREADY_RUNNING"
                }
            } catch {
                return "ERROR: $($_.Exception.Message)"
            }
        } -ArgumentList $ServiceName -ErrorAction Stop

        switch -Wildcard ($result) {
            "OK" {
                Write-Host "[$Server] Service '$ServiceName' started." -ForegroundColor Green
            }
            "ALREADY_RUNNING" {
                Write-Host "[$Server] Service '$ServiceName' already running." -ForegroundColor DarkYellow
            }
            "ERROR:*" {
                Write-Host "[$Server] FAILED to start '$ServiceName' : $result" -ForegroundColor Red
            }
            default {
                Write-Host "[$Server] Service '$ServiceName' not found or unknown result: $result" -ForegroundColor DarkYellow
            }
        }
    } catch {
        Write-Host "[$Server] REMOTING ERROR starting '$ServiceName' : $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Start-RemoteAppPool {
    param(
        [Parameter(Mandatory)][string]$Server,
        [Parameter(Mandatory)][string]$AppPoolName
    )

    Write-Host "[$Server] Starting app pool '$AppPoolName'..." -ForegroundColor Yellow
    try {
        $result = Invoke-Command -ComputerName $Server -ScriptBlock {
            param($poolName)
            try {
                Import-Module WebAdministration -ErrorAction Stop

                $state = (Get-WebAppPoolState -Name $poolName -ErrorAction Stop).Value
                if ($state -ne 'Started') {
                    Start-WebAppPool -Name $poolName -ErrorAction Stop
                    return "OK"
                } else {
                    return "ALREADY_RUNNING"
                }
            } catch {
                return "ERROR: $($_.Exception.Message)"
            }
        } -ArgumentList $AppPoolName -ErrorAction Stop

        switch -Wildcard ($result) {
            "OK" {
                Write-Host "[$Server] App pool '$AppPoolName' started." -ForegroundColor Green
            }
            "ALREADY_RUNNING" {
                Write-Host "[$Server] App pool '$AppPoolName' already started." -ForegroundColor DarkYellow
            }
            "ERROR:*" {
                Write-Host "[$Server] FAILED to start app pool '$AppPoolName' : $result" -ForegroundColor Red
            }
            default {
                Write-Host "[$Server] App pool '$AppPoolName' not found or unknown result: $result" -ForegroundColor DarkYellow
            }
        }
    } catch {
        Write-Host "[$Server] REMOTING ERROR starting app pool '$AppPoolName' : $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Test-RemoteServiceRunning {
    param(
        [Parameter(Mandatory)][string]$Server,
        [Parameter(Mandatory)][string]$ServiceName
    )

    try {
        $status = Invoke-Command -ComputerName $Server -ScriptBlock {
            param($svcName)
            try {
                (Get-Service -Name $svcName -ErrorAction Stop).Status.ToString()
            } catch {
                "NOTFOUND"
            }
        } -ArgumentList $ServiceName -ErrorAction Stop

        switch ($status) {
            'Running' {
                Write-Host "[$Server] OK   - Service '$ServiceName' is Running." -ForegroundColor Green
                return $true
            }
            'Stopped' {
                Write-Host "[$Server] FAIL - Service '$ServiceName' is Stopped." -ForegroundColor Red
                return $false
            }
            'NOTFOUND' {
                Write-Host "[$Server] WARN - Service '$ServiceName' not found." -ForegroundColor DarkYellow
                return $true  # non-blocking
            }
            default {
                Write-Host "[$Server] FAIL - Service '$ServiceName' is $status." -ForegroundColor Red
                return $false
            }
        }
    } catch {
        Write-Host "[$Server] FAIL - Error checking service '$ServiceName' : $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

function Test-RemoteAppPoolRunning {
    param(
        [Parameter(Mandatory)][string]$Server,
        [Parameter(Mandatory)][string]$AppPoolName
    )

    try {
        $state = Invoke-Command -ComputerName $Server -ScriptBlock {
            param($poolName)
            try {
                Import-Module WebAdministration -ErrorAction Stop
                (Get-WebAppPoolState -Name $poolName -ErrorAction Stop).Value
            } catch {
                "NOTFOUND"
            }
        } -ArgumentList $AppPoolName -ErrorAction Stop

        switch ($state) {
            'Started' {
                Write-Host "[$Server] OK   - App pool '$AppPoolName' is Started." -ForegroundColor Green
                return $true
            }
            'Stopped' {
                Write-Host "[$Server] FAIL - App pool '$AppPoolName' is Stopped." -ForegroundColor Red
                return $false
            }
            'NOTFOUND' {
                Write-Host "[$Server] WARN - App pool '$AppPoolName' not found." -ForegroundColor DarkYellow
                return $true  # non-blocking
            }
            default {
                Write-Host "[$Server] FAIL - App pool '$AppPoolName' is $state." -ForegroundColor Red
                return $false
            }
        }
    } catch {
        Write-Host "[$Server] FAIL - Error checking app pool '$AppPoolName' : $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# -----------------------------
# START PHASE
# -----------------------------

# Start roles in this order so core (VAS/CCM) is up before outer tiers
$roleOrder = @("APL","VCS","VWS","VIM","CCM","VAS")

foreach ($role in $roleOrder) {

    $matchingServers = $servers | Where-Object { $_ -like "*$role*" }

    if (-not $matchingServers) {
        Write-Host "No servers found matching role '$role'." -ForegroundColor DarkYellow
        continue
    }

    Write-Host "==== Starting services for role: $role ====" -ForegroundColor Cyan

    foreach ($server in $matchingServers) {

        Write-Host "---- Server: $server ----" -ForegroundColor Magenta

        # Get EnvName from the remote server
        $envName = $null
        try {
            $envName = Invoke-Command -ComputerName $server -ScriptBlock { $env:EnvName } -ErrorAction Stop
        } catch {
            Write-Host "[$server] ERROR - Unable to retrieve EnvName: $($_.Exception.Message)" -ForegroundColor Red
            continue
        }

        if (-not $envName) {
            Write-Host "[$server] ERROR - EnvName environment variable is empty; skipping." -ForegroundColor Red
            continue
        }

        switch ($role) {

            "VAS" {
                Start-RemoteService -Server $server -ServiceName ("*_VDW"              -f $envName)
                Start-RemoteService -Server $server -ServiceName ("*_EventProcessor"   -f $envName)
                Start-RemoteService -Server $server -ServiceName ("*_MessageBroker"    -f $envName)
                Start-RemoteService -Server $server -ServiceName ("*_IntegrityChecker" -f $envName)
            }

            "CCM" {
                # Treat CCM like VAS for Oracle-related Vision services (may not exist on all CCM boxes)
              #  Start-RemoteService -Server $server -ServiceName ("*_VDW"              -f $envName)
              #  Start-RemoteService -Server $server -ServiceName ("*_EventProcessor"   -f $envName)
              #  Start-RemoteService -Server $server -ServiceName ("*_MessageBroker"    -f $envName)
                Start-RemoteService -Server $server -ServiceName ("*_IntegrityChecker" -f $envName)
            }

            "VIM" {
                Start-RemoteService -Server $server -ServiceName ("*_ARL"           -f $envName)
                Start-RemoteService -Server $server -ServiceName ("*_Audit"         -f $envName)
                Start-RemoteService -Server $server -ServiceName ("*_Occurrence"    -f $envName)
                Start-RemoteService -Server $server -ServiceName ("*_OfficerDetail" -f $envName)
                Start-RemoteService -Server $server -ServiceName ("*_PoliceLinkVIM" -f $envName)
                Start-RemoteAppPool -Server $server -AppPoolName ("*_PoliceLinkWeb_AppPool" -f $envName)
            }

            "VWS" {
                Start-RemoteAppPool -Server $server -AppPoolName ("*_VWS_Admin"  -f $envName)
                Start-RemoteAppPool -Server $server -AppPoolName ("*_VWS_Server" -f $envName)
                Start-RemoteAppPool -Server $server -AppPoolName "VISIONWebService"
            }

            "VCS" {
                Start-RemoteAppPool -Server $server -AppPoolName ("*_VWS_Server" -f $envName)
                Start-RemoteAppPool -Server $server -AppPoolName "VISIONWebService"
                Start-RemoteAppPool -Server $server -AppPoolName "MapXtremeAppPool"
            }

            "APL" {
                Start-RemoteService -Server $server -ServiceName ("*_AVLUpdater" -f $envName)
            }
        }
    }
}

# -----------------------------
# VERIFICATION PHASE
# -----------------------------

Write-Host ""
Write-Host "==== Verification: all targeted services/app pools are Running/Started ====" -ForegroundColor Cyan

$globalAllOk = $true

foreach ($role in $roleOrder) {

    $matchingServers = $servers | Where-Object { $_ -like "*$role*" }

    if (-not $matchingServers) { continue }

    Write-Host "---- Verify role: $role ----" -ForegroundColor Magenta

    foreach ($server in $matchingServers) {

        $envName = $null
        try {
            $envName = Invoke-Command -ComputerName $server -ScriptBlock { $env:EnvName } -ErrorAction Stop
        } catch {
            Write-Host "[$server] FAIL - Unable to retrieve EnvName for verification: $($_.Exception.Message)" -ForegroundColor Red
            $globalAllOk = $false
            continue
        }

        if (-not $envName) {
            Write-Host "[$server] FAIL - EnvName is empty during verification." -ForegroundColor Red
            $globalAllOk = $false
            continue
        }

        switch ($role) {

            "VAS" {
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_VDW"              -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_EventProcessor"   -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_MessageBroker"    -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_IntegrityChecker" -f $envName))) { $globalAllOk = $false }
            }

            "CCM" {
               # if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_VDW"              -f $envName))) { $globalAllOk = $false }
               # if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_EventProcessor"   -f $envName))) { $globalAllOk = $false }
               # if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_MessageBroker"    -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_IntegrityChecker" -f $envName))) { $globalAllOk = $false }
            }

            "VIM" {
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_ARL"           -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_Audit"         -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_Occurrence"    -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_OfficerDetail" -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_PoliceLinkVIM" -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteAppPoolRunning -Server $server -AppPoolName ("*_PoliceLinkWeb_AppPool" -f $envName))) { $globalAllOk = $false }
            }

            "VWS" {
                if (-not (Test-RemoteAppPoolRunning -Server $server -AppPoolName ("*_VWS_Admin"  -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteAppPoolRunning -Server $server -AppPoolName ("*_VWS_Server" -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteAppPoolRunning -Server $server -AppPoolName "VISIONWebService")) { $globalAllOk = $false }
            }

            "VCS" {
                if (-not (Test-RemoteAppPoolRunning -Server $server -AppPoolName ("*_VWS_Server" -f $envName))) { $globalAllOk = $false }
                if (-not (Test-RemoteAppPoolRunning -Server $server -AppPoolName "VISIONWebService")) { $globalAllOk = $false }
                if (-not (Test-RemoteAppPoolRunning -Server $server -AppPoolName "MapXtremeAppPool")) { $globalAllOk = $false }
            }

            "APL" {
                if (-not (Test-RemoteServiceRunning -Server $server -ServiceName ("*_AVLUpdater" -f $envName))) { $globalAllOk = $false }
            }
        }
    }
}

Write-Host ""
if ($globalAllOk) {
    Write-Host "GLOBAL RESULT: All targeted QCAD services and web components are Running/Started." -ForegroundColor Green
    Write-Host "Environment has been successfully brought back online (per Fujitsu email scope)." -ForegroundColor Green
} else {
    Write-Host "GLOBAL RESULT: One or more services/app pools are NOT Running/Started." -ForegroundColor Red
    Write-Host "Investigate the failures above before declaring the environment fully available." -ForegroundColor Red
}

Write-Host ""
Write-Host "QCAD Oracle Cutover START script completed." -ForegroundColor Cyan
Write-Host "Transcript log: $logPath" -ForegroundColor Cyan

Stop-Transcript
