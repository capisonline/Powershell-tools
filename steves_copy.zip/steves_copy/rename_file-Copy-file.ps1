﻿
# File paths 
# Change this to where you've backed up machine.config
$sourceFilePath = "C:\temp\QCAD\BA\Issues\test-rename-copy.txt"

# Read server list from text file
$servers = Get-Content "C:\temp\scripts\server_list.txt"

foreach ($server in $servers) {
    # Renaming existing machine.config file to machine.config.original
    # Change this to the machine.config file IE: C:\Windows\Microsoft.NET\Framework\v2.0.50727\CONFIG\machine.config 
    # And then: C:\Windows\Microsoft.NET\Framework\v2.0.50727\CONFIG\machine.config_original
    Invoke-Command -ComputerName $server -ScriptBlock {
        Rename-Item "C:\temp\feature_list.txt" "C:\temp\feature_list-testing-file_rename-latest.txt" -ErrorAction SilentlyContinue
    }

    # Copying machine.config from local PC to specified location on the server
    # change this to the location you're copying to IE: "\\$server\C$\Windows\Microsoft.NET\Framework\v2.0.50727\CONFIG\"
    Copy-Item -Path $sourceFilePath -Destination "\\$server\C$\temp\" -Force
}
