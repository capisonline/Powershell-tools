#requires -Version 5.1
<#
.SYNOPSIS
    Triage Azure DevOps pipeline failures from a downloaded logs folder.

.DESCRIPTION
    Scans an extracted ADO logs folder, clusters failing steps by error fingerprint,
    maps each cluster to the YAML displayName + inline script that produced it,
    and writes three CSVs: cluster summary, individual hits, and run metadata.
    Console output is a tight Format-Table of the top clusters only -- full detail
    lives in the CSVs so you can sort/filter in Excel.

    Recognises the canonical ADO log markers documented at
    https://learn.microsoft.com/en-us/azure/devops/pipelines/scripts/logging-commands
    plus common runtime failure patterns (PowerShell exit codes, .NET stack traces,
    WinRM, MSBuild, "Cannot find any service", exit code N).

.PARAMETER Path
    Folder containing extracted ADO logs. Defaults to current directory.

.PARAMETER PipelineFile
    Path to the pipeline YAML. Auto-detected when omitted -- checks for
    azure-pipelines-expanded.yaml inside the logs folder first (ADO ships this
    in every log zip), then pipeline.yml beside or above the logs folder.

.PARAMETER Context
    Lines of context to capture around each error (stored in the hits CSV). Default 3.

.PARAMETER ExcludePattern
    Regex of error lines to ignore (e.g. 'is already (stopped|running)').

.PARAMETER ConsoleTopN
    Number of clusters to show in the console table. Default 15.

.PARAMETER CompareWith
    If supplied, compares the analysed run against a baseline and emits a fourth
    CSV (<leaf>_compare_<ts>.csv) plus a console diff summary. Accepts three forms,
    auto-detected:
      - A logs folder path (re-runs analysis against it).
      - An existing *_clusters_*.csv file (loaded directly, no re-analysis).
      - An ADO build ID (numeric). Uses API mode -- requires -Org, -Project, and auth.
    Each cluster is classified as RESOLVED / NEW / PERSISTING / REDUCED / INCREASED.

.PARAMETER BuildId
    ADO build run ID. Switches to API mode: fetches the build's timeline and logs
    via the Azure DevOps REST API instead of reading a local logs folder. Mutually
    exclusive with -Path.

.PARAMETER Org
    ADO organisation name (the slug in https://dev.azure.com/<org>/). Required in API
    mode. Falls back to $env:ADO_ORG if not supplied.

.PARAMETER Project
    ADO project name. Required in API mode. Falls back to $env:ADO_PROJECT if not
    supplied.

.PARAMETER AccessToken
    Entra ID bearer token for API auth (preferred). Acquire with:
        az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv
    Falls back to $env:ADO_ACCESS_TOKEN if not supplied.

.PARAMETER Pat
    Personal Access Token for API auth (compatibility option). Required scope: Build (Read).
    Falls back to $env:ADO_PAT if not supplied. AccessToken takes precedence over Pat.

.OUTPUTS
    Three CSV files written next to the logs folder:
      <leaf>_clusters_<ts>.csv  - one row per cluster (rank, count, servers, sample, YAML line)
      <leaf>_hits_<ts>.csv      - one row per individual error occurrence
      <leaf>_runmeta_<ts>.csv   - single-row run metadata (branch, commit, totals)
    Plus, when -CompareWith is supplied:
      <leaf>_compare_<ts>.csv   - one row per fingerprint with Status + count delta

.EXAMPLE
    .\Get-PipelineErrors.ps1 -Path .\logs_63476

.EXAMPLE
    .\Get-PipelineErrors.ps1 -Path .\logs_63476 -ExcludePattern 'is already stopped'

.EXAMPLE
    .\Get-PipelineErrors.ps1 -Path .\logs_63476 -ConsoleTopN 5 -PipelineFile .\pipeline.yml

.EXAMPLE
    # Compare two runs to verify a fix landed and check for regressions.
    .\Get-PipelineErrors.ps1 -Path .\logs_63489 -CompareWith .\logs_63476

.EXAMPLE
    # Reuse a previously-generated clusters CSV as the baseline (skips re-analysis).
    .\Get-PipelineErrors.ps1 -Path .\logs_63489 -CompareWith .\logs_63476_clusters_20260501_113056.csv

.EXAMPLE
    # API mode: analyse a build directly without downloading logs.
    $env:ADO_ACCESS_TOKEN = (az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv)
    .\Get-PipelineErrors.ps1 -BuildId 63489 -Org qpolice -Project QCAD

.EXAMPLE
    # API mode + compare against a previous build, also via API.
    .\Get-PipelineErrors.ps1 -BuildId 63489 -CompareWith 63476 -Org qpolice -Project QCAD -Pat $env:ADO_PAT
#>
[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$Path,

    [string]$PipelineFile,
    [int]$Context = 3,
    [string]$ExcludePattern,
    [int]$ConsoleTopN = 15,
    [string]$CompareWith,

    # API mode parameters
    [int]$BuildId,
    [string]$Org,
    [string]$Project,
    [string]$AccessToken,
    [string]$Pat
)

$ErrorActionPreference = 'Stop'

# Patterns the ADO agent itself emits, plus common runtime failure indicators.
# Order matters: more specific patterns first so the matched group is meaningful.
$ErrorPatterns = @(
    # ADO formatting markers
    '##\[error\](?<msg>.*)'
    '##vso\[task\.logissue[^\]]*type=error[^\]]*\](?<msg>.*)'
    '##vso\[task\.complete[^\]]*result=Failed[^\]]*\](?<msg>.*)'
    # PowerShell / external command exit codes
    "PowerShell exited with code '(?<msg>\d+)'"
    'exited with code (?<msg>\d+)'
    'terminated with exit code (?<msg>\d+)'
    # .NET / generic exceptions
    '(?<msg>System\.\w+(\.\w+)*Exception:.*)'
    '(?<msg>Unhandled exception.*)'
    # Build tooling
    '(?<msg>error [A-Z]{1,4}\d{3,5}:.*)'      # MSBuild / CSC / TSC style
    '(?<msg>FAILED with exit code \d+)'
    # Remote / networking
    '(?<msg>WinRM cannot complete the operation.*)'
    '(?<msg>The WinRM client cannot process the request.*)'
    # Common script-level failure phrases
    '(?<msg>FAIL(ED)?[:\- ].*)'
    '(?<msg>requires manual assessment.*)'
    # Bare "Error:" prefix at start of a logical line (after optional timestamp / bracketed prefix)
    '(?:^|\]\s*|Z\s*)(?<msg>Error:\s+.*)'
)

# Fingerprint: strip values that vary across hosts so duplicate errors cluster.
function Get-Fingerprint {
    param([string]$Message)
    $fp = $Message
    # Order: most specific to most general so earlier replacements don't get clobbered.
    $fp = $fp -replace '\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b', '<GUID>'
    $fp = $fp -replace '\d{4}-\d{2}-\d{2}[T ]?[\d:.Z]*', '<TS>'
    $fp = $fp -replace '[A-Za-z]:\\[^\s''""]+', '<PATH>'
    $fp = $fp -replace '\\\\[^\s''""]+', '<UNC>'
    $fp = $fp -replace '\b\d{1,3}(?:\.\d{1,3}){3}\b', '<IP>'
    # Hostnames - two common styles. Run hyphenated first (more specific).
    $fp = $fp -replace '\b[A-Z]{2,}(?:-[A-Z0-9]+){1,4}\b', '<HOST>'         # e.g. QPS-APL-VT-01
    $fp = $fp -replace '\b[A-Z]{4,}\d{1,3}\b', '<HOST>'                     # e.g. EGLVCADVASVT01
    $fp = $fp -replace "rabbit@\S+", 'rabbit@<HOST>'
    $fp = $fp -replace '\b\d+\b', '<N>'
    return $fp.Trim().ToLowerInvariant()
}

function Find-LocalErrors {
    param([string]$Root, [int]$ContextLines, [string]$Exclude)

    if (-not (Test-Path $Root)) { throw "Path not found: $Root" }
    $rootFull = (Resolve-Path $Root).Path
    $files = Get-ChildItem -Path $Root -Recurse -File -Filter *.txt -ErrorAction SilentlyContinue
    if (-not $files) { throw "No .txt log files under $Root" }

    $hits = New-Object System.Collections.Generic.List[object]
    $combined = ($ErrorPatterns -join '|')
    # Generic terminator patterns: an "exited with code" line is almost always preceded
    # by the *real* error in the same file. Suppress them when a more specific hit
    # already exists in this file, so they don't dominate the cluster ranking.
    # No ^ anchors -- log lines are timestamped so the pattern won't be at start of line.
    $genericRx = "PowerShell exited with code '\d+'|exited with code \d+|terminated with exit code \d+"

    foreach ($file in $files) {
        $lines = Get-Content -LiteralPath $file.FullName -ErrorAction SilentlyContinue
        if (-not $lines) { continue }

        # Step name resolution:
        #   - if file lives in a subfolder of $Root, step = parent folder name
        #   - if file lives at the root, step = filename minus leading "N_"
        $parent = Split-Path $file.FullName -Parent
        if ((Resolve-Path $parent).Path -eq $rootFull) {
            $step = ($file.BaseName -replace '^\d+_', '')
        }
        else {
            $step = Split-Path $parent -Leaf
        }
        $sub = ($file.BaseName -replace '^\d+_', '')

        $fileHits = New-Object System.Collections.Generic.List[object]
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $line = $lines[$i]
            if ($line -notmatch $combined) { continue }
            if ($Exclude -and $line -match $Exclude) { continue }
            # Skip script-source echo lines (ADO logs the inline PowerShell verbatim).
            if ($line -match '(?:^|\s)(?:script:|Write-Host\s+"|inputs:|targetType:)\s*["'']?') { continue }
            # Skip very long lines (>800 chars) -- almost always script echoes or stack dumps.
            if ($line.Length -gt 800) { continue }

            $start = [Math]::Max(0, $i - $ContextLines)
            $end   = [Math]::Min($lines.Count - 1, $i + $ContextLines)
            $ctx   = ($lines[$start..$end] -join "`n")
            $clean = $line -replace '^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s*', ''

            $fileHits.Add([pscustomobject]@{
                Step        = $step
                SubStep     = $sub
                File        = $file.FullName
                LineNumber  = $i + 1
                Message     = $clean.Trim()
                Context     = $ctx
                Fingerprint = Get-Fingerprint $clean
                IsGeneric   = ($line -match $genericRx)
            })
        }

        # Suppress generic terminators when this file also has a specific hit.
        $hasSpecific = $fileHits | Where-Object { -not $_.IsGeneric } | Select-Object -First 1
        foreach ($h in $fileHits) {
            if ($h.IsGeneric -and $hasSpecific) { continue }
            $hits.Add($h)
        }
    }
    return ,$hits
}

function Get-RunMetadata {
    param([string]$Root)

    # The Checkout step log carries branch / commit / repo metadata that the
    # Initialize Job log does not. Find any "*Checkout*.txt" and extract.
    $checkoutFiles = Get-ChildItem -Path $Root -Recurse -File -Filter "*Checkout*.txt" -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notlike '*Post-job*' } |
        Select-Object -First 1
    if (-not $checkoutFiles) { return $null }

    $content = Get-Content -LiteralPath $checkoutFiles.FullName -Raw -ErrorAction SilentlyContinue
    if (-not $content) { return $null }

    $meta = [pscustomobject]@{
        Repo          = $null
        Branch        = $null
        Commit        = $null
        CommitMessage = $null
    }
    if ($content -match 'Syncing repository:\s+([^\s(]+)') { $meta.Repo = $Matches[1] }
    # Step name embeds the branch: "Checkout Repo.Name@branch to s"
    if ($checkoutFiles.BaseName -match '@([^\s]+) to s') { $meta.Branch = $Matches[1] }
    # Fetch line carries the SHA being checked out.
    if ($content -match '\+([0-9a-f]{40}):refs/remotes/origin/') { $meta.Commit = $Matches[1] }
    if ($content -match 'HEAD is now at [0-9a-f]+\s+(.+)') { $meta.CommitMessage = $Matches[1].Trim() }
    return $meta
}

function Find-PipelineYaml {
    param([string]$LogsRoot, [string]$Explicit)

    if ($Explicit -and (Test-Path $Explicit)) {
        return (Resolve-Path $Explicit).Path
    }
    if ($Explicit) {
        Write-Warning "PipelineFile not found: $Explicit -- falling back to auto-detect"
    }
    # Auto-detect order:
    #   1. azure-pipelines-expanded.yaml inside the logs folder (ADO includes this in
    #      the log zip download -- it's the post-expansion YAML, the source of truth
    #      for *exactly* what ran).
    #   2. pipeline.yml beside or above the logs folder (source repo working copy).
    $parent      = Split-Path $LogsRoot -Parent
    $grandparent = if ($parent) { Split-Path $parent -Parent } else { $null }
    $candidates = @(
        (Join-Path $LogsRoot 'azure-pipelines-expanded.yaml')
        (Join-Path $LogsRoot 'pipeline.yml')
    )
    if ($parent)      { $candidates += (Join-Path $parent      'pipeline.yml') }
    if ($grandparent) { $candidates += (Join-Path $grandparent 'pipeline.yml') }
    foreach ($c in $candidates) {
        if ($c -and (Test-Path $c)) { return (Resolve-Path $c).Path }
    }
    return $null
}

function Get-StepSource {
    param(
        [string]$YamlPath,
        [string]$StepName,    # e.g. "Running Start VisVT_APLParser" or "Modify EGLVCADVASVT01 RabbitMQ_Cluster"
        [string]$ErrorMessage # used to extract the server name for disambiguation
    )

    if (-not $YamlPath -or -not (Test-Path $YamlPath)) { return $null }

    # Cache YAML content per call site (script-scoped).
    if (-not $script:_YamlLines -or $script:_YamlPath -ne $YamlPath) {
        $script:_YamlLines = Get-Content -LiteralPath $YamlPath
        $script:_YamlPath  = $YamlPath
    }
    $lines = $script:_YamlLines

    # Strip "(N)" disambiguator that ADO appends to repeat step names.
    $clean = $StepName -replace '\s*\(\d+\)\s*$', ''
    # The folder name strips the colon present in the YAML displayName.
    # e.g. folder "Running Start VisVT_APLParser" -> YAML "Running: Start VisVT_APLParser"
    $candidates = @($clean, ($clean -replace '^(\S+)\s+', '$1: '))

    # Try to extract the server identifier from the error message ("[QPS-APL-VT-01]" etc).
    $server = $null
    if ($ErrorMessage -match '\[([A-Z][A-Z0-9-]{3,})\]') { $server = $Matches[1] }

    # Locate every line that names the step's displayName.
    # ($matches is an automatic variable in PS; use a different name.)
    $displayHits = @()
    for ($i = 0; $i -lt $lines.Count; $i++) {
        foreach ($cand in $candidates) {
            $escaped = [regex]::Escape($cand)
            if ($lines[$i] -match "displayName:\s*['""]?$escaped['""]?\s*$") {
                $displayHits += $i
                break
            }
        }
    }
    if (-not $displayHits) { return $null }

    # Disambiguate by server: pick the match whose surrounding script (next ~80 lines)
    # contains the literal server name.
    $chosen = $displayHits[0]
    if ($server) {
        foreach ($m in $displayHits) {
            $end = [Math]::Min($lines.Count - 1, $m + 80)
            $window = ($lines[$m..$end] -join "`n")
            if ($window -match [regex]::Escape($server)) { $chosen = $m; break }
        }
    }

    # Find the inline script: next "script:" line within ~30 lines of the displayName.
    $scriptLine = $null
    for ($j = $chosen; $j -lt [Math]::Min($lines.Count, $chosen + 30); $j++) {
        if ($lines[$j] -match '^\s*script:\s*(.*)$') { $scriptLine = $j; break }
    }

    return [pscustomobject]@{
        DisplayLine = $chosen + 1
        ScriptLine  = if ($null -ne $scriptLine) { $scriptLine + 1 } else { $null }
        Snippet     = if ($null -ne $scriptLine) { $lines[$scriptLine] } else { $lines[$chosen] }
    }
}

function Get-ServerFromMessage {
    param([string]$Message)
    # Bracketed hostname like [QPS-APL-VT-01] or [EGLVCADVASVT01]
    if ($Message -match '\[([A-Z][A-Z0-9-]{3,})\]') { return $Matches[1] }
    if ($Message -match "rabbit@([\w-]+)")          { return $Matches[1] }
    return $null
}

function Get-ServiceFromMessage {
    param([string]$Message)
    # Quoted service name like 'VisVT_APLParser' or 'RabbitMQ'
    if ($Message -match "'(VisVT_[A-Za-z_]+|RabbitMQ)'") { return $Matches[1] }
    return $null
}

function Build-ClusterAndHitRows {
    param([object[]]$Hits, [string]$YamlPath)

    $clusters = $Hits | Group-Object Fingerprint | Sort-Object Count -Descending
    $clusterRows = New-Object System.Collections.Generic.List[object]
    $hitRows     = New-Object System.Collections.Generic.List[object]

    $rank = 0
    foreach ($c in $clusters) {
        $rank++
        $sample = $c.Group[0]
        $stepSet = $c.Group | Select-Object -ExpandProperty Step -Unique
        $servers = $c.Group | ForEach-Object { Get-ServerFromMessage $_.Message } | Where-Object { $_ } | Select-Object -Unique
        $service = Get-ServiceFromMessage $sample.Message

        $src = $null
        if ($YamlPath) {
            $src = Get-StepSource -YamlPath $YamlPath -StepName $sample.Step -ErrorMessage $sample.Message
        }

        $clusterRows.Add([pscustomobject]@{
            Rank                  = $rank
            Count                 = $c.Count
            Service               = $service
            AffectedServers       = ($servers -join '; ')
            AffectedServerCount   = $servers.Count
            AffectedSteps         = ($stepSet -join '; ')
            AffectedStepCount     = $stepSet.Count
            SampleMessage         = $sample.Message
            SampleLogFile         = $sample.File
            SampleLogLine         = $sample.LineNumber
            ProducedByYamlFile    = if ($src) { $YamlPath } else { $null }
            ProducedByDisplayLine = if ($src) { $src.DisplayLine } else { $null }
            ProducedByScriptLine  = if ($src) { $src.ScriptLine } else { $null }
            Fingerprint           = $sample.Fingerprint
        })

        foreach ($h in $c.Group) {
            $hitRows.Add([pscustomobject]@{
                ClusterRank = $rank
                Step        = $h.Step
                SubStep     = $h.SubStep
                Server      = (Get-ServerFromMessage $h.Message)
                Service     = (Get-ServiceFromMessage $h.Message)
                Message     = $h.Message
                LogFile     = $h.File
                LogLine     = $h.LineNumber
                Context     = ($h.Context -replace "`r", '' -replace "`n", ' | ')
                Fingerprint = $h.Fingerprint
            })
        }
    }

    return @{ Clusters = $clusterRows; Hits = $hitRows }
}

function Get-ClustersForCompare {
    param(
        [Parameter(Mandatory)] [string]$Source,
        [hashtable]$AdoConfig
    )

    # Auto-detect input form: directory, *.csv file, or numeric build ID.
    if (Test-Path -LiteralPath $Source -PathType Container) {
        # Logs folder -- re-run analysis pipeline against it.
        $oldRoot = (Resolve-Path -LiteralPath $Source).Path
        $oldHits = Find-LocalErrors -Root $oldRoot -ContextLines $Context -Exclude $ExcludePattern
        if (-not $oldHits -or $oldHits.Count -eq 0) {
            return @()
        }
        $oldYaml = Find-PipelineYaml -LogsRoot $oldRoot -Explicit $PipelineFile
        $oldRows = Build-ClusterAndHitRows -Hits $oldHits -YamlPath $oldYaml
        return @($oldRows.Clusters)
    }
    elseif ((Test-Path -LiteralPath $Source -PathType Leaf) -and ($Source -like '*clusters*.csv')) {
        # Existing clusters CSV -- load directly, skip re-analysis.
        $loaded = @(Import-Csv -LiteralPath $Source)
        if ($loaded.Count -eq 0) { return @() }
        if (-not ($loaded[0].PSObject.Properties.Name -contains 'Fingerprint')) {
            throw "Compare requires a clusters.csv with a Fingerprint column. '$Source' is missing this column -- likely an older tool version."
        }
        # Coerce Count and Rank back to integers (Import-Csv returns strings).
        foreach ($row in $loaded) {
            if ($row.Count) { $row.Count = [int]$row.Count }
            if ($row.Rank)  { $row.Rank  = [int]$row.Rank }
        }
        return $loaded
    }
    elseif ($Source -match '^\d+$') {
        # Numeric -- ADO build ID via API mode.
        if (-not $AdoConfig) {
            throw "Build ID compare input ('$Source') requires API mode. Pass -Org / -Project / auth on the main invocation, or use a logs folder path or *_clusters_*.csv instead."
        }
        # Build a baseline config that targets the OLD build id, reusing org/project/auth.
        $baselineConfig = @{}
        foreach ($k in $AdoConfig.Keys) { $baselineConfig[$k] = $AdoConfig[$k] }
        $baselineConfig.BuildId = [int]$Source

        $oldTimeline = Get-AdoBuildTimeline -Config $baselineConfig
        $oldHits = ConvertTo-LogHits -Timeline $oldTimeline -Config $baselineConfig -ContextLines $Context -Exclude $ExcludePattern
        if (-not $oldHits -or $oldHits.Count -eq 0) { return @() }
        # YAML mapping is optional for compare (fingerprints don't depend on it).
        $oldRows = Build-ClusterAndHitRows -Hits $oldHits -YamlPath $null
        return @($oldRows.Clusters)
    }
    else {
        throw "Unrecognised -CompareWith source: '$Source'. Expected a logs folder path, an existing *_clusters_*.csv, or a numeric ADO build ID."
    }
}

function Compare-Runs {
    param(
        [Parameter(Mandatory)] [AllowEmptyCollection()] [object[]]$OldClusters,
        [Parameter(Mandatory)] [AllowEmptyCollection()] [object[]]$NewClusters
    )

    # Build hashtables keyed on fingerprint.
    $oldByFp = @{}
    foreach ($c in $OldClusters) {
        if ($c.Fingerprint) { $oldByFp[$c.Fingerprint] = $c }
    }
    $newByFp = @{}
    foreach ($c in $NewClusters) {
        if ($c.Fingerprint) { $newByFp[$c.Fingerprint] = $c }
    }

    # Union of all fingerprints.
    $allFps = New-Object System.Collections.Generic.HashSet[string]
    foreach ($fp in $oldByFp.Keys) { [void]$allFps.Add($fp) }
    foreach ($fp in $newByFp.Keys) { [void]$allFps.Add($fp) }

    $compareRows = New-Object System.Collections.Generic.List[object]
    foreach ($fp in $allFps) {
        $oldC = $oldByFp[$fp]
        $newC = $newByFp[$fp]

        $oldCount = if ($oldC) { [int]$oldC.Count } else { 0 }
        $newCount = if ($newC) { [int]$newC.Count } else { 0 }

        $status =
            if ($oldC -and -not $newC)         { 'RESOLVED' }
            elseif ($newC -and -not $oldC)     { 'NEW' }
            elseif ($newCount -gt $oldCount)   { 'INCREASED' }
            elseif ($newCount -lt $oldCount)   { 'REDUCED' }
            else                               { 'PERSISTING' }

        # Server delta (split on '; ', filter empties).
        $oldServers = if ($oldC -and $oldC.AffectedServers) { @($oldC.AffectedServers -split '; ' | Where-Object { $_ }) } else { @() }
        $newServers = if ($newC -and $newC.AffectedServers) { @($newC.AffectedServers -split '; ' | Where-Object { $_ }) } else { @() }
        $added   = @($newServers | Where-Object { $_ -notin $oldServers })
        $removed = @($oldServers | Where-Object { $_ -notin $newServers })

        $compareRows.Add([pscustomobject]@{
            Status         = $status
            Fingerprint    = $fp
            OldRank        = if ($oldC) { [int]$oldC.Rank } else { $null }
            NewRank        = if ($newC) { [int]$newC.Rank } else { $null }
            OldCount       = $oldCount
            NewCount       = $newCount
            CountDelta     = $newCount - $oldCount
            SampleMessage  = if ($newC) { $newC.SampleMessage } else { $oldC.SampleMessage }
            OldServers     = ($oldServers -join '; ')
            NewServers     = ($newServers -join '; ')
            ServersAdded   = ($added -join '; ')
            ServersRemoved = ($removed -join '; ')
        })
    }

    # Sort: NEW first (highest signal during iteration), then INCREASED, RESOLVED, REDUCED, PERSISTING.
    # Within each status, sort by combined count descending.
    $statusOrder = @{ 'NEW' = 1; 'INCREASED' = 2; 'RESOLVED' = 3; 'REDUCED' = 4; 'PERSISTING' = 5 }
    $sorted = $compareRows | Sort-Object @{Expression = { $statusOrder[$_.Status] }}, @{Expression = { $_.NewCount + $_.OldCount }; Descending = $true}
    return @($sorted)
}

function Write-CompareConsoleSummary {
    param(
        [Parameter(Mandatory)] [AllowEmptyCollection()] [object[]]$CompareRows,
        [string]$OldLabel,
        [string]$NewLabel
    )

    Write-Host ""
    Write-Host "=== COMPARISON REPORT ===" -ForegroundColor Cyan
    Write-Host ("From: {0}" -f $OldLabel)
    Write-Host ("To:   {0}" -f $NewLabel)
    Write-Host ""

    Write-Host "CLUSTER STATUS SUMMARY" -ForegroundColor Cyan
    Write-Host "----------------------"
    foreach ($status in 'RESOLVED', 'NEW', 'PERSISTING', 'REDUCED', 'INCREASED') {
        $count = @($CompareRows | Where-Object { $_.Status -eq $status }).Count
        $color = switch ($status) {
            'NEW'        { 'Yellow' }
            'INCREASED'  { 'Yellow' }
            'RESOLVED'   { 'Green' }
            default      { 'Gray' }
        }
        Write-Host ("{0,-12}: {1,3}" -f $status, $count) -ForegroundColor $color
    }
    Write-Host ""

    $regressions = @($CompareRows | Where-Object { $_.Status -eq 'NEW' } | Sort-Object NewCount -Descending | Select-Object -First 5)
    if ($regressions.Count -gt 0) {
        Write-Host "TOP NEW CLUSTERS (regressions -- investigate first):" -ForegroundColor Yellow
        $regressions |
            Select-Object @{N='Rank';E={$_.NewRank}},
                          @{N='Count';E={$_.NewCount}},
                          @{N='Sample';E={ if ($_.SampleMessage.Length -gt 90) { $_.SampleMessage.Substring(0,90)+'...' } else { $_.SampleMessage } }} |
            Format-Table -AutoSize | Out-Host
    }
    else {
        Write-Host "No new regressions in this run." -ForegroundColor Green
    }
}

# --- API mode functions ---

function Get-AdoConfig {
    param(
        [int]$BuildId,
        [string]$Org,
        [string]$Project,
        [string]$AccessToken,
        [string]$Pat
    )

    if (-not $BuildId) { return $null }

    if (-not $Org)         { $Org         = $env:ADO_ORG }
    if (-not $Project)     { $Project     = $env:ADO_PROJECT }
    if (-not $AccessToken) { $AccessToken = $env:ADO_ACCESS_TOKEN }
    if (-not $Pat)         { $Pat         = $env:ADO_PAT }

    if (-not $Org)     { throw "API mode requires an organisation. Pass -Org or set `$env:ADO_ORG." }
    if (-not $Project) { throw "API mode requires a project. Pass -Project or set `$env:ADO_PROJECT." }

    $authType  = $null
    $authToken = $null
    if ($AccessToken) {
        $authType  = 'Bearer'
        $authToken = $AccessToken
    }
    elseif ($Pat) {
        $authType  = 'Basic'
        $authToken = $Pat
    }
    else {
        throw @"
API mode requires authentication. Supply one of:
  - Entra ID bearer token via -AccessToken or `$env:ADO_ACCESS_TOKEN
    Acquire with: az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv
  - PAT via -Pat or `$env:ADO_PAT (scope required: Build (Read))
"@
    }

    return @{
        BuildId    = $BuildId
        Org        = $Org
        Project    = $Project
        AuthType   = $authType
        AuthToken  = $authToken
        BaseUrl    = "https://dev.azure.com/$Org/$Project/_apis"
        ApiVersion = '7.1'
    }
}

function Get-AdoAuthHeader {
    param([Parameter(Mandatory)] [hashtable]$Config)

    if ($Config.AuthType -eq 'Bearer') {
        return @{ 'Authorization' = "Bearer $($Config.AuthToken)" }
    }
    if ($Config.AuthType -eq 'Basic') {
        # PAT format: base64 of ":<pat>" (empty username + colon + token).
        $bytes  = [System.Text.Encoding]::UTF8.GetBytes(":" + $Config.AuthToken)
        $base64 = [Convert]::ToBase64String($bytes)
        return @{ 'Authorization' = "Basic $base64" }
    }
    throw "Unknown auth type: $($Config.AuthType)"
}

function Invoke-AdoApi {
    param(
        [Parameter(Mandatory)] [hashtable]$Config,
        [Parameter(Mandatory)] [string]$Url,
        [string]$Accept = 'application/json',
        [int]$MaxRetries = 3
    )

    $headers = Get-AdoAuthHeader -Config $Config
    $headers['Accept'] = $Accept

    # Append api-version if not already in URL.
    if ($Url -notmatch '[?&]api-version=') {
        $sep = if ($Url -match '\?') { '&' } else { '?' }
        $Url = "$Url${sep}api-version=$($Config.ApiVersion)"
    }

    for ($attempt = 0; $attempt -le $MaxRetries; $attempt++) {
        try {
            if ($Accept -eq 'application/json') {
                return Invoke-RestMethod -Uri $Url -Headers $headers -Method Get -ErrorAction Stop
            }
            else {
                # Plain-text endpoints (e.g. logs) need Invoke-WebRequest to get raw content.
                return (Invoke-WebRequest -Uri $Url -Headers $headers -Method Get -ErrorAction Stop).Content
            }
        }
        catch {
            $statusCode = $null
            if ($_.Exception.Response) {
                try { $statusCode = [int]$_.Exception.Response.StatusCode } catch { $statusCode = $null }
            }

            if ($statusCode -eq 429 -and $attempt -lt $MaxRetries) {
                # Rate-limited: honour Retry-After header if present.
                $retryAfter = 10
                try {
                    $hdrVal = $_.Exception.Response.Headers['Retry-After']
                    if ($hdrVal) { $retryAfter = [int]$hdrVal }
                } catch { }
                $backoff = [Math]::Max($retryAfter, [Math]::Pow(2, $attempt))
                Write-Warning "Rate-limited (429); sleeping $backoff seconds before retry..."
                Start-Sleep -Seconds $backoff
                continue
            }

            if ($statusCode -in @(401, 403)) {
                throw "Authentication failed ($statusCode). Check your token has 'Build (Read)' scope and is not expired. URL: $Url"
            }
            if ($statusCode -eq 404) {
                throw "Resource not found ($statusCode). Verify org='$($Config.Org)', project='$($Config.Project)', buildId=$($Config.BuildId). URL: $Url"
            }

            if ($attempt -ge $MaxRetries) {
                throw "ADO API call failed after $($attempt + 1) attempts. URL: $Url. Error: $($_.Exception.Message)"
            }
            Start-Sleep -Seconds ([Math]::Pow(2, $attempt))
        }
    }
}

function Get-AdoBuildMetadata {
    param([Parameter(Mandatory)] [hashtable]$Config)

    $url   = "$($Config.BaseUrl)/build/builds/$($Config.BuildId)"
    $build = Invoke-AdoApi -Config $Config -Url $url

    return [pscustomobject]@{
        Repo          = $build.repository.name
        Branch        = $build.sourceBranch -replace '^refs/heads/', ''
        Commit        = $build.sourceVersion
        CommitMessage = $build.triggerInfo.'ci.message'
        BuildId       = $build.id
        BuildNumber   = $build.buildNumber
        Status        = $build.status
        Result        = $build.result
        QueueTime     = $build.queueTime
        StartTime     = $build.startTime
        FinishTime    = $build.finishTime
        RequestedFor  = if ($build.requestedFor) { $build.requestedFor.displayName } else { $null }
        WebUrl        = if ($build._links -and $build._links.web) { $build._links.web.href } else { $null }
    }
}

function Get-AdoBuildTimeline {
    param([Parameter(Mandatory)] [hashtable]$Config)

    $url      = "$($Config.BaseUrl)/build/builds/$($Config.BuildId)/timeline"
    $timeline = Invoke-AdoApi -Config $Config -Url $url
    if (-not $timeline -or -not $timeline.records) { return @() }
    return @($timeline.records)
}

function Get-AdoLogContent {
    param(
        [Parameter(Mandatory)] [hashtable]$Config,
        [Parameter(Mandatory)] [int]$LogId
    )

    $url = "$($Config.BaseUrl)/build/builds/$($Config.BuildId)/logs/$LogId"
    try {
        return Invoke-AdoApi -Config $Config -Url $url -Accept 'text/plain'
    }
    catch {
        Write-Warning "Failed to fetch log $LogId for build $($Config.BuildId): $($_.Exception.Message)"
        return $null
    }
}

function ConvertTo-LogHits {
    param(
        [Parameter(Mandatory)] [object[]]$Timeline,
        [Parameter(Mandatory)] [hashtable]$Config,
        [int]$ContextLines = 3,
        [string]$Exclude
    )

    $combined  = ($ErrorPatterns -join '|')
    $genericRx = "PowerShell exited with code '\d+'|exited with code \d+|terminated with exit code \d+"

    $hits = New-Object System.Collections.Generic.List[object]

    # Process records that failed and have a log to fetch.
    $failedRecords = @($Timeline | Where-Object {
        $_.result -in @('failed', 'succeededWithIssues') -and $_.log -and $_.log.id
    })

    Write-Host ("Fetching logs for {0} failed record(s)..." -f $failedRecords.Count) -ForegroundColor Cyan

    foreach ($record in $failedRecords) {
        $logContent = Get-AdoLogContent -Config $Config -LogId $record.log.id
        if (-not $logContent) { continue }

        $lines    = $logContent -split "`r?`n"
        $stepName = if ($record.name) { $record.name } else { $record.identifier }
        # Synthetic file path so cluster source-mapping has a stable identifier per record.
        $synthFile = "build:{0}/log:{1}/{2}" -f $Config.BuildId, $record.log.id, $stepName
        # Cache the full content so Test-SilentFailure can re-scan it for success-class lines
        # without a second API fetch.
        if ($script:_StepContentCache) { $script:_StepContentCache[$synthFile] = $logContent }

        $fileHits = New-Object System.Collections.Generic.List[object]
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $line = $lines[$i]
            if ($line -notmatch $combined) { continue }
            if ($Exclude -and $line -match $Exclude) { continue }
            if ($line -match '(?:^|\s)(?:script:|Write-Host\s+"|inputs:|targetType:)\s*["'']?') { continue }
            if ($line.Length -gt 800) { continue }

            $start = [Math]::Max(0, $i - $ContextLines)
            $end   = [Math]::Min($lines.Count - 1, $i + $ContextLines)
            $ctx   = ($lines[$start..$end] -join "`n")
            $clean = $line -replace '^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s*', ''

            $fileHits.Add([pscustomobject]@{
                Step        = $stepName
                SubStep     = $stepName
                File        = $synthFile
                LineNumber  = $i + 1
                Message     = $clean.Trim()
                Context     = $ctx
                Fingerprint = Get-Fingerprint $clean
                IsGeneric   = ($line -match $genericRx)
            })
        }

        # Same generic-terminator suppression as Find-LocalErrors.
        $hasSpecific = $fileHits | Where-Object { -not $_.IsGeneric } | Select-Object -First 1
        foreach ($h in $fileHits) {
            if ($h.IsGeneric -and $hasSpecific) { continue }
            $hits.Add($h)
        }
    }

    # Also harvest ADO-tagged issues[] from the timeline. These complement the log-scraped
    # hits and ensure we capture errors that were emitted via ##[error] / task.logissue
    # even when the log-scrape happened to skip them.
    foreach ($record in $Timeline) {
        if (-not $record.issues) { continue }
        $stepName  = if ($record.name) { $record.name } else { $record.identifier }
        $synthFile = "build:{0}/issues/{1}" -f $Config.BuildId, $stepName
        foreach ($issue in $record.issues) {
            if ($issue.type -ne 'error') { continue }
            $msg = $issue.message
            if (-not $msg) { continue }
            $fp = Get-Fingerprint $msg
            # Skip if we already harvested an identical-fingerprint hit from this step's logs.
            if ($hits | Where-Object { $_.Step -eq $stepName -and $_.Fingerprint -eq $fp } | Select-Object -First 1) { continue }
            $hits.Add([pscustomobject]@{
                Step        = $stepName
                SubStep     = $stepName
                File        = $synthFile
                LineNumber  = 0
                Message     = $msg
                Context     = $msg
                Fingerprint = $fp
                IsGeneric   = $false
            })
        }
    }

    return ,$hits
}

# --- API mode augmentations (cluster.Result, Duration, IsCascade, SilentFailure, timeline.csv) ---

function Build-TimelineRows {
    param([Parameter(Mandatory)] [object[]]$Timeline)

    # Build id -> record lookup so we can resolve parent name and result.
    $byId = @{}
    foreach ($r in $Timeline) { $byId[$r.id] = $r }

    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($r in $Timeline) {
        $parent   = if ($r.parentId) { $byId[$r.parentId] } else { $null }
        $duration = $null
        if ($r.startTime -and $r.finishTime) {
            try {
                $start    = [datetime]::Parse($r.startTime).ToUniversalTime()
                $end      = [datetime]::Parse($r.finishTime).ToUniversalTime()
                $duration = [math]::Round(($end - $start).TotalSeconds, 1)
            } catch { }
        }
        $rows.Add([pscustomobject]@{
            Id              = $r.id
            ParentId        = $r.parentId
            Type            = $r.type
            Name            = $r.name
            Identifier      = $r.identifier
            StartTime       = $r.startTime
            FinishTime      = $r.finishTime
            DurationSeconds = $duration
            State           = $r.state
            Result          = $r.result
            Attempt         = $r.attempt
            LogId           = if ($r.log) { $r.log.id } else { $null }
            ParentName      = if ($parent) { $parent.name } else { $null }
            ParentResult    = if ($parent) { $parent.result } else { $null }
        })
    }
    return @($rows)
}

function Add-ClusterAugmentation {
    # Adds Result, DurationSeconds, IsCascade, RootCauseClusterRank to every cluster row.
    # In offline mode (no $Timeline) the new columns are present but null, preserving CSV
    # schema parity per FR-9.
    param(
        [Parameter(Mandatory)] [object[]]$Clusters,
        [object[]]$Timeline = $null
    )

    foreach ($cluster in $Clusters) {
        $cluster | Add-Member -NotePropertyName Result               -NotePropertyValue $null -Force
        $cluster | Add-Member -NotePropertyName DurationSeconds      -NotePropertyValue $null -Force
        $cluster | Add-Member -NotePropertyName IsCascade            -NotePropertyValue $null -Force
        $cluster | Add-Member -NotePropertyName RootCauseClusterRank -NotePropertyValue $null -Force
    }

    if (-not $Timeline -or $Timeline.Count -eq 0) { return $Clusters }

    # Build id -> record and stepName -> records lookups.
    $byId = @{}
    foreach ($r in $Timeline) { $byId[$r.id] = $r }
    $byName = @{}
    foreach ($r in $Timeline) {
        $name = if ($r.name) { $r.name } else { $r.identifier }
        if (-not $byName.ContainsKey($name)) { $byName[$name] = @() }
        $byName[$name] += $r
    }

    # Step name -> first cluster containing that step. Used to map the failed-ancestor
    # record back to a cluster rank for the RootCauseClusterRank column.
    $stepToCluster = @{}
    foreach ($cluster in $Clusters) {
        foreach ($s in ($cluster.AffectedSteps -split '; ')) {
            if ($s -and -not $stepToCluster.ContainsKey($s)) { $stepToCluster[$s] = $cluster }
        }
    }

    foreach ($cluster in $Clusters) {
        $primaryStep = ($cluster.AffectedSteps -split '; ')[0]
        if (-not $primaryStep) { continue }
        $records = $byName[$primaryStep]
        if (-not $records) { continue }

        # Prefer the failed record for this step name; fall back to the first record.
        $rec = ($records | Where-Object { $_.result -in @('failed', 'succeededWithIssues') } | Select-Object -First 1)
        if (-not $rec) { $rec = $records[0] }

        $cluster.Result = $rec.result
        if ($rec.startTime -and $rec.finishTime) {
            try {
                $start = [datetime]::Parse($rec.startTime).ToUniversalTime()
                $end   = [datetime]::Parse($rec.finishTime).ToUniversalTime()
                $cluster.DurationSeconds = [math]::Round(($end - $start).TotalSeconds, 1)
            } catch { }
        }

        # Cascade detection: walk parentId until we find a failed ancestor.
        # First failed ancestor is the root cause; this cluster is the cascade.
        $cluster.IsCascade = $false
        $currentId = $rec.parentId
        while ($currentId) {
            $parent = $byId[$currentId]
            if (-not $parent) { break }
            if ($parent.result -in @('failed', 'succeededWithIssues')) {
                $cluster.IsCascade = $true
                $parentName = if ($parent.name) { $parent.name } else { $parent.identifier }
                $rootCluster = $stepToCluster[$parentName]
                if ($rootCluster -and $rootCluster -ne $cluster) {
                    $cluster.RootCauseClusterRank = $rootCluster.Rank
                }
                break
            }
            $currentId = $parent.parentId
        }
    }

    return $Clusters
}

function Test-SilentFailure {
    # For each cluster, set SilentFailure = True iff ANY of the cluster's source step logs
    # contain BOTH an error-class line (from $ErrorPatterns) AND a "successfully" line.
    # Catches the "FAILED ... Started successfully" pattern that the test framework emits
    # when an operation reports success despite an underlying error.
    param(
        [Parameter(Mandatory)] [object[]]$Clusters,
        [Parameter(Mandatory)] [AllowEmptyCollection()] [object[]]$Hits
    )

    $successPattern = '(?i)\b(started|stopped|completed|deployed|installed|restarted)\s+successfully\b'

    foreach ($cluster in $Clusters) {
        $cluster | Add-Member -NotePropertyName SilentFailure -NotePropertyValue $false -Force
    }

    if ($Hits.Count -eq 0) { return $Clusters }

    # Determine which step files contain success-class lines.
    # In offline mode, $hit.File is a real path -- read once per file (cached).
    # In API mode, $hit.File is "build:N/log:M/stepName" -- look up via $script:_StepContentCache populated by ConvertTo-LogHits.
    $silentSteps = @{}
    $filesByStep = @{}
    foreach ($h in $Hits) {
        if (-not $filesByStep.ContainsKey($h.Step)) { $filesByStep[$h.Step] = @() }
        if ($h.File -and $filesByStep[$h.Step] -notcontains $h.File) { $filesByStep[$h.Step] += $h.File }
    }

    foreach ($stepName in $filesByStep.Keys) {
        foreach ($file in $filesByStep[$stepName]) {
            $content = $null
            if ($file -and $file.StartsWith('build:')) {
                # API-mode synthetic path -- look in cache.
                if ($script:_StepContentCache.ContainsKey($file)) {
                    $content = $script:_StepContentCache[$file]
                }
            } elseif ($file -and (Test-Path -LiteralPath $file)) {
                # Offline-mode real path -- read on demand and cache.
                if (-not $script:_StepContentCache.ContainsKey($file)) {
                    $script:_StepContentCache[$file] = (Get-Content -LiteralPath $file -Raw)
                }
                $content = $script:_StepContentCache[$file]
            }
            if ($content -and $content -match $successPattern) {
                $silentSteps[$stepName] = $true
                break  # one positive file is enough to flag the step
            }
        }
    }

    foreach ($cluster in $Clusters) {
        foreach ($s in ($cluster.AffectedSteps -split '; ')) {
            if ($silentSteps.ContainsKey($s)) {
                $cluster.SilentFailure = $true
                break
            }
        }
    }

    return $Clusters
}

# --- main ---

# Initialise the script-scoped step-content cache (used by Test-SilentFailure;
# populated lazily from disk in offline mode and eagerly by ConvertTo-LogHits in API mode).
$script:_StepContentCache = @{}

# Path and BuildId are mutually exclusive.
if ($Path -and $BuildId) {
    throw "Specify either -Path (offline mode) or -BuildId (API mode), not both."
}

$adoConfig = $null
$rootPath  = $null

if ($BuildId) {
    # === API mode ===
    $adoConfig = Get-AdoConfig -BuildId $BuildId -Org $Org -Project $Project -AccessToken $AccessToken -Pat $Pat

    Write-Host ""
    Write-Host "=== PIPELINE ERROR REPORT (API mode) ===" -ForegroundColor Cyan
    Write-Host ("Org             : {0}" -f $adoConfig.Org)
    Write-Host ("Project         : {0}" -f $adoConfig.Project)
    Write-Host ("Build ID        : {0}" -f $adoConfig.BuildId)
    Write-Host ("Auth            : {0}" -f $adoConfig.AuthType)

    $apiMeta = Get-AdoBuildMetadata -Config $adoConfig
    if ($apiMeta.Repo)         { Write-Host ("Repo            : {0}" -f $apiMeta.Repo) }
    if ($apiMeta.Branch)       { Write-Host ("Branch          : {0}" -f $apiMeta.Branch) }
    if ($apiMeta.Commit)       { Write-Host ("Commit          : {0}" -f $apiMeta.Commit) }
    if ($apiMeta.BuildNumber)  { Write-Host ("Build number    : {0}" -f $apiMeta.BuildNumber) }
    if ($apiMeta.RequestedFor) { Write-Host ("Requested for   : {0}" -f $apiMeta.RequestedFor) }
    Write-Host ("Build status    : {0} / {1}" -f $apiMeta.Status, $apiMeta.Result)
    if ($apiMeta.WebUrl)       { Write-Host ("Web URL         : {0}" -f $apiMeta.WebUrl) }

    $timeline = Get-AdoBuildTimeline -Config $adoConfig
    Write-Host ("Timeline records: {0}" -f $timeline.Count)

    $hits = ConvertTo-LogHits -Timeline $timeline -Config $adoConfig -ContextLines $Context -Exclude $ExcludePattern

    # Construct a $meta object compatible with the offline-mode runmeta CSV shape.
    $meta = [pscustomobject]@{
        Repo          = $apiMeta.Repo
        Branch        = $apiMeta.Branch
        Commit        = $apiMeta.Commit
        CommitMessage = $apiMeta.CommitMessage
    }

    # YAML still useful for source-mapping when the user has a local copy.
    $yaml = Find-PipelineYaml -LogsRoot (Get-Location).Path -Explicit $PipelineFile
    if ($yaml) { Write-Host ("Pipeline YAML   : {0}" -f $yaml) }

    $stamp     = Get-Date -Format "yyyyMMdd_HHmmss"
    $leaf      = "build_$($adoConfig.BuildId)"
    $parentDir = (Get-Location).Path
}
else {
    # === Offline mode (existing behaviour) ===
    if (-not $Path) { $Path = (Get-Location).Path }
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        throw "Path is not a folder or does not exist: $Path"
    }
    $rootPath = (Resolve-Path -LiteralPath $Path).Path
    $hits     = Find-LocalErrors -Root $rootPath -ContextLines $Context -Exclude $ExcludePattern
    $meta     = Get-RunMetadata -Root $rootPath
    $yaml     = Find-PipelineYaml -LogsRoot $rootPath -Explicit $PipelineFile

    $stamp     = Get-Date -Format "yyyyMMdd_HHmmss"
    $leaf      = Split-Path $rootPath -Leaf
    $parentDir = Split-Path $rootPath -Parent

    # Brief metadata banner on console.
    Write-Host ""
    Write-Host "=== PIPELINE ERROR REPORT ===" -ForegroundColor Cyan
    if ($meta) {
        if ($meta.Repo)          { Write-Host ("Repo            : {0}" -f $meta.Repo) }
        if ($meta.Branch)        { Write-Host ("Branch          : {0}" -f $meta.Branch) }
        if ($meta.Commit)        { Write-Host ("Commit          : {0}" -f $meta.Commit) }
        if ($meta.CommitMessage) { Write-Host ("Commit message  : {0}" -f $meta.CommitMessage) }
    }
    if ($yaml) { Write-Host ("Pipeline YAML   : {0}" -f $yaml) }
}

$summaryPath  = Join-Path $parentDir "${leaf}_clusters_${stamp}.csv"
$hitsPath     = Join-Path $parentDir "${leaf}_hits_${stamp}.csv"
$metaPath     = Join-Path $parentDir "${leaf}_runmeta_${stamp}.csv"
$timelinePath = Join-Path $parentDir "${leaf}_timeline_${stamp}.csv"

if (-not $hits -or $hits.Count -eq 0) {
    Write-Host "No errors found." -ForegroundColor Green
    if (-not $CompareWith) { return }
    # Compare-only path: new run is clean, but we still want to compare against old.
    $rows = @{ Clusters = @(); Hits = @() }
    $failedSteps = 0
}
else {
    $rows = Build-ClusterAndHitRows -Hits $hits -YamlPath $yaml
    $failedSteps = ($hits | Select-Object -ExpandProperty Step -Unique).Count

    # Augment cluster rows with new columns (Result/Duration/IsCascade in API mode;
    # all null in offline mode). SilentFailure is added separately and works in both modes.
    $rows.Clusters = Add-ClusterAugmentation -Clusters $rows.Clusters -Timeline $timeline
    $rows.Clusters = Test-SilentFailure      -Clusters $rows.Clusters -Hits $hits

    Write-Host ("Total error hits: {0}" -f $hits.Count)
    Write-Host ("Failed steps    : {0}" -f $failedSteps)
    Write-Host ("Clusters        : {0}" -f $rows.Clusters.Count)
    Write-Host ""

    # Surface silent failures at the top regardless of count -- they are the highest-priority
    # defect class for cutover credibility (the test framework reports success despite an error).
    $silent = @($rows.Clusters | Where-Object { $_.SilentFailure })
    if ($silent.Count -gt 0) {
        Write-Host ("WARNING: {0} cluster(s) flagged as SILENT FAILURES (test framework reports success despite an error):" -f $silent.Count) -ForegroundColor Yellow
        $silent |
            Select-Object Rank, Count, AffectedServerCount, Service,
                @{N='Sample';E={ if ($_.SampleMessage.Length -gt 90) { $_.SampleMessage.Substring(0,90)+'...' } else { $_.SampleMessage } }} |
            Format-Table -AutoSize | Out-Host
    }

    # Console: top N clusters as a tight table.
    $rows.Clusters |
        Select-Object -First $ConsoleTopN Rank, Count, AffectedServerCount, Service,
            @{N='Sample';E={ if ($_.SampleMessage.Length -gt 90) { $_.SampleMessage.Substring(0,90)+'...' } else { $_.SampleMessage } }},
            @{N='YamlLine';E={ $_.ProducedByDisplayLine }} |
        Format-Table -AutoSize | Out-Host

    # Save CSVs (one row per cluster + one row per individual hit).
    $rows.Clusters | Export-Csv -LiteralPath $summaryPath -NoTypeInformation -Encoding UTF8
    $rows.Hits     | Export-Csv -LiteralPath $hitsPath    -NoTypeInformation -Encoding UTF8

    # In API mode, also write the timeline as a CSV so power users can pivot the dependency tree.
    if ($BuildId -and $timeline -and $timeline.Count -gt 0) {
        Build-TimelineRows -Timeline $timeline | Export-Csv -LiteralPath $timelinePath -NoTypeInformation -Encoding UTF8
    }

    # Run metadata as a single-row CSV (handy for a separate manifest sheet).
    if ($meta) {
        [pscustomobject]@{
            Repo          = $meta.Repo
            Branch        = $meta.Branch
            Commit        = $meta.Commit
            CommitMessage = $meta.CommitMessage
            PipelineYaml  = $yaml
            LogsFolder    = if ($rootPath) { $rootPath } else { "build:$($adoConfig.BuildId)" }
            TotalHits     = $hits.Count
            FailedSteps   = $failedSteps
            Clusters      = $rows.Clusters.Count
            GeneratedAt   = (Get-Date -Format 'o')
        } | Export-Csv -LiteralPath $metaPath -NoTypeInformation -Encoding UTF8
    }

    Write-Host ("Clusters CSV : {0}" -f $summaryPath) -ForegroundColor Cyan
    Write-Host ("Hits CSV     : {0}" -f $hitsPath)    -ForegroundColor Cyan
    Write-Host ("Run meta CSV : {0}" -f $metaPath)    -ForegroundColor Cyan
    if ($BuildId -and $timeline -and $timeline.Count -gt 0) {
        Write-Host ("Timeline CSV : {0}" -f $timelinePath) -ForegroundColor Cyan
    }
}

# --- compare mode (when -CompareWith is supplied) ---
if ($CompareWith) {
    Write-Host ""
    Write-Host ("Resolving compare baseline: {0}" -f $CompareWith) -ForegroundColor Cyan
    $oldClusters = Get-ClustersForCompare -Source $CompareWith -AdoConfig $adoConfig
    Write-Host ("Loaded {0} baseline cluster(s)" -f $oldClusters.Count)

    $compareRows = Compare-Runs -OldClusters $oldClusters -NewClusters $rows.Clusters

    $comparePath = Join-Path $parentDir "${leaf}_compare_${stamp}.csv"
    $compareRows | Export-Csv -LiteralPath $comparePath -NoTypeInformation -Encoding UTF8

    # Labels: leaf name for paths/CSVs; "build N" for build IDs; raw value as a fallback.
    $oldLabel = if ($CompareWith -match '^\d+$') {
        "build $CompareWith"
    } elseif (Test-Path -LiteralPath $CompareWith) {
        Split-Path -Path (Resolve-Path -LiteralPath $CompareWith).Path -Leaf
    } else {
        $CompareWith
    }
    $newLabel = $leaf

    Write-CompareConsoleSummary -CompareRows $compareRows -OldLabel $oldLabel -NewLabel $newLabel

    Write-Host ("Compare CSV  : {0}" -f $comparePath) -ForegroundColor Cyan
}
