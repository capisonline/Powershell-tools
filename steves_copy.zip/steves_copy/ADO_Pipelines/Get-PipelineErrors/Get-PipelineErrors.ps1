#requires -Version 5.1
<#
.SYNOPSIS
    Triage Azure DevOps pipeline failures from a downloaded logs folder.

.DESCRIPTION
    Scans an extracted ADO logs folder, clusters failing steps by error fingerprint,
    maps each cluster to the YAML displayName + inline script that produced it,
    and writes three CSVs: cluster summary, individual hits, and run metadata.
    Console output is a tight Format-Table of the top clusters only -- full detail
    lives in the CSVs so you can sort/filter in Excel.

    Recognises the canonical ADO log markers documented at
    https://learn.microsoft.com/en-us/azure/devops/pipelines/scripts/logging-commands
    plus common runtime failure patterns (PowerShell exit codes, .NET stack traces,
    WinRM, MSBuild, "Cannot find any service", exit code N).

.PARAMETER Path
    Folder containing extracted ADO logs. Defaults to current directory.

.PARAMETER PipelineFile
    Path to the pipeline YAML. Auto-detected when omitted -- checks for
    azure-pipelines-expanded.yaml inside the logs folder first (ADO ships this
    in every log zip), then pipeline.yml beside or above the logs folder.

.PARAMETER Context
    Lines of context to capture around each error (stored in the hits CSV). Default 3.

.PARAMETER ExcludePattern
    Regex of error lines to ignore (e.g. 'is already (stopped|running)').

.PARAMETER ConsoleTopN
    Number of clusters to show in the console table. Default 15.

.OUTPUTS
    Three CSV files written next to the logs folder:
      <leaf>_clusters_<ts>.csv  - one row per cluster (rank, count, servers, sample, YAML line)
      <leaf>_hits_<ts>.csv      - one row per individual error occurrence
      <leaf>_runmeta_<ts>.csv   - single-row run metadata (branch, commit, totals)

.EXAMPLE
    .\Get-PipelineErrors.ps1 -Path .\logs_63476

.EXAMPLE
    .\Get-PipelineErrors.ps1 -Path .\logs_63476 -ExcludePattern 'is already stopped'

.EXAMPLE
    .\Get-PipelineErrors.ps1 -Path .\logs_63476 -ConsoleTopN 5 -PipelineFile .\pipeline.yml
#>
[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$Path,

    [string]$PipelineFile,
    [int]$Context = 3,
    [string]$ExcludePattern,
    [int]$ConsoleTopN = 15
)

$ErrorActionPreference = 'Stop'

# Patterns the ADO agent itself emits, plus common runtime failure indicators.
# Order matters: more specific patterns first so the matched group is meaningful.
$ErrorPatterns = @(
    # ADO formatting markers
    '##\[error\](?<msg>.*)'
    '##vso\[task\.logissue[^\]]*type=error[^\]]*\](?<msg>.*)'
    '##vso\[task\.complete[^\]]*result=Failed[^\]]*\](?<msg>.*)'
    # PowerShell / external command exit codes
    "PowerShell exited with code '(?<msg>\d+)'"
    'exited with code (?<msg>\d+)'
    'terminated with exit code (?<msg>\d+)'
    # .NET / generic exceptions
    '(?<msg>System\.\w+(\.\w+)*Exception:.*)'
    '(?<msg>Unhandled exception.*)'
    # Build tooling
    '(?<msg>error [A-Z]{1,4}\d{3,5}:.*)'      # MSBuild / CSC / TSC style
    '(?<msg>FAILED with exit code \d+)'
    # Remote / networking
    '(?<msg>WinRM cannot complete the operation.*)'
    '(?<msg>The WinRM client cannot process the request.*)'
    # Common script-level failure phrases
    '(?<msg>FAIL(ED)?[:\- ].*)'
    '(?<msg>requires manual assessment.*)'
    # Bare "Error:" prefix at start of a logical line (after optional timestamp / bracketed prefix)
    '(?:^|\]\s*|Z\s*)(?<msg>Error:\s+.*)'
)

# Fingerprint: strip values that vary across hosts so duplicate errors cluster.
function Get-Fingerprint {
    param([string]$Message)
    $fp = $Message
    # Order: most specific to most general so earlier replacements don't get clobbered.
    $fp = $fp -replace '\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b', '<GUID>'
    $fp = $fp -replace '\d{4}-\d{2}-\d{2}[T ]?[\d:.Z]*', '<TS>'
    $fp = $fp -replace '[A-Za-z]:\\[^\s''""]+', '<PATH>'
    $fp = $fp -replace '\\\\[^\s''""]+', '<UNC>'
    $fp = $fp -replace '\b\d{1,3}(?:\.\d{1,3}){3}\b', '<IP>'
    # Hostnames - two common styles. Run hyphenated first (more specific).
    $fp = $fp -replace '\b[A-Z]{2,}(?:-[A-Z0-9]+){1,4}\b', '<HOST>'         # e.g. QPS-APL-VT-01
    $fp = $fp -replace '\b[A-Z]{4,}\d{1,3}\b', '<HOST>'                     # e.g. EGLVCADVASVT01
    $fp = $fp -replace "rabbit@\S+", 'rabbit@<HOST>'
    $fp = $fp -replace '\b\d+\b', '<N>'
    return $fp.Trim().ToLowerInvariant()
}

function Find-LocalErrors {
    param([string]$Root, [int]$ContextLines, [string]$Exclude)

    if (-not (Test-Path $Root)) { throw "Path not found: $Root" }
    $rootFull = (Resolve-Path $Root).Path
    $files = Get-ChildItem -Path $Root -Recurse -File -Filter *.txt -ErrorAction SilentlyContinue
    if (-not $files) { throw "No .txt log files under $Root" }

    $hits = New-Object System.Collections.Generic.List[object]
    $combined = ($ErrorPatterns -join '|')
    # Generic terminator patterns: an "exited with code" line is almost always preceded
    # by the *real* error in the same file. Suppress them when a more specific hit
    # already exists in this file, so they don't dominate the cluster ranking.
    # No ^ anchors -- log lines are timestamped so the pattern won't be at start of line.
    $genericRx = "PowerShell exited with code '\d+'|exited with code \d+|terminated with exit code \d+"

    foreach ($file in $files) {
        $lines = Get-Content -LiteralPath $file.FullName -ErrorAction SilentlyContinue
        if (-not $lines) { continue }

        # Step name resolution:
        #   - if file lives in a subfolder of $Root, step = parent folder name
        #   - if file lives at the root, step = filename minus leading "N_"
        $parent = Split-Path $file.FullName -Parent
        if ((Resolve-Path $parent).Path -eq $rootFull) {
            $step = ($file.BaseName -replace '^\d+_', '')
        }
        else {
            $step = Split-Path $parent -Leaf
        }
        $sub = ($file.BaseName -replace '^\d+_', '')

        $fileHits = New-Object System.Collections.Generic.List[object]
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $line = $lines[$i]
            if ($line -notmatch $combined) { continue }
            if ($Exclude -and $line -match $Exclude) { continue }
            # Skip script-source echo lines (ADO logs the inline PowerShell verbatim).
            if ($line -match '(?:^|\s)(?:script:|Write-Host\s+"|inputs:|targetType:)\s*["'']?') { continue }
            # Skip very long lines (>800 chars) -- almost always script echoes or stack dumps.
            if ($line.Length -gt 800) { continue }

            $start = [Math]::Max(0, $i - $ContextLines)
            $end   = [Math]::Min($lines.Count - 1, $i + $ContextLines)
            $ctx   = ($lines[$start..$end] -join "`n")
            $clean = $line -replace '^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s*', ''

            $fileHits.Add([pscustomobject]@{
                Step        = $step
                SubStep     = $sub
                File        = $file.FullName
                LineNumber  = $i + 1
                Message     = $clean.Trim()
                Context     = $ctx
                Fingerprint = Get-Fingerprint $clean
                IsGeneric   = ($line -match $genericRx)
            })
        }

        # Suppress generic terminators when this file also has a specific hit.
        $hasSpecific = $fileHits | Where-Object { -not $_.IsGeneric } | Select-Object -First 1
        foreach ($h in $fileHits) {
            if ($h.IsGeneric -and $hasSpecific) { continue }
            $hits.Add($h)
        }
    }
    return ,$hits
}

function Get-RunMetadata {
    param([string]$Root)

    # The Checkout step log carries branch / commit / repo metadata that the
    # Initialize Job log does not. Find any "*Checkout*.txt" and extract.
    $checkoutFiles = Get-ChildItem -Path $Root -Recurse -File -Filter "*Checkout*.txt" -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notlike '*Post-job*' } |
        Select-Object -First 1
    if (-not $checkoutFiles) { return $null }

    $content = Get-Content -LiteralPath $checkoutFiles.FullName -Raw -ErrorAction SilentlyContinue
    if (-not $content) { return $null }

    $meta = [pscustomobject]@{
        Repo          = $null
        Branch        = $null
        Commit        = $null
        CommitMessage = $null
    }
    if ($content -match 'Syncing repository:\s+([^\s(]+)') { $meta.Repo = $Matches[1] }
    # Step name embeds the branch: "Checkout Repo.Name@branch to s"
    if ($checkoutFiles.BaseName -match '@([^\s]+) to s') { $meta.Branch = $Matches[1] }
    # Fetch line carries the SHA being checked out.
    if ($content -match '\+([0-9a-f]{40}):refs/remotes/origin/') { $meta.Commit = $Matches[1] }
    if ($content -match 'HEAD is now at [0-9a-f]+\s+(.+)') { $meta.CommitMessage = $Matches[1].Trim() }
    return $meta
}

function Find-PipelineYaml {
    param([string]$LogsRoot, [string]$Explicit)

    if ($Explicit -and (Test-Path $Explicit)) {
        return (Resolve-Path $Explicit).Path
    }
    if ($Explicit) {
        Write-Warning "PipelineFile not found: $Explicit -- falling back to auto-detect"
    }
    # Auto-detect order:
    #   1. azure-pipelines-expanded.yaml inside the logs folder (ADO includes this in
    #      the log zip download -- it's the post-expansion YAML, the source of truth
    #      for *exactly* what ran).
    #   2. pipeline.yml beside or above the logs folder (source repo working copy).
    $parent      = Split-Path $LogsRoot -Parent
    $grandparent = if ($parent) { Split-Path $parent -Parent } else { $null }
    $candidates = @(
        (Join-Path $LogsRoot 'azure-pipelines-expanded.yaml')
        (Join-Path $LogsRoot 'pipeline.yml')
    )
    if ($parent)      { $candidates += (Join-Path $parent      'pipeline.yml') }
    if ($grandparent) { $candidates += (Join-Path $grandparent 'pipeline.yml') }
    foreach ($c in $candidates) {
        if ($c -and (Test-Path $c)) { return (Resolve-Path $c).Path }
    }
    return $null
}

function Get-StepSource {
    param(
        [string]$YamlPath,
        [string]$StepName,    # e.g. "Running Start VisVT_APLParser" or "Modify EGLVCADVASVT01 RabbitMQ_Cluster"
        [string]$ErrorMessage # used to extract the server name for disambiguation
    )

    if (-not $YamlPath -or -not (Test-Path $YamlPath)) { return $null }

    # Cache YAML content per call site (script-scoped).
    if (-not $script:_YamlLines -or $script:_YamlPath -ne $YamlPath) {
        $script:_YamlLines = Get-Content -LiteralPath $YamlPath
        $script:_YamlPath  = $YamlPath
    }
    $lines = $script:_YamlLines

    # Strip "(N)" disambiguator that ADO appends to repeat step names.
    $clean = $StepName -replace '\s*\(\d+\)\s*$', ''
    # The folder name strips the colon present in the YAML displayName.
    # e.g. folder "Running Start VisVT_APLParser" -> YAML "Running: Start VisVT_APLParser"
    $candidates = @($clean, ($clean -replace '^(\S+)\s+', '$1: '))

    # Try to extract the server identifier from the error message ("[QPS-APL-VT-01]" etc).
    $server = $null
    if ($ErrorMessage -match '\[([A-Z][A-Z0-9-]{3,})\]') { $server = $Matches[1] }

    # Locate every line that names the step's displayName.
    # ($matches is an automatic variable in PS; use a different name.)
    $displayHits = @()
    for ($i = 0; $i -lt $lines.Count; $i++) {
        foreach ($cand in $candidates) {
            $escaped = [regex]::Escape($cand)
            if ($lines[$i] -match "displayName:\s*['""]?$escaped['""]?\s*$") {
                $displayHits += $i
                break
            }
        }
    }
    if (-not $displayHits) { return $null }

    # Disambiguate by server: pick the match whose surrounding script (next ~80 lines)
    # contains the literal server name.
    $chosen = $displayHits[0]
    if ($server) {
        foreach ($m in $displayHits) {
            $end = [Math]::Min($lines.Count - 1, $m + 80)
            $window = ($lines[$m..$end] -join "`n")
            if ($window -match [regex]::Escape($server)) { $chosen = $m; break }
        }
    }

    # Find the inline script: next "script:" line within ~30 lines of the displayName.
    $scriptLine = $null
    for ($j = $chosen; $j -lt [Math]::Min($lines.Count, $chosen + 30); $j++) {
        if ($lines[$j] -match '^\s*script:\s*(.*)$') { $scriptLine = $j; break }
    }

    return [pscustomobject]@{
        DisplayLine = $chosen + 1
        ScriptLine  = if ($null -ne $scriptLine) { $scriptLine + 1 } else { $null }
        Snippet     = if ($null -ne $scriptLine) { $lines[$scriptLine] } else { $lines[$chosen] }
    }
}

function Get-ServerFromMessage {
    param([string]$Message)
    # Bracketed hostname like [QPS-APL-VT-01] or [EGLVCADVASVT01]
    if ($Message -match '\[([A-Z][A-Z0-9-]{3,})\]') { return $Matches[1] }
    if ($Message -match "rabbit@([\w-]+)")          { return $Matches[1] }
    return $null
}

function Get-ServiceFromMessage {
    param([string]$Message)
    # Quoted service name like 'VisVT_APLParser' or 'RabbitMQ'
    if ($Message -match "'(VisVT_[A-Za-z_]+|RabbitMQ)'") { return $Matches[1] }
    return $null
}

function Build-ClusterAndHitRows {
    param([object[]]$Hits, [string]$YamlPath)

    $clusters = $Hits | Group-Object Fingerprint | Sort-Object Count -Descending
    $clusterRows = New-Object System.Collections.Generic.List[object]
    $hitRows     = New-Object System.Collections.Generic.List[object]

    $rank = 0
    foreach ($c in $clusters) {
        $rank++
        $sample = $c.Group[0]
        $stepSet = $c.Group | Select-Object -ExpandProperty Step -Unique
        $servers = $c.Group | ForEach-Object { Get-ServerFromMessage $_.Message } | Where-Object { $_ } | Select-Object -Unique
        $service = Get-ServiceFromMessage $sample.Message

        $src = $null
        if ($YamlPath) {
            $src = Get-StepSource -YamlPath $YamlPath -StepName $sample.Step -ErrorMessage $sample.Message
        }

        $clusterRows.Add([pscustomobject]@{
            Rank                  = $rank
            Count                 = $c.Count
            Service               = $service
            AffectedServers       = ($servers -join '; ')
            AffectedServerCount   = $servers.Count
            AffectedSteps         = ($stepSet -join '; ')
            AffectedStepCount     = $stepSet.Count
            SampleMessage         = $sample.Message
            SampleLogFile         = $sample.File
            SampleLogLine         = $sample.LineNumber
            ProducedByYamlFile    = if ($src) { $YamlPath } else { $null }
            ProducedByDisplayLine = if ($src) { $src.DisplayLine } else { $null }
            ProducedByScriptLine  = if ($src) { $src.ScriptLine } else { $null }
            Fingerprint           = $sample.Fingerprint
        })

        foreach ($h in $c.Group) {
            $hitRows.Add([pscustomobject]@{
                ClusterRank = $rank
                Step        = $h.Step
                SubStep     = $h.SubStep
                Server      = (Get-ServerFromMessage $h.Message)
                Service     = (Get-ServiceFromMessage $h.Message)
                Message     = $h.Message
                LogFile     = $h.File
                LogLine     = $h.LineNumber
                Context     = ($h.Context -replace "`r", '' -replace "`n", ' | ')
                Fingerprint = $h.Fingerprint
            })
        }
    }

    return @{ Clusters = $clusterRows; Hits = $hitRows }
}

# --- main ---
if (-not $Path) { $Path = (Get-Location).Path }
if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
    throw "Path is not a folder or does not exist: $Path"
}
$rootPath = (Resolve-Path -LiteralPath $Path).Path
$hits     = Find-LocalErrors -Root $rootPath -ContextLines $Context -Exclude $ExcludePattern
$meta     = Get-RunMetadata -Root $rootPath
$yaml     = Find-PipelineYaml -LogsRoot $rootPath -Explicit $PipelineFile

$stamp        = Get-Date -Format "yyyyMMdd_HHmmss"
$leaf         = Split-Path $rootPath -Leaf
$parentDir    = Split-Path $rootPath -Parent
$summaryPath  = Join-Path $parentDir "${leaf}_clusters_${stamp}.csv"
$hitsPath     = Join-Path $parentDir "${leaf}_hits_${stamp}.csv"
$metaPath     = Join-Path $parentDir "${leaf}_runmeta_${stamp}.csv"

# Brief metadata banner on console.
Write-Host ""
Write-Host "=== PIPELINE ERROR REPORT ===" -ForegroundColor Cyan
if ($meta) {
    if ($meta.Repo)          { Write-Host ("Repo            : {0}" -f $meta.Repo) }
    if ($meta.Branch)        { Write-Host ("Branch          : {0}" -f $meta.Branch) }
    if ($meta.Commit)        { Write-Host ("Commit          : {0}" -f $meta.Commit) }
    if ($meta.CommitMessage) { Write-Host ("Commit message  : {0}" -f $meta.CommitMessage) }
}
if ($yaml) { Write-Host ("Pipeline YAML   : {0}" -f $yaml) }

if (-not $hits -or $hits.Count -eq 0) {
    Write-Host "No errors found." -ForegroundColor Green
    return
}

$rows = Build-ClusterAndHitRows -Hits $hits -YamlPath $yaml
$failedSteps = ($hits | Select-Object -ExpandProperty Step -Unique).Count
Write-Host ("Total error hits: {0}" -f $hits.Count)
Write-Host ("Failed steps    : {0}" -f $failedSteps)
Write-Host ("Clusters        : {0}" -f $rows.Clusters.Count)
Write-Host ""

# Console: top N clusters as a tight table.
$rows.Clusters |
    Select-Object -First $ConsoleTopN Rank, Count, AffectedServerCount, Service,
        @{N='Sample';E={ if ($_.SampleMessage.Length -gt 90) { $_.SampleMessage.Substring(0,90)+'...' } else { $_.SampleMessage } }},
        @{N='YamlLine';E={ $_.ProducedByDisplayLine }} |
    Format-Table -AutoSize | Out-Host

# Save CSVs (one row per cluster + one row per individual hit).
$rows.Clusters | Export-Csv -LiteralPath $summaryPath -NoTypeInformation -Encoding UTF8
$rows.Hits     | Export-Csv -LiteralPath $hitsPath    -NoTypeInformation -Encoding UTF8

# Run metadata as a single-row CSV (handy for a separate manifest sheet).
if ($meta) {
    [pscustomobject]@{
        Repo          = $meta.Repo
        Branch        = $meta.Branch
        Commit        = $meta.Commit
        CommitMessage = $meta.CommitMessage
        PipelineYaml  = $yaml
        LogsFolder    = $rootPath
        TotalHits     = $hits.Count
        FailedSteps   = $failedSteps
        Clusters      = $rows.Clusters.Count
        GeneratedAt   = (Get-Date -Format 'o')
    } | Export-Csv -LiteralPath $metaPath -NoTypeInformation -Encoding UTF8
}

Write-Host ("Clusters CSV : {0}" -f $summaryPath) -ForegroundColor Cyan
Write-Host ("Hits CSV     : {0}" -f $hitsPath)    -ForegroundColor Cyan
Write-Host ("Run meta CSV : {0}" -f $metaPath)    -ForegroundColor Cyan
