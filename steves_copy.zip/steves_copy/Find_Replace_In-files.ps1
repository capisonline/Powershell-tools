﻿# Load the server mappings from the CSV file 
$serverMappings = Import-Csv -Path "C:\temp\QCAD\BA\LogMan\xml_update-input.csv"

# List of XML files to be updated
$xmlFiles = @(
    "C:\temp\QCAD\BA\LogMan\tasks\plmconf.xml"#,
    #"path\to\logmanconf2.xml",
    #"path\to\logmanconf3.xml"
)

foreach ($xmlFile in $xmlFiles) {
    # Read the content of the XML file as plain text
    $xmlContent = Get-Content -Path $xmlFile -Raw

    $originalContent = $xmlContent  # Save original content for comparison

    foreach ($mapping in $serverMappings) {
        # Perform the find and replace operation for each mapping
        $oldServer = [regex]::Escape($mapping.OldServer)
        $newServer = $mapping.NewServer

        # Replace all instances of the old server name with the new server name
        if ($xmlContent -match $oldServer) {
            Write-Output "Found and replacing '$oldServer' with '$newServer' in file '$xmlFile'"
            $xmlContent = $xmlContent -replace $oldServer, $newServer
        } else {
            Write-Output "No match found for '$oldServer' in file '$xmlFile'"
        }
    }

    if ($xmlContent -ne $originalContent) {
        # Define the path for the new file
        $newFilePath = [System.IO.Path]::ChangeExtension($xmlFile, ".updated.xml")

        # Save the updated content to a new XML file
        Set-Content -Path $newFilePath -Value $xmlContent

        Write-Output "Updated file saved as '$newFilePath'"
    } else {
        Write-Output "No changes made to '$xmlFile'"
    }
}

Write-Output "Server names updated successfully in new XML files."
