﻿# Import the Active Directory module 
Import-Module ActiveDirectory

# Define the path for the input text file containing the usernames and group names
$inputTxtPath = "C:\temp\QCAD\VT\Security\Local_Groups\AD_List.txt"

# Define the path for the output CSV file
$outputCsvPath = "C:\temp\QCAD\VT\Security\Local_Groups\AD_User-Group_Descriptions-QPS-Service Users1111.csv"

# Define the properties to retrieve for both users and groups
$userProperties = "SamAccountName", "Name", "Description"
$groupProperties = "SamAccountName", "Name", "Description"

# Read names from the input text file
$names = Get-Content -Path $inputTxtPath

# Initialize an array to hold AD object data
$adObjectsInfo = @()

# Loop through each name and get AD object information
foreach ($name in $names) {
    # Try to get user information
    $objectInfo = Get-ADUser -Filter "SamAccountName -eq '$name'" -Properties $userProperties -ErrorAction SilentlyContinue
    if ($objectInfo) {
        $adObjectsInfo += $objectInfo
    } else {
        # If no user found, try to get group information
        $objectInfo = Get-ADGroup -Filter "SamAccountName -eq '$name'" -Properties $groupProperties -ErrorAction SilentlyContinue
        if ($objectInfo) {
            $adObjectsInfo += $objectInfo
        } else {
            Write-Host "No AD user or group found for name: $name"
        }
    }
}

# Select the properties to include in the CSV
$selectedADInfo = $adObjectsInfo | Select-Object $userProperties

# Export the selected information to a CSV file
$selectedADInfo | Export-Csv -Path $outputCsvPath -NoTypeInformation

Write-Host "AD user and group descriptions have been exported to $outputCsvPath"
