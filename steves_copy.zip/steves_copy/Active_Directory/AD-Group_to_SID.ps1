﻿# Import the Active Directory module 
Import-Module ActiveDirectory

# Define the path to the input CSV file
$inputCsvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\SID_INputfil.csv"

# Define the path to the output CSV file
$outputCsvPath = "C:\temp\QCAD\PA\Group_Policy\User-Groups\SID_output.csv"

# Read group names from the CSV file
$groupList = Import-Csv -Path $inputCsvPath

# Create an empty array to store the results
$results = @()

# Loop through each group in the list
foreach ($group in $groupList) {
    # Get the group details from Active Directory
    $groupDetails = Get-ADGroup -Filter "Name -eq '$($group.GroupName)'" -Properties *

    # Check if the group was found
    if ($groupDetails) {
        # Create a custom object with the group name and SID
        $obj = New-Object -TypeName PSObject -Property @{
            GroupName = $group.GroupName
            SID = $groupDetails.SID
        }

        # Add the object to the results array
        $results += $obj
    } else {
        # If group is not found, still add it to the output with a null SID
        $obj = New-Object -TypeName PSObject -Property @{
            GroupName = $group.GroupName
            SID = $null
        }

        # Add the object to the results array
        $results += $obj
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

# Output completion message
Write-Host "The SID extraction and CSV export have completed. Check the output file at $outputCsvPath."
