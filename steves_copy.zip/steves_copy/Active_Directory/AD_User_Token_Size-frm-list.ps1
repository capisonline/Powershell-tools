﻿function Get-UserTokenSize { 
    param (
        [Parameter(Mandatory = $true)]
        [string]$UserName
    )

    try {
        $user = Get-ADUser -Identity $UserName -Properties MemberOf
        $groups = $user.MemberOf

        # Count the number of groups
        $groupCount = $groups.Count

        # Calculate the approximate token size
        $tokenSize = ($groupCount + 1) * 40 + 1200

        $result = [PSCustomObject]@{
            UserName  = $UserName
            GroupCount = $groupCount
            TokenSize  = $tokenSize
            Status     = if ($tokenSize -gt 64000) {
                "Warning: Token size exceeds 64 KB."
            } elseif ($tokenSize -gt 32000) {
                "Notice: Token size exceeds 32 KB."
            } else {
                "Token size is within acceptable limits."
            }
        }

        return $result
    } catch {
        Write-Output "Error processing user '$UserName': $_"
    }
}

# Read the list of usernames from the input file
$userList = Get-Content -Path "C:\temp\scripts\Active_Directory\User_List.txt"

# Initialize an array to hold results
$results = @()

# Process each username in the list
foreach ($userName in $userList) {
    $result = Get-UserTokenSize -UserName $userName
    if ($result) {
        $results += $result
    }
}

# Output the results to the console
$results | Format-Table -AutoSize

# Optionally, export the results to a CSV file
$results | Export-Csv -Path "C:\temp\scripts\Active_Directory\TokenSizeReport.csv" -NoTypeInformation
