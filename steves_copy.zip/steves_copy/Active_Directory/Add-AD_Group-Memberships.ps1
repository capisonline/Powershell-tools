﻿# Import the Active Directory module 
Import-Module ActiveDirectory

# Specify the file path for the input CSV file
$inputCsv = "C:\temp\QCAD\VT\AD-Groups\Input__Add-AD_Group_Memberships.csv"

# Specify the file path for the output CSV
$outputCsv = "C:\temp\QCAD\VT\AD-Groups\Add-AD_Group_Memberships-Results-444444444.csv"

# Read the input CSV
$csvData = Import-Csv -Path $inputCsv

# Prepare an empty array to collect results
$results = @()

foreach ($row in $csvData) {
    $status = 'Error'
    $errorMessage = $null
    $member = $null

    try {
        # Check and find the group and member only if both are present in the input
        if (-not $row.GroupName -or -not $row.MemberName) {
            throw "GroupName or MemberName is missing in the CSV row."
        }

        $group = Get-ADGroup -Identity $row.GroupName -ErrorAction Stop
        Write-Host "Processing group: $($row.GroupName)"

        # Check both user and group for member, catch block will handle errors
        $member = Get-ADUser -Identity $row.MemberName -ErrorAction SilentlyContinue
        if (-not $member) {
            $member = Get-ADGroup -Identity $row.MemberName -ErrorAction SilentlyContinue
        }

        if ($member) {
            Write-Host "Found member: $($row.MemberName) as $($member.ObjectClass)"

            # Check and add member to the group if not already added
            $isMember = $group | Get-ADGroupMember -Recursive | Where-Object { $_.DistinguishedName -eq $member.DistinguishedName }
            if ($isMember) {
                $status = "Already a member"
            } else {
                Add-ADGroupMember -Identity $group -Members $member.DistinguishedName -ErrorAction Stop
                $status = "Success"
            }
        } else {
            throw "Member $($row.MemberName) not found as user or group."
        }
    } catch {
        $status = "Failed"
        $errorMessage = $_.Exception.Message
        Write-Host "Error: $errorMessage"
    }

    # Create a result object and add it to the results array
    $results += [PSCustomObject]@{
        GroupName = $row.GroupName
        MemberName = $row.MemberName
        Added = $status
        ErrorMessage = $errorMessage
    }
}

# Export results to CSV
$results | Export-Csv -Path $outputCsv -NoTypeInformation

# Completion message
Write-Host "Process completed. Results saved to $outputCsv"

