﻿# Import the Active Directory module 
Import-Module ActiveDirectory

# Define the path to the input CSV file
$inputTextPath = "C:\temp\QCAD\VT\Security\Sec_Edit\OLD_Servers\SID_List.txt"

# Define the path to the output CSV file
$outputCsvPath = "C:\temp\QCAD\VT\Security\Sec_Edit\OLD_Servers\SID-AD_output11111.csv"

# Read names from the text file
$names = Get-Content -Path $inputTextPath

# Create an empty array to store the results
$results = @()

# Loop through each name in the list
foreach ($name in $names) {
    # Use Trim() to remove any accidental whitespace around names
    $name = $name.Trim()
    # Initialize variable to hold details
    $details = $null
    
    # Attempt to get group details
    try {
        $details = Get-ADGroup -Identity $name -Properties ObjectSID -ErrorAction Stop | Select-Object -Property Name, ObjectSID
    } catch {
        # If not found as a group, try as a user
        try {
            $details = Get-ADUser -Identity $name -Properties ObjectSID -ErrorAction Stop | Select-Object -Property Name, ObjectSID
        } catch {
            Write-Warning "No AD group or user found with the name: $name"
        }
    }

    # If details are found, add them to results
    if ($details) {
        $obj = New-Object -TypeName PSObject -Property @{
            Name = $details.Name
            SID = $details.ObjectSID
        }
        $results += $obj
    } else {
        # Add a record with null SID if no details are found
        $obj = New-Object -TypeName PSObject -Property @{
            Name = $name
            SID = "Not Found"
        }
        $results += $obj
    }
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation -Encoding UTF8

# Output completion message
Write-Host "The SID extraction and CSV export have completed. Check the output file at $outputCsvPath."
