﻿<# 
This script ingests a CSV of AD group names and recursively searches and saves the members.
Any groups found are recursively searched and saved.
The objective is to reduce excessive AD permissions.
#>

# Define the path to your CSV file
$csvPath = "C:\temp\QCAD\Issues\AD_Groups\Nested-AD_Group_Memberships_Input.csv"

# Define the output file path
$outputPath = "C:\temp\QCAD\Issues\AD_Groups\Nested-AD-GroupMembers.csv"

# Import group names from the CSV file
$groupNames = Import-Csv $csvPath | Select-Object -ExpandProperty GroupName

# Prepare an array to hold the output
$output = @()

# Function to recursively find all members including nested groups
function Get-NestedGroupMembers {
    param ([string]$groupName)

    # Get direct members
    $members = Get-ADGroupMember -Identity $groupName -ErrorAction SilentlyContinue

    foreach ($member in $members) {
        # Create an object for each member
        $output += [PSCustomObject]@{
            'Group Name'  = $groupName
            'Member Type' = $member.objectClass
            'Member Name' = $member.Name
        }
        
        # If the member is a group, recurse into it
        if ($member.objectClass -eq 'group') {
            Get-NestedGroupMembers -groupName $member.Name
        }
    }
}

# Process each group from the CSV file
foreach ($groupName in $groupNames) {
    Get-NestedGroupMembers -groupName $groupName
}

# Export the results to a CSV file
$output | Export-Csv -Path $outputPath -NoTypeInformation

# Output completion message
Write-Host "Group memberships have been exported to $outputPath"
