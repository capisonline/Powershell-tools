﻿# Import the Active Directory module 
Import-Module ActiveDirectory

# Specify the file path for the input text file with group names
$inputFile = "C:\temp\QCAD\PA\AD-Groups\Nested-AD_Group_Memberships_Input.csv"

# Specify the file path for the output CSV
$outputCsv = "C:\temp\QCAD\PA\AD-Groups\Nested-AD-GroupMembers_SIDs--final.csv"

# Read group names from the input file
$groupNames = Get-Content -Path $inputFile

# Prepare an empty array to collect results
$results = @()

foreach ($groupName in $groupNames) {
    # Check if the group exists
    $group = Get-ADGroup -Filter "Name -eq '$groupName'" -ErrorAction SilentlyContinue

    if ($group) {
        # Retrieve members of the group
        $members = Get-ADGroupMember -Identity $group -ErrorAction SilentlyContinue

        foreach ($member in $members) {
            # Create a custom object with the required details
            $result = New-Object -TypeName PSObject
            $result | Add-Member -MemberType NoteProperty -Name "GroupName" -Value $group.Name
            $result | Add-Member -MemberType NoteProperty -Name "GroupNameSID" -Value $group.SID
            $result | Add-Member -MemberType NoteProperty -Name "MemberName" -Value $member.Name
            $result | Add-Member -MemberType NoteProperty -Name "MemberNameSID" -Value $member.SID

            # Add the object to results array
            $results += $result
        }
    } else {
        Write-Warning "Group '$groupName' not found."
    }
}

# Export results to CSV
$results | Export-Csv -Path $outputCsv -NoTypeInformation

# Output completion message
Write-Host "Export completed. Data saved to $outputCsv"
