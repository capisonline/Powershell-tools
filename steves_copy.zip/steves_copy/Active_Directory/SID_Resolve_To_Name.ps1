﻿

# Path to the text file containing the SIDs 
$sidListPath = "C:\temp\scripts\Security\SID_list.txt"

# Optional: Export the results to a CSV file
$csvFilePath = "C:\temp\scripts\Security\SID_output-retro.csv"

# Read the SIDs from the file
$sids = Get-Content -Path $sidListPath

# Create an empty array to hold the results
$results = @()

foreach ($sid in $sids) {
    try {
        # Attempt to translate the SID to a user or group name
        $objSID = New-Object System.Security.Principal.SecurityIdentifier($sid)
        $objUser = $objSID.Translate([System.Security.Principal.NTAccount])
        $name = $objUser.Value
    } catch {
        # If the SID cannot be resolved, catch the exception and use a placeholder
        $name = "Could not resolve SID: $sid"
    }

    # Create a result object
    $result = [PSCustomObject]@{
        SID = $sid
        Name = $name
    }

    # Add the result object to the results array
    $results += $result
}

# Display the results in the console
$results | Format-Table -AutoSize


$results | Export-Csv -Path $csvFilePath -NoTypeInformation

Write-Host "SID resolution completed. Results saved to $csvFilePath"
