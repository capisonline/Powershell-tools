﻿# Import the Active Directory module 
Import-Module ActiveDirectory

# Define the path to the input CSV file
$inputTextPath = "C:\temp\QCAD\TP\Security\Sec_Edit\OLD_Servers\SIDs.txt"

# Define the path to the output CSV file
$outputCsvPath = "C:\temp\QCAD\TP\Security\Sec_Edit\OLD_Servers\SID_output1.csv"

# Read group names from the text file
$groupNames = Get-Content -Path $inputTextPath

# Create an empty array to store the results
$results = @()

# Loop through each group name in the list
foreach ($groupName in $groupNames) {
    # Use Trim() to remove any accidental whitespace around group names
    $groupName = $groupName.Trim()
    # Get the group details from Active Directory
    $groupDetails = Get-ADGroup -Identity $groupName -Properties ObjectSID | Select-Object -Property Name, ObjectSID

    # Create a custom object with the group name and SID
    $obj = New-Object -TypeName PSObject -Property @{
        GroupName = $groupDetails.Name
        SID = $groupDetails.ObjectSID
    }

    # Add the object to the results array
    $results += $obj
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation -Encoding UTF8

# Output completion message
Write-Host "The SID extraction and CSV export have completed. Check the output file at $outputCsvPath."
