﻿
function Get-NestedGroupDepth { 
    param (
        [Parameter(Mandatory = $true)]
        [string]$GroupName
    )

    $global:MaxDepth = 0

    function Get-GroupDepth {
        param (
            [Parameter(Mandatory = $true)]
            [string]$group,
            [int]$depth
        )
        $global:MaxDepth = [math]::Max($global:MaxDepth, $depth)
        $subGroups = Get-ADGroupMember -Identity $group | Where-Object { $_.objectClass -eq 'group' }
        foreach ($subGroup in $subGroups) {
            Get-GroupDepth -group $subGroup.Name -depth ($depth + 1)
        }
    }

    Get-GroupDepth -group $GroupName -depth 1

    return [PSCustomObject]@{
        GroupName = $GroupName
        MaxDepth  = $global:MaxDepth
    }
}

# Read the list of group names from the input file
$groupList = Get-Content -Path "C:\temp\scripts\Active_Directory\User_List.txt"

# Initialize an array to hold results
$results = @()

# Process each group name in the list
foreach ($groupName in $groupList) {
    $result = Get-NestedGroupDepth -GroupName $groupName.Trim()
    if ($result) {
        $results += $result
    }
}

# Output the results to a CSV file
$results | Export-Csv -Path "C:\temp\scripts\Active_Directory\GroupNestingDepthReport.csv" -NoTypeInformation
