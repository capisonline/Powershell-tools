﻿# This script uses dnscmd which is deprecated
#Define the path to your CSV file 
$csvFilePath = "C:\temp\QCAD\PA\DNS_Alias\DNS_Alias-creation_list.csv"

# Import the CSV file. It's expected to have 'AliasName' and 'ServerName' columns.
$dnsEntries = Import-Csv -Path $csvFilePath

# Loop through each entry in the CSV file
foreach ($entry in $dnsEntries) {
    $aliasName = $entry.AliasName
    $serverName = $entry.ServerName

    # Check if the DNS alias already exists
    $existingRecord = Resolve-DnsName -Name $aliasName -ErrorAction SilentlyContinue

    if ($existingRecord) {
        Write-Output "DNS alias '$aliasName' already exists. Skipping creation."
    }
    else {
        # 
        # Modify the zone name and server as necessary.
        $zoneName = "prds.qldpol"
        $dnsServer = "164.112.162.141" # Use the server's name or IP address if not local
        
        # Use dnscmd to add the CNAME record
        $command = "dnscmd $dnsServer /RecordAdd $zoneName $aliasName CNAME $serverName"
        Invoke-Expression $command
        
        Write-Output "DNS alias '$aliasName' for server '$serverName' created."
    }
}

Write-Output "DNS alias check and creation process completed."
