﻿# Define the path where the text files are stored 
$folderPath = "C:\temp\QCAD\VT\Roles_Features"

# Get all text files in the folder
$textFiles = Get-ChildItem -Path $folderPath -Filter "*.txt"

# Loop through each file
foreach ($file in $textFiles) {
    # Extract the server name from the filename (assuming the filename is the server name)
    $serverName = [System.IO.Path]::GetFileNameWithoutExtension($file.FullName)
    
    # Read the roles and features listed in the file
    $featuresToInstall = Get-Content -Path $file.FullName
    
    # Install each feature on the respective server
    foreach ($feature in $featuresToInstall) {
        # Using Invoke-Command to run the installation remotely
        Invoke-Command -ComputerName $serverName -ScriptBlock {
            Install-WindowsFeature -Name $using:feature
        } 
    }
    
    # Output to console
    Write-Output "Installed features on $serverName from file $file.Name"
}

# Final message
Write-Output "All installations completed based on the files."
