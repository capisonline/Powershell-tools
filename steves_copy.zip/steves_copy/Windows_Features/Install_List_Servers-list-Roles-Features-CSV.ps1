﻿# Installs a list of Roles / Features on servers 
# Servername in column A Role / Feature Column B
# Define the path to the CSV file 
$csvPath = 'C:\temp\QCAD\PA\Roles_Features\OutputResults\Missed_Roles-Features.csv'

# Read the CSV into a variable, grouping by server name
$servers = Import-Csv $csvPath | Group-Object -Property ServerName

# Loop through each server
foreach ($server in $servers) {
    # Extract the server name
    $serverName = $server.Name
    
    # Create an array of all features to be installed on this server
    $featuresToInstall = $server.Group | ForEach-Object { $_.Feature }

    # Define the script block to execute on the remote server
    $scriptBlock = {
        param($features)
        # Install the features. Since $features is an array, it's passed directly.
        Install-WindowsFeature -Name $features -IncludeManagementTools
    }

    # Execute the script block on the remote server, passing in the features to install as an array
    Invoke-Command -ComputerName $serverName -ScriptBlock $scriptBlock -ArgumentList (,$featuresToInstall)
}
