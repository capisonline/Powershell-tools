﻿$serversFile = "C:\temp\scripts\server_list.txt" # Path to the file containing the list of servers 
$outputCsv = "C:\temp\QCAD\TP\Shares\ntfs_permissions.csv" # Output CSV file path

# Read the list of servers from the file
$servers = Get-Content -Path $serversFile

# Header for the CSV file
"Server,Drive,Path,IdentityReference,FileSystemRights,AccessControlType" | Out-File -FilePath $outputCsv

foreach ($server in $servers) {
    $drives = Get-WmiObject -Class Win32_LogicalDisk -ComputerName $server | Where-Object { $_.DriveType -eq 3 -and $_.DeviceID -ne 'C:' }
    foreach ($drive in $drives) {
        $paths = Get-ChildItem -Path "\\$server\$($drive.DeviceID.Replace(':', '$'))" -Recurse -Directory -ErrorAction SilentlyContinue
        foreach ($path in $paths) {
            $acl = Get-Acl -Path $path.FullName
            foreach ($access in $acl.Access) {
                $line = "$server,$($drive.DeviceID),$($path.FullName),$($access.IdentityReference),$($access.FileSystemRights),$($access.AccessControlType)"
                $line | Out-File -FilePath $outputCsv -Append
            }
        }
    }
}

Write-Output "NTFS permissions have been saved to $outputCsv"
