﻿<# 
.SYNOPSIS
    This script reads a list of server hostnames from a file and a list of URL templates from another file. 
    It replaces a placeholder `{server}` in each URL template with each server name and makes an HTTP request to the generated URLs.
    The script then logs the response status codes to a CSV file for analysis.

.DESCRIPTION
    - Reads a list of servers from `servers.txt`.
    - Reads a list of URL templates from `urls.txt`.
    - Replaces `{server}` in each URL with the actual server hostname.
    - Sends HTTP GET requests to each modified URL.
    - Captures the response status (e.g., 200 OK, 404 Not Found, etc.).
    - Saves the results in a CSV file (`url_status_results.csv`).

.INPUTS
    - A text file (`servers.txt`) containing a list of server hostnames.
    - A text file (`urls.txt`) containing URL templates with `{server}` placeholders.

.OUTPUTS
    - A CSV file (`url_status_results.csv`) containing:
        * ServerName
        * URL
        * StatusCode

.EXAMPLE
    Running the script:
    ```
    .\Check-URL-Status.ps1
    ```

    Example `servers.txt`:
    ```
    server1.example.com
    server2.example.com
    ```

    Example `urls.txt`:
    ```
    https://{server}/api/healthcheck
    https://{server}/status
    ```

    Sample Output (CSV):
    ```
    ServerName,URL,StatusCode
    server1.example.com,https://server1.example.com/api/healthcheck,200
    server1.example.com,https://server1.example.com/status,404
    ```

.NOTES
    - Requires Internet access for web requests.
    - Ensure PowerShell is running with necessary permissions.
    - Timeout is set to 10 seconds for each request.

.VERSION
    1.0 - Initial version

.AUTHOR
    Your Name
#>

# Define file paths
$ServerListPath = "C:\temp\QCAD\tp\TP_NEW_Server_list.txt"    # Update with actual path
$URLListPath = "C:\temp\QCAD\TP\reto-fix\URL-List.txt"          # Update with actual path
$OutputCSV = "C:\temp\QCAD\TP\reto-fix\url_status_results.csv"

# Read servers and URLs from files
$Servers = Get-Content -Path $ServerListPath
$URLs = Get-Content -Path $URLListPath

# Initialize an array to store results
$Results = @()

# Loop through each server and replace the placeholder in each URL
foreach ($Server in $Servers) {
    foreach ($URLTemplate in $URLs) {
        # Replace placeholder {server} with actual server name
        $URL = $URLTemplate -replace "{server}", $Server

        try {
            # Send HTTP request
            $Response = Invoke-WebRequest -Uri $URL -Method Get -UseBasicParsing -TimeoutSec 10
            $StatusCode = $Response.StatusCode
        } catch {
            # Capture error status (e.g., 404 Not Found, Timeout, etc.)
            $StatusCode = $_.Exception.Response.StatusCode.Value__ -as [string]
            if (-not $StatusCode) { $StatusCode = "Error: $_" }
        }

        # Store result
        $Results += [PSCustomObject]@{
            ServerName = $Server
            URL        = $URL
            StatusCode = $StatusCode
        }
    }
}

# Export results to CSV
$Results | Export-Csv -Path $OutputCSV -NoTypeInformation

Write-Host "URL status check completed. Results saved to: $OutputCSV"
