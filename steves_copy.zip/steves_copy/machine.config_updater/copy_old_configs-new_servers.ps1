﻿<#
This script connects to one server and copies a file to another server. 
The CSV columns require this structure:
ColumnA         ColumnB         ColumnC                                                ColumnD
Old_Server      New_Server      Source_FilePath                                        Destination_Path
QPS-CCM-TP-03	EGLVCADCCMTP01  C:\Windows\Microsoft.NET\Framework\v2.0.50727\CONFIG   C:\Windows\Microsoft.NET\Framework\v2.0.50727\

1x file per row
It will check the destination file if it already exists & if so, rename it.
#>

# Define the path to the CSV file 
$csvFilePath = "C:\temp\QCAD\VT\Machine.config-files\file_mappings.csv"

# Import the CSV file
$fileMappings = Import-Csv -Path $csvFilePath

# Loop through each mapping in the CSV file
foreach ($mapping in $fileMappings) {
    $oldServer = $mapping.Old_Server.Trim()
    $newServer = $mapping.New_Server.Trim()
    $sourceFilePath = $mapping.Source_FilePath.Trim()
    $destinationPath = $mapping.Destination_Path.Trim()

    # Construct UNC paths for source and destination
    $uncSourcePath = "\\" + $oldServer + "\" + $sourceFilePath.Replace(":", "$")
    $uncDestinationPath = "\\" + $newServer + "\" + $destinationPath.Replace(":", "$")

    # Construct the full path for the destination file
    $destinationFileFullPath = Join-Path -Path $uncDestinationPath -ChildPath (Split-Path -Path $sourceFilePath -Leaf)

    # Check if the destination file exists
    if (Test-Path -Path $destinationFileFullPath) {
        # Rename the existing destination file by appending a timestamp
        $timestamp = Get-Date -Format "yyyy-MM-dd-HH-mm"
        $fileExtension = [System.IO.Path]::GetExtension($destinationFileFullPath)
        $destinationFileRenamed = $destinationFileFullPath.Replace($fileExtension, "_backup_$timestamp$fileExtension")
        
        Rename-Item -Path $destinationFileFullPath -NewName $destinationFileRenamed
        Write-Host "Renamed existing destination file to: $destinationFileRenamed"
    }
    
    # Ensure the destination directory exists
    if (-not (Test-Path -Path $uncDestinationPath)) {
        # Create the destination directory if it does not exist
        New-Item -ItemType Directory -Path $uncDestinationPath -Force
    }

    # Copy the file
    try {
        Copy-Item -Path $uncSourcePath -Destination $uncDestinationPath -Force
        Write-Host "Successfully copied $uncSourcePath to $uncDestinationPath"
    } catch {
        Write-Warning "Failed to copy $uncSourcePath to $uncDestinationPath. Error: $_"
    }
}
