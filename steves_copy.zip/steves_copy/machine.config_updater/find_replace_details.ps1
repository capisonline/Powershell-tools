﻿# PowerShell script to edit the machine.config file on QCAD Servers
# to remove any Microsoft VisualStudio Diagnostics information
# it will also edit the Oracle versions to 2.122.19.1 and 4.122.19.1
# Updates all 4 config files in each server
# Recommend creating a separate QCADServerXX.txt file for each environment
# Created by: Brett Kratzmann
 
 
#----------------------------------------------------------------------
 
# Create a list of Servers 
$Servers = Get-Content "C:\temp\QCAD\VT\VT_NEW_Server_list.txt"

# CSV log file path
$CsvLogFilePath = "C:\temp\QCAD\VT\deployment-notes\14-04-25\UpdateLog-final.csv"

# Initialize an array for CSV log content
$CsvLogContent = @()

#----------------------------------------------------------------------
foreach ($Server in $Servers) {
    $ServerLogEntries = Invoke-Command -ComputerName $Server -ScriptBlock {
        $Server = $using:server

        # Files to be edited
        $Files = @(
            "\\$Server\D$\vision\VisVT\*.config"
        )

        # Text to be replaced vtcad-vcsnlb.prds.qldpol   qps-qcad-pa-vws.PRDS.QLDPOL
        $Replacements = @(
            @{ Old = 'vtcad-vcsnlb.prds.qldpol'; New = 'qps-qcad-pa-vcs.prds.qldpol' },
            @{ Old = 'VTcad-vwsnlb.prds.qldpol'; New = 'qps-qcad-pa-vws.prds.qldpol' },
            @{ Old = 'VTcad-vimnlb.prds.qldpol'; New = 'qps-qcad-pa-vim.prds.qldpol' }
        )

        # Collect log entries for this server
        $LogEntries = @()
        foreach ($File in $Files) {
            try {
                if (Test-Path $File) {
                    $Content = Get-Content $File
                    foreach ($Replacement in $Replacements) {
                        if ($Content -match [regex]::Escape($Replacement.Old)) {
                            $ModifiedContent = $Content -Replace [regex]::Escape($Replacement.Old), $Replacement.New
                            $ModifiedContent | Set-Content $File -Verbose

                            # Log the old and new settings
                            $LogEntries += [PSCustomObject]@{
                                FilePath = $File
                                OldSetting = $Replacement.Old
                                NewSetting = $Replacement.New
                            }
                        }
                    }
                } else {
                    $LogEntries += [PSCustomObject]@{
                        FilePath = $File
                        OldSetting = "File not found"
                        NewSetting = "N/A"
                    }
                }
            } catch {
                $LogEntries += [PSCustomObject]@{
                    FilePath = $File
                    OldSetting = "Error"
                    NewSetting = $_.Exception.Message
                }
            }
        }
        return $LogEntries
    }

    # Append the server's log entries to the main log content
    $CsvLogContent += $ServerLogEntries
}

# Export the log content to a CSV file
$CsvLogContent | Export-Csv -Path $CsvLogFilePath -NoTypeInformation -Encoding UTF8 -Append
