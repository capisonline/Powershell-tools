﻿
# Define the path to the folder containing the log files on the server 
$logFolderPath = "C:\temp\QCAD\TP\Error_Logs"

# Define the base paths for the output CSV files
$localCsvBasePath = "C:\temp\QCAD\TP\Error_Logs\csv\Vision_Errors_output.csv"
$remoteCsvBasePath = "\\PC556466-1\C$\temp\QCAD\TP\Error_Logs\output\TP_output.csv"

# Get the hostname of the local server
$hostname = $env:COMPUTERNAME

# Function to scan a file for the word "ERROR"
function Scan-File {
    param (
        [string]$filePath,
        [string]$hostName
    )

    $results = @()
    try {
        # Open the file with shared read access
        $fileStream = [System.IO.File]::Open($filePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $streamReader = New-Object System.IO.StreamReader($fileStream)
        while ($line = $streamReader.ReadLine()) {
            if ($line -match "ERROR") {
                $dateTime = $line.Substring(0, 19)
                $results += [pscustomobject]@{
                    FileName = $filePath
                    DateTime = $dateTime
                    Status   = "ERROR"
                }
            }
        }
        $streamReader.Close()
        $fileStream.Close()
    } catch {
        $results += [pscustomobject]@{
            FileName = $filePath
            DateTime = ""
            Status   = "File Locked or Not Accessible"
        }
    }

    return $results
}

# Function to scan all log files in a folder
function Scan-Folder {
    param (
        [string]$folderPath,
        [string]$hostName
    )

    $logFiles = Get-ChildItem -Path $folderPath -Filter *.log

    foreach ($logFile in $logFiles) {
        $fileResults = Scan-File -filePath $logFile.FullName -hostName $hostName
        
        # Construct the CSV file names based on hostname and log file name
        $localCsvFilePath = "$localCsvBasePath${hostName}_${logFile.Name}.csv"
        $remoteCsvFilePath = "$remoteCsvBasePath${hostName}_${logFile.Name}.csv"
        
        # Update the local CSV file with the scan results
        $fileResults | Export-Csv -Path $localCsvFilePath -NoTypeInformation -Force

        # Attempt to update the remote CSV file with the scan results
        try {
            $fileResults | Export-Csv -Path $remoteCsvFilePath -NoTypeInformation -Force
        } catch {
            Write-Host "Failed to update the remote CSV file: $_"
        }
    }
}

# Monitor the folder for changes
while ($true) {
    Scan-Folder -folderPath $logFolderPath -hostName $hostname
    Start-Sleep -Seconds 5
}
