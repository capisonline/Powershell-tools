﻿<#
.SYNOPSIS
    Local log scanner with timestamp filtering and fixed line-based context capture.

.DESCRIPTION
    Scans all .txt log files recursively within a folder.
    Matches ERROR or WARNING lines with a valid timestamp in a time window.
    For each match, captures N lines before and N lines after.
    Outputs results to a CSV file per host only if matches are found.
#>

# === CONFIGURATION ===
$logInputPath = "C:\temp\QCAD\VT\Merge\Error_Logs\All2"                           # Log folder to scan
$outputPath = "C:\temp\QCAD\VT\Merge\Error_Logs\logscan_14-05-2026-2.csv"
$searchPhrases = @("ERROR", "WARNING")
$linesBefore = 5
$linesAfter = 20

# Define start and end date/time in the format "yyyy-MM-dd HH:mm:ss"
$startTime = [datetime]::ParseExact("2026-05-12 09:00:00", "yyyy-MM-dd HH:mm:ss", $null)
$endTime   = [datetime]::ParseExact("2026-05-13 18:00:59", "yyyy-MM-dd HH:mm:ss", $null)

# === SETUP ===
$outputDir = Split-Path $outputPath
if (!(Test-Path $outputDir)) {
    New-Item -Path $outputDir -ItemType Directory -Force | Out-Null
}
$results = @()

# === RECURSIVELY SCAN LOG FILES ===
Get-ChildItem -Path $logInputPath -Filter "*.log*" -Recurse | ForEach-Object {
    $file = $_.FullName
    $lines = Get-Content -Path $file

    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = "$($lines[$i])".Trim()

        # Skip if line is too short to contain a timestamp
        if ($line.Length -lt 23) { continue }

        $timestampString = $line.Substring(0, 23)
        try {
            $timestamp = [datetime]::ParseExact($timestampString, "yyyy-MM-dd HH:mm:ss,fff", $null)
        } catch {
            continue
        }

        # Skip if not within the defined window
        if ($timestamp -lt $startTime -or $timestamp -gt $endTime) {
            continue
        }

        foreach ($phrase in $searchPhrases) {
            if ($line -match $phrase) {
                # Define context range
                $startIdx = [Math]::Max(0, $i - $linesBefore)
                $endIdx = [Math]::Min($lines.Count - 1, $i + $linesAfter)
                $matchBlock = $lines[$startIdx..$endIdx] -join "`r`n"

                $results += [PSCustomObject]@{
                    Hostname  = $env:COMPUTERNAME
                    File      = $file
                    Timestamp = $timestamp
                    Phrase    = $phrase
                    Context   = $matchBlock
                }

                break  # Avoid multiple matches on same line
            }
        }
    }
}

# === EXPORT RESULTS IF ANY ===
if ($results.Count -gt 0) {
    $results | Export-Csv -Path $outputPath -NoTypeInformation
}
