﻿# Specify path to the folder containing the log files on each server 
# replace : with $ IE: E:\Vision\VisBA\System_VisBA\Logs 
# should be E$\Vision\VisBA\System_VisBA\Logs 
# 3:# the search is recursive but will take a while so the closer the better to the end folder
# IE: Don't just scan E$ unless you really have to

# 1: Input server list
$servers = Get-Content "C:\temp\QCAD\TP\TP_NEW_Server_list.txt"
# 2:
$logFolderPath = "E$\Vision\"

# Output file
$localCsvFilePath = "C:\temp\QCAD\TP\Error_Logs\failed-cutover\TP_Errors.csv"



# Scan a file for the word "ERROR"
function Scan-File {
    param (
        [string]$filePath,
        [string]$serverName
    )

    $results = @()
    try {
        # Open the file with shared read access
        $fileStream = [System.IO.File]::Open($filePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $streamReader = New-Object System.IO.StreamReader($fileStream)
        while ($line = $streamReader.ReadLine()) {
            if ($line -match "0xC00E0025") {
                # Extract the date, time, and error message
                if ($line -match '^(?<DateTime>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) \[\d+\] ERROR - (?<Message>.*)$') {
                    $dateTime = $matches['DateTime']
                    $message = $matches['Message']
                    $results += [pscustomobject]@{
                        ServerName = $serverName
                        FileName   = $filePath
                        DateTime   = $dateTime
                        Message    = $message
                    }
                }
            }
        }
        $streamReader.Close()
        $fileStream.Close()
    } catch {
        $results += [pscustomobject]@{
            ServerName = $serverName
            FileName   = $filePath
            DateTime   = ""
            Message    = "File Locked or Not Accessible"
        }
    }

    return $results
}

# Function to scan all log files in a folder on a remote server
function Scan-Folder {
    param (
        [string]$serverName,
        [string]$folderPath
    )

    $logFiles = Get-ChildItem -Path "\\$serverName\$folderPath" -Recurse -Filter *.log

    $allResults = @()

    foreach ($logFile in $logFiles) {
        $fileResults = Scan-File -filePath $logFile.FullName -serverName $serverName
        $allResults += $fileResults
    }

    return $allResults
}

# Main script to scan all servers and save results to a CSV file
$allErrors = @()

foreach ($server in $servers) {
    Write-Host "Scanning server: $server"
    $serverResults = Scan-Folder -serverName $server -folderPath $logFolderPath
    $allErrors += $serverResults
}

if ($allErrors.Count -gt 0) {
    $allErrors | Export-Csv -Path $localCsvFilePath -NoTypeInformation -Force
    Write-Host "Errors saved to $localCsvFilePath"
} else {
    Write-Host "No errors found on any server."
}
