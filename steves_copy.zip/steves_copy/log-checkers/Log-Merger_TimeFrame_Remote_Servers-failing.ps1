﻿<# 
.SYNOPSIS
This script aggregates log entries from multiple servers into a single CSV file for easy import into Excel.

.DESCRIPTION
The script reads a list of server names from a text file, accesses specified log directories on each server, 
and collects log entries within a specified time frame. The log entries are saved to a CSV file with separate 
columns for the source path, timestamp, and log entry. The user can then sort the CSV file by timestamp in Excel.

.PARAMETER serverListFile
Path to the text file containing the list of server names.

.PARAMETER remoteLogDirectory
Directory on each server where log files are stored.

.PARAMETER localLogDirectory
Local directory to save the merged CSV file.

.PARAMETER startTime
Start date and time in the format "yyyy-MM-dd HH:mm:ss".

.PARAMETER endTime
End date and time in the format "yyyy-MM-dd HH:mm:ss".

.EXAMPLE
powershell.exe -File MergeLogs.ps1
#>

# Define variables 
$serverListFile = "C:\temp\QCAD\PA\PA_NEW_Server_list.txt" # Path to the text file containing the list of servers
$remoteLogDirectory = "E$\Vision" # Directory on each server where log files are stored
$localLogDirectory = "C:\temp\QCAD\PA\Issues\Log_File_Errors" # Local directory to save the merged log file


# Define start and end date/time in the format "yyyy-MM-dd HH:mm:ss"
$startTime = [datetime]::ParseExact("2024-07-29 15:00:00", "yyyy-MM-dd HH:mm:ss", $null)
$endTime = [datetime]::ParseExact("2024-08-04 15:45:59", "yyyy-MM-dd HH:mm:ss", $null)

# Create local log directory if it doesn't exist
if (-Not (Test-Path -Path $localLogDirectory)) {
    New-Item -ItemType Directory -Path $localLogDirectory
}

# Define the path for the merged CSV file
$mergedCsvFile = Join-Path -Path $localLogDirectory -ChildPath "merged_logs-msmqs.csv"

# Clear the merged CSV file if it already exists
if (Test-Path -Path $mergedCsvFile) {
    Remove-Item -Path $mergedCsvFile
}

# Initialize an array to hold log entries
$logEntries = @()

# Read server list from the text file
$servers = Get-Content -Path $serverListFile

# Function to get log entries from a remote server
function Get-LogEntriesFromServer {
    param (
        [string]$server, # Server name
        [string]$remoteLogDirectory, # Log directory on the server
        [datetime]$startTime, # Start time of the timeframe
        [datetime]$endTime # End time of the timeframe
    )

    Write-Output "Getting log files from server: $server"

    try {
        # Construct the UNC path to the log directory
        $remotePath = "\\$server\$remoteLogDirectory"
        Write-Output "Accessing remote path: $remotePath"
        
        # Get all items from the remote server's log directory recursively
        $remoteItems = Get-ChildItem -Path $remotePath -Recurse -ErrorAction Stop
        Write-Output "Found $($remoteItems.Count) items in remote directory: $remotePath"
        
        # Filter only log files
        $remoteLogFiles = $remoteItems | Where-Object { $_.Name -like "*.log" }
        Write-Output "Filtered $($remoteLogFiles.Count) log files in remote directory: $remotePath"
    }
    catch {
        Write-Output "Failed to access server: $server"
        Write-Output $_.Exception.Message
        return
    }
    
    foreach ($logFile in $remoteLogFiles) {
        Write-Output "Reading log file: $($logFile.FullName)"
        try {
            # Read the content of each log file
            $fileContent = Get-Content -Path $logFile.FullName -ErrorAction Stop
            Write-Output "Read $($fileContent.Count) lines from log file: $($logFile.FullName)"
        }
        catch {
            Write-Output "Failed to read log file: $($logFile.FullName)"
            Write-Output $_.Exception.Message
            continue
        }
        
        foreach ($line in $fileContent) {
            # Check if line matches timestamp pattern
            if ($line -match "^(?<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})") {
                $timestamp = [datetime]::ParseExact($matches['timestamp'], "yyyy-MM-dd HH:mm:ss,fff", $null)
                if ($timestamp -ge $startTime -and $timestamp -le $endTime) {
                    # Add the matching log line with the source UNC path to the log entries array
                    $logEntryWithSource = [PSCustomObject]@{
                        SourcePath = $logFile.FullName
                        Timestamp = $timestamp
                        LogEntry = $line
                    }
                    $logEntries += $logEntryWithSource
                }
            }
        }
    }
}

# Process each server listed in the servers.txt file
foreach ($server in $servers) {
    Write-Output "Processing logs from server: $server"
    Get-LogEntriesFromServer -server $server -remoteLogDirectory $remoteLogDirectory -startTime $startTime -endTime $endTime
}

# Export all log entries to the final merged CSV file
$logEntries | Export-Csv -Path $mergedCsvFile -NoTypeInformation

Write-Output "Merged log entries saved to $mergedCsvFile"
