﻿<# 
.SYNOPSIS
    This script merges log entries from multiple servers' log directories based on a specified time range 
    and outputs the results to a single log file. 

.DESCRIPTION
    The script reads a list of server names from a text file, accesses a specific log directory on each server, 
    and retrieves log files in .log format. It then filters log entries within a user-specified date and time range 
    (in the format yyyy-MM-dd HH:mm:ss) and merges the valid log entries into one file.

    The merged log file is saved to a local directory, which is dynamically created based on the current date 
    when the script is run. The log file itself is named using the current date and time to ensure uniqueness.

    The script:
    1. Defines a list of servers and log directory paths.
    2. Specifies the start and end times for filtering log entries.
    3. Creates the local log directory based on the current date.
    4. Merges filtered log entries into a single file and saves it in the newly created directory.
    5. Handles errors during the log retrieval process, such as server accessibility issues or read errors.

.PARAMETER serverListFile
    Path to the text file that contains a list of server names to process.

.PARAMETER remoteLogDirectory
    The path to the log directory on each server from which log files are retrieved.

.PARAMETER startTime
    The start time of the time range for which log entries should be filtered.

.PARAMETER endTime
    The end time of the time range for which log entries should be filtered.

.PARAMETER localLogDirectory
    The path where the local log files should be saved. The script automatically appends the current date to this path.

.EXAMPLE
    Run the script to retrieve logs from the specified servers within a specific time range:
    
    Just run it in ISE and update the variables as required

.NOTES
    This script is designed for environments with multiple remote servers and robust logging. 
    Originally written for QCAD as it exploits Log4Net logging structure. 
    It accesses the log directories on the servers and recursively filters logs based on the specified time frame.

    Make sure that the server list file exists and contains valid server names.
    The script requires access to the servers and their respective log directories.
    It has no known impact to performance but results may vary depending on log size.
    QCAD log4net settings are "no lock" meaning log files can be read while being written to.
    https://logging.apache.org/log4net/release/config-examples.html see: RollingFileAppender

    To sort and view this neatly - use Excel. Import txt > Split by delimeter > Sort by timestamp > filter if you want to.
    Written by: rogers.steven2@police.qld.gov.au

#>

# Define variables
$serverListFile = "C:\temp\QCAD\TP\TP_NEW_Server_list.txt" # Path to the text file containing the list of servers
$remoteLogDirectory = "E$\Vision" # Directory on each server where log files are stored

# Get the current date and time
$currentDate = (Get-Date).ToString("yyyy-MM-dd")
$currentTime = (Get-Date).ToString("HHmmss")

# Create a local log directory with the current date
$localLogDirectory = "C:\temp\QCAD\TP\Error_Logs\failed-cutover\log-timestamped\$currentDate" # Local directory to save the merged log file

# Define the output filename with the current date and time
$mergedLogFile = Join-Path -Path $localLogDirectory -ChildPath "$currentDate-$currentTime-merged_logs.txt"

# Define start and end date/time in the format "yyyy-MM-dd HH:mm:ss" (This is log4nets timestamp structure) 
$startTime = [datetime]::ParseExact("2024-09-25 16:00:00", "yyyy-MM-dd HH:mm:ss", $null)
$endTime = [datetime]::ParseExact("2024-09-25 16:45:59", "yyyy-MM-dd HH:mm:ss", $null)

# Create local log directory if it doesn't exist
if (-Not (Test-Path -Path $localLogDirectory)) {
    New-Item -ItemType Directory -Path $localLogDirectory
}

# Clear the merged log file if it already exists
if (Test-Path -Path $mergedLogFile) {
    Clear-Content -Path $mergedLogFile
}

# Read server list from the text file
$servers = Get-Content -Path $serverListFile

# Function to get log entries from a remote server
function Get-LogEntriesFromServer {
    param (
        [string]$server, # Server name
        [string]$remoteLogDirectory, # Log directory on the server
        [datetime]$startTime, # Start time of the timeframe
        [datetime]$endTime # End time of the timeframe
    )

    Write-Output "Getting log files from server: $server"

    try {
        # Construct the UNC path to the log directory
        $remotePath = "\\$server\$remoteLogDirectory"
        Write-Output "Accessing remote path: $remotePath"
        
        # Get all items from the remote server's log directory recursively
        $remoteItems = Get-ChildItem -Path $remotePath -Recurse -ErrorAction Stop
        Write-Output "Found $($remoteItems.Count) items in remote directory: $remotePath"
        
        # Filter only log files
        $remoteLogFiles = $remoteItems | Where-Object { $_.Name -like "*.log" }
        Write-Output "Filtered $($remoteLogFiles.Count) log files in remote directory: $remotePath"
    }
    catch {
        Write-Output "Failed to access server: $server"
        Write-Output $_.Exception.Message
        return
    }

    foreach ($logFile in $remoteLogFiles) {
        Write-Output "Reading log file: $($logFile.FullName)"
        try {
            # Read the content of each log file
            $fileContent = Get-Content -Path $logFile.FullName -ErrorAction Stop
            Write-Output "Read $($fileContent.Count) lines from log file: $($logFile.FullName)"
        }
        catch {
            Write-Output "Failed to read log file: $($logFile.FullName)"
            Write-Output $_.Exception.Message
            continue
        }
        
        foreach ($line in $fileContent) {
            # Check if line matches timestamp pattern 
            if ($line -match "^(?<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})") {
                $timestamp = [datetime]::ParseExact($matches['timestamp'], "yyyy-MM-dd HH:mm:ss,fff", $null)
                if ($timestamp -ge $startTime -and $timestamp -le $endTime) {
                    # Append the matching log line with the source UNC path to the merged log file
                    $logEntryWithSource = "$($logFile.FullName): $line"
                    Add-Content -Path $mergedLogFile -Value $logEntryWithSource
                }
            }
        }
    }
}

# Process each server listed in the servers.txt file
foreach ($server in $servers) {
    Write-Output "Processing logs from server: $server"
    Get-LogEntriesFromServer -server $server -remoteLogDirectory $remoteLogDirectory -startTime $startTime -endTime $endTime
}

Write-Output "Merged log entries saved to $mergedLogFile"
