﻿<#
.SYNOPSIS
    Local log scanner for ERROR and WARNING entries with timestamp filtering.

.DESCRIPTION
    Recursively scans all .txt files in a folder for lines within a specified
    datetime window that contain specified keywords (e.g., ERROR, WARNING).
    Extracts context around each keyword and exports results to CSV per host.

.OUTPUT
    Only generates an output CSV if matches are found.
#>

# === CONFIGURATION ===
$logInputPath = "E:\vision"     # Folder to scan
$outputPath = "D:\Failtesting\LogScan\logscan_$env:COMPUTERNAME.csv"
$searchPhrases = @("ERROR", "WARNING")
$contextWordsBefore = 500
$contextWordsAfter = 500

# Define start and end date/time in the format "yyyy-MM-dd HH:mm:ss"
$startTime = [datetime]::ParseExact("2025-05-27 12:00:00", "yyyy-MM-dd HH:mm:ss", $null)
$endTime   = [datetime]::ParseExact("2025-05-27 18:00:59", "yyyy-MM-dd HH:mm:ss", $null)

# === SETUP ===
$outputDir = Split-Path $outputPath
if (!(Test-Path $outputDir)) {
    New-Item -Path $outputDir -ItemType Directory -Force | Out-Null
}

$results = @()
$rowNumber = 0

# === RECURSE AND SCAN LOG FILES ===
Get-ChildItem -Path $logInputPath -Filter "*.log" -Recurse | ForEach-Object {
    $file = $_.FullName
    Get-Content -Path $file -ReadCount 1 | ForEach-Object {
        $rowNumber++
        $line = $_.Trim()

        # Ensure line is long enough to contain timestamp
        if ($line.Length -lt 23) { return }

        # Extract and parse the timestamp from the start of the line
        $timestampString = $line.Substring(0, 23)
        try {
            $timestamp = [datetime]::ParseExact($timestampString, "yyyy-MM-dd HH:mm:ss,fff", $null)
        } catch {
            return  # Skip if timestamp cannot be parsed
        }

        # Check if line is within the desired time window
        if ($timestamp -lt $startTime -or $timestamp -gt $endTime) {
            return
        }

        # Check for each search phrase
        foreach ($phrase in $searchPhrases) {
            if ($line -match $phrase) {
                $words = $line -split '\s+'
                $phraseIndex = [Array]::IndexOf($words, $phrase)
                if ($phraseIndex -ge 0) {
                    $startIndex = [Math]::Max(0, $phraseIndex - $contextWordsBefore)
                    $endIndex = [Math]::Min($words.Length - 1, $phraseIndex + $contextWordsAfter)
                    $context = $words[$startIndex..$endIndex] -join ' '
                    $results += [PSCustomObject]@{
                        Hostname  = $env:COMPUTERNAME
                        File      = $file
                        Timestamp = $timestamp
                        Row       = $rowNumber
                        Phrase    = $phrase
                        Context   = $context
                    }
                }
            }
        }
    }
}

# === EXPORT IF RESULTS FOUND ===
if ($results.Count -gt 0) {
    $results | Export-Csv -Path $outputPath -NoTypeInformation
}
<#
.SYNOPSIS
    Local log scanner for ERROR and WARNING entries with timestamp filtering.

.DESCRIPTION
    Recursively scans all .txt files in a folder for lines within a specified
    datetime window that contain specified keywords (e.g., ERROR, WARNING).
    Extracts context around each keyword and exports results to CSV per host.

.OUTPUT
    Only generates an output CSV if matches are found.
#>

# === CONFIGURATION ===
$logInputPath = "D:\Failtesting\logs"                             # Folder to scan
$outputPath = "D:\Failtesting\LogScan\logscan_$env:COMPUTERNAME.csv"
$searchPhrases = @("ERROR", "WARNING")
$contextWordsBefore = 500
$contextWordsAfter = 500

# Define start and end date/time in the format "yyyy-MM-dd HH:mm:ss"
$startTime = [datetime]::ParseExact("2025-03-13 09:00:00", "yyyy-MM-dd HH:mm:ss", $null)
$endTime   = [datetime]::ParseExact("2025-03-13 10:00:59", "yyyy-MM-dd HH:mm:ss", $null)

# === SETUP ===
$outputDir = Split-Path $outputPath
if (!(Test-Path $outputDir)) {
    New-Item -Path $outputDir -ItemType Directory -Force | Out-Null
}

$results = @()
$rowNumber = 0

# === RECURSE AND SCAN LOG FILES ===
Get-ChildItem -Path $logInputPath -Filter "*.log*" -Recurse | ForEach-Object {
    $file = $_.FullName
    Get-Content -Path $file -ReadCount 1 | ForEach-Object {
        $rowNumber++
        $line = $_.Trim()

        # Ensure line is long enough to contain timestamp
        if ($line.Length -lt 23) { return }

        # Extract and parse the timestamp from the start of the line
        $timestampString = $line.Substring(0, 23)
        try {
            $timestamp = [datetime]::ParseExact($timestampString, "yyyy-MM-dd HH:mm:ss,fff", $null)
        } catch {
            return  # Skip if timestamp cannot be parsed
        }

        # Check if line is within the desired time window
        if ($timestamp -lt $startTime -or $timestamp -gt $endTime) {
            return
        }

        # Check for each search phrase
        foreach ($phrase in $searchPhrases) {
            if ($line -match $phrase) {
                $words = $line -split '\s+'
                $phraseIndex = [Array]::IndexOf($words, $phrase)
                if ($phraseIndex -ge 0) {
                    $startIndex = [Math]::Max(0, $phraseIndex - $contextWordsBefore)
                    $endIndex = [Math]::Min($words.Length - 1, $phraseIndex + $contextWordsAfter)
                    $context = $words[$startIndex..$endIndex] -join ' '
                    $results += [PSCustomObject]@{
                        Hostname  = $env:COMPUTERNAME
                        File      = $file
                        Timestamp = $timestamp
                        Row       = $rowNumber
                        Phrase    = $phrase
                        Context   = $context
                    }
                }
            }
        }
    }
}

# === EXPORT IF RESULTS FOUND ===
if ($results.Count -gt 0) {
    $results | Export-Csv -Path $outputPath -NoTypeInformation
}
