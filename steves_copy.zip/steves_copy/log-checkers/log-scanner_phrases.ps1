﻿# Path to the large log file 
$logFilePath = "C:\temp\QCAD\TP\Error_Logs\failed-cutover\seperated"

# Output CSV file path
$outputCsvPath = "C:\temp\QCAD\TP\Error_Logs\failed-cutover\log-timestamped\TP-cutover.csv"

# Phrases to search for
$searchPhrases = @("ERROR", "WARNING")

# Function to extract context around a found phrase
function Get-Context {
    param (
        [string]$line,
        [string]$phrase,
        [int]$rowNumber
    )
    $contextWordsBefore = 100
    $contextWordsAfter = 100
    $words = $line -split ' '
    $phraseIndex = [Array]::IndexOf($words, $phrase)

    if ($phraseIndex -ne -1) {
        $startIndex = [Math]::Max(0, $phraseIndex - $contextWordsBefore)
        $endIndex = [Math]::Min($words.Length - 1, $phraseIndex + $contextWordsAfter)
        $context = $words[$startIndex..$endIndex] -join ' '
        return [PSCustomObject]@{
            RowNumber = $rowNumber
            Phrase = $phrase
            Context = $context
        }
    }
    return $null
}

# Initialize array to store results
$results = @()

# Read the log file line by line
$rowNumber = 0
Get-Content -Path $logFilePath -ReadCount 0 | ForEach-Object {
    $rowNumber++
    foreach ($phrase in $searchPhrases) {
        if ($_ -match $phrase) {
            $result = Get-Context -line $_ -phrase $phrase -rowNumber $rowNumber
            if ($result) {
                $results += $result
            }
        }
    }
}

# Export results to CSV
$results | Export-Csv -Path $outputCsvPath -NoTypeInformation

Write-Host "Log analysis completed. Results saved to $outputCsvPath"
