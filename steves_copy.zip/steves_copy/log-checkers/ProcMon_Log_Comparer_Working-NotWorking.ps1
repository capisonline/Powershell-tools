﻿# Define paths to the CSV files from the working and non-working machines 
$workingLog = "C:\temp\QCAD\PA\Issues\TP_Message_broker_Logfile.CSV"
$nonWorkingLog = "C:\temp\QCAD\PA\Issues\ProcMon-Messagebroker.exe-Logfile.CSV"

# Import CSV files into PowerShell objects
$workingData = Import-Csv -Path $workingLog
$nonWorkingData = Import-Csv -Path $nonWorkingLog

# Function to compare logs
function Compare-Logs {
    param (
        [Parameter(Mandatory = $true)]
        [array]$workingData,
        [Parameter(Mandatory = $true)]
        [array]$nonWorkingData
    )

    $comparisonResults = @()

    foreach ($nonWorkingEvent in $nonWorkingData) {
        $matchingEvents = $workingData | Where-Object {
            $_.'Process Name' -eq $nonWorkingEvent.'Process Name' -and
            $_.'Operation' -eq $nonWorkingEvent.'Operation' -and
            $_.'Path' -eq $nonWorkingEvent.'Path'
        }

        if ($matchingEvents) {
            foreach ($match in $matchingEvents) {
                $comparisonResults += [pscustomobject]@{
                    'Time of Day'       = $nonWorkingEvent.'Time of Day'
                    'Process Name'      = $nonWorkingEvent.'Process Name'
                    'Operation'         = $nonWorkingEvent.'Operation'
                    'Path'              = $nonWorkingEvent.'Path'
                    'NonWorkingResult'  = $nonWorkingEvent.'Result'
                    'WorkingResult'     = $match.'Result'
                    'NonWorkingDetail'  = $nonWorkingEvent.'Detail'
                    'WorkingDetail'     = $match.'Detail'
                }
            }
        } else {
            $comparisonResults += [pscustomobject]@{
                'Time of Day'       = $nonWorkingEvent.'Time of Day'
                'Process Name'      = $nonWorkingEvent.'Process Name'
                'Operation'         = $nonWorkingEvent.'Operation'
                'Path'              = $nonWorkingEvent.'Path'
                'NonWorkingResult'  = $nonWorkingEvent.'Result'
                'WorkingResult'     = 'Not Found'
                'NonWorkingDetail'  = $nonWorkingEvent.'Detail'
                'WorkingDetail'     = 'Not Found'
            }
        }
    }

    return $comparisonResults
}

# Run the comparison function
$comparisonResults = Compare-Logs -workingData $workingData -nonWorkingData $nonWorkingData

# Display the comparison results
$comparisonResults | Format-Table -AutoSize

# Save the comparison results to a new CSV file
$comparisonResults | Export-Csv -Path "C:\temp\QCAD\PA\Issues\ProcMon-Messagebroker.exe-Logfile_Comparison777.CSV" -NoTypeInformation
