﻿<# 
.SYNOPSIS
    This script connects to a list of remote servers, copies all .log files from the E:\Vision directory,
    and saves them to a local directory. The log files are renamed with the hostname to ensure that they
    can be easily identified and merged without losing information about their origin.
    
.DESCRIPTION
    The script reads a list of server names or IP addresses from a text file (servers.txt) and connects 
    to each server using a UNC path to access the E:\Vision directory. It copies all .log files from 
    that directory to a specified local folder. Each copied log file is renamed to include the server's 
    hostname as a prefix to avoid filename conflicts and to allow easy identification of the file source. 
    The script does not alter any files on the remote servers.

.PARAMETER serversList
    The path to the text file containing the list of servers. Each server name or IP address should 
    be on a new line in the text file.

.PARAMETER remoteDirectory
    The directory on the remote servers where the .log files are located. In this case, it's the 
    E:\Vision directory.

.PARAMETER localDirectory
    The local folder where the log files will be copied. The script will create this directory 
    if it does not exist.

.EXAMPLE
    Run the script to copy logs from a list of servers and rename them with the hostname:
    
    ./copy_logs.ps1

    Ensure the list of servers is specified in C:\path\to\servers.txt, and the log files from each server 
    will be copied to C:\path\to\local\logs with their filenames prefixed by the hostname.
    
.NOTES
    The script uses Test-Connection to verify that the servers are reachable before attempting to 
    copy the log files. It only reads files from the remote servers and does not alter the server-side files.
    Requires appropriate permissions to access the remote servers and directories.
#>

# Define the path to the list of servers
$serversList = "C:\temp\QCAD\VT\Merge\Error_Logs\VT_NEW.txt"

# Define the directory on the remote servers where the log files are located
$remoteDirectory = "E$\Vision"

# Define the local directory where the log files will be copied
$localDirectory = "C:\temp\QCAD\VT\Merge\Error_Logs\All2"

# Create the local directory if it doesn't exist
if (-not (Test-Path -Path $localDirectory)) {
    New-Item -ItemType Directory -Path $localDirectory
}

# Read the list of servers from the text file
$servers = Get-Content -Path $serversList

# Loop through each server in the list
foreach ($server in $servers) {
    # Test if the server is reachable
    if (Test-Connection -ComputerName $server -Count 1 -Quiet) {
        Write-Host "Connecting to $server..."

        # Define the UNC path to access the remote folder (E:\Vision) on the server
        $remotePath = "\\$server\$remoteDirectory"

        # Check if the remote path exists on the server
        if (Test-Path -Path $remotePath) {
            # Get all log files (*.log) from the remote server's directory
            $logFiles = Get-ChildItem -Path $remotePath -Filter *.log -Recurse

            foreach ($logFile in $logFiles) {
                # Construct the destination file name with the hostname
                $newFileName = "$server`_$($logFile.Name)"

                # Define the local file path
                $localFilePath = Join-Path $localDirectory $newFileName

                # Copy the log file to the local directory with the new name
                Copy-Item -Path $logFile.FullName -Destination $localFilePath

                Write-Host "Copied $($logFile.Name) from $server to $localFilePath"
            }
        } else {
            Write-Host "Directory $remoteDirectory not found on $server"
        }
    } else {
        Write-Host "Failed to connect to $server"
    }
}

Write-Host "Log file copy operation completed."
