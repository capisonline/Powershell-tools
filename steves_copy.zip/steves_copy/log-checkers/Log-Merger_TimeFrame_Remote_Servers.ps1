﻿# Define variables 
$serverListFile = "C:\temp\QCAD\PR\PR_Issue\10-1-25\copied_logs\findings\serverlist.txt" # Path to the text file containing the list of servers
$remoteLogDirectory = "C$\temp\QCAD\PR\PR_Issue\10-1-25\copied_logs" # Directory on each server where log files are stored
$localLogDirectory = "C:\temp\QCAD\PR\PR_Issue\10-1-25\copied_logs\findings\merged" # Local directory to save the merged log file

# Define start and end date/time in the format "yyyy-MM-dd HH:mm:ss"
$startTime = [datetime]::ParseExact("2025-01-10 06:30:00", "yyyy-MM-dd HH:mm:ss", $null)
$endTime = [datetime]::ParseExact("2025-01-10 06:59:00", "yyyy-MM-dd HH:mm:ss", $null)

# Create local log directory if it doesn't exist
if (-Not (Test-Path -Path $localLogDirectory)) {
    New-Item -ItemType Directory -Path $localLogDirectory
}

# Define the path for the merged log file
$mergedLogFile = Join-Path -Path $localLogDirectory -ChildPath "merged_logs_CCM-Failed-4.txt"

# Clear the merged log file if it already exists
if (Test-Path -Path $mergedLogFile) {
    Clear-Content -Path $mergedLogFile
}

# Read server list from the text file
$servers = Get-Content -Path $serverListFile

# Function to get log entries from a remote server
function Get-LogEntriesFromServer {
    param (
        [string]$server, # Server name
        [string]$remoteLogDirectory, # Log directory on the server
        [datetime]$startTime, # Start time of the timeframe
        [datetime]$endTime # End time of the timeframe
    )

    Write-Output "Getting log files from server: $server"

    try {
        # Construct the UNC path to the log directory
        $remotePath = "\\$server\$remoteLogDirectory"
        Write-Output "Accessing remote path: $remotePath"
        
        # Get all items from the remote server's log directory recursively
        $remoteItems = Get-ChildItem -Path $remotePath -Recurse -ErrorAction Stop
        Write-Output "Found $($remoteItems.Count) items in remote directory: $remotePath"
        
        # Filter only log files
        $remoteLogFiles = $remoteItems | Where-Object { $_.Name -like "*.log*" }
        Write-Output "Filtered $($remoteLogFiles.Count) log files in remote directory: $remotePath"
    }
    catch {
        Write-Output "Failed to access server: $server"
        Write-Output $_.Exception.Message
        return
    }
    
    foreach ($logFile in $remoteLogFiles) {
        Write-Output "Reading log file: $($logFile.FullName)"
        try {
            # Read the content of each log file
            $fileContent = Get-Content -Path $logFile.FullName -ErrorAction Stop
            Write-Output "Read $($fileContent.Count) lines from log file: $($logFile.FullName)"
        }
        catch {
            Write-Output "Failed to read log file: $($logFile.FullName)"
            Write-Output $_.Exception.Message
            continue
        }
        
        foreach ($line in $fileContent) {
            # Check if line matches timestamp pattern
            if ($line -match "^(?<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})") {
                $timestamp = [datetime]::ParseExact($matches['timestamp'], "yyyy-MM-dd HH:mm:ss,fff", $null)
                if ($timestamp -ge $startTime -and $timestamp -le $endTime) {
                    # Append the matching log line with the source UNC path to the merged log file
                    $logEntryWithSource = "$($logFile.FullName): $line"
                    Add-Content -Path $mergedLogFile -Value $logEntryWithSource
                }
            }
        }
    }
}

# Process each server listed in the servers.txt file
foreach ($server in $servers) {
    Write-Output "Processing logs from server: $server"
    Get-LogEntriesFromServer -server $server -remoteLogDirectory $remoteLogDirectory -startTime $startTime -endTime $endTime
}

Write-Output "Merged log entries saved to $mergedLogFile"
