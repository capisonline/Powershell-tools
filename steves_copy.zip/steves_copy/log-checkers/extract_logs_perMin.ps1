﻿<# 
.SYNOPSIS
    This script retrieves log files from multiple remote servers, extracts log entries based on timestamps,
    and sorts them into separate minute-based files.

.DESCRIPTION
    - Reads a list of servers from a text file.
    - Connects to each server and scans log files in a specified directory.
    - Extracts log entries within a defined timeframe (start time to end time).
    - Groups log entries by minute and saves them into separate files (one per minute).
    - Ensures log entries from different files and servers are correctly appended to their corresponding
      minute-based file.

.PARAMETER serverListFile
    The path to the text file containing the list of servers.

.PARAMETER remoteLogDirectory
    The UNC path to the directory where logs are stored on each remote server.

.PARAMETER localLogDirectory
    The local directory where sorted logs will be saved.

.PARAMETER startTime
    The start of the timeframe for filtering log entries.

.PARAMETER endTime
    The end of the timeframe for filtering log entries.

.OUTPUTS
    - A set of log files in the format `log_yyyy-MM-dd_HH-mm.txt`
    - Each file contains all log entries for a specific minute from all servers.

.NOTES
    - The script reads logs from multiple servers.
    - It appends log entries to the correct minute-based file.
    - Requires access to remote servers and appropriate permissions.

.EXAMPLE
    .\ExtractLogsByMinute.ps1
    This command executes the script, retrieving logs from all servers listed in the input file,
    filtering based on timestamp, and saving them into minute-based log files.

#>

# Define variables
$serverListFile = "C:\temp\QCAD\VT\Fail_Testing\POL_Failover_List_Servers.txt" # Path to the text file containing the list of servers
$remoteLogDirectory = "E$\Vision" # Directory on each server where log files are stored
$localLogDirectory = "C:\temp\QCAD\VT\Fail_Testing\POL_DC_Results" # Local directory to save the minute-separated log files

# Define start and end date/time in the format "yyyy-MM-dd HH:mm:ss"
$startTime = [datetime]::ParseExact("2025-07-04 09:00:00", "yyyy-MM-dd HH:mm:ss", $null)
$endTime = [datetime]::ParseExact("2025-07-04 15:00:59", "yyyy-MM-dd HH:mm:ss", $null)

# Create local log directory if it doesn't exist
if (-Not (Test-Path -Path $localLogDirectory)) {
    New-Item -ItemType Directory -Path $localLogDirectory
}

# Read server list from the text file
$servers = Get-Content -Path $serverListFile

# Function to get log entries from a remote server and split by minute
function Get-LogEntriesFromServer {
    param (
        [string]$server, # Server name
        [string]$remoteLogDirectory, # Log directory on the server
        [datetime]$startTime, # Start time of the timeframe
        [datetime]$endTime # End time of the timeframe
    )

    Write-Output "Getting log files from server: $server"

    try {
        # Construct the UNC path to the log directory
        $remotePath = "\\$server\$remoteLogDirectory"
        Write-Output "Accessing remote path: $remotePath"

        # Get all items from the remote server's log directory recursively
        $remoteItems = Get-ChildItem -Path $remotePath -Recurse -ErrorAction Stop
        Write-Output "Found $($remoteItems.Count) items in remote directory: $remotePath"

        # Filter only log files
        $remoteLogFiles = $remoteItems | Where-Object { $_.Name -like "*.log*" }
        Write-Output "Filtered $($remoteLogFiles.Count) log files in remote directory: $remotePath"
    }
    catch {
        Write-Output "Failed to access server: $server"
        Write-Output $_.Exception.Message
        return
    }

    foreach ($logFile in $remoteLogFiles) {
        Write-Output "Reading log file: $($logFile.FullName)"

        try {
            # Read the content of each log file
            $fileContent = Get-Content -Path $logFile.FullName -ErrorAction Stop
            Write-Output "Read $($fileContent.Count) lines from log file: $($logFile.FullName)"
        }
        catch {
            Write-Output "Failed to read log file: $($logFile.FullName)"
            Write-Output $_.Exception.Message
            continue
        }

        foreach ($line in $fileContent) {
            # Check if line matches timestamp pattern
            if ($line -match "^(?<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})") {
                $timestamp = [datetime]::ParseExact($matches['timestamp'], "yyyy-MM-dd HH:mm:ss,fff", $null)

                # Process only entries within the specified timeframe
                if ($timestamp -ge $startTime -and $timestamp -le $endTime) {
                    # Determine the minute-based filename based on the timestamp
                    $minuteFileName = "log_$($timestamp.ToString('yyyy-MM-dd_HH-mm')).txt"
                    $minuteFilePath = Join-Path -Path $localLogDirectory -ChildPath $minuteFileName

                    # Append the matching log line with the source UNC path to the corresponding minute file
                    $logEntryWithSource = "$($logFile.FullName): $line"
                    Add-Content -Path $minuteFilePath -Value $logEntryWithSource
                }
            }
        }
    }
}

# Process each server listed in the server list file
foreach ($server in $servers) {
    Write-Output "Processing logs from server: $server"
    Get-LogEntriesFromServer -server $server -remoteLogDirectory $remoteLogDirectory -startTime $startTime -endTime $endTime
}

Write-Output "Log entries have been split by minute and saved to $localLogDirectory"
