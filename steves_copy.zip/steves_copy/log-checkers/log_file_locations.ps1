﻿# Path to the input text file containing the list of remote servers 
$serversFilePath = "C:\temp\QCAD\VT\VT_Old_Servers.txt"

# Path to the output CSV file
$outputCsvPath = "C:\temp\QCAD\VT\Error_Logs\VT_LogFile_location_Details.csv"

# Read the list of server names
$servers = Get-Content -Path $serversFilePath

# Initialize an array to hold the log file details
$logFileDetails = @()

# Function to search for log files on a remote server
function Search-LogFiles {
    param (
        [string]$server
    )

    $logFiles = Invoke-Command -ComputerName $server -ScriptBlock {
        Get-ChildItem -Path "E$\*" -Recurse -Filter "*.log" -ErrorAction SilentlyContinue | Select-Object FullName, LastWriteTime
    }

    return $logFiles
}

# Iterate through each server and search for log files
foreach ($server in $servers) {
    $logFiles = Search-LogFiles -server $server
    foreach ($file in $logFiles) {
        $details = [PSCustomObject]@{
            ServerName   = $server
            FilePath     = $file.FullName
            LastWriteTime = $file.LastWriteTime
        }
        $logFileDetails.Add($details)
    }
}

# Export the details to a CSV file
$logFileDetails | Export-Csv -Path $outputCsvPath -NoTypeInformation -Append

# Output the results
Write-Output "Log file details have been saved to $outputCsvPath"
